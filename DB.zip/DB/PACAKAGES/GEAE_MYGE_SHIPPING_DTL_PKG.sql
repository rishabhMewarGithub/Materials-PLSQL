

GEAE_MYGE_SHIPPING_DTL_PKG

create or replace PACKAGE BODY GEAE_MYGE_SHIPPING_DTL_PKG
AS

--------Change Log-------------------------------------
/*
Date          Changed By         Description
21-OCT-2014   Ravi Saxena        MYJIRATEST-3565 Add UPQ to LINE_DETAILS
28-OCT-2014   Ravi Saxena        MYJIRATEST-4044 Line proc to not show cancelled shipment detail lines, fetch delivery level details seperately, aggregation of COO and shipping_status to be done by requested_quantity
28-OCT-2014   Ravi Saxena        MYJIRATEST-3565 Add logic for Shipment Dispute allowed
29-OCT-2014   Ravi Saxena        MYJIRATEST-4026 Add Invoice_id in hdr and line procedures
29-OCT-2014   Ravi Saxena        MYJIRATEST-3992 Add Qty Update allowed flag to line procedure
30-OCT-2014   Ravi Saxena        MYJIRATEST-3217 Add AWB Link and correct AWB to BOL
05-NOV-2014   Ravi Saxena        MYJIRATEST-4208 Column group sort order, Order Status
14-NOV-2014   Ravi Saxena        MYJIRATEST-4432 Round Discount percentage to 2 decimals
19-NOV-2014   Ravi Saxena        MYJIRATEST-4569 For Kits, cancel update allowed flag will depend on the Kit components being downloaded to WMS
20-NOV-2014   Ravi Saxena        MYJIRATEST-4579 Do not allow to create dispute for returns
24-NOV-2014   Ravi Saxena        MYJIRATEST-4206 Club addresses
09-JAN-2015   Ravi Saxena        MYJIRATEST-4813 Add procedure for Invoice Document return
09-JAN-2015   Ravi Saxena        MYJIRATEST-5080 Add Total Order Value and Total discount value and enable ship and deliver to addresses in order search in GET_HDR_INFO
27-JAN-2015   Ravi Saxena        MYJIRATEST-4668 Order Line status revamp
29-JAN-2015   Ravi Saxena        MYJIRATEST-5333 Optimized for Invoices which are not result of Order Entry (like Warranty)
27-APR-2015   Ankita Shetty      MYJIRATEST-7194 To change the output file name to <Invoice_number>.pdf
03-JUN-2015   Ankita Shetty      MYJIRATEST-8445 Changed the condition for fetching Credit Invoive details in get_line_info
26-OCT-2015   Neelima Y          MYJIRATEST-11342 Created new lookup to add new order types
07-JAN-2016   Trupti D.          MYJIRATEST-12410 Added mappings for ship_status
20-JAN-2016   Neelima Y.         MYJIRATEST-10594 Added array P_MYGEA_GRP_INFO_ARRAY
18-FEB-2016   Trupti D.          MYJIRATEST-7809  Return SSO for created by and last updated by in Get_line_info
31-MAR-2016   Trupti D.          MYJIRATEST-3745 added logic to check shipment dispute created or not for an order line
31-MAY-2016   R Prasad           MYJIRATEST-6441 Added new procedure GET_ORDER_AUDIT_HISTORY_PRC to display history details at UI side
25-OCT-2016   R Prasad           US13541- Added function to hold critical part flag
02-Apr-2018   Gourab S           DE14766 - Changed the condition for Display in Order Details in get_line_info.
28-Nov-2018   Manisha K          US224681: Passport:Materials:Passport customers should be able to View Passport Order Header details
28-Nov-2018   Manisha K          US225607: Passport:Materials:Passport customers should be able to View Passport Order Line details
15-Feb-2019   Manisha K          Rewrote the code for wsp_date and qty to resolve the issue of skipping over null values of workstop date echo KSC_EXIT_STATUS $? 1 qty
05-Mar-2019   Manisha K          Modified the below code for ESN ,as it was fetchin wrong data in case of ESN as null and workstop qty/date is present
11-MAR-2019   Das, Debopam       US225986 - Suppression Of KIT Component For GE Aero OU In Aero Portal
23-Apr-2019   Manisha K          Modified the get_line_info proc to fix DE44340: Invalid ESN blocks PO to be displayed
*/

PROCEDURE GET_HDR_INFO(
    P_SSO       VARCHAR2,
    P_IACO_CODE VARCHAR2,
    P_CUST_ID V_CUST_ID_ARRAY,
    P_ROLE    VARCHAR2,
    P_OU_ID   VARCHAR2,
    P_MS_NUMBER VARCHAR2,
    P_DELIVERY_ID VARCHAR2,
    P_ORDER_ID VARCHAR2,
    P_INVOICE_ID VARCHAR2,
    P_ORDER_HDR_INFO_ARRAY OUT V_ORDER_HDR_INFO_ARRAY,
    P_COLUMN_GRP_INFO_ARRAY OUT V_COLUMN_GRP_INFO_ARRAY,
    P_MYGEA_GRP_INFO_ARRAY OUT V_MYGEA_GRP_INFO_ARRAY,        -- MYJIRATEST-10594   GEAE_MYGE_NEW_COLUMN_GRP NEELima Y.
    P_COLUMN_INFO_ARRAY OUT V_COLUMN_INFO_ARRAY,
    P_MSG OUT VARCHAR2)
AS
   --
   v_loc_msg            VARCHAR2(500);
   v_param_count        NUMBER;
   v_delivery_id        NUMBER;
   v_order_id           NUMBER;
   v_invoice_id         NUMBER;
   v_ou_id              NUMBER;
   v_loop_cnt           NUMBER;
   v_loop_myge_cnt      NUMBER;                              -- MYJIRATEST-10594 NEELima Y.
   v_clm_string         VARCHAR2(4000);
   v_clm_myge_string    VARCHAR2(4000);                      -- MYJIRATEST-10594 NEELima Y.
  -- l_ord_hdr_info        V_ORDER_HDR_INFO_ARRAY := V_ORDER_HDR_INFO_ARRAY();
  -- l_clm_grp_info        V_COLUMN_GRP_INFO_ARRAY := V_COLUMN_GRP_INFO_ARRAY();
   l_clm_info            V_COLUMN_INFO_ARRAY := V_COLUMN_INFO_ARRAY();
   v_search_type        VARCHAR2(100);
   v_search_mygea_type  VARCHAR2(100);                        -- MYJIRATEST-10594 NEELima Y.

   v_ship_location      VARCHAR2(500);
   v_ship_address1      VARCHAR2(500);
   v_ship_address2      VARCHAR2(500);
   v_ship_address3      VARCHAR2(500);
   v_ship_address4      VARCHAR2(500);
   v_ship_address5      VARCHAR2(500);
   v_ship_address       VARCHAR2(2500);
   v_deliver_location   VARCHAR2(500);
   v_deliver_address1   VARCHAR2(500);
   v_deliver_address2   VARCHAR2(500);
   v_deliver_address3   VARCHAR2(500);
   v_deliver_address4   VARCHAR2(500);
   v_deliver_address5   VARCHAR2(500);
   v_deliver_address    VARCHAR2(2500);
   v_bill_location      VARCHAR2(500);
   v_bill_address1      VARCHAR2(500);
   v_bill_address2      VARCHAR2(500);
   v_bill_address3      VARCHAR2(500);
   v_bill_address4      VARCHAR2(500);
   v_bill_address5      VARCHAR2(500);
   v_bill_address       VARCHAR2(2500);

   --MYJIRATEST-5080 Ravi S 09-JAN-2015
   v_booked_flag        VARCHAR2(1);
   v_order_value        NUMBER;
   v_disc_value         NUMBER;

   v_authorized         VARCHAR2(1);
   v_cust_id            NUMBER;
   v_dispute_order      VARCHAR2(1);

   e_exit               EXCEPTION;
   e_clm_missing        EXCEPTION;


   CURSOR C_ORD(P_ORDER_ID NUMBER, P_OU_ID NUMBER) IS
      SELECT NULL invoice_number, NULL invoice_date, NULL customer_trx_id, NULL invoice_amount,
             NULL organization_code, NULL ship_date, ac.customer_name, ac.customer_number, ooh.ordered_date,
             ottt.description order_type, NVL(GET_CLOSED_LINE_STATUS(P_ORDER_ID,P_OU_ID),flv.description) order_status, ooh.cust_po_number, ooh.attribute1 supplier_code,
             ooh.header_id order_id, NULL bill_of_lading, NULL awb_number, ooh.ship_to_org_id,
             ooh.deliver_to_org_id, ooh.invoice_to_org_id, NULL ms_number, ac.customer_id, NULL invoice_id, NULL awb_link
        FROM oe_order_headers_all ooh, oe_transaction_types_tl ottt, fnd_lookup_values flv, ar_customers ac
       WHERE ooh.org_id = P_OU_ID
         AND ooh.order_type_id = ottt.transaction_type_id
         AND ooh.flow_status_code = flv.lookup_code
         AND flv.lookup_type = 'FLOW_STATUS'
         AND ooh.sold_to_org_id = ac.customer_id
         AND ooh.header_id = P_ORDER_ID;

   CURSOR C_SHP_MS(P_DELIVERY_ID NUMBER, P_MS_NUMBER VARCHAR2, P_OU_ID NUMBER) IS
      SELECT NULL invoice_number, NULL invoice_date, NULL customer_trx_id, NULL invoice_amount,
             mtp.organization_code, wnd.confirm_date ship_date, ac.customer_name, ac.customer_number, NULL ordered_date,
             NULL order_type, NULL order_status, NULL cust_po_number, NULL supplier_code,
             NULL order_id, wnd.attribute5 bill_of_lading, wnd.attribute5||' ('||NVL(substr(wnd.ship_method_code,instr(wnd.ship_method_code,'_',1,1)+1,instr(wnd.ship_method_code,'_',1,2)-INSTR(wnd.ship_method_code,'_',1,1)-1),NULL)||')' awb_number,
             wdd.ship_to_site_use_id ship_to_org_id,
             wdd.deliver_to_site_use_id deliver_to_org_id, NULL invoice_to_org_id, wdd.attribute3 ms_number, ac.customer_id,
             NULL invoice_id, GET_TRACKING_URL(wnd.ship_method_code,wnd.attribute5) awb_link
        FROM wsh_delivery_details wdd, wsh_delivery_assignments wda, wsh_new_deliveries wnd, ar_customers ac, mtl_parameters mtp
       WHERE wdd.org_id = P_OU_ID
         AND wdd.delivery_detail_id = wda.delivery_detail_id
         AND wnd.delivery_id = wda.delivery_id
         AND wdd.customer_id = ac.customer_id
         AND mtp.organization_id = wdd.organization_id
         AND wda.delivery_id = P_DELIVERY_ID
         AND wdd.attribute3 = P_MS_NUMBER
      GROUP BY mtp.organization_code, wnd.confirm_date, ac.customer_name, ac.customer_number, wnd.attribute5, wnd.ship_method_code,
               wdd.ship_to_site_use_id, wdd.deliver_to_site_use_id, wdd.attribute3, ac.customer_id;

   CURSOR C_SHP(P_DELIVERY_ID NUMBER, P_OU_ID NUMBER) IS
      SELECT NULL invoice_number, NULL invoice_date, NULL customer_trx_id, NULL invoice_amount,
             mtp.organization_code, wnd.confirm_date ship_date, ac.customer_name, ac.customer_number, NULL ordered_date,
             NULL order_type, NULL order_status, NULL cust_po_number, NULL supplier_code,
             NULL order_id, wnd.attribute5 bill_of_lading, wnd.attribute5||' ('||NVL(substr(wnd.ship_method_code,instr(wnd.ship_method_code,'_',1,1)+1,instr(wnd.ship_method_code,'_',1,2)-INSTR(wnd.ship_method_code,'_',1,1)-1),NULL)||')' awb_number, wdd.ship_to_site_use_id ship_to_org_id,
             wdd.deliver_to_site_use_id deliver_to_org_id, NULL invoice_to_org_id, NULL ms_number, ac.customer_id,
             NULL invoice_id, GET_TRACKING_URL(wnd.ship_method_code,wnd.attribute5) awb_link
        FROM wsh_delivery_details wdd, wsh_delivery_assignments wda, wsh_new_deliveries wnd, ar_customers ac, mtl_parameters mtp
       WHERE wdd.org_id = P_OU_ID
         AND wdd.delivery_detail_id = wda.delivery_detail_id
         AND wnd.delivery_id = wda.delivery_id
         AND wdd.customer_id = ac.customer_id
         AND mtp.organization_id = wdd.organization_id
         AND wda.delivery_id = P_DELIVERY_ID
         AND wdd.attribute3 IS NULL
      GROUP BY mtp.organization_code, wnd.confirm_date, ac.customer_name, ac.customer_number, wnd.attribute5, wnd.ship_method_code,
               wdd.ship_to_site_use_id, wdd.deliver_to_site_use_id, ac.customer_id;

   CURSOR C_INV(P_INVOICE_ID NUMBER, P_OU_ID NUMBER) IS
      SELECT rct.trx_number invoice_number, rct.trx_date invoice_date, rct.customer_trx_id, SUM(rctl.extended_amount) invoice_amount,
             NULL organization_code, NULL ship_date, ac.customer_name, ac.customer_number, NULL ordered_date,
             NULL order_type, NULL order_status, NULL cust_po_number, NULL supplier_code,
             NULL order_id, NULL bill_of_lading, NULL awb_number, NULL ship_to_org_id,
             NULL deliver_to_org_id, rct.bill_to_site_use_id invoice_to_org_id, NULL ms_number, ac.customer_id,
             rct.customer_trx_id invoice_id, NULL awb_link
        FROM ar_customers ac, ra_customer_trx_lines_all rctl, ra_customer_trx_all rct
       WHERE rct.org_id = P_OU_ID
         AND rct.sold_to_customer_id = ac.customer_id(+)
         AND rct.customer_trx_id = rctl.customer_trx_id
         AND rctl.line_type = 'LINE'
         --AND rctl.interface_line_context = 'ORDER ENTRY'  --MYJIRATEST-5333 Ravi S 29-JAN-2015
         AND rct.customer_trx_id = P_INVOICE_ID
      GROUP BY rct.trx_number, rct.trx_date, rct.customer_trx_id, ac.customer_name, ac.customer_number,
               rct.bill_to_site_use_id, ac.customer_id;

   CURSOR C_GRP(P_SEARCH_TYPE VARCHAR2) IS
      SELECT DISTINCT SUBSTR(description,INSTR(description,'~')+1) group_name,
             TO_NUMBER(SUBSTR(description,1,INSTR(description,'~')-1)) sort_order,
             description complete_group_name
        FROM fnd_lookup_values
       WHERE lookup_type = P_SEARCH_TYPE
         AND description IS NOT NULL
         AND SUBSTR(description,1,1) <> '~'
         AND enabled_flag = 'Y'
         AND TRUNC(SYSDATE) BETWEEN NVL(start_date_active,TRUNC(SYSDATE)) AND NVL(end_date_active,SYSDATE)
      ORDER BY TO_NUMBER(SUBSTR(description,1,INSTR(description,'~')-1));

   CURSOR C_CLM_GRP(P_SEARCH_TYPE VARCHAR2, P_GROUP_NAME VARCHAR2) IS
      SELECT tag column_id
        FROM fnd_lookup_values
       WHERE lookup_type = P_SEARCH_TYPE
         AND description = P_GROUP_NAME
         AND enabled_flag = 'Y'
         AND TRUNC(SYSDATE) BETWEEN NVL(start_date_active,TRUNC(SYSDATE)) AND NVL(end_date_active,SYSDATE)
      ORDER BY TO_NUMBER(lookup_code);

BEGIN

--
   v_loc_msg := 'Initializing Out Parameters';
   P_ORDER_HDR_INFO_ARRAY  := V_ORDER_HDR_INFO_ARRAY();
   P_COLUMN_GRP_INFO_ARRAY := V_COLUMN_GRP_INFO_ARRAY();
   P_MYGEA_GRP_INFO_ARRAY := V_MYGEA_GRP_INFO_ARRAY();            -- MYJIRATEST-10594 NEELima Y.
   P_COLUMN_INFO_ARRAY := V_COLUMN_INFO_ARRAY();

   v_loc_msg := 'Checking input parameters';
   v_param_count := 0;
   IF P_DELIVERY_ID IS NOT NULL THEN
      v_param_count := v_param_count + 1;
   END IF;
   IF P_ORDER_ID IS NOT NULL THEN
      v_param_count := v_param_count + 1;
   END IF;
   IF P_INVOICE_ID IS NOT NULL THEN
      v_param_count := v_param_count + 1;
   END IF;
   IF v_param_count <> 1 THEN
      P_MSG := GET_ERR_MSG(8029);
      RAISE e_exit;
   END IF;
   IF P_OU_ID IS NULL THEN
      P_MSG := GET_ERR_MSG(8029);
      RAISE e_exit;
   END IF;
  -- v_ou_id := TO_NUMBER(P_OU_ID);  --US224681; Manisha K, 11-OCT Commented the line as the OU_ID will be fetched according order_id, or invoice or delivery_id
   IF P_ORDER_ID IS NOT NULL THEN
      v_loc_msg := 'Getting details based on order_id';
      v_order_id := TO_NUMBER(P_ORDER_ID);
      v_authorized := 'N';


/**********************************************************
US224681; Manisha K, 10-OCT Added the below code for Passport Requirement
If user have access for both OU ID's ,then the OU_ID will be fetched based on the order_id
***********************************************************/
   v_loc_msg := 'Fetching OU_ID Value';
/*****************************************
14-March-2019- Manisha commenting the below if else condition
to fix the issue to see old CSO orders if customer is switched from cso to passport
*****************************************/
   -- IF P_OU_ID like '%~%' THEN
      BEGIN
      SELECT org_Id
      INTO v_OU_ID FROM oe_order_headers_all
      WHERE HEADER_ID =v_order_id;
      EXCEPTION
      WHEN OTHERS THEN
      P_MSG := 'Error while fetching the OU_ID: '||SQLCODE||SQLERRM;
      RAISE e_exit;
      END;
--  ELSE
--     v_ou_id := TO_NUMBER(P_OU_ID);
--  END IF;

  IF v_ou_id IS NULL THEN
        p_MSG:=GET_ERR_MSG(8503);
        RAISE e_exit;
    END IF;


      BEGIN
         SELECT sold_to_org_id, booked_flag
           INTO v_cust_id, v_booked_flag
           FROM oe_order_headers_all
          WHERE header_id = v_order_id;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            P_MSG:=GET_ERR_MSG(8010);
            RAISE e_exit;
      END;
      IF P_ROLE = 'Global Enquiry' THEN
         v_authorized := 'Y';
      ELSE
         FOR i IN 1..P_CUST_ID.COUNT LOOP
            IF P_CUST_ID(i) = v_cust_id THEN
               v_authorized := 'Y';
            END IF;
         END LOOP;
      END IF;
      IF v_authorized = 'N' THEN
         P_MSG:=GET_ERR_MSG(8180);
         RAISE e_exit;
      END IF;
      BEGIN
         SELECT 'Y'
           INTO v_dispute_order
           FROM oe_order_headers_all ooh, fnd_lookup_values flv
          WHERE flv.lookup_type = 'GEAE_MYGE_DISPUTE_ORDER_TYPES'
            AND ooh.order_type_id = flv.tag
            AND ooh.header_id = v_order_id;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            v_dispute_order := 'N';
      END;
      --MYJIRATEST-5080 Ravi S 09-JAN-2015
      IF v_booked_flag = 'Y' THEN
         BEGIN
            SELECT SUM(unit_selling_price*ordered_quantity*DECODE(line_category_code,'RETURN',-1,1)), SUM((unit_list_price - unit_selling_price)*ordered_quantity)
              INTO v_order_value, v_disc_value
              FROM oe_order_lines_all
             WHERE header_id = v_order_id;
         EXCEPTION
            WHEN OTHERS THEN
               v_order_value := NULL;
               v_disc_value := NULL;
         END;
      ELSE
         v_order_value := NULL;
         v_disc_value := NULL;
      END IF;
      v_loop_cnt := 0;
      FOR r_ord IN C_ORD(v_order_id, v_ou_id) LOOP
         v_loop_cnt := v_loop_cnt+1;
         GET_ADDRESS_DETAILS(r_ord.ship_to_org_id,v_ship_location,v_ship_address1,v_ship_address2,v_ship_address3,v_ship_address4,v_ship_address5,v_ship_address);
         GET_ADDRESS_DETAILS(r_ord.deliver_to_org_id,v_deliver_location,v_deliver_address1,v_deliver_address2,v_deliver_address3,v_deliver_address4,v_deliver_address5,v_deliver_address);
         GET_ADDRESS_DETAILS(r_ord.invoice_to_org_id,v_bill_location,v_bill_address1,v_bill_address2,v_bill_address3,v_bill_address4,v_bill_address5,v_bill_address); --uncommented by Prasad on 07-JUL-2016
         P_ORDER_HDR_INFO_ARRAY.EXTEND;
         P_ORDER_HDR_INFO_ARRAY(P_ORDER_HDR_INFO_ARRAY.last):=
         V_ORDER_HDR_INFO_BO(r_ord.ms_number,r_ord.organization_code,
                                v_ship_location,v_ship_address1,v_ship_address2,v_ship_address3,v_ship_address4,v_ship_address5,
                                v_deliver_location,v_deliver_address1,v_deliver_address2,v_deliver_address3,v_deliver_address4,v_deliver_address5,
                                r_ord.awb_number,r_ord.invoice_number,r_ord.invoice_date,NULL --inv_link
                               ,r_ord.invoice_amount, r_ord.customer_number, r_ord.customer_name, r_ord.ordered_date,
                                r_ord.order_type, r_ord.order_status, r_ord.cust_po_number, r_ord.supplier_code,
                                r_ord.ship_date, r_ord.bill_of_lading, r_ord.organization_code,
                                v_bill_location,v_bill_address1,v_bill_address2,v_bill_address3,v_bill_address4,v_bill_address5,
                                r_ord.customer_id,v_dispute_order,r_ord.invoice_id,r_ord.awb_link,v_order_value,v_disc_value);
      END LOOP;
      IF v_loop_cnt = 0 THEN
         P_MSG := GET_ERR_MSG(8031);
         RAISE e_exit;
      END IF;

      v_search_type := 'GEAE_MYGE_ORD_COLUMN_GRP';
   ELSIF P_DELIVERY_ID IS NOT NULL THEN
      v_delivery_id := TO_NUMBER(P_DELIVERY_ID);
      v_authorized := 'N';

/**********************************************************
US224681; Manisha K, 10-OCT Added the below code for Passport Requirement
If user have access for both OU ID's ,then the OU_ID will be fetched based on the delivery_id
***********************************************************/
    v_loc_msg := 'Fetching OU_ID Value';
/*****************************************
14-March-2019- Manisha commenting the below if else condition
to fix the issue to see old CSO orders if customer is switched from cso to passport
*****************************************/
   -- IF P_OU_ID like '%~%' THEN
      BEGIN
       SELECT  distinct wdd.org_id
       INTO v_OU_ID
        FROM wsh_delivery_details wdd, wsh_delivery_assignments wda --, wsh_new_deliveries wnd, ar_customers ac, mtl_parameters mtp
       WHERE 1=1 --wdd.org_id = P_OU_ID
         AND wdd.delivery_detail_id = wda.delivery_detail_id
         AND wda.delivery_id = v_delivery_id
         AND wdd.org_id is not null;   -- Manisha 12-Dec added this comment as more than one row was getting fetched including null value
      EXCEPTION
      WHEN OTHERS THEN
      P_MSG := 'Error while fetching the OU_ID for delivery ID: '||SQLCODE||SQLERRM;
      RAISE e_exit;
      END;
--  ELSE
--     v_ou_id := TO_NUMBER(P_OU_ID);
--  END IF;

  IF v_ou_id IS NULL THEN
        p_MSG:=GET_ERR_MSG(8503);
        RAISE e_exit;
    END IF;

      BEGIN
         SELECT wdd.customer_id
           INTO v_cust_id
           FROM wsh_delivery_assignments wda, wsh_delivery_details wdd
          WHERE wda.delivery_detail_id = wdd.delivery_detail_id
            AND wda.delivery_id = v_delivery_id
            AND rownum = 1;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            P_MSG:=GET_ERR_MSG(8029);
            RAISE e_exit;
      END;
      IF P_ROLE = 'Global Enquiry' THEN
         v_authorized := 'Y';
      ELSE
         FOR i IN 1..P_CUST_ID.COUNT LOOP
            IF P_CUST_ID(i) = v_cust_id THEN
               v_authorized := 'Y';
            END IF;
         END LOOP;
      END IF;
      IF v_authorized = 'N' THEN
         P_MSG:=GET_ERR_MSG(8180);
         RAISE e_exit;
      END IF;
      IF P_MS_NUMBER IS NOT NULL THEN
         v_loc_msg := 'Getting details based on delivery_id and ms number';
         v_loop_cnt := 0;
         FOR r_shp_ms IN C_SHP_MS(v_delivery_id, P_MS_NUMBER, v_ou_id) LOOP
            v_loop_cnt := v_loop_cnt+1;
            GET_ADDRESS_DETAILS(r_shp_ms.ship_to_org_id,v_ship_location,v_ship_address1,v_ship_address2,v_ship_address3,v_ship_address4,v_ship_address5,v_ship_address);
            GET_ADDRESS_DETAILS(r_shp_ms.deliver_to_org_id,v_deliver_location,v_deliver_address1,v_deliver_address2,v_deliver_address3,v_deliver_address4,v_deliver_address5,v_deliver_address);
            GET_ADDRESS_DETAILS(r_shp_ms.invoice_to_org_id,v_bill_location,v_bill_address1,v_bill_address2,v_bill_address3,v_bill_address4,v_bill_address5,v_bill_address); --uncommented by Prasad on 07-JUL-2016

            P_ORDER_HDR_INFO_ARRAY.EXTEND;
            P_ORDER_HDR_INFO_ARRAY(P_ORDER_HDR_INFO_ARRAY.last):=
            V_ORDER_HDR_INFO_BO(r_shp_ms.ms_number,r_shp_ms.organization_code,
                                   v_ship_location,v_ship_address1,v_ship_address2,v_ship_address3,v_ship_address4,v_ship_address5,
                                   v_deliver_location,v_deliver_address1,v_deliver_address2,v_deliver_address3,v_deliver_address4,v_deliver_address5,
                                   r_shp_ms.awb_number,r_shp_ms.invoice_number,r_shp_ms.invoice_date,NULL --inv_link
                                  ,r_shp_ms.invoice_amount, r_shp_ms.customer_number, r_shp_ms.customer_name, r_shp_ms.ordered_date,
                                   r_shp_ms.order_type, r_shp_ms.order_status, r_shp_ms.cust_po_number, r_shp_ms.supplier_code,
                                   r_shp_ms.ship_date, r_shp_ms.bill_of_lading, r_shp_ms.organization_code,
                                   v_bill_location,v_bill_address1,v_bill_address2,v_bill_address3,v_bill_address4,v_bill_address5,
                                   r_shp_ms.customer_id,NULL,r_shp_ms.invoice_id,r_shp_ms.awb_link,NULL,NULL);
         END LOOP;
         IF v_loop_cnt = 0 THEN
            P_MSG := GET_ERR_MSG(8031);
            RAISE e_exit;
         END IF;
      ELSE
         v_loc_msg := 'Getting details based on delivery_id and ms number being null';
         v_loop_cnt := 0;
         FOR r_shp IN C_SHP(v_delivery_id, v_ou_id) LOOP
            v_loop_cnt := v_loop_cnt+1;
            GET_ADDRESS_DETAILS(r_shp.ship_to_org_id,v_ship_location,v_ship_address1,v_ship_address2,v_ship_address3,v_ship_address4,v_ship_address5,v_ship_address);
            GET_ADDRESS_DETAILS(r_shp.deliver_to_org_id,v_deliver_location,v_deliver_address1,v_deliver_address2,v_deliver_address3,v_deliver_address4,v_deliver_address5,v_deliver_address);
          --  GET_ADDRESS_DETAILS(r_shp.invoice_to_org_id,v_bill_location,v_bill_address1,v_bill_address2,v_bill_address3,v_bill_address4,v_bill_address5,v_bill_address); -- commented by Prasad on 07-JUL-2016

            P_ORDER_HDR_INFO_ARRAY.EXTEND;
            P_ORDER_HDR_INFO_ARRAY(P_ORDER_HDR_INFO_ARRAY.last):=
            V_ORDER_HDR_INFO_BO(r_shp.ms_number,r_shp.organization_code,
                                   v_ship_location,v_ship_address1,v_ship_address2,v_ship_address3,v_ship_address4,v_ship_address5,
                                   v_deliver_location,v_deliver_address1,v_deliver_address2,v_deliver_address3,v_deliver_address4,v_deliver_address5,
                                   r_shp.awb_number,r_shp.invoice_number,r_shp.invoice_date,NULL --inv_link
                                  ,r_shp.invoice_amount, r_shp.customer_number, r_shp.customer_name, r_shp.ordered_date,
                                   r_shp.order_type, r_shp.order_status, r_shp.cust_po_number, r_shp.supplier_code,
                                   r_shp.ship_date, r_shp.bill_of_lading, r_shp.organization_code,
                                   v_bill_location,v_bill_address1,v_bill_address2,v_bill_address3,v_bill_address4,v_bill_address5,
                                   r_shp.customer_id,NULL,r_shp.invoice_id,r_shp.awb_link,NULL,NULL);
         END LOOP;
         IF v_loop_cnt = 0 THEN
            P_MSG := GET_ERR_MSG(8031);
            RAISE e_exit;
         END IF;
      END IF;
      v_search_type := 'GEAE_MYGE_SHP_COLUMN_GRP';
   ELSIF P_INVOICE_ID IS NOT NULL THEN
      v_loc_msg := 'Getting details based on invoice_id';
      v_invoice_id := TO_NUMBER(P_INVOICE_ID);
      v_authorized := 'N';

 /**********************************************************
US224681;Manisha K, 10-OCT Added the below code for Passport Requirement
If user have access for both OU ID's ,then the OU_ID will be fetched based on the invoice_id
***********************************************************/

      v_loc_msg := 'Fetching OU_ID Value';
/*****************************************
14-March-2019- Manisha commenting the below if else condition
to fix the issue to see old CSO orders if customer is switched from cso to passport
*****************************************/
   --   IF P_OU_ID like '%~%' THEN
      BEGIN
       SELECT org_id
       into v_OU_ID
       FROM ra_customer_trx_all
       WHERE customer_trx_id = P_INVOICE_ID;
      EXCEPTION
      WHEN OTHERS THEN
      P_MSG := 'Error while fetching the OU_ID for invoice ID: '||SQLCODE||SQLERRM;
      RAISE e_exit;
      END;
--    ELSE
--     v_ou_id := TO_NUMBER(P_OU_ID);
--    END IF;

  IF v_ou_id IS NULL THEN
        p_MSG:=GET_ERR_MSG(8503);
        RAISE e_exit;
    END IF;


      BEGIN
         SELECT sold_to_customer_id
           INTO v_cust_id
           FROM ra_customer_trx_all
          WHERE customer_trx_id = v_invoice_id;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            P_MSG:=GET_ERR_MSG(8029);
            RAISE e_exit;
      END;
      IF P_ROLE = 'Global Enquiry' THEN
         v_authorized := 'Y';
      ELSE
         FOR i IN 1..P_CUST_ID.COUNT LOOP
            IF P_CUST_ID(i) = v_cust_id THEN
               v_authorized := 'Y';
            END IF;
         END LOOP;
      END IF;
      IF v_authorized = 'N' THEN
         P_MSG:=GET_ERR_MSG(8180);
         RAISE e_exit;
      END IF;
      v_loop_cnt := 0;
      FOR r_inv IN C_INV(v_invoice_id, v_ou_id) LOOP
         v_loop_cnt := v_loop_cnt+1;
        -- GET_ADDRESS_DETAILS(r_inv.ship_to_org_id,v_ship_location,v_ship_address1,v_ship_address2,v_ship_address3,v_ship_address4,v_ship_address5,v_ship_address); --commented by Prasad on 07-JUL-2016
        -- GET_ADDRESS_DETAILS(r_inv.deliver_to_org_id,v_deliver_location,v_deliver_address1,v_deliver_address2,v_deliver_address3,v_deliver_address4,v_deliver_address5,v_deliver_address); commented by Prasad on 07-JUL-2016
         GET_ADDRESS_DETAILS(r_inv.invoice_to_org_id,v_bill_location,v_bill_address1,v_bill_address2,v_bill_address3,v_bill_address4,v_bill_address5,v_bill_address);

         P_ORDER_HDR_INFO_ARRAY.EXTEND;
         P_ORDER_HDR_INFO_ARRAY(P_ORDER_HDR_INFO_ARRAY.last):=
         V_ORDER_HDR_INFO_BO(r_inv.ms_number,r_inv.organization_code,
                                v_ship_location,v_ship_address1,v_ship_address2,v_ship_address3,v_ship_address4,v_ship_address5,
                                v_deliver_location,v_deliver_address1,v_deliver_address2,v_deliver_address3,v_deliver_address4,v_deliver_address5,
                                r_inv.awb_number,r_inv.invoice_number,r_inv.invoice_date,NULL --inv_link
                               ,r_inv.invoice_amount, r_inv.customer_number, r_inv.customer_name, r_inv.ordered_date,
                                r_inv.order_type, r_inv.order_status, r_inv.cust_po_number, r_inv.supplier_code,
                                r_inv.ship_date, r_inv.bill_of_lading, r_inv.organization_code,
                                v_bill_location,v_bill_address1,v_bill_address2,v_bill_address3,v_bill_address4,v_bill_address5,
                                r_inv.customer_id,NULL,r_inv.invoice_id,r_inv.awb_link,NULL,NULL);
      END LOOP;
      IF v_loop_cnt = 0 THEN
         P_MSG := GET_ERR_MSG(8031);
         RAISE e_exit;
      END IF;
      v_search_type := 'GEAE_MYGE_INV_COLUMN_GRP';
   END IF;
   BEGIN
      v_loc_msg := 'Getting column details';
      SELECT V_COLUMN_INFO_BO
                     (lookup_code,
                     meaning)
         BULK COLLECT INTO l_clm_info
        FROM fnd_lookup_values
        WHERE lookup_type = 'GEAE_MYGE_OSI_COLUMN_INFO'
          AND enabled_flag = 'Y'
          AND TRUNC(SYSDATE) BETWEEN NVL(start_date_active,TRUNC(SYSDATE)) AND NVL(end_date_active,SYSDATE);

      IF SQL%ROWCOUNT  > 0 THEN
         FOR i in 1 .. l_clm_info.COUNT LOOP
            P_COLUMN_INFO_ARRAY.EXTEND;
            P_COLUMN_INFO_ARRAY(P_COLUMN_INFO_ARRAY.last) := l_clm_info(i);
         END LOOP;
      END IF;
      v_loop_cnt := 0;
      v_loop_myge_cnt := 0;                                    ------MYJIRATEST-10594 NEELima Y.
      v_loc_msg := 'Getting column group details';
      v_search_mygea_type := 'GEAE_MYGE_NEW_COLUMN_GRP';        -- MYJIRATEST-10594 NEELima Y.
      FOR r_grp IN C_GRP(v_search_type) LOOP
         v_clm_string := NULL;
         v_clm_myge_string := NULL;                            ----MYJIRATEST-10594 NEELima Y.
         FOR r_clm_grp IN C_CLM_GRP(v_search_type,r_grp.complete_group_name) LOOP
            v_loop_cnt := v_loop_cnt+1;
            v_clm_string := v_clm_string||r_clm_grp.column_id||'|';
         END LOOP;
         P_COLUMN_GRP_INFO_ARRAY.EXTEND;
         P_COLUMN_GRP_INFO_ARRAY(P_COLUMN_GRP_INFO_ARRAY.last):= V_COLUMN_GRP_INFO_BO(r_grp.group_name,v_clm_string);
         FOR r_clm_myge_grp IN C_CLM_GRP(v_search_mygea_type,r_grp.complete_group_name) LOOP  -- MYJIRATEST-10594 NEELima Y.
            v_loop_myge_cnt := v_loop_myge_cnt+1;
            v_clm_myge_string := v_clm_myge_string||r_clm_myge_grp.column_id||'|';
         END LOOP;
         IF v_clm_myge_string IS NOT NULL THEN
         P_MYGEA_GRP_INFO_ARRAY.EXTEND;
         P_MYGEA_GRP_INFO_ARRAY(P_MYGEA_GRP_INFO_ARRAY.last):= V_MYGEA_GRP_INFO_BO(r_grp.group_name,v_clm_myge_string);
         END IF;                                                                            -- MYJIRATEST-10594 NEELima Y.
      END LOOP;
      IF v_loop_cnt = 0 THEN
         RAISE e_clm_missing;
      END IF;
   EXCEPTION
      WHEN e_clm_missing THEN
         P_MSG := GET_ERR_MSG(8030);
         RAISE e_exit;
      WHEN OTHERS THEN
         P_MSG := GET_ERR_MSG(8030);
         RAISE e_exit;
   END;

EXCEPTION
   WHEN e_exit THEN
      NULL;
   WHEN OTHERS THEN
      P_MSG := '8000:Error while '||v_loc_msg||' '||SUBSTR(SQLERRM,1,100);
END GET_HDR_INFO;

PROCEDURE GET_LINE_INFO(
    P_SSO       VARCHAR2,
    P_IACO_CODE VARCHAR2,
    P_CUST_ID V_CUST_ID_ARRAY,
    P_ROLE    VARCHAR2,
    P_OU_ID   VARCHAR2,
    P_MS_NUMBER VARCHAR2,
    P_DELIVERY_ID VARCHAR2,
    P_ORDER_ID VARCHAR2,
    P_INVOICE_ID VARCHAR2,
    P_ORDER_LINE_INFO_ARRAY OUT V_ORDER_LINE_INFO_ARRAY,
    P_MSG OUT VARCHAR2)
AS

   v_loc_msg            VARCHAR2(500);
   v_param_count        NUMBER;
   v_delivery_id        NUMBER;
   v_order_id           NUMBER;
   v_invoice_id         NUMBER;
   v_ou_id              NUMBER;
   v_loop_cnt           NUMBER;
   v_ship_location      VARCHAR2(500);
   v_ship_address1      VARCHAR2(500);
   v_ship_address2      VARCHAR2(500);
   v_ship_address3      VARCHAR2(500);
   v_ship_address4      VARCHAR2(500);
   v_ship_address5      VARCHAR2(500);
   v_ship_address       VARCHAR2(2500);
   v_deliver_location   VARCHAR2(500);
   v_deliver_address1   VARCHAR2(500);
   v_deliver_address2   VARCHAR2(500);
   v_deliver_address3   VARCHAR2(500);
   v_deliver_address4   VARCHAR2(500);
   v_deliver_address5   VARCHAR2(500);
   v_deliver_address    VARCHAR2(2500);
   v_bill_location      VARCHAR2(500);
   v_bill_address1      VARCHAR2(500);
   v_bill_address2      VARCHAR2(500);
   v_bill_address3      VARCHAR2(500);
   v_bill_address4      VARCHAR2(500);
   v_bill_address5      VARCHAR2(500);
   v_bill_address       VARCHAR2(2500);

   v_authorized         VARCHAR2(1);
   v_cust_id            NUMBER;

   v_ln_simple_sts_flag VARCHAR2(240);
   v_line_status        VARCHAR2(240);
   v_upd_cancel_flag    VARCHAR2(2);
   v_crital_part_flag    VARCHAR2(2);
   e_exit               EXCEPTION;
   /*
    #########################################
    -- US225986
    -- Das, Debopam (212674555)
	#########################################
    */
    lv_ou_id NUMBER;
    lv_name  VARCHAR2(240) := 'GE Aero Energy Services';

   CURSOR C_ORD(P_ORDER_ID NUMBER, P_OU_ID NUMBER) IS
      Select * from (
	  SELECT ool.line_id, ool.org_id, ool.header_id, ool.line_number, ool.ordered_item, ool.request_date, ool.promise_date,
             ool.schedule_arrival_date, ool.schedule_ship_date, ool.order_quantity_uom, ool.cancelled_quantity, ool.shipped_quantity,
             ool.ordered_quantity, ool.fulfilled_quantity, ool.shipping_quantity, ool.tax_exempt_flag, ool.tax_exempt_number,
             ool.tax_exempt_reason_code, ool.cust_po_number, ool.sold_to_org_id, ool.ship_from_org_id, ool.ship_to_org_id,
             ool.deliver_to_org_id, ool.invoice_to_org_id, ool.inventory_item_id, ool.tax_code, ool.tax_rate, ool.schedule_status_code,
             ool.price_list_id, ool.pricing_date, ool.shipment_number, NVL((SELECT description
			 FROM fnd_lookup_values fv WHERE LOOKUP_TYPE='GEAE_WMS_AMPS_MYGE_PRY_LKP'
			 AND ool.shipment_priority_code=fv.lookup_code  --- Added by OWMS- ERL Team
			 AND enabled_flag='Y'),ool.shipment_priority_code) SHIPMENT_PRIORITY_CODE, delivery.shipping_method,
             ool.freight_terms_code, ool.freight_carrier_code, fob_lkp.description fob_point, ool.payment_term_id, ool.return_context,
             ool.return_attribute3 return_coo, ool.return_attribute1, ool.return_attribute2, ool.unit_selling_price,
             ool.unit_list_price, ool.unit_selling_price*ool.ordered_quantity ext_price, ool.tax_value, ool.creation_date, (select user_name from fnd_user where user_id=ool.created_by) created_by, ---Changed by Trupti D. for MYJIRATEST-7809 18-FEB-2016
             ool.last_update_date, (select user_name from fnd_user where user_id=ool.last_updated_by) last_updated_by, ool.item_type_code, ool.component_number component_number,                                     ---Changed by Trupti D. for MYJIRATEST-7809 18-FEB-2016
             (DECODE (ool.item_type_code,'MODEL', (SELECT MAX (ol.actual_shipment_date)
                                                     FROM oe_order_lines_all ol
                                                    WHERE ol.link_to_line_id  = ool.line_id
                                                      AND ol.header_id        = ool.header_id
                                                      AND ol.org_id           = ool.org_id ),ool.actual_shipment_date)) actual_shipment_date,
             ottl.name line_type, qlht.name price_list, rtt.name payment_term, hzp.party_name sold_to, cust_acct.account_number customer_number,
             ship_from_org.organization_code ship_from, ooh.order_number, ooh.quote_number, ooh.order_type_id, ooh.ordered_date,
             ret_reason.description return_reason, ool.split_from_line_id, ool.ship_set_id, ool.planning_priority, ool.shipping_instructions,
             ool.packing_instructions, ool.invoiced_quantity, ool.flow_status_code, ool.customer_line_number,
             ool.original_ordered_item, os.name order_source, msi.description keyword, --changed by Gourab s for DE14766
                           msi.description part_nomen, rsa.name sales_person,delivery.delivery_id,
             (SELECT ih.trx_number
                FROM ra_customer_trx_lines_all il, ra_customer_trx_all ih
               WHERE il.line_type = 'LINE' AND il.interface_line_context = 'ORDER ENTRY' AND ih.customer_trx_id = il.customer_trx_id
                 AND ih.org_id = P_OU_ID
                 AND TO_CHAR(ooh.order_number) = il.INTERFACE_LINE_ATTRIBUTE1 --Changed by Ankita.S for MYJIRATEST-8445
                 AND TO_CHAR(ool.line_id) = il.interface_line_attribute6
                 AND rownum = 1
             ) invoice_number,
             (SELECT ih.customer_trx_id
                FROM ra_customer_trx_lines_all il, ra_customer_trx_all ih
               WHERE il.line_type = 'LINE' AND il.interface_line_context = 'ORDER ENTRY' AND ih.customer_trx_id = il.customer_trx_id
                 AND ih.org_id = P_OU_ID
                 AND TO_CHAR(ooh.order_number) = il.INTERFACE_LINE_ATTRIBUTE1 --Changed by Ankita.S for MYJIRATEST-8445
                 AND TO_CHAR(ool.line_id) = il.interface_line_attribute6
                 AND rownum = 1
             ) invoice_id,
             ROUND(((ool.unit_list_price - ool.unit_selling_price)*100)/DECODE(ool.unit_list_price,0,1,ool.unit_list_price),2) discount_percentage,
             (ool.unit_list_price - ool.unit_selling_price)*ool.ordered_quantity discount_amount,
             (SELECT ih.trx_date
                FROM ra_customer_trx_lines_all il, ra_customer_trx_all ih
               WHERE il.line_type = 'LINE' AND il.interface_line_context = 'ORDER ENTRY' AND ih.customer_trx_id = il.customer_trx_id
                 AND ih.org_id = P_OU_ID
                 AND TO_CHAR(ooh.order_number) = il.INTERFACE_LINE_ATTRIBUTE1 --Changed by Ankita.S for MYJIRATEST-8445
                 AND TO_CHAR(ool.line_id) = il.interface_line_attribute6
                 AND rownum = 1
             ) invoice_date,
             (SELECT SUM(il.extended_amount)
                FROM ra_customer_trx_lines_all il, ra_customer_trx_all ih
               WHERE il.line_type = 'LINE' AND il.interface_line_context = 'ORDER ENTRY' AND ih.customer_trx_id = il.customer_trx_id
                 AND ih.org_id = P_OU_ID
                 AND TO_CHAR(ooh.order_number) = il.INTERFACE_LINE_ATTRIBUTE1 --Changed by Ankita.S for MYJIRATEST-8445
                 AND TO_CHAR(ool.line_id) = il.interface_line_attribute6
             ) invoice_value,
             wdd.attribute3 ms_number, SUM(wdd.shipped_quantity) shipment_quantity, wdd.attribute8 dimensions,
             delivery.gross_weight, delivery.link_to_carrier, NVL(ool.option_number,-1) option_number, NVL(ool.service_number,-1) service_number,
             (SELECT catalog_upq FROM GEAE_QP_ITEM_PRICES_V WHERE price_list_name = qlht.name AND inventory_item_id = to_char(ool.inventory_item_id)) upq,
             DECODE(ool.item_type_code,'MODEL','N','Y') qty_upd_allowed,
             GET_ORIG_PO_NUMBER(ool.return_context,ool.return_attribute1,ool.return_attribute2) orig_po_for_return,
             GET_LINE_DWLD_TO_WMS(ool.header_id, ool.line_id) dwld_to_wms,
             GET_SHIP_LINE_FLAG(ool.header_id, ool.line_id) shipping_line_flag,
             GET_COO(ool.org_id,ool.header_id, ool.line_id) country_of_origin,
             GET_SHIP_STATUS(ool.org_id,ool.header_id, ool.line_id) shipping_status,
             GET_SERIAL_NUMBERS(ool.org_id,ool.header_id, ool.line_id) serial_numbers,
             GET_DISP_ALLWD_FLG(ool.org_id,ool.header_id, ool.line_id) dispute_allowed,
--Manisha 05-Mar-2019 Modified the below code for ESN ,as it was fetchin wrong data in case of ESN as null and workstop qty/date is present
           --  substr(ool.attribute7,1,6) mygea_esn,  ----Neelima Y MYJIRATEST-8723
           --Manisha 29-Mar-2019 DE44340 Modified the ESN code as it can be alphanumeric
         --   cast(REGEXP_SUBSTR(REPLACE(ool.attribute7,'~',','), '([^,]*)(,|$)', 1, 1,NULL, 1)as number) mygea_esn,
         SUBSTR(REGEXP_SUBSTR(REPLACE(REPLACE(ool.attribute7,',',' '),'~',','), '([^,]*)(,|$)', 1, 1,NULL, 1), 1,6) mygea_esn,
             GET_DISP_CREATED_FLG(ool.org_id,ool.header_id, ool.line_id) dispute_created,  --MYJIRATEST-3745 TRUPTI D. 31-MAR-2016
     /**Manisha 15-Feb-2019 Rewrote the code for wsp_date and qty to resolve the issue of skipping over null values of workstop date and workstop qty***/
           --  To_date(REGEXP_SUBSTR (ool.attribute7, '[^~]+', 1, 2), 'YYYY/MM/DD hh24:mi:ss') workstp_date,    --Added by Suguna
           -- cast(REGEXP_SUBSTR (ool.attribute7, '[^~]+', 1, 3)as number) workstp_qty     --Added by Manisha
           --  To_date(REGEXP_SUBSTR(REPLACE(ool.attribute7,'~',','), '([^,]*)(,|$)', 1, 2,NULL, 1), 'YYYY/MM/DD hh24:mi:ss') workstp_date,
           To_date(REGEXP_SUBSTR(REPLACE(REPLACE(ool.attribute7,',','  '),'~',','), '([^,]*)(,|$)', 1, 2,NULL, 1), 'YYYY/MM/DD hh24:mi:ss') workstp_date,
         --  cast(REGEXP_SUBSTR(REPLACE(ool.attribute7,'~',','), '([^,]*)(,|$)', 1, 3,NULL, 1)as number) workstp_qty     --Added by Manisha
         cast(REGEXP_SUBSTR(REPLACE(REPLACE(ool.attribute7,',','  '),'~',','), '([^,]*)(,|$)', 1, 3,NULL, 1)as number) workstp_qty     --Added by Manisha
        FROM oe_order_lines_all ool, oe_order_headers_all ooh,
             (SELECT * FROM wsh_delivery_details WHERE requested_quantity <> 0 AND released_status <> 'B') wdd,
             (SELECT wda.delivery_detail_id, wnd.delivery_id, wnd.gross_weight, wnd.attribute5 link_to_carrier, wnd_sm.description shipping_method
                FROM wsh_delivery_assignments wda, wsh_new_deliveries wnd, fnd_lookup_values wnd_sm
               WHERE wnd_sm.lookup_type(+) = 'SHIP_METHOD'
                 AND wnd_sm.lookup_code(+) = wnd.ship_method_code
                 AND wnd.delivery_id = wda.delivery_id) delivery,
             fnd_lookup_values fob_lkp, oe_transaction_types_tl ottl, qp_list_headers_tl qlht, ra_terms_tl rtt, hz_parties hzp,
             hz_cust_accounts cust_acct, mtl_parameters ship_from_org, ar_lookups ret_reason, oe_order_sources os, mtl_system_items msi,
             ra_salesreps_all rsa
       WHERE ool.header_id = ooh.header_id
         AND ool.org_id = ooh.org_id
         AND wdd.org_id(+) = ool.org_id
         AND ool.line_id = wdd.source_line_id(+)
         AND ool.header_id = wdd.source_header_id(+)
         AND delivery.delivery_detail_id(+) = wdd.delivery_detail_id
         AND fob_lkp.lookup_type(+) = 'FOB'
         AND fob_lkp.lookup_code(+) = ool.fob_point_code
         AND fob_lkp.VIEW_APPLICATION_ID(+)=222  -- Added by Amita to resolve duplicate line dtl issue
         AND ool.line_type_id = ottl.transaction_type_id
         AND ool.price_list_id = qlht.list_header_id(+)
         AND ool.payment_term_id = rtt.term_id(+)
         AND ool.sold_to_org_id = cust_acct.cust_account_id
--         AND ool.item_type_code IN ('MODEL','STANDARD')
         AND ool.item_type_code NOT IN ('CLASS') --Changed by Neelima Y for MYJIRATEST-2207
         AND cust_acct.party_id = hzp.party_id
         AND ool.ship_from_org_id = ship_from_org.organization_id
         AND ret_reason.lookup_type(+) = 'CREDIT_MEMO_REASON'
         AND ret_reason.lookup_code(+) = ool.return_reason_code
         AND ooh.order_source_id = os.order_source_id
         AND ool.inventory_item_id = msi.inventory_item_id
         AND ool.ship_from_org_id = msi.organization_id
         AND ool.salesrep_id = rsa.salesrep_id(+)
         AND ooh.org_id = P_OU_ID
         AND ooh.header_id = P_ORDER_ID
		 and P_OU_ID                  <> lv_ou_id	 --Added by Debopam
      GROUP BY ool.line_id, ool.org_id, ool.header_id, ool.line_number, ool.ordered_item, ool.request_date, ool.promise_date,
             ool.schedule_arrival_date, ool.schedule_ship_date, ool.order_quantity_uom, ool.cancelled_quantity, ool.shipped_quantity,
             ool.ordered_quantity, ool.fulfilled_quantity, ool.shipping_quantity, ool.tax_exempt_flag, ool.tax_exempt_number,
             ool.tax_exempt_reason_code, ool.cust_po_number, ool.sold_to_org_id, ool.ship_from_org_id, ool.ship_to_org_id,
             ool.deliver_to_org_id, ool.invoice_to_org_id, ool.inventory_item_id, ool.tax_code, ool.tax_rate, ool.schedule_status_code,
             ool.price_list_id, ool.pricing_date, ool.shipment_number, ool.shipment_priority_code, delivery.shipping_method,
             ool.freight_terms_code, ool.freight_carrier_code, fob_lkp.description, ool.payment_term_id, ool.return_context,
             ool.return_attribute3, ool.return_attribute1, ool.return_attribute2, ool.unit_selling_price,
             ool.unit_list_price, ool.unit_selling_price, ool.ordered_quantity, ool.tax_value, ool.creation_date, ool.created_by,
             ool.last_update_date, ool.last_updated_by, ool.item_type_code, ool.component_number, ool.item_type_code, ool.actual_shipment_date,
             ottl.name, qlht.name, rtt.name, hzp.party_name, cust_acct.account_number, ship_from_org.organization_code, ooh.order_number, ooh.quote_number,
             ooh.order_type_id, ooh.ordered_date, ret_reason.description, ool.split_from_line_id, ool.ship_set_id, ool.planning_priority, ool.shipping_instructions,
             ool.packing_instructions, ool.invoiced_quantity, ool.flow_status_code, ool.customer_line_number,
             ool.original_ordered_item, os.name, msi.attribute7, msi.description, rsa.name, delivery.delivery_id, wdd.attribute3,
             wdd.attribute8, delivery.gross_weight, delivery.link_to_carrier, ool.option_number, ool.service_number,ool.attribute7   ----Neelima Y MYJIRATEST-8723
             -- Changes Started by Debopam
			 UNION ALL
	         SELECT ool.line_id, ool.org_id, ool.header_id, ool.line_number, ool.ordered_item, ool.request_date, ool.promise_date,
             ool.schedule_arrival_date, ool.schedule_ship_date, ool.order_quantity_uom, ool.cancelled_quantity, ool.shipped_quantity,
             ool.ordered_quantity, ool.fulfilled_quantity, ool.shipping_quantity, ool.tax_exempt_flag, ool.tax_exempt_number,
             ool.tax_exempt_reason_code, ool.cust_po_number, ool.sold_to_org_id, ool.ship_from_org_id, ool.ship_to_org_id,
             ool.deliver_to_org_id, ool.invoice_to_org_id, ool.inventory_item_id, ool.tax_code, ool.tax_rate, ool.schedule_status_code,
             ool.price_list_id, ool.pricing_date, ool.shipment_number, NVL((SELECT description
			 FROM fnd_lookup_values fv WHERE LOOKUP_TYPE='GEAE_WMS_AMPS_MYGE_PRY_LKP'
			 AND ool.shipment_priority_code=fv.lookup_code  --- Added by OWMS- ERL Team
			 AND enabled_flag='Y'),ool.shipment_priority_code) SHIPMENT_PRIORITY_CODE, delivery.shipping_method,
             ool.freight_terms_code, ool.freight_carrier_code, fob_lkp.description fob_point, ool.payment_term_id, ool.return_context,
             ool.return_attribute3 return_coo, ool.return_attribute1, ool.return_attribute2, ool.unit_selling_price,
             ool.unit_list_price, ool.unit_selling_price*ool.ordered_quantity ext_price, ool.tax_value, ool.creation_date, (select user_name from fnd_user where user_id=ool.created_by) created_by, ---Changed by Trupti D. for MYJIRATEST-7809 18-FEB-2016
             ool.last_update_date, (select user_name from fnd_user where user_id=ool.last_updated_by) last_updated_by, ool.item_type_code, ool.component_number component_number,                                     ---Changed by Trupti D. for MYJIRATEST-7809 18-FEB-2016
             (DECODE (ool.item_type_code,'MODEL', (SELECT MAX (ol.actual_shipment_date)
                                                     FROM oe_order_lines_all ol
                                                    WHERE ol.link_to_line_id  = ool.line_id
                                                      AND ol.header_id        = ool.header_id
                                                      AND ol.org_id           = ool.org_id ),ool.actual_shipment_date)) actual_shipment_date,
             ottl.name line_type, qlht.name price_list, rtt.name payment_term, hzp.party_name sold_to, cust_acct.account_number customer_number,
             ship_from_org.organization_code ship_from, ooh.order_number, ooh.quote_number, ooh.order_type_id, ooh.ordered_date,
             ret_reason.description return_reason, ool.split_from_line_id, ool.ship_set_id, ool.planning_priority, ool.shipping_instructions,
             ool.packing_instructions, ool.invoiced_quantity, ool.flow_status_code, ool.customer_line_number,
             ool.original_ordered_item, os.name order_source, msi.description keyword, --changed by Gourab s for DE14766
                           msi.description part_nomen, rsa.name sales_person,delivery.delivery_id,
             (SELECT ih.trx_number
                FROM ra_customer_trx_lines_all il, ra_customer_trx_all ih
               WHERE il.line_type = 'LINE' AND il.interface_line_context = 'ORDER ENTRY' AND ih.customer_trx_id = il.customer_trx_id
                 AND ih.org_id = P_OU_ID
                 AND TO_CHAR(ooh.order_number) = il.INTERFACE_LINE_ATTRIBUTE1 --Changed by Ankita.S for MYJIRATEST-8445
                 AND TO_CHAR(ool.line_id) = il.interface_line_attribute6
                 AND rownum = 1
             ) invoice_number,
             (SELECT ih.customer_trx_id
                FROM ra_customer_trx_lines_all il, ra_customer_trx_all ih
               WHERE il.line_type = 'LINE' AND il.interface_line_context = 'ORDER ENTRY' AND ih.customer_trx_id = il.customer_trx_id
                 AND ih.org_id = P_OU_ID
                 AND TO_CHAR(ooh.order_number) = il.INTERFACE_LINE_ATTRIBUTE1 --Changed by Ankita.S for MYJIRATEST-8445
                 AND TO_CHAR(ool.line_id) = il.interface_line_attribute6
                 AND rownum = 1
             ) invoice_id,
             ROUND(((ool.unit_list_price - ool.unit_selling_price)*100)/DECODE(ool.unit_list_price,0,1,ool.unit_list_price),2) discount_percentage,
             (ool.unit_list_price - ool.unit_selling_price)*ool.ordered_quantity discount_amount,
             (SELECT ih.trx_date
                FROM ra_customer_trx_lines_all il, ra_customer_trx_all ih
               WHERE il.line_type = 'LINE' AND il.interface_line_context = 'ORDER ENTRY' AND ih.customer_trx_id = il.customer_trx_id
                 AND ih.org_id = P_OU_ID
                 AND TO_CHAR(ooh.order_number) = il.INTERFACE_LINE_ATTRIBUTE1 --Changed by Ankita.S for MYJIRATEST-8445
                 AND TO_CHAR(ool.line_id) = il.interface_line_attribute6
                 AND rownum = 1
             ) invoice_date,
             (SELECT SUM(il.extended_amount)
                FROM ra_customer_trx_lines_all il, ra_customer_trx_all ih
               WHERE il.line_type = 'LINE' AND il.interface_line_context = 'ORDER ENTRY' AND ih.customer_trx_id = il.customer_trx_id
                 AND ih.org_id = P_OU_ID
                 AND TO_CHAR(ooh.order_number) = il.INTERFACE_LINE_ATTRIBUTE1 --Changed by Ankita.S for MYJIRATEST-8445
                 AND TO_CHAR(ool.line_id) = il.interface_line_attribute6
             ) invoice_value,
             wdd.attribute3 ms_number, SUM(wdd.shipped_quantity) shipment_quantity, wdd.attribute8 dimensions,
             delivery.gross_weight, delivery.link_to_carrier, NVL(ool.option_number,-1) option_number, NVL(ool.service_number,-1) service_number,
             (SELECT catalog_upq FROM GEAE_QP_ITEM_PRICES_V WHERE price_list_name = qlht.name AND inventory_item_id = to_char(ool.inventory_item_id)) upq,
             DECODE(ool.item_type_code,'MODEL','N','Y') qty_upd_allowed,
             GET_ORIG_PO_NUMBER(ool.return_context,ool.return_attribute1,ool.return_attribute2) orig_po_for_return,
             GET_LINE_DWLD_TO_WMS(ool.header_id, ool.line_id) dwld_to_wms,
             GET_SHIP_LINE_FLAG(ool.header_id, ool.line_id) shipping_line_flag,
             GET_COO(ool.org_id,ool.header_id, ool.line_id) country_of_origin,
             GET_SHIP_STATUS(ool.org_id,ool.header_id, ool.line_id) shipping_status,
             GET_SERIAL_NUMBERS(ool.org_id,ool.header_id, ool.line_id) serial_numbers,
             GET_DISP_ALLWD_FLG(ool.org_id,ool.header_id, ool.line_id) dispute_allowed,
--Manisha 05-Mar-2019 Modified the below code for ESN ,as it was fetching wrong data in case of ESN as null and workstop qty/date is present
           --  substr(ool.attribute7,1,6) mygea_esn,  ----Neelima Y MYJIRATEST-8723
        --Manisha 29-Mar-2019 DE44340 Modified the ESN code as it can be alphanumeric
          --  cast(REGEXP_SUBSTR(REPLACE(ool.attribute7,'~',','), '([^,]*)(,|$)', 1, 1,NULL, 1)as number) mygea_esn,
              SUBSTR(REGEXP_SUBSTR(REPLACE(REPLACE(ool.attribute7,',',' '),'~',','), '([^,]*)(,|$)', 1, 1,NULL, 1),1,6) mygea_esn,
             GET_DISP_CREATED_FLG(ool.org_id,ool.header_id, ool.line_id) dispute_created,  --MYJIRATEST-3745 TRUPTI D. 31-MAR-2016
     /**Manisha 15-Feb-2019 Rewrote the code for wsp_date and qty to resolve the issue of skipping over null values of workstop date and workstop qty***/
           --  To_date(REGEXP_SUBSTR (ool.attribute7, '[^~]+', 1, 2), 'YYYY/MM/DD hh24:mi:ss') workstp_date,    --Added by Suguna
           -- cast(REGEXP_SUBSTR (ool.attribute7, '[^~]+', 1, 3)as number) workstp_qty     --Added by Manisha
             To_date(REGEXP_SUBSTR(REPLACE(REPLACE(ool.attribute7,',','  '),'~',','), '([^,]*)(,|$)', 1, 2,NULL, 1), 'YYYY/MM/DD hh24:mi:ss') workstp_date,
             cast(REGEXP_SUBSTR(REPLACE(REPLACE(ool.attribute7,',','  '),'~',','), '([^,]*)(,|$)', 1, 3,NULL, 1)as number) workstp_qty     --Added by Manisha
        FROM oe_order_lines_all ool, oe_order_headers_all ooh,
             (SELECT * FROM wsh_delivery_details WHERE requested_quantity <> 0 AND released_status <> 'B') wdd,
             (SELECT wda.delivery_detail_id, wnd.delivery_id, wnd.gross_weight, wnd.attribute5 link_to_carrier, wnd_sm.description shipping_method
                FROM wsh_delivery_assignments wda, wsh_new_deliveries wnd, fnd_lookup_values wnd_sm
               WHERE wnd_sm.lookup_type(+) = 'SHIP_METHOD'
                 AND wnd_sm.lookup_code(+) = wnd.ship_method_code
                 AND wnd.delivery_id = wda.delivery_id) delivery,
             fnd_lookup_values fob_lkp, oe_transaction_types_tl ottl, qp_list_headers_tl qlht, ra_terms_tl rtt, hz_parties hzp,
             hz_cust_accounts cust_acct, mtl_parameters ship_from_org, ar_lookups ret_reason, oe_order_sources os, mtl_system_items msi,
             ra_salesreps_all rsa
       WHERE ool.header_id = ooh.header_id
         AND ool.org_id = ooh.org_id
         AND wdd.org_id(+) = ool.org_id
         AND ool.line_id = wdd.source_line_id(+)
         AND ool.header_id = wdd.source_header_id(+)
         AND delivery.delivery_detail_id(+) = wdd.delivery_detail_id
         AND fob_lkp.lookup_type(+) = 'FOB'
         AND fob_lkp.lookup_code(+) = ool.fob_point_code
         AND fob_lkp.VIEW_APPLICATION_ID(+)=222  -- Added by Amita to resolve duplicate line dtl issue
         AND ool.line_type_id = ottl.transaction_type_id
         AND ool.price_list_id = qlht.list_header_id(+)
         AND ool.payment_term_id = rtt.term_id(+)
         AND ool.sold_to_org_id = cust_acct.cust_account_id
--         AND ool.item_type_code IN ('MODEL','STANDARD')
         AND ool.item_type_code NOT IN ('CLASS') --Changed by Neelima Y for MYJIRATEST-2207
         AND cust_acct.party_id = hzp.party_id
         AND ool.ship_from_org_id = ship_from_org.organization_id
         AND ret_reason.lookup_type(+) = 'CREDIT_MEMO_REASON'
         AND ret_reason.lookup_code(+) = ool.return_reason_code
         AND ooh.order_source_id = os.order_source_id
         AND ool.inventory_item_id = msi.inventory_item_id
         AND ool.ship_from_org_id = msi.organization_id
         AND ool.salesrep_id = rsa.salesrep_id(+)
         AND ooh.org_id = P_OU_ID
         AND ooh.header_id = P_ORDER_ID
		 AND ool.link_to_line_id IS NULL -- Added by Debopam
		 AND P_OU_ID         = lv_ou_id	 --Added by Debopam
      GROUP BY ool.line_id, ool.org_id, ool.header_id, ool.line_number, ool.ordered_item, ool.request_date, ool.promise_date,
             ool.schedule_arrival_date, ool.schedule_ship_date, ool.order_quantity_uom, ool.cancelled_quantity, ool.shipped_quantity,
             ool.ordered_quantity, ool.fulfilled_quantity, ool.shipping_quantity, ool.tax_exempt_flag, ool.tax_exempt_number,
             ool.tax_exempt_reason_code, ool.cust_po_number, ool.sold_to_org_id, ool.ship_from_org_id, ool.ship_to_org_id,
             ool.deliver_to_org_id, ool.invoice_to_org_id, ool.inventory_item_id, ool.tax_code, ool.tax_rate, ool.schedule_status_code,
             ool.price_list_id, ool.pricing_date, ool.shipment_number,ool.shipment_priority_code, delivery.shipping_method,
             ool.freight_terms_code, ool.freight_carrier_code, fob_lkp.description, ool.payment_term_id, ool.return_context,
             ool.return_attribute3, ool.return_attribute1, ool.return_attribute2, ool.unit_selling_price,
             ool.unit_list_price, ool.unit_selling_price, ool.ordered_quantity, ool.tax_value, ool.creation_date, ool.created_by,
             ool.last_update_date, ool.last_updated_by, ool.item_type_code, ool.component_number, ool.item_type_code, ool.actual_shipment_date,
             ottl.name, qlht.name, rtt.name, hzp.party_name, cust_acct.account_number, ship_from_org.organization_code, ooh.order_number, ooh.quote_number,
             ooh.order_type_id, ooh.ordered_date, ret_reason.description, ool.split_from_line_id, ool.ship_set_id, ool.planning_priority, ool.shipping_instructions,
             ool.packing_instructions, ool.invoiced_quantity, ool.flow_status_code, ool.customer_line_number,
             ool.original_ordered_item, os.name, msi.attribute7, msi.description, rsa.name, delivery.delivery_id, wdd.attribute3,
             wdd.attribute8, delivery.gross_weight, delivery.link_to_carrier, ool.option_number, ool.service_number,ool.attribute7   ----Neelima Y MYJIRATEST-8723
	 )
	 ORDER BY line_number, shipment_number,option_number,component_number, service_number;


   CURSOR C_SHP_MS(P_DELIVERY_ID NUMBER, P_MS_NUMBER VARCHAR2, P_OU_ID NUMBER) IS
      SELECT ool.line_id, ool.org_id, ool.header_id, ool.line_number, ool.ordered_item, ool.request_date, ool.promise_date,
             ool.schedule_arrival_date, ool.schedule_ship_date, ool.order_quantity_uom, ool.cancelled_quantity, ool.shipped_quantity,
             ool.ordered_quantity, ool.fulfilled_quantity, ool.shipping_quantity, ool.tax_exempt_flag, ool.tax_exempt_number,
             ool.tax_exempt_reason_code, ool.cust_po_number, ool.sold_to_org_id, ool.ship_from_org_id, ool.ship_to_org_id,
             ool.deliver_to_org_id, ool.invoice_to_org_id, ool.inventory_item_id, ool.tax_code, ool.tax_rate, ool.schedule_status_code,
             ool.price_list_id, ool.pricing_date, ool.shipment_number, NVL((SELECT description
			 FROM fnd_lookup_values fv WHERE LOOKUP_TYPE='GEAE_WMS_AMPS_MYGE_PRY_LKP'
			 AND ool.shipment_priority_code=fv.lookup_code  --- Added by OWMS- ERL Team
			 AND enabled_flag='Y'),ool.shipment_priority_code) SHIPMENT_PRIORITY_CODE, wnd_sm.description shipping_method,
             ool.freight_terms_code, ool.freight_carrier_code, fob_lkp.description fob_point, ool.payment_term_id, ool.return_context,
             ool.return_attribute3 return_coo, ool.return_attribute1, ool.return_attribute2, ool.unit_selling_price,
             ool.unit_list_price, ool.unit_selling_price*ool.ordered_quantity ext_price, ool.tax_value, ool.creation_date, ool.created_by,
             ool.last_update_date, ool.last_updated_by, ool.item_type_code, ool.component_number,
             (DECODE (ool.item_type_code,'MODEL', (SELECT MAX (ol.actual_shipment_date)
                                                     FROM oe_order_lines_all ol
                                                    WHERE ol.link_to_line_id  = ool.line_id
                                                      AND ol.header_id        = ool.header_id
                                                      AND ol.org_id           = ool.org_id ),ool.actual_shipment_date)) actual_shipment_date,
             ottl.name line_type, qlht.name price_list, rtt.name payment_term, hzp.party_name sold_to, cust_acct.account_number customer_number,
             ship_from_org.organization_code ship_from, ooh.order_number, ooh.quote_number, ooh.order_type_id, ooh.ordered_date,
             ret_reason.description return_reason, ool.split_from_line_id, ool.ship_set_id, ool.planning_priority, ool.shipping_instructions,
             ool.packing_instructions, ool.invoiced_quantity, ool.flow_status_code, ool.customer_line_number,
             ool.original_ordered_item, os.name order_source, msi.attribute7 keyword, msi.description part_nomen, rsa.name sales_person,
             wnd.delivery_id,
             (SELECT ih.trx_number
                FROM ra_customer_trx_lines_all il, ra_customer_trx_all ih
               WHERE il.line_type = 'LINE' AND il.interface_line_context = 'ORDER ENTRY' AND ih.customer_trx_id = il.customer_trx_id
                 AND ih.org_id = P_OU_ID
                 AND TO_CHAR(ooh.order_number) = il.INTERFACE_LINE_ATTRIBUTE1 --Changed by Ankita.S for MYJIRATEST-8445
                 AND TO_CHAR(ool.line_id) = il.interface_line_attribute6
                 AND rownum = 1
             ) invoice_number,
             (SELECT ih.customer_trx_id
                FROM ra_customer_trx_lines_all il, ra_customer_trx_all ih
               WHERE il.line_type = 'LINE' AND il.interface_line_context = 'ORDER ENTRY' AND ih.customer_trx_id = il.customer_trx_id
                 AND ih.org_id = P_OU_ID
                 AND TO_CHAR(ooh.order_number) = il.INTERFACE_LINE_ATTRIBUTE1 --Changed by Ankita.S for MYJIRATEST-8445
                 AND TO_CHAR(ool.line_id) = il.interface_line_attribute6
                 AND rownum = 1
             ) invoice_id,
             ROUND(((ool.unit_list_price - ool.unit_selling_price)*100)/DECODE(ool.unit_list_price,0,1,ool.unit_list_price),2) discount_percentage,
             (ool.unit_list_price - ool.unit_selling_price)*ool.ordered_quantity discount_amount,
             (SELECT ih.trx_date
                FROM ra_customer_trx_lines_all il, ra_customer_trx_all ih
               WHERE il.line_type = 'LINE' AND il.interface_line_context = 'ORDER ENTRY' AND ih.customer_trx_id = il.customer_trx_id
                 AND ih.org_id = P_OU_ID
                 AND TO_CHAR(ooh.order_number) = il.INTERFACE_LINE_ATTRIBUTE1 --Changed by Ankita.S for MYJIRATEST-8445
                 AND TO_CHAR(ool.line_id) = il.interface_line_attribute6
                 AND rownum = 1
             ) invoice_date,
             (SELECT SUM(il.extended_amount)
                FROM ra_customer_trx_lines_all il, ra_customer_trx_all ih
               WHERE il.line_type = 'LINE' AND il.interface_line_context = 'ORDER ENTRY' AND ih.customer_trx_id = il.customer_trx_id
                 AND ih.org_id = P_OU_ID
                 AND TO_CHAR(ooh.order_number) = il.INTERFACE_LINE_ATTRIBUTE1 --Changed by Ankita.S for MYJIRATEST-8445
                 AND TO_CHAR(ool.line_id) = il.interface_line_attribute6
             ) invoice_value,
             wdd.attribute3 ms_number, SUM(wdd.shipped_quantity) shipment_quantity, wdd.attribute8 dimensions,
             wnd.gross_weight gross_weight, wnd.attribute5 link_to_carrier, NVL(ool.option_number,-1), NVL(ool.service_number,-1),
             (SELECT catalog_upq FROM GEAE_QP_ITEM_PRICES_V WHERE price_list_name = qlht.name AND inventory_item_id = to_char(ool.inventory_item_id)) upq,
             DECODE(ool.item_type_code,'MODEL','N','Y') qty_upd_allowed,
             GET_ORIG_PO_NUMBER(ool.return_context,ool.return_attribute1,ool.return_attribute2) orig_po_for_return,
             GET_LINE_DWLD_TO_WMS(ool.header_id, ool.line_id) dwld_to_wms,
             GET_SHIP_LINE_FLAG(ool.header_id, ool.line_id) shipping_line_flag,
             GET_COO(ool.org_id,ool.header_id, ool.line_id) country_of_origin,
             GET_SHIP_STATUS(ool.org_id,ool.header_id, ool.line_id) shipping_status,
             GET_SERIAL_NUMBERS(ool.org_id,ool.header_id, ool.line_id) serial_numbers,
             GET_DISP_ALLWD_FLG(ool.org_id,ool.header_id, ool.line_id) dispute_allowed,
             --Manisha 05-Mar-2019 Modified the below code for ESN ,as it was fetchin wrong data in case of ESN as null and workstop qty/date is present
            -- substr(ool.attribute7,1,6) mygea_esn, ----Neelima Y MYJIRATEST-8723
           -- cast(REGEXP_SUBSTR(REPLACE(ool.attribute7,'~',','), '([^,]*)(,|$)', 1, 1,NULL, 1)as number) mygea_esn,
           --Manisha 29-Mar-2019 DE44340 Modified the ESN code as it can be alphanumeric
           SUBSTR(REGEXP_SUBSTR(REPLACE(REPLACE(ool.attribute7,',',' '),'~',','), '([^,]*)(,|$)', 1, 1,NULL, 1), 1,6) mygea_esn,
            GET_DISP_CREATED_FLG(ool.org_id,ool.header_id, ool.line_id) dispute_created, --MYJIRATEST-3745 TRUPTI D. 31-MAR-2016
            /**Manisha 15-Feb-2019 Rewrote the code for wsp_date and qty to resolve the issue of skipping over null values of workstop date and workstop qty***/
--			--cast(REGEXP_SUBSTR (ool.attribute7, '[^~]+', 1, 2) as date )workstp_date,    --Added by Manisha
--            To_date(REGEXP_SUBSTR (ool.attribute7, '[^~]+', 1, 2), 'YYYY/MM/DD hh24:mi:ss')workstp_date, -- Added by Suguna
--            cast(REGEXP_SUBSTR (ool.attribute7, '[^~]+', 1, 3) as number) workstp_qty     --Added by Manisha
             To_date(REGEXP_SUBSTR(REPLACE(REPLACE(ool.attribute7,',','  '),'~',','), '([^,]*)(,|$)', 1, 2,NULL, 1), 'YYYY/MM/DD hh24:mi:ss') workstp_date,
            cast(REGEXP_SUBSTR(REPLACE(REPLACE(ool.attribute7,',','  '),'~',','), '([^,]*)(,|$)', 1, 3,NULL, 1)as number) workstp_qty
        FROM oe_order_lines_all ool, oe_order_headers_all ooh,
             (SELECT * FROM wsh_delivery_details WHERE requested_quantity <> 0 AND released_status <> 'B') wdd,
             wsh_delivery_assignments wda, wsh_new_deliveries wnd, fnd_lookup_values wnd_sm,
             fnd_lookup_values fob_lkp, oe_transaction_types_tl ottl, qp_list_headers_tl qlht, ra_terms_tl rtt, hz_parties hzp,
             hz_cust_accounts cust_acct, mtl_parameters ship_from_org, ar_lookups ret_reason, oe_order_sources os, mtl_system_items msi,
             ra_salesreps_all rsa
        WHERE ool.header_id = ooh.header_id
          AND ool.org_id = ooh.org_id
          AND wdd.org_id = ool.org_id
          AND wnd_sm.lookup_type(+) = 'SHIP_METHOD'
          AND wnd_sm.lookup_code(+) = wnd.ship_method_code
          AND ool.line_id = wdd.source_line_id
          AND ool.header_id = wdd.source_header_id
          AND wda.delivery_detail_id = wdd.delivery_detail_id
          AND wnd.delivery_id = wda.delivery_id
          AND fob_lkp.lookup_type(+) = 'FOB'
          AND fob_lkp.lookup_code(+) = ool.fob_point_code
          AND fob_lkp.VIEW_APPLICATION_ID(+)=222       -- Added by Amita to resolve duplicate line dtl issue
          AND ool.line_type_id = ottl.transaction_type_id
          AND ool.price_list_id = qlht.list_header_id(+)
          AND ool.payment_term_id = rtt.term_id(+)
          AND ool.sold_to_org_id = cust_acct.cust_account_id
--         AND ool.item_type_code IN ('MODEL','STANDARD')
          AND ool.item_type_code NOT IN ('CLASS') --Changed by Neelima Y for MYJIRATEST-2207
          AND cust_acct.party_id = hzp.party_id
          AND ool.ship_from_org_id = ship_from_org.organization_id
          AND ret_reason.lookup_type(+) = 'CREDIT_MEMO_REASON'
          AND ret_reason.lookup_code(+) = ool.return_reason_code
          AND ooh.order_source_id = os.order_source_id
          AND ool.inventory_item_id = msi.inventory_item_id
          AND ool.ship_from_org_id = msi.organization_id
          AND ool.salesrep_id = rsa.salesrep_id(+)
          AND ooh.org_id = P_OU_ID
          AND wnd.delivery_id = P_DELIVERY_ID
          AND wdd.attribute3 = P_MS_NUMBER
      GROUP BY ool.line_id, ool.org_id, ool.header_id, ool.line_number, ool.ordered_item, ool.request_date, ool.promise_date,
             ool.schedule_arrival_date, ool.schedule_ship_date, ool.order_quantity_uom, ool.cancelled_quantity, ool.shipped_quantity,
             ool.ordered_quantity, ool.fulfilled_quantity, ool.shipping_quantity, ool.tax_exempt_flag, ool.tax_exempt_number,
             ool.tax_exempt_reason_code, ool.cust_po_number, ool.sold_to_org_id, ool.ship_from_org_id, ool.ship_to_org_id,
             ool.deliver_to_org_id, ool.invoice_to_org_id, ool.inventory_item_id, ool.tax_code, ool.tax_rate, ool.schedule_status_code,
             ool.price_list_id, ool.pricing_date, ool.shipment_number, ool.shipment_priority_code, wnd_sm.description,
             ool.freight_terms_code, ool.freight_carrier_code, fob_lkp.description, ool.payment_term_id, ool.return_context,
             ool.return_attribute3, ool.return_attribute1, ool.return_attribute2, ool.unit_selling_price,
             ool.unit_list_price, ool.unit_selling_price, ool.ordered_quantity, ool.tax_value, ool.creation_date, ool.created_by,
             ool.last_update_date, ool.last_updated_by, ool.item_type_code, ool.component_number, ool.item_type_code, ool.actual_shipment_date,
             ottl.name, qlht.name, rtt.name, hzp.party_name, cust_acct.account_number, ship_from_org.organization_code, ooh.order_number, ooh.quote_number,
             ooh.order_type_id, ooh.ordered_date, ret_reason.description, ool.split_from_line_id, ool.ship_set_id, ool.planning_priority, ool.shipping_instructions,
             ool.packing_instructions, ool.invoiced_quantity, ool.flow_status_code, ool.customer_line_number,
             ool.original_ordered_item, os.name, msi.attribute7, msi.description, rsa.name, wnd.delivery_id, wdd.attribute3,
             wdd.attribute8, wnd.gross_weight, wnd.attribute5, ool.option_number, ool.service_number,ool.attribute7   ----Neelima Y MYJIRATEST-8723
      ORDER BY ool.header_id, ool.line_number, ool.shipment_number, NVL(ool.option_number,-1), NVL(ool.component_number,-1), NVL(ool.service_number,-1)
             ;

   CURSOR C_SHP(P_DELIVERY_ID NUMBER, P_OU_ID NUMBER) IS
      SELECT ool.line_id, ool.org_id, ool.header_id, ool.line_number, ool.ordered_item, ool.request_date, ool.promise_date,
             ool.schedule_arrival_date, ool.schedule_ship_date, ool.order_quantity_uom, ool.cancelled_quantity, ool.shipped_quantity,
             ool.ordered_quantity, ool.fulfilled_quantity, ool.shipping_quantity, ool.tax_exempt_flag, ool.tax_exempt_number,
             ool.tax_exempt_reason_code, ool.cust_po_number, ool.sold_to_org_id, ool.ship_from_org_id, ool.ship_to_org_id,
             ool.deliver_to_org_id, ool.invoice_to_org_id, ool.inventory_item_id, ool.tax_code, ool.tax_rate, ool.schedule_status_code,
             ool.price_list_id, ool.pricing_date, ool.shipment_number, NVL((SELECT description
			 FROM fnd_lookup_values fv WHERE LOOKUP_TYPE='GEAE_WMS_AMPS_MYGE_PRY_LKP'
			 AND ool.shipment_priority_code=fv.lookup_code  --- Added by OWMS- ERL Team
			 AND enabled_flag='Y'),ool.shipment_priority_code) SHIPMENT_PRIORITY_CODE, wnd_sm.description shipping_method,
             ool.freight_terms_code, ool.freight_carrier_code, fob_lkp.description fob_point, ool.payment_term_id, ool.return_context,
             ool.return_attribute3 return_coo, ool.return_attribute1, ool.return_attribute2, ool.unit_selling_price,
             ool.unit_list_price, ool.unit_selling_price*ool.ordered_quantity ext_price, ool.tax_value, ool.creation_date, ool.created_by,
             ool.last_update_date, ool.last_updated_by, ool.item_type_code, ool.component_number,
             (DECODE (ool.item_type_code,'MODEL', (SELECT MAX (ol.actual_shipment_date)
                                                     FROM oe_order_lines_all ol
                                                    WHERE ol.link_to_line_id  = ool.line_id
                                                      AND ol.header_id        = ool.header_id
                                                      AND ol.org_id           = ool.org_id ),ool.actual_shipment_date)) actual_shipment_date,
             ottl.name line_type, qlht.name price_list, rtt.name payment_term, hzp.party_name sold_to, cust_acct.account_number customer_number,
             ship_from_org.organization_code ship_from, ooh.order_number, ooh.quote_number, ooh.order_type_id, ooh.ordered_date,
             ret_reason.description return_reason, ool.split_from_line_id, ool.ship_set_id, ool.planning_priority, ool.shipping_instructions,
             ool.packing_instructions, ool.invoiced_quantity, ool.flow_status_code, ool.customer_line_number,
             ool.original_ordered_item, os.name order_source, msi.attribute7 keyword, msi.description part_nomen, rsa.name sales_person,
             wnd.delivery_id,
             (SELECT ih.trx_number
                FROM ra_customer_trx_lines_all il, ra_customer_trx_all ih
               WHERE il.line_type = 'LINE' AND il.interface_line_context = 'ORDER ENTRY' AND ih.customer_trx_id = il.customer_trx_id
                 AND ih.org_id = P_OU_ID
                 AND TO_CHAR(ooh.order_number) = il.INTERFACE_LINE_ATTRIBUTE1 --Changed by Ankita.S for MYJIRATEST-8445
                 AND TO_CHAR(ool.line_id) = il.interface_line_attribute6
                 AND rownum = 1
             ) invoice_number,
             (SELECT ih.customer_trx_id
                FROM ra_customer_trx_lines_all il, ra_customer_trx_all ih
               WHERE il.line_type = 'LINE' AND il.interface_line_context = 'ORDER ENTRY' AND ih.customer_trx_id = il.customer_trx_id
                 AND ih.org_id = P_OU_ID
                 AND TO_CHAR(ooh.order_number) = il.INTERFACE_LINE_ATTRIBUTE1 --Changed by Ankita.S for MYJIRATEST-8445
                 AND TO_CHAR(ool.line_id) = il.interface_line_attribute6
                 AND rownum = 1
             ) invoice_id,
             ROUND(((ool.unit_list_price - ool.unit_selling_price)*100)/DECODE(ool.unit_list_price,0,1,ool.unit_list_price),2) discount_percentage,
             (ool.unit_list_price - ool.unit_selling_price)*ool.ordered_quantity discount_amount,
             (SELECT ih.trx_date
                FROM ra_customer_trx_lines_all il, ra_customer_trx_all ih
               WHERE il.line_type = 'LINE' AND il.interface_line_context = 'ORDER ENTRY' AND ih.customer_trx_id = il.customer_trx_id
                 AND ih.org_id = P_OU_ID
                 AND TO_CHAR(ooh.order_number) = il.INTERFACE_LINE_ATTRIBUTE1 --Changed by Ankita.S for MYJIRATEST-8445
                 AND TO_CHAR(ool.line_id) = il.interface_line_attribute6
                 AND rownum = 1
             ) invoice_date,
             (SELECT SUM(il.extended_amount)
                FROM ra_customer_trx_lines_all il, ra_customer_trx_all ih
               WHERE il.line_type = 'LINE' AND il.interface_line_context = 'ORDER ENTRY' AND ih.customer_trx_id = il.customer_trx_id
                 AND ih.org_id = P_OU_ID
                 AND TO_CHAR(ooh.order_number) = il.INTERFACE_LINE_ATTRIBUTE1 --Changed by Ankita.S for MYJIRATEST-8445
                 AND TO_CHAR(ool.line_id) = il.interface_line_attribute6
             ) invoice_value,
             wdd.attribute3 ms_number, SUM(wdd.shipped_quantity) shipment_quantity, wdd.attribute8 dimensions,
             wnd.gross_weight gross_weight, wnd.attribute5 link_to_carrier, NVL(ool.option_number,-1), NVL(ool.service_number,-1),
             (SELECT catalog_upq FROM GEAE_QP_ITEM_PRICES_V WHERE price_list_name = qlht.name AND inventory_item_id = to_char(ool.inventory_item_id)) upq,
             DECODE(ool.item_type_code,'MODEL','N','Y') qty_upd_allowed,
             GET_ORIG_PO_NUMBER(ool.return_context,ool.return_attribute1,ool.return_attribute2) orig_po_for_return,
             GET_LINE_DWLD_TO_WMS(ool.header_id, ool.line_id) dwld_to_wms,
             GET_SHIP_LINE_FLAG(ool.header_id, ool.line_id) shipping_line_flag,
             GET_COO(ool.org_id,ool.header_id, ool.line_id) country_of_origin,
             GET_SHIP_STATUS(ool.org_id,ool.header_id, ool.line_id) shipping_status,
             GET_SERIAL_NUMBERS(ool.org_id,ool.header_id, ool.line_id) serial_numbers,
             GET_DISP_ALLWD_FLG(ool.org_id,ool.header_id, ool.line_id) dispute_allowed,
--Manisha 05-Mar-2019 Modified the below code for ESN ,as it was fetchin wrong data in case of ESN as null and workstop qty/date is present
          --    substr(ool.attribute7,1,6) mygea_esn,  ----Neelima Y MYJIRATEST-8723
          --Manisha 29-Mar-2019 DE44340 Modified the ESN code as it can be alphanumeric
         -- cast(REGEXP_SUBSTR(REPLACE(ool.attribute7,'~',','), '([^,]*)(,|$)', 1, 1,NULL, 1)as number) mygea_esn,
         SUBSTR(REGEXP_SUBSTR(REPLACE(REPLACE(ool.attribute7,',',' '),'~',','), '([^,]*)(,|$)', 1, 1,NULL, 1),1,6) mygea_esn,
             GET_DISP_CREATED_FLG(ool.org_id,ool.header_id, ool.line_id) dispute_created, --MYJIRATEST-3745 TRUPTI D. 31-MAR-2016
/**Manisha 15-Feb-2019 Rewrote the code for wsp_date and qty to resolve the issue of skipping over null values of workstop date and workstop qty***/
			 --cast( REGEXP_SUBSTR (ool.attribute7, '[^~]+', 1, 2) as date )workstp_date,    --Added by Manisha
--			 To_date(REGEXP_SUBSTR (ool.attribute7, '[^~]+', 1, 2), 'YYYY/MM/DD hh24:mi:ss')workstp_date, -- Added by Suguna
--             cast(REGEXP_SUBSTR (ool.attribute7, '[^~]+', 1, 3) as number) workstp_qty     --Added by Manisha
            To_date(REGEXP_SUBSTR(REPLACE(REPLACE(ool.attribute7,',','  '),'~',','), '([^,]*)(,|$)', 1, 2,NULL, 1), 'YYYY/MM/DD hh24:mi:ss') workstp_date,
            cast(REGEXP_SUBSTR(REPLACE(REPLACE(ool.attribute7,',','  '),'~',','), '([^,]*)(,|$)', 1, 3,NULL, 1)as number) workstp_qty
        FROM oe_order_lines_all ool, oe_order_headers_all ooh,
             (SELECT * FROM wsh_delivery_details WHERE requested_quantity <> 0 AND released_status <> 'B') wdd,
             wsh_delivery_assignments wda, wsh_new_deliveries wnd, fnd_lookup_values wnd_sm,
             fnd_lookup_values fob_lkp, oe_transaction_types_tl ottl, qp_list_headers_tl qlht, ra_terms_tl rtt, hz_parties hzp,
             hz_cust_accounts cust_acct, mtl_parameters ship_from_org, ar_lookups ret_reason, oe_order_sources os, mtl_system_items msi,
             ra_salesreps_all rsa
       WHERE ool.header_id = ooh.header_id
         AND ool.org_id = ooh.org_id
         AND wdd.org_id = ool.org_id
         AND wnd_sm.lookup_type(+) = 'SHIP_METHOD'
         AND wnd_sm.lookup_code(+) = wnd.ship_method_code
         AND ool.line_id = wdd.source_line_id
         AND ool.header_id = wdd.source_header_id
         AND wda.delivery_detail_id = wdd.delivery_detail_id
         AND wnd.delivery_id = wda.delivery_id
         AND fob_lkp.lookup_type(+) = 'FOB'
         AND fob_lkp.lookup_code(+) = ool.fob_point_code
         AND fob_lkp.VIEW_APPLICATION_ID(+)=222  -- Added by Amita to resolve duplicate line dtl issue
         AND ool.line_type_id = ottl.transaction_type_id
         AND ool.price_list_id = qlht.list_header_id(+)
         AND ool.payment_term_id = rtt.term_id(+)
         AND ool.sold_to_org_id = cust_acct.cust_account_id
--         AND ool.item_type_code IN ('MODEL','STANDARD')
         AND ool.item_type_code NOT IN ('CLASS') --Changed by Neelima Y for MYJIRATEST-2207
         AND cust_acct.party_id = hzp.party_id
         AND ool.ship_from_org_id = ship_from_org.organization_id
         AND ret_reason.lookup_type(+) = 'CREDIT_MEMO_REASON'
         AND ret_reason.lookup_code(+) = ool.return_reason_code
         AND ooh.order_source_id = os.order_source_id
         AND ool.inventory_item_id = msi.inventory_item_id
         AND ool.ship_from_org_id = msi.organization_id
         AND ool.salesrep_id = rsa.salesrep_id(+)
         AND ooh.org_id = P_OU_ID
         AND wnd.delivery_id = P_DELIVERY_ID
         AND wdd.attribute3 IS NULL
      GROUP BY ool.line_id, ool.org_id, ool.header_id, ool.line_number, ool.ordered_item, ool.request_date, ool.promise_date,
             ool.schedule_arrival_date, ool.schedule_ship_date, ool.order_quantity_uom, ool.cancelled_quantity, ool.shipped_quantity,
             ool.ordered_quantity, ool.fulfilled_quantity, ool.shipping_quantity, ool.tax_exempt_flag, ool.tax_exempt_number,
             ool.tax_exempt_reason_code, ool.cust_po_number, ool.sold_to_org_id, ool.ship_from_org_id, ool.ship_to_org_id,
             ool.deliver_to_org_id, ool.invoice_to_org_id, ool.inventory_item_id, ool.tax_code, ool.tax_rate, ool.schedule_status_code,
             ool.price_list_id, ool.pricing_date, ool.shipment_number, ool.shipment_priority_code, wnd_sm.description,
             ool.freight_terms_code, ool.freight_carrier_code, fob_lkp.description, ool.payment_term_id, ool.return_context,
             ool.return_attribute3, ool.return_attribute1, ool.return_attribute2, ool.unit_selling_price,
             ool.unit_list_price, ool.unit_selling_price, ool.ordered_quantity, ool.tax_value, ool.creation_date, ool.created_by,
             ool.last_update_date, ool.last_updated_by, ool.item_type_code, ool.component_number, ool.item_type_code, ool.actual_shipment_date,
             ottl.name, qlht.name, rtt.name, hzp.party_name, cust_acct.account_number, ship_from_org.organization_code, ooh.order_number, ooh.quote_number,
             ooh.order_type_id, ooh.ordered_date, ret_reason.description, ool.split_from_line_id, ool.ship_set_id, ool.planning_priority, ool.shipping_instructions,
             ool.packing_instructions, ool.invoiced_quantity, ool.flow_status_code, ool.customer_line_number,
             ool.original_ordered_item, os.name, msi.attribute7, msi.description, rsa.name, wnd.delivery_id, wdd.attribute3,
             wdd.attribute8, wnd.gross_weight, wnd.attribute5, ool.option_number, ool.service_number,ool.attribute7   ----Neelima Y MYJIRATEST-8723
      ORDER BY ool.header_id, ool.line_number, ool.shipment_number, NVL(ool.option_number,-1), NVL(ool.component_number,-1), NVL(ool.service_number,-1)
             ;

   CURSOR C_INV(P_INVOICE_ID NUMBER, P_OU_ID NUMBER) IS
      SELECT ool.line_id, ool.org_id, ool.header_id, ool.line_number, ool.ordered_item, ool.request_date, ool.promise_date,
             ool.schedule_arrival_date, ool.schedule_ship_date, ool.order_quantity_uom, ool.cancelled_quantity, ool.shipped_quantity,
             ool.ordered_quantity, ool.fulfilled_quantity, ool.shipping_quantity, ool.tax_exempt_flag, ool.tax_exempt_number,
             ool.tax_exempt_reason_code, ool.cust_po_number, ool.sold_to_org_id, ool.ship_from_org_id, ool.ship_to_org_id,
             ool.deliver_to_org_id, ool.invoice_to_org_id, ool.inventory_item_id, ool.tax_code, ool.tax_rate, ool.schedule_status_code,
             ool.price_list_id, ool.pricing_date, ool.shipment_number, NVL((SELECT description
			 FROM fnd_lookup_values fv WHERE LOOKUP_TYPE='GEAE_WMS_AMPS_MYGE_PRY_LKP'
			 AND ool.shipment_priority_code=fv.lookup_code  --- Added by OWMS- ERL Team
			 AND enabled_flag='Y'),ool.shipment_priority_code) SHIPMENT_PRIORITY_CODE, delivery.shipping_method,
             ool.freight_terms_code, ool.freight_carrier_code, fob_lkp.description fob_point, ool.payment_term_id, ool.return_context,
             ool.return_attribute3 return_coo, ool.return_attribute1, ool.return_attribute2, ool.unit_selling_price,
             ool.unit_list_price, ool.unit_selling_price*ool.ordered_quantity ext_price, ool.tax_value, ool.creation_date, ool.created_by,
             ool.last_update_date, ool.last_updated_by, ool.item_type_code, ool.component_number,
             (DECODE (ool.item_type_code,'MODEL', (SELECT MAX (ol.actual_shipment_date)
                                                     FROM oe_order_lines_all ol
                                                    WHERE ol.link_to_line_id  = ool.line_id
                                                      AND ol.header_id        = ool.header_id
                                                      AND ol.org_id           = ool.org_id ),ool.actual_shipment_date)) actual_shipment_date,
             ottl.name line_type, qlht.name price_list, rtt.name payment_term, hzp.party_name sold_to, cust_acct.account_number customer_number,
             ship_from_org.organization_code ship_from, ooh.order_number, ooh.quote_number, ooh.order_type_id, ooh.ordered_date,
             ret_reason.description return_reason, ool.split_from_line_id, ool.ship_set_id, ool.planning_priority, ool.shipping_instructions,
             ool.packing_instructions, ool.invoiced_quantity, ool.flow_status_code, ool.customer_line_number,
             ool.original_ordered_item, os.name order_source, msi.attribute7 keyword, msi.description part_nomen, rsa.name sales_person,
             delivery.delivery_id, rctl.trx_number invoice_number, rctl.customer_trx_id invoice_id,
             ROUND(((ool.unit_list_price - ool.unit_selling_price)*100)/DECODE(ool.unit_list_price,0,1,ool.unit_list_price),2) discount_percentage,
             (ool.unit_list_price - ool.unit_selling_price)*ool.ordered_quantity discount_amount, rctl.trx_date invoice_date,
             rctl.extended_amount invoice_value,
             wdd.attribute3 ms_number, SUM(wdd.shipped_quantity) shipment_quantity, wdd.attribute8 dimensions,
             delivery.gross_weight, delivery.link_to_carrier, NVL(ool.option_number,-1), NVL(ool.service_number,-1),
             (SELECT catalog_upq FROM GEAE_QP_ITEM_PRICES_V WHERE price_list_name = qlht.name AND inventory_item_id = to_char(ool.inventory_item_id)) upq,
             DECODE(ool.item_type_code,'MODEL','N','Y') qty_upd_allowed,
             GET_ORIG_PO_NUMBER(ool.return_context,ool.return_attribute1,ool.return_attribute2) orig_po_for_return,
             GET_LINE_DWLD_TO_WMS(ool.header_id, ool.line_id) dwld_to_wms,
             GET_SHIP_LINE_FLAG(ool.header_id, ool.line_id) shipping_line_flag,
             GET_COO(ool.org_id,ool.header_id, ool.line_id) country_of_origin,
             GET_SHIP_STATUS(ool.org_id,ool.header_id, ool.line_id) shipping_status,
             GET_SERIAL_NUMBERS(ool.org_id,ool.header_id, ool.line_id) serial_numbers,
             GET_DISP_ALLWD_FLG(ool.org_id,ool.header_id, ool.line_id) dispute_allowed,
             --Manisha 29-Mar-2019 Modified the ESN code as it can be alphanumeric
            -- substr(ool.attribute7,1,6) mygea_esn,  ----Neelima Y MYJIRATEST-8723
			--Manisha 29-Mar-2019 DE44340 Modified the ESN code as it can be alphanumeric
            SUBSTR(REGEXP_SUBSTR(REPLACE(REPLACE(ool.attribute7,',',' '),'~',','), '([^,]*)(,|$)', 1, 1,NULL, 1),1,6) mygea_esn,
             GET_DISP_CREATED_FLG(ool.org_id,ool.header_id, ool.line_id) dispute_created, ----MYJIRATEST-3745 TRUPTI D. 31-MAR-2016
/**Manisha 15-Feb-2019 Rewrote the code for wsp_date and qty to resolve the issue of skipping over null values of workstop date and workstop qty***/
			-- cast( REGEXP_SUBSTR (ool.attribute7, '[^~]+', 1, 2) as date) workstp_date,    --Added by Manisha
--			To_date(REGEXP_SUBSTR (ool.attribute7, '[^~]+', 1, 2), 'YYYY/MM/DD hh24:mi:ss')workstp_date, -- Added by Suguna
--             cast(REGEXP_SUBSTR (ool.attribute7, '[^~]+', 1, 3) as number) workstp_qty     --Added by Manisha
        To_date(REGEXP_SUBSTR(REPLACE(REPLACE(ool.attribute7,',','  '),'~',','), '([^,]*)(,|$)', 1, 2,NULL, 1), 'YYYY/MM/DD hh24:mi:ss') workstp_date,
        cast(REGEXP_SUBSTR(REPLACE(REPLACE(ool.attribute7,',','  '),'~',','), '([^,]*)(,|$)', 1, 3,NULL, 1)as number) workstp_qty     --Added by Manisha
        FROM oe_order_lines_all ool, oe_order_headers_all ooh,
             (SELECT ih.customer_trx_id, ih.trx_number, ih.trx_date, --MYJIRATEST-5333 Ravi S 29-JAN-2015
                     DECODE(il.interface_line_context,'ORDER ENTRY',to_number(il.interface_line_attribute6),NULL) line_id,
                     ih.sold_to_customer_id, ih.org_id, SUM(il.extended_amount) extended_amount
                FROM ra_customer_trx_lines_all il, ra_customer_trx_all ih
               WHERE il.line_type = 'LINE' AND ih.customer_trx_id = il.customer_trx_id AND ih.org_id = P_OU_ID
              GROUP BY ih.customer_trx_id, ih.trx_number, ih.trx_date,
                       DECODE(il.interface_line_context,'ORDER ENTRY',to_number(il.interface_line_attribute6),NULL),
                       ih.sold_to_customer_id, ih.org_id
              ) rctl,
              (SELECT * FROM wsh_delivery_details WHERE requested_quantity <> 0 AND released_status <> 'B') wdd,
              (SELECT wda.delivery_detail_id, wnd.delivery_id, wnd.gross_weight, wnd.attribute5 link_to_carrier, wnd_sm.description shipping_method
                 FROM wsh_delivery_assignments wda, wsh_new_deliveries wnd, fnd_lookup_values wnd_sm
                WHERE wnd_sm.lookup_type(+) = 'SHIP_METHOD'
                  AND wnd_sm.lookup_code(+) = wnd.ship_method_code
                  AND wnd.delivery_id = wda.delivery_id) delivery,
              fnd_lookup_values fob_lkp, oe_transaction_types_tl ottl, qp_list_headers_tl qlht, ra_terms_tl rtt, hz_parties hzp,
              hz_cust_accounts cust_acct, mtl_parameters ship_from_org, ar_lookups ret_reason, oe_order_sources os, mtl_system_items msi,
              ra_salesreps_all rsa
        WHERE ool.header_id = ooh.header_id(+)
          AND ool.org_id = ooh.org_id(+)
          AND wdd.org_id(+) = ool.org_id
          AND ool.line_id(+) = rctl.line_id
          AND ool.line_id = wdd.source_line_id(+)
          AND ool.header_id = wdd.source_header_id(+)
          AND delivery.delivery_detail_id(+) = wdd.delivery_detail_id
          AND fob_lkp.lookup_type(+) = 'FOB'
          AND fob_lkp.lookup_code(+) = ool.fob_point_code
          AND fob_lkp.VIEW_APPLICATION_ID(+)=222  -- Added by Amita to resolve duplicate line dtl issue
          AND ool.line_type_id = ottl.transaction_type_id(+)
          AND ool.price_list_id = qlht.list_header_id(+)
          AND ool.payment_term_id = rtt.term_id(+)
          AND rctl.sold_to_customer_id = cust_acct.cust_account_id(+)
--         AND ool.item_type_code IN ('MODEL','STANDARD')
          AND ool.item_type_code NOT IN ('CLASS') --Changed by Neelima Y for MYJIRATEST-2207
          AND cust_acct.party_id = hzp.party_id(+)
          AND ool.ship_from_org_id = ship_from_org.organization_id(+)
          AND ret_reason.lookup_type(+) = 'CREDIT_MEMO_REASON'
          AND ret_reason.lookup_code(+) = ool.return_reason_code
          AND ooh.order_source_id = os.order_source_id(+)
          AND ool.inventory_item_id = msi.inventory_item_id(+)
          AND ool.ship_from_org_id = msi.organization_id(+)
          AND ool.salesrep_id = rsa.salesrep_id(+)
          AND ool.org_id(+) = rctl.org_id
          AND rctl.customer_trx_id = P_INVOICE_ID
      GROUP BY ool.line_id, ool.org_id, ool.header_id, ool.line_number, ool.ordered_item, ool.request_date, ool.promise_date,
             ool.schedule_arrival_date, ool.schedule_ship_date, ool.order_quantity_uom, ool.cancelled_quantity, ool.shipped_quantity,
             ool.ordered_quantity, ool.fulfilled_quantity, ool.shipping_quantity, ool.tax_exempt_flag, ool.tax_exempt_number,
             ool.tax_exempt_reason_code, ool.cust_po_number, ool.sold_to_org_id, ool.ship_from_org_id, ool.ship_to_org_id,
             ool.deliver_to_org_id, ool.invoice_to_org_id, ool.inventory_item_id, ool.tax_code, ool.tax_rate, ool.schedule_status_code,
             ool.price_list_id, ool.pricing_date, ool.shipment_number, ool.shipment_priority_code, delivery.shipping_method,
             ool.freight_terms_code, ool.freight_carrier_code, fob_lkp.description, ool.payment_term_id, ool.return_context,
             ool.return_attribute3, ool.return_attribute1, ool.return_attribute2, ool.unit_selling_price,
             ool.unit_list_price, ool.unit_selling_price, ool.ordered_quantity, ool.tax_value, ool.creation_date, ool.created_by,
             ool.last_update_date, ool.last_updated_by, ool.item_type_code, ool.component_number, ool.item_type_code, ool.actual_shipment_date,
             ottl.name, qlht.name, rtt.name, hzp.party_name, cust_acct.account_number, ship_from_org.organization_code, ooh.order_number, ooh.quote_number,
             ooh.order_type_id, ooh.ordered_date, ret_reason.description, ool.split_from_line_id, ool.ship_set_id, ool.planning_priority, ool.shipping_instructions,
             ool.packing_instructions, ool.invoiced_quantity, ool.flow_status_code, ool.customer_line_number,
             ool.original_ordered_item, os.name, msi.attribute7, msi.description, rsa.name, delivery.delivery_id, rctl.trx_number, rctl.customer_trx_id,
             rctl.trx_date, rctl.extended_amount, wdd.attribute3, wdd.attribute8, delivery.gross_weight, delivery.link_to_carrier,
             ool.option_number, ool.service_number,ool.attribute7   ----Neelima Y MYJIRATEST-8723
      ORDER BY ool.header_id, ool.line_number, ool.shipment_number, NVL(ool.option_number,-1), NVL(ool.component_number,-1), NVL(ool.service_number,-1)
             ;

BEGIN

   v_loc_msg := 'Initializing Out Parameters';
   P_ORDER_LINE_INFO_ARRAY  := V_ORDER_LINE_INFO_ARRAY();

   /*
    #########################################
    -- US225986
    -- Das, Debopam (212674555)
    #########################################
    */
    BEGIN
        -- Fetching OU ID For GE Aero Energy Services
        SELECT
               organization_id
        INTO
               lv_ou_id
        FROM
               hr_operating_units
        WHERE
               1        = 1
               AND name = lv_name
        ;

    EXCEPTION
    WHEN NO_DATA_FOUND THEN
        lv_ou_id := NULL;
    WHEN OTHERS THEN
        lv_ou_id := NULL;
    END; -- End of Debos change

   v_loc_msg := 'Checking input parameters';
   v_param_count := 0;
   IF P_DELIVERY_ID IS NOT NULL THEN
      v_param_count := v_param_count + 1;
   END IF;
   IF P_ORDER_ID IS NOT NULL THEN
      v_param_count := v_param_count + 1;
   END IF;
   IF P_INVOICE_ID IS NOT NULL THEN
      v_param_count := v_param_count + 1;
   END IF;
   IF v_param_count <> 1 THEN
      P_MSG := GET_ERR_MSG(8029);
      RAISE e_exit;
   END IF;
   IF P_OU_ID IS NULL THEN
      P_MSG := GET_ERR_MSG(8029);
      RAISE e_exit;
   END IF;
   v_loc_msg := 'Assigning OU ID';
  -- v_ou_id := TO_NUMBER(P_OU_ID);  --US225607; Manisha K, 24-OCT Commented the line as the OU_ID will be fetched according order_id, or invoice or delivery_id
   v_loc_msg := 'Getting simplified line status flag';
   --v_ln_simple_sts_flag := GET_SIMPLE_STS_FLAG(v_ou_id); -- commented and added after finding the ou id suguna-Dec 7 2018
   IF P_ORDER_ID IS NOT NULL THEN
      v_loc_msg := 'Getting details based on order_id';
      v_order_id := TO_NUMBER(P_ORDER_ID);
      v_loc_msg := 'Checking authorization for order';
      v_authorized := 'N';


/**********************************************************
US225607; Manisha K, 24-OCT Added the below code for Passport Requirement
If user have access for both OU ID's ,then the OU_ID will be fetched based on the order_id
***********************************************************/
   v_loc_msg := 'Fetching OU_ID Value';
   /*****************************************
14-March-2019- Manisha commenting the below if else condition
to fix the issue to see old CSO orders if customer is switched from cso to passport
*****************************************/
  --  IF P_OU_ID like '%~%' THEN
      BEGIN
      SELECT org_Id
      INTO v_OU_ID FROM oe_order_headers_all
      WHERE HEADER_ID =v_order_id;
      EXCEPTION
      WHEN OTHERS THEN
      P_MSG := 'Error while fetching the OU_ID: '||SQLCODE||SQLERRM;
      RAISE e_exit;
      END;
--  ELSE
--     v_ou_id := TO_NUMBER(P_OU_ID);
--  END IF;

  IF v_ou_id IS NULL THEN
        p_MSG:=GET_ERR_MSG(8503);
        RAISE e_exit;
    END IF;
v_ln_simple_sts_flag := GET_SIMPLE_STS_FLAG(v_ou_id); --commented in the begining of the procedure added here after finding the ou id

      BEGIN
         SELECT sold_to_org_id
           INTO v_cust_id
           FROM oe_order_headers_all
          WHERE header_id = v_order_id;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            P_MSG:=GET_ERR_MSG(8010);
            RAISE e_exit;
      END;
      IF P_ROLE = 'Global Enquiry' THEN
         v_authorized := 'Y';
      ELSE
         FOR i IN 1..P_CUST_ID.COUNT LOOP
            IF P_CUST_ID(i) = v_cust_id THEN
               v_authorized := 'Y';
            END IF;
         END LOOP;
      END IF;
      IF v_authorized = 'N' THEN
         P_MSG:=GET_ERR_MSG(8180);
         RAISE e_exit;
      END IF;
      v_loc_msg := 'Calling C_ORD Loop';
      v_loop_cnt := 0;
      FOR r_ord IN C_ORD(v_order_id, v_ou_id) LOOP
         v_loop_cnt := v_loop_cnt+1;
         v_loc_msg := 'Calling GET_CANCEL_FLAG in C_ORD Loop';
         v_upd_cancel_flag := GET_CANCEL_FLAG(r_ord.header_id,r_ord.line_id,r_ord.dwld_to_wms);
         v_loc_msg := 'Calling GET_CRITAL_PART_FLAG in C_ORD Loop';
         v_crital_part_flag:=GET_CRITAL_PART_FLAG(r_ord.header_id,r_ord.line_id,r_ord.inventory_item_id);
         v_loc_msg := 'Calling GET_ORD_LN_STATUS in C_ORD Loop';
         v_line_status := GET_ORD_LN_STATUS(v_ln_simple_sts_flag,r_ord.shipping_line_flag,r_ord.flow_status_code,r_ord.dwld_to_wms);
         v_loc_msg := 'Calling Address details in C_ORD Loop';
         GET_ADDRESS_DETAILS(r_ord.ship_to_org_id,v_ship_location,v_ship_address1,v_ship_address2,v_ship_address3,v_ship_address4,v_ship_address5,v_ship_address);
         GET_ADDRESS_DETAILS(r_ord.deliver_to_org_id,v_deliver_location,v_deliver_address1,v_deliver_address2,v_deliver_address3,v_deliver_address4,v_deliver_address5,v_deliver_address);
         GET_ADDRESS_DETAILS(r_ord.invoice_to_org_id,v_bill_location,v_bill_address1,v_bill_address2,v_bill_address3,v_bill_address4,v_bill_address5,v_bill_address);
         v_loc_msg := 'Extend VARRAY in C_ORD Loop';
         P_ORDER_LINE_INFO_ARRAY.EXTEND;
         v_loc_msg := 'Assigning VARRAY in C_ORD Loop';
         P_ORDER_LINE_INFO_ARRAY(P_ORDER_LINE_INFO_ARRAY.last):=
         V_ORDER_LINE_INFO_BO(r_ord.line_id, r_ord.org_id, r_ord.header_id, r_ord.line_number, r_ord.ordered_item, r_ord.request_date,
             r_ord.promise_date, r_ord.schedule_arrival_date, r_ord.schedule_ship_date, r_ord.order_quantity_uom, r_ord.cancelled_quantity,
             r_ord.shipped_quantity, r_ord.ordered_quantity, r_ord.fulfilled_quantity, r_ord.shipping_quantity, r_ord.tax_exempt_flag,
             r_ord.tax_exempt_number, r_ord.tax_exempt_reason_code, r_ord.cust_po_number, r_ord.sold_to_org_id, r_ord.ship_from_org_id,
             r_ord.ship_to_org_id, r_ord.deliver_to_org_id, r_ord.invoice_to_org_id, r_ord.inventory_item_id, r_ord.tax_code,
             r_ord.tax_rate, r_ord.schedule_status_code, r_ord.price_list_id, r_ord.pricing_date, r_ord.shipment_number,
             r_ord.shipment_priority_code, r_ord.shipping_method, r_ord.freight_terms_code, r_ord.freight_carrier_code, r_ord.fob_point,
             r_ord.payment_term_id, r_ord.return_context, r_ord.country_of_origin, r_ord.return_attribute1, r_ord.return_attribute2,
             r_ord.unit_selling_price, r_ord.unit_list_price, r_ord.ext_price, r_ord.tax_value, r_ord.creation_date, r_ord.created_by,
             r_ord.last_update_date, r_ord.last_updated_by, r_ord.item_type_code, r_ord.component_number, r_ord.actual_shipment_date,
             r_ord.line_type, r_ord.price_list, r_ord.payment_term, r_ord.sold_to, r_ord.customer_number, r_ord.ship_from,
             v_ship_location,v_ship_address1,v_ship_address2,v_ship_address3,v_ship_address4,v_ship_address5,
             v_deliver_location,v_deliver_address1,v_deliver_address2,v_deliver_address3,v_deliver_address4,v_deliver_address5,
             v_bill_location,v_bill_address1,v_bill_address2,v_bill_address3,v_bill_address4,v_bill_address5,
             r_ord.order_number, r_ord.quote_number, r_ord.order_type_id, r_ord.ordered_date, r_ord.return_reason,
             r_ord.split_from_line_id, r_ord.ship_set_id, r_ord.planning_priority, r_ord.shipping_instructions, r_ord.packing_instructions,
             r_ord.invoiced_quantity, v_line_status, r_ord.customer_line_number, r_ord.original_ordered_item, r_ord.order_source,
             r_ord.keyword, r_ord.part_nomen, r_ord.sales_person, r_ord.delivery_id, r_ord.invoice_number, r_ord.discount_percentage,
             r_ord.discount_amount, r_ord.invoice_date, r_ord.invoice_value, r_ord.orig_po_for_return, v_upd_cancel_flag, r_ord.dispute_allowed,
             r_ord.ms_number, r_ord.shipping_status, r_ord.shipment_quantity, r_ord.dimensions, r_ord.gross_weight, r_ord.serial_numbers,
             r_ord.link_to_carrier, r_ord.return_coo, r_ord.upq, r_ord.invoice_id, r_ord.qty_upd_allowed,v_ship_address,v_deliver_address,v_bill_address,r_ord.mygea_esn,r_ord.dispute_created,v_crital_part_flag  ----Neelima Y MYJIRATEST-8723 --MYJIRATEST-3745 TRUPTI D. 31-MAR-2016
			 ,r_ord.workstp_date, r_ord.workstp_qty);
      END LOOP;
      v_loc_msg := 'Checking if no lines retreived in C_ORD Loop';
      IF v_loop_cnt = 0 THEN
         P_MSG := GET_ERR_MSG(8031);
         RAISE e_exit;
      END IF;
   ELSIF P_DELIVERY_ID IS NOT NULL THEN
      v_loc_msg := 'Assigning DELIVERY_ID';
      v_delivery_id := TO_NUMBER(P_DELIVERY_ID);
      v_loc_msg := 'Checking authorization for Shipment';
      v_authorized := 'N';

/**********************************************************
US225607; Manisha K, 10-OCT Added the below code for Passport Requirement
If user have access for both OU ID's ,then the OU_ID will be fetched based on the delivery_id
***********************************************************/
     v_loc_msg := 'Fetching OU_ID Value';
/*****************************************
14-March-2019- Manisha commenting the below if else condition
to fix the issue to see old CSO orders if customer is switched from cso to passport
*****************************************/
  --  IF P_OU_ID like '%~%' THEN
      BEGIN
       SELECT  distinct wdd.org_id
       INTO v_OU_ID
        FROM wsh_delivery_details wdd, wsh_delivery_assignments wda --, wsh_new_deliveries wnd, ar_customers ac, mtl_parameters mtp
       WHERE 1=1 --wdd.org_id = P_OU_ID
         AND wdd.delivery_detail_id = wda.delivery_detail_id
        -- AND wnd.delivery_id = wda.delivery_id
        -- AND wdd.customer_id = ac.customer_id
        -- AND mtp.organization_id = wdd.organization_id
         AND wda.delivery_id = v_delivery_id
         AND wdd.org_id is not null;   -- Manisha added this comment as more than one row was getting fetched including null value;
      EXCEPTION
      WHEN OTHERS THEN
      P_MSG := 'Error while fetching the OU_ID for delivery ID: '||SQLCODE||SQLERRM;
      RAISE e_exit;
      END;
--  ELSE
--     v_ou_id := TO_NUMBER(P_OU_ID);
--  END IF;

  IF v_ou_id IS NULL THEN
        p_MSG:=GET_ERR_MSG(8503);
        RAISE e_exit;
    END IF;

v_ln_simple_sts_flag := GET_SIMPLE_STS_FLAG(v_ou_id); --commented in the begining of the procedure added here after finding the ou id

      BEGIN
         SELECT wdd.customer_id
           INTO v_cust_id
           FROM wsh_delivery_assignments wda, wsh_delivery_details wdd
          WHERE wda.delivery_detail_id = wdd.delivery_detail_id
            AND wda.delivery_id = v_delivery_id
            AND rownum = 1;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            P_MSG:=GET_ERR_MSG(8029);
            RAISE e_exit;
      END;
      IF P_ROLE = 'Global Enquiry' THEN
         v_authorized := 'Y';
      ELSE
         FOR i IN 1..P_CUST_ID.COUNT LOOP
            IF P_CUST_ID(i) = v_cust_id THEN
               v_authorized := 'Y';
            END IF;
         END LOOP;
      END IF;
      IF v_authorized = 'N' THEN
         P_MSG:=GET_ERR_MSG(8180);
         RAISE e_exit;
      END IF;
      IF P_MS_NUMBER IS NOT NULL THEN
         v_loc_msg := 'Getting details based on delivery_id and ms number';
         v_loop_cnt := 0;
         v_loc_msg := 'Calling Loop C_SHP_MS';
         FOR r_shp_ms IN C_SHP_MS(v_delivery_id, P_MS_NUMBER, v_ou_id) LOOP
            v_loop_cnt := v_loop_cnt+1;
            v_loc_msg := 'Calling GET_CANCEL_FLAG in C_SHP_MS Loop';
            v_upd_cancel_flag := GET_CANCEL_FLAG(r_shp_ms.header_id,r_shp_ms.line_id,r_shp_ms.dwld_to_wms);
            v_loc_msg := 'Calling GET_CRITAL_PART_FLAG in C_SHP_MS Loop';
            v_crital_part_flag:=GET_CRITAL_PART_FLAG(r_shp_ms.header_id,r_shp_ms.line_id,r_shp_ms.inventory_item_id);
            v_loc_msg := 'Calling GET_ORD_LN_STATUS in C_SHP_MS Loop';
            v_line_status := GET_ORD_LN_STATUS(v_ln_simple_sts_flag,r_shp_ms.shipping_line_flag,r_shp_ms.flow_status_code,r_shp_ms.dwld_to_wms);
            v_loc_msg := 'Getting address details in Loop C_SHP_MS';
            GET_ADDRESS_DETAILS(r_shp_ms.ship_to_org_id,v_ship_location,v_ship_address1,v_ship_address2,v_ship_address3,v_ship_address4,v_ship_address5,v_ship_address);
            GET_ADDRESS_DETAILS(r_shp_ms.deliver_to_org_id,v_deliver_location,v_deliver_address1,v_deliver_address2,v_deliver_address3,v_deliver_address4,v_deliver_address5,v_deliver_address);
            GET_ADDRESS_DETAILS(r_shp_ms.invoice_to_org_id,v_bill_location,v_bill_address1,v_bill_address2,v_bill_address3,v_bill_address4,v_bill_address5,v_bill_address);
            v_loc_msg := 'Extending VARRAY in Loop C_SHP_MS';
            P_ORDER_LINE_INFO_ARRAY.EXTEND;
            v_loc_msg := 'Assigning VARRAY in Loop C_SHP_MS';
            P_ORDER_LINE_INFO_ARRAY(P_ORDER_LINE_INFO_ARRAY.last):=
            V_ORDER_LINE_INFO_BO(r_shp_ms.line_id, r_shp_ms.org_id, r_shp_ms.header_id, r_shp_ms.line_number, r_shp_ms.ordered_item, r_shp_ms.request_date,
             r_shp_ms.promise_date, r_shp_ms.schedule_arrival_date, r_shp_ms.schedule_ship_date, r_shp_ms.order_quantity_uom, r_shp_ms.cancelled_quantity,
             r_shp_ms.shipped_quantity, r_shp_ms.ordered_quantity, r_shp_ms.fulfilled_quantity, r_shp_ms.shipping_quantity, r_shp_ms.tax_exempt_flag,
             r_shp_ms.tax_exempt_number, r_shp_ms.tax_exempt_reason_code, r_shp_ms.cust_po_number, r_shp_ms.sold_to_org_id, r_shp_ms.ship_from_org_id,
             r_shp_ms.ship_to_org_id, r_shp_ms.deliver_to_org_id, r_shp_ms.invoice_to_org_id, r_shp_ms.inventory_item_id, r_shp_ms.tax_code,
             r_shp_ms.tax_rate, r_shp_ms.schedule_status_code, r_shp_ms.price_list_id, r_shp_ms.pricing_date, r_shp_ms.shipment_number,
             r_shp_ms.shipment_priority_code, r_shp_ms.shipping_method, r_shp_ms.freight_terms_code, r_shp_ms.freight_carrier_code, r_shp_ms.fob_point,
             r_shp_ms.payment_term_id, r_shp_ms.return_context, r_shp_ms.country_of_origin, r_shp_ms.return_attribute1, r_shp_ms.return_attribute2,
             r_shp_ms.unit_selling_price, r_shp_ms.unit_list_price, r_shp_ms.ext_price, r_shp_ms.tax_value, r_shp_ms.creation_date, r_shp_ms.created_by,
             r_shp_ms.last_update_date, r_shp_ms.last_updated_by, r_shp_ms.item_type_code, r_shp_ms.component_number, r_shp_ms.actual_shipment_date,
             r_shp_ms.line_type, r_shp_ms.price_list, r_shp_ms.payment_term, r_shp_ms.sold_to, r_shp_ms.customer_number, r_shp_ms.ship_from,
             v_ship_location,v_ship_address1,v_ship_address2,v_ship_address3,v_ship_address4,v_ship_address5,
             v_deliver_location,v_deliver_address1,v_deliver_address2,v_deliver_address3,v_deliver_address4,v_deliver_address5,
             v_bill_location,v_bill_address1,v_bill_address2,v_bill_address3,v_bill_address4,v_bill_address5,
             r_shp_ms.order_number, r_shp_ms.quote_number, r_shp_ms.order_type_id, r_shp_ms.ordered_date, r_shp_ms.return_reason,
             r_shp_ms.split_from_line_id, r_shp_ms.ship_set_id, r_shp_ms.planning_priority, r_shp_ms.shipping_instructions, r_shp_ms.packing_instructions,
             r_shp_ms.invoiced_quantity, v_line_status, r_shp_ms.customer_line_number, r_shp_ms.original_ordered_item, r_shp_ms.order_source,
             r_shp_ms.keyword, r_shp_ms.part_nomen, r_shp_ms.sales_person, r_shp_ms.delivery_id, r_shp_ms.invoice_number, r_shp_ms.discount_percentage,
             r_shp_ms.discount_amount, r_shp_ms.invoice_date, r_shp_ms.invoice_value, r_shp_ms.orig_po_for_return, v_upd_cancel_flag, r_shp_ms.dispute_allowed,
             r_shp_ms.ms_number, r_shp_ms.shipping_status, r_shp_ms.shipment_quantity, r_shp_ms.dimensions, r_shp_ms.gross_weight, r_shp_ms.serial_numbers,
             r_shp_ms.link_to_carrier, r_shp_ms.return_coo, r_shp_ms.upq, r_shp_ms.invoice_id, r_shp_ms.qty_upd_allowed,v_ship_address,v_deliver_address,v_bill_address,r_shp_ms.mygea_esn,r_shp_ms.dispute_created,v_crital_part_flag ----Neelima Y MYJIRATEST-8723 --MYJIRATEST-3745 TRUPTI D. 31-MAR-2016
			 ,r_shp_ms.workstp_date, r_shp_ms.workstp_qty);  --Added By Manisha
         END LOOP;
         v_loc_msg := 'Checking Loop count after Loop C_SHP_MS';
         IF v_loop_cnt = 0 THEN
            P_MSG := GET_ERR_MSG(8031);
            RAISE e_exit;
         END IF;
      ELSE
         v_loc_msg := 'Getting details based on delivery_id and ms number being null';
         v_loop_cnt := 0;
         v_loc_msg := 'Calling Loop C_SHP';
         FOR r_shp IN C_SHP(v_delivery_id, v_ou_id) LOOP
            v_loop_cnt := v_loop_cnt+1;
            v_loc_msg := 'Calling GET_CANCEL_FLAG in C_SHP Loop';
            v_upd_cancel_flag := GET_CANCEL_FLAG(r_shp.header_id,r_shp.line_id,r_shp.dwld_to_wms);
            v_loc_msg := 'Calling GET_CRITAL_PART_FLAG in C_SHP Loop';
            v_crital_part_flag:=GET_CRITAL_PART_FLAG(r_shp.header_id,r_shp.line_id,r_shp.inventory_item_id);
            v_loc_msg := 'Calling GET_ORD_LN_STATUS in C_SHP Loop';
            v_line_status := GET_ORD_LN_STATUS(v_ln_simple_sts_flag,r_shp.shipping_line_flag,r_shp.flow_status_code,r_shp.dwld_to_wms);
            v_loc_msg := 'Getting address in Loop C_SHP';
            GET_ADDRESS_DETAILS(r_shp.ship_to_org_id,v_ship_location,v_ship_address1,v_ship_address2,v_ship_address3,v_ship_address4,v_ship_address5,v_ship_address);
            GET_ADDRESS_DETAILS(r_shp.deliver_to_org_id,v_deliver_location,v_deliver_address1,v_deliver_address2,v_deliver_address3,v_deliver_address4,v_deliver_address5,v_deliver_address);
            GET_ADDRESS_DETAILS(r_shp.invoice_to_org_id,v_bill_location,v_bill_address1,v_bill_address2,v_bill_address3,v_bill_address4,v_bill_address5,v_bill_address);
            v_loc_msg := 'Extending VARRAY in Loop C_SHP';
            P_ORDER_LINE_INFO_ARRAY.EXTEND;
            v_loc_msg := 'Assigning VARRAY in Loop C_SHP';
            P_ORDER_LINE_INFO_ARRAY(P_ORDER_LINE_INFO_ARRAY.last):=
            V_ORDER_LINE_INFO_BO(r_shp.line_id, r_shp.org_id, r_shp.header_id, r_shp.line_number, r_shp.ordered_item, r_shp.request_date,
             r_shp.promise_date, r_shp.schedule_arrival_date, r_shp.schedule_ship_date, r_shp.order_quantity_uom, r_shp.cancelled_quantity,
             r_shp.shipped_quantity, r_shp.ordered_quantity, r_shp.fulfilled_quantity, r_shp.shipping_quantity, r_shp.tax_exempt_flag,
             r_shp.tax_exempt_number, r_shp.tax_exempt_reason_code, r_shp.cust_po_number, r_shp.sold_to_org_id, r_shp.ship_from_org_id,
             r_shp.ship_to_org_id, r_shp.deliver_to_org_id, r_shp.invoice_to_org_id, r_shp.inventory_item_id, r_shp.tax_code,
             r_shp.tax_rate, r_shp.schedule_status_code, r_shp.price_list_id, r_shp.pricing_date, r_shp.shipment_number,
             r_shp.shipment_priority_code, r_shp.shipping_method, r_shp.freight_terms_code, r_shp.freight_carrier_code, r_shp.fob_point,
             r_shp.payment_term_id, r_shp.return_context, r_shp.country_of_origin, r_shp.return_attribute1, r_shp.return_attribute2,
             r_shp.unit_selling_price, r_shp.unit_list_price, r_shp.ext_price, r_shp.tax_value, r_shp.creation_date, r_shp.created_by,
             r_shp.last_update_date, r_shp.last_updated_by, r_shp.item_type_code, r_shp.component_number, r_shp.actual_shipment_date,
             r_shp.line_type, r_shp.price_list, r_shp.payment_term, r_shp.sold_to, r_shp.customer_number, r_shp.ship_from,
             v_ship_location,v_ship_address1,v_ship_address2,v_ship_address3,v_ship_address4,v_ship_address5,
             v_deliver_location,v_deliver_address1,v_deliver_address2,v_deliver_address3,v_deliver_address4,v_deliver_address5,
             v_bill_location,v_bill_address1,v_bill_address2,v_bill_address3,v_bill_address4,v_bill_address5,
             r_shp.order_number, r_shp.quote_number, r_shp.order_type_id, r_shp.ordered_date, r_shp.return_reason,
             r_shp.split_from_line_id, r_shp.ship_set_id, r_shp.planning_priority, r_shp.shipping_instructions, r_shp.packing_instructions,
             r_shp.invoiced_quantity, v_line_status, r_shp.customer_line_number, r_shp.original_ordered_item, r_shp.order_source,
             r_shp.keyword, r_shp.part_nomen, r_shp.sales_person, r_shp.delivery_id, r_shp.invoice_number, r_shp.discount_percentage,
             r_shp.discount_amount, r_shp.invoice_date, r_shp.invoice_value, r_shp.orig_po_for_return, v_upd_cancel_flag, r_shp.dispute_allowed,
             r_shp.ms_number, r_shp.shipping_status, r_shp.shipment_quantity, r_shp.dimensions, r_shp.gross_weight, r_shp.serial_numbers,
             r_shp.link_to_carrier, r_shp.return_coo, r_shp.upq, r_shp.invoice_id, r_shp.qty_upd_allowed,v_ship_address,v_deliver_address,v_bill_address,r_shp.mygea_esn,r_shp.dispute_created,v_crital_part_flag  ----Neelima Y MYJIRATEST-8723 --MYJIRATEST-3745 TRUPTI D. 31-MAR-2016
			 ,r_shp.workstp_date, r_shp.workstp_qty);  --Added By Manisha
         END LOOP;
         v_loc_msg := 'Checking Loop count in Loop C_SHP';
         IF v_loop_cnt = 0 THEN
            P_MSG := GET_ERR_MSG(8031);
            RAISE e_exit;
         END IF;
      END IF;
   ELSIF P_INVOICE_ID IS NOT NULL THEN
      v_loc_msg := 'Getting details based on invoice_id';
      v_invoice_id := TO_NUMBER(P_INVOICE_ID);
      v_loc_msg := 'Checking authorization for invoice';
      v_authorized := 'N';

/**********************************************************
US225607; Manisha K, 24-OCT Added the below code for Passport Requirement
If user have access for both OU ID's ,then the OU_ID will be fetched based on the order_id
***********************************************************/
     v_loc_msg := 'Fetching OU_ID Value';
     /*****************************************
14-March-2019- Manisha commenting the below if else condition
to fix the issue to see old CSO orders if customer is switched from cso to passport
*****************************************/
  --  IF P_OU_ID like '%~%' THEN
      BEGIN
      SELECT org_id
       into v_OU_ID
       FROM ra_customer_trx_all
       WHERE customer_trx_id = P_INVOICE_ID;
      EXCEPTION
      WHEN OTHERS THEN
      P_MSG := 'Error while fetching the OU_ID for invoice ID: '||SQLCODE||SQLERRM;
      RAISE e_exit;
      END;
--  ELSE
--     v_ou_id := TO_NUMBER(P_OU_ID);
--  END IF;

  IF v_ou_id IS NULL THEN
        p_MSG:=GET_ERR_MSG(8503);
        RAISE e_exit;
    END IF;
v_ln_simple_sts_flag := GET_SIMPLE_STS_FLAG(v_ou_id); --commented in the begining of the procedure added here after finding the ou id

      BEGIN
         SELECT sold_to_customer_id
           INTO v_cust_id
           FROM ra_customer_trx_all
          WHERE customer_trx_id = v_invoice_id;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            P_MSG:=GET_ERR_MSG(8029);
            RAISE e_exit;
      END;
      IF P_ROLE = 'Global Enquiry' THEN
         v_authorized := 'Y';
      ELSE
         FOR i IN 1..P_CUST_ID.COUNT LOOP
            IF P_CUST_ID(i) = v_cust_id THEN
               v_authorized := 'Y';
            END IF;
         END LOOP;
      END IF;
      IF v_authorized = 'N' THEN
         P_MSG:=GET_ERR_MSG(8180);
         RAISE e_exit;
      END IF;
      v_loop_cnt := 0;
      v_loc_msg := 'Calling Loop C_INV';
      FOR r_inv IN C_INV(v_invoice_id, v_ou_id) LOOP
         v_loop_cnt := v_loop_cnt+1;
         v_loc_msg := 'Calling GET_CANCEL_FLAG in C_INV Loop';
         v_upd_cancel_flag := GET_CANCEL_FLAG(r_inv.header_id,r_inv.line_id,r_inv.dwld_to_wms);
         v_loc_msg := 'Calling GET_ORD_LN_STATUS in C_INV Loop';
         v_line_status := GET_ORD_LN_STATUS(v_ln_simple_sts_flag,r_inv.shipping_line_flag,r_inv.flow_status_code,r_inv.dwld_to_wms);
         v_loc_msg := 'Calling GET_CRITAL_PART_FLAG in C_INV Loop';
         v_crital_part_flag:=GET_CRITAL_PART_FLAG(r_inv.header_id,r_inv.line_id,r_inv.inventory_item_id);
         v_loc_msg := 'Getting address in Loop C_INV';
         GET_ADDRESS_DETAILS(r_inv.ship_to_org_id,v_ship_location,v_ship_address1,v_ship_address2,v_ship_address3,v_ship_address4,v_ship_address5,v_ship_address);
         GET_ADDRESS_DETAILS(r_inv.deliver_to_org_id,v_deliver_location,v_deliver_address1,v_deliver_address2,v_deliver_address3,v_deliver_address4,v_deliver_address5,v_deliver_address);
         GET_ADDRESS_DETAILS(r_inv.invoice_to_org_id,v_bill_location,v_bill_address1,v_bill_address2,v_bill_address3,v_bill_address4,v_bill_address5,v_bill_address);
         v_loc_msg := 'Extending VARRAY in Loop C_INV';
         P_ORDER_LINE_INFO_ARRAY.EXTEND;
         v_loc_msg := 'Assigning VARRAY in Loop C_INV';
         P_ORDER_LINE_INFO_ARRAY(P_ORDER_LINE_INFO_ARRAY.last):=
         V_ORDER_LINE_INFO_BO(r_inv.line_id, r_inv.org_id, r_inv.header_id, r_inv.line_number, r_inv.ordered_item, r_inv.request_date,
             r_inv.promise_date, r_inv.schedule_arrival_date, r_inv.schedule_ship_date, r_inv.order_quantity_uom, r_inv.cancelled_quantity,
             r_inv.shipped_quantity, r_inv.ordered_quantity, r_inv.fulfilled_quantity, r_inv.shipping_quantity, r_inv.tax_exempt_flag,
             r_inv.tax_exempt_number, r_inv.tax_exempt_reason_code, r_inv.cust_po_number, r_inv.sold_to_org_id, r_inv.ship_from_org_id,
             r_inv.ship_to_org_id, r_inv.deliver_to_org_id, r_inv.invoice_to_org_id, r_inv.inventory_item_id, r_inv.tax_code,
             r_inv.tax_rate, r_inv.schedule_status_code, r_inv.price_list_id, r_inv.pricing_date, r_inv.shipment_number,
             r_inv.shipment_priority_code, r_inv.shipping_method, r_inv.freight_terms_code, r_inv.freight_carrier_code, r_inv.fob_point,
             r_inv.payment_term_id, r_inv.return_context, r_inv.country_of_origin, r_inv.return_attribute1, r_inv.return_attribute2,
             r_inv.unit_selling_price, r_inv.unit_list_price, r_inv.ext_price, r_inv.tax_value, r_inv.creation_date, r_inv.created_by,
             r_inv.last_update_date, r_inv.last_updated_by, r_inv.item_type_code, r_inv.component_number, r_inv.actual_shipment_date,
             r_inv.line_type, r_inv.price_list, r_inv.payment_term, r_inv.sold_to, r_inv.customer_number, r_inv.ship_from,
             v_ship_location,v_ship_address1,v_ship_address2,v_ship_address3,v_ship_address4,v_ship_address5,
             v_deliver_location,v_deliver_address1,v_deliver_address2,v_deliver_address3,v_deliver_address4,v_deliver_address5,
             v_bill_location,v_bill_address1,v_bill_address2,v_bill_address3,v_bill_address4,v_bill_address5,
             r_inv.order_number, r_inv.quote_number, r_inv.order_type_id, r_inv.ordered_date, r_inv.return_reason,
             r_inv.split_from_line_id, r_inv.ship_set_id, r_inv.planning_priority, r_inv.shipping_instructions, r_inv.packing_instructions,
             r_inv.invoiced_quantity, v_line_status, r_inv.customer_line_number, r_inv.original_ordered_item, r_inv.order_source,
             r_inv.keyword, r_inv.part_nomen, r_inv.sales_person, r_inv.delivery_id, r_inv.invoice_number, r_inv.discount_percentage,
             r_inv.discount_amount, r_inv.invoice_date, r_inv.invoice_value, r_inv.orig_po_for_return, v_upd_cancel_flag, r_inv.dispute_allowed,
             r_inv.ms_number, r_inv.shipping_status, r_inv.shipment_quantity, r_inv.dimensions, r_inv.gross_weight, r_inv.serial_numbers,
             r_inv.link_to_carrier, r_inv.return_coo, r_inv.upq, r_inv.invoice_id, r_inv.qty_upd_allowed,v_ship_address,v_deliver_address,v_bill_address,r_inv.mygea_esn,r_inv.dispute_created,v_crital_part_flag  ----Neelima Y MYJIRATEST-8723 --MYJIRATEST-3745 TRUPTI D. 31-MAR-2016
			 ,r_inv.workstp_date, r_inv.workstp_qty); --Added By Manisha
      END LOOP;
      v_loc_msg := 'Checking Loop count in Loop C_INV';
      IF v_loop_cnt = 0 THEN
         P_MSG := GET_ERR_MSG(8031);
         RAISE e_exit;
      END IF;
   END IF;
EXCEPTION
   WHEN e_exit THEN
      NULL;
   WHEN OTHERS THEN
      P_MSG := '8000:Error while '||v_loc_msg||' '||SUBSTR(SQLERRM,1,100);
END GET_LINE_INFO;


PROCEDURE GET_ADDRESS_DETAILS(
     P_SITE_USE_ID NUMBER,
     P_LOCATION OUT VARCHAR2,
     P_ADDRESS1 OUT VARCHAR2,
     P_ADDRESS2 OUT VARCHAR2,
     P_ADDRESS3 OUT VARCHAR2,
     P_ADDRESS4 OUT VARCHAR2,
     P_ADDRESS5 OUT VARCHAR2,
     P_ADDRESS  OUT VARCHAR2)  --MYJIRATEST-4206 Ravi S 24-NOV-2014
AS
  --

BEGIN
   BEGIN
      SELECT su.location, loc.address1, loc.address2, loc.address3, loc.address4,
             DECODE (loc.city,
                        NULL, NULL,
                        loc.city || ', '
                       )
             || DECODE (loc.state,
                        NULL, loc.province || ', ',
                        loc.state || ', '
                       )
             || DECODE (loc.postal_code,
                        NULL, NULL,
                        loc.postal_code || ', '
                       )
             || DECODE (loc.country, NULL, NULL, loc.country)
        INTO P_LOCATION, P_ADDRESS1, P_ADDRESS2, P_ADDRESS3, P_ADDRESS4, P_ADDRESS5
        FROM hz_cust_site_uses_all su,
             hz_locations loc,
             hz_party_sites ps,
             hz_cust_acct_sites_all cas
       WHERE su.site_use_id = P_SITE_USE_ID
         AND su.cust_acct_site_id = cas.cust_acct_site_id(+)
         AND cas.party_site_id = ps.party_site_id(+)
         AND loc.location_id(+) = ps.location_id
         AND rownum = 1;
   EXCEPTION
      WHEN OTHERS THEN
         P_LOCATION := NULL;
         P_ADDRESS1 := NULL;
         P_ADDRESS2 := NULL;
         P_ADDRESS3 := NULL;
         P_ADDRESS4 := NULL;
         P_ADDRESS5 := NULL;
   END;
   --MYJIRATEST-4206 Ravi S 24-NOV-2014
   IF P_ADDRESS1 IS NOT NULL THEN
      P_ADDRESS := P_ADDRESS1;
   END IF;
   IF P_ADDRESS2 IS NOT NULL THEN
      IF P_ADDRESS IS NOT NULL THEN
         P_ADDRESS := P_ADDRESS || chr(10) || P_ADDRESS2;
      ELSE
         P_ADDRESS := P_ADDRESS2;
      END IF;
   END IF;
   IF P_ADDRESS3 IS NOT NULL THEN
      IF P_ADDRESS IS NOT NULL THEN
         P_ADDRESS := P_ADDRESS || chr(10) || P_ADDRESS3;
      ELSE
         P_ADDRESS := P_ADDRESS3;
      END IF;
   END IF;
   IF P_ADDRESS4 IS NOT NULL THEN
      IF P_ADDRESS IS NOT NULL THEN
         P_ADDRESS := P_ADDRESS || chr(10) || P_ADDRESS4;
      ELSE
         P_ADDRESS := P_ADDRESS4;
      END IF;
   END IF;
   IF P_ADDRESS5 IS NOT NULL THEN
      IF P_ADDRESS IS NOT NULL THEN
         P_ADDRESS := P_ADDRESS || chr(10) || P_ADDRESS5;
      ELSE
         P_ADDRESS := P_ADDRESS5;
      END IF;
   END IF;
END GET_ADDRESS_DETAILS;

FUNCTION GET_SERIAL_NUMBERS(P_OU_ID IN NUMBER,
                            P_ORDER_ID IN NUMBER,
                            P_LINE_ID IN NUMBER)
    RETURN VARCHAR2
AS
   V_SERIAL_NUMBERS VARCHAR2(30000);
   V_CNT NUMBER;
   CURSOR C_SERIAL_NUMBERS(P_ORDER_ID NUMBER, P_LINE_ID NUMBER, P_OU_ID NUMBER) IS
      SELECT gosd.serial_number
        FROM wsh_delivery_details wdd, geae_ont_serial_details gosd
       WHERE wdd.org_id = P_OU_ID
         AND wdd.source_header_id = P_ORDER_ID
         AND wdd.source_line_id = P_LINE_ID
         AND wdd.requested_quantity <> 0
         AND wdd.delivery_detail_id = gosd.delivery_detail_id
      GROUP BY gosd.serial_number;
BEGIN
   SELECT COUNT(*)
     INTO V_CNT
     FROM (SELECT DISTINCT gosd.serial_number
             FROM wsh_delivery_details wdd, geae_ont_serial_details gosd
            WHERE wdd.org_id = P_OU_ID
              AND wdd.source_header_id = P_ORDER_ID
              AND wdd.source_line_id = P_LINE_ID
              AND wdd.requested_quantity <> 0
              AND wdd.delivery_detail_id = gosd.delivery_detail_id);
   IF V_CNT > 1 THEN
      BEGIN
         FOR r_serial_numbers IN C_SERIAL_NUMBERS(P_ORDER_ID, P_LINE_ID, P_OU_ID) LOOP
            V_SERIAL_NUMBERS := V_SERIAL_NUMBERS||r_serial_numbers.serial_number||'|';
         END LOOP;
      EXCEPTION
         WHEN OTHERS THEN
            V_SERIAL_NUMBERS := NULL;
      END;
   ELSE
      BEGIN
         SELECT gosd.serial_number
           INTO V_SERIAL_NUMBERS
           FROM wsh_delivery_details wdd, geae_ont_serial_details gosd
          WHERE wdd.org_id = P_OU_ID
            AND wdd.source_header_id = P_ORDER_ID
            AND wdd.source_line_id = P_LINE_ID
            AND wdd.requested_quantity <> 0
            AND wdd.delivery_detail_id = gosd.delivery_detail_id
         GROUP BY gosd.serial_number;
      EXCEPTION
         WHEN OTHERS THEN
            V_SERIAL_NUMBERS := NULL;
      END;
   END IF;

   RETURN V_SERIAL_NUMBERS;

EXCEPTION
   WHEN OTHERS THEN
      RETURN NULL;
END GET_SERIAL_NUMBERS;

FUNCTION GET_SHIP_STATUS(P_OU_ID IN NUMBER,
                         P_ORDER_ID IN NUMBER,
                         P_LINE_ID IN NUMBER)
    RETURN VARCHAR2
AS
   V_SHIP_STATUS VARCHAR2(1000);
   V_CNT NUMBER;
   CURSOR C_SHIP_STATUS(P_ORDER_ID NUMBER, P_LINE_ID NUMBER, P_OU_ID NUMBER) IS
      SELECT ship_sts.meaning||'-'||SUM(wdd.requested_quantity) ship_status
        FROM wsh_delivery_details wdd, fnd_lookup_values ship_sts, fnd_application fa
       WHERE wdd.org_id = P_OU_ID
         AND wdd.source_header_id = P_ORDER_ID
         AND wdd.source_line_id = P_LINE_ID
         AND wdd.requested_quantity <> 0
         AND fa.application_short_name = 'WSH'
         AND ship_sts.view_application_id = fa.application_id
         AND ship_sts.lookup_type = 'PICK_STATUS'
         AND ship_sts.lookup_code = wdd.released_status
      GROUP BY ship_sts.meaning;
BEGIN
   SELECT COUNT(*)
     INTO V_CNT
     FROM (SELECT DISTINCT ship_sts.meaning
             FROM wsh_delivery_details wdd, fnd_lookup_values ship_sts, fnd_application fa
            WHERE wdd.org_id = P_OU_ID
              AND wdd.source_header_id = P_ORDER_ID
              AND wdd.source_line_id = P_LINE_ID
              AND wdd.requested_quantity <> 0
              AND fa.application_short_name = 'WSH'
              AND ship_sts.view_application_id = fa.application_id
              AND ship_sts.lookup_type = 'PICK_STATUS'
              AND ship_sts.lookup_code = wdd.released_status);
   IF V_CNT > 1 THEN
      BEGIN
         FOR r_ship_status IN C_SHIP_STATUS(P_ORDER_ID, P_LINE_ID, P_OU_ID) LOOP
            V_SHIP_STATUS := V_SHIP_STATUS||r_ship_status.ship_status||'|';
         END LOOP;
      EXCEPTION
         WHEN OTHERS THEN
            V_SHIP_STATUS := NULL;
      END;
   ELSE
      BEGIN
         SELECT DECODE(ship_sts.meaning,'Booked','Open','Entered','Open',' Interfaced to Receivables','Closed',' Partially Interfaced to Receivables','Closed','Awaiting Invoice Interface - On Hold','Closed','Picked','Shipped','Picked Partial','Shipped','In-Process') ship_status -----Changed by Trupti D. for MYJIRATEST-12410 07-Jan-2016
           INTO V_SHIP_STATUS
           FROM wsh_delivery_details wdd, fnd_lookup_values ship_sts, fnd_application fa
          WHERE wdd.org_id = P_OU_ID
            AND wdd.source_header_id = P_ORDER_ID
            AND wdd.source_line_id = P_LINE_ID
            AND wdd.requested_quantity <> 0
            AND fa.application_short_name = 'WSH'
            AND ship_sts.view_application_id = fa.application_id
            AND ship_sts.lookup_type = 'PICK_STATUS'
            AND ship_sts.lookup_code = wdd.released_status
         GROUP BY ship_sts.meaning;
      EXCEPTION
         WHEN OTHERS THEN
            V_SHIP_STATUS := NULL;
      END;
   END IF;

   RETURN V_SHIP_STATUS;

EXCEPTION
   WHEN OTHERS THEN
      RETURN NULL;
END GET_SHIP_STATUS;

FUNCTION GET_COO(P_OU_ID IN NUMBER,
                 P_ORDER_ID IN NUMBER,
                 P_LINE_ID IN NUMBER)
    RETURN VARCHAR2
AS
   V_COO VARCHAR2(1000);
   V_CNT NUMBER;
   CURSOR C_COO(P_ORDER_ID NUMBER, P_LINE_ID NUMBER, P_OU_ID NUMBER) IS
      SELECT attribute6||'-'||SUM(requested_quantity) coo
        FROM wsh_delivery_details
       WHERE org_id = P_OU_ID
         AND source_header_id = P_ORDER_ID
         AND source_line_id = P_LINE_ID
         AND requested_quantity <> 0
      GROUP BY attribute6;
BEGIN
   SELECT COUNT(*)
     INTO V_CNT
     FROM (SELECT DISTINCT attribute6
             FROM wsh_delivery_details
            WHERE org_id = P_OU_ID
              AND source_header_id = P_ORDER_ID
              AND source_line_id = P_LINE_ID
              AND requested_quantity <> 0);
   IF V_CNT > 1 THEN
      BEGIN
         FOR r_coo IN C_COO(P_ORDER_ID, P_LINE_ID, P_OU_ID) LOOP
            V_COO := V_COO||r_coo.coo||'|';
         END LOOP;
      EXCEPTION
         WHEN OTHERS THEN
            V_COO := NULL;
      END;
   ELSE
      BEGIN
         SELECT attribute6 coo
           INTO V_COO
           FROM wsh_delivery_details
          WHERE org_id = P_OU_ID
            AND source_header_id = P_ORDER_ID
            AND source_line_id = P_LINE_ID
            AND requested_quantity <> 0
         GROUP BY attribute6;
      EXCEPTION
         WHEN OTHERS THEN
            V_COO := NULL;
      END;
   END IF;

   RETURN V_COO;

EXCEPTION
   WHEN OTHERS THEN
      RETURN NULL;
END GET_COO;


FUNCTION GET_ORIG_PO_NUMBER(P_RETURN_CONTEXT IN VARCHAR2,
                            P_RETURN_ATTRIBUTE1 IN VARCHAR2,
                            P_RETURN_ATTRIBUTE2 IN VARCHAR2)
    RETURN VARCHAR2
AS
V_PO_NUMBER VARCHAR2(50);
BEGIN
   IF P_RETURN_CONTEXT IN ('PO','ORDER') THEN
      SELECT cust_po_number
        INTO V_PO_NUMBER
        FROM oe_order_headers_all
       WHERE header_id = TO_NUMBER(P_RETURN_ATTRIBUTE1);
   ELSIF P_RETURN_CONTEXT = 'INVOICE' THEN
      SELECT ooh.cust_po_number
        INTO V_PO_NUMBER
        FROM oe_order_headers_all ooh, oe_order_lines_all ool, ra_customer_trx_all rct, ra_customer_trx_lines_all rctl
       WHERE rct.customer_trx_id = rctl.customer_trx_id
         AND TO_NUMBER(rctl.interface_line_attribute6) = ool.line_id
         AND rctl.line_type = 'LINE'
         AND rctl.interface_line_context = 'ORDER ENTRY'
         AND ooh.header_id = ool.header_id;
   ELSE
      V_PO_NUMBER := NULL;
   END IF;
   RETURN V_PO_NUMBER;
EXCEPTION
   WHEN NO_DATA_FOUND THEN
      RETURN NULL;
END GET_ORIG_PO_NUMBER;

FUNCTION GET_CANCEL_FLAG(P_HEADER_ID  NUMBER
                        ,P_LINE_ID  NUMBER
                        ,P_LINE_DWLD VARCHAR2) RETURN VARCHAR2 IS  --MYJIRATEST-4668 Ravi S 27-JAN-2015
   l_item_type_code   VARCHAR2(20);
   l_open_flag     VARCHAR2(10);
   l_LINE_CAT_CODE     VARCHAR2(20);
   l_req_date     DATE ;
   L_no_days     NUMBER;
   l_cancel_flag     VARCHAR2(2);
BEGIN
   SELECT ool.OPEN_FLAG
         ,ool.ITEM_TYPE_CODE
         ,LINE_CATEGORY_CODE
         ,ool.REQUEST_DATE
         ,(SELECT tag
     FROM fnd_lookup_values
    WHERE lookup_type = 'GEAE_MYGE_CANCEL_DAYS'
      and LOOKUP_CODE=ORG_ID||'-'||OOL.ITEM_TYPE_CODE) NO_OF_DAYS   --default value set as 10
     INTO l_open_flag
         ,l_item_type_code
         ,l_LINE_CAT_CODE
         ,l_req_date
         ,L_no_days
     FROM oe_order_lines_all ool
    WHERE ool.header_id = P_HEADER_ID
      AND ool.line_id = P_LINE_ID;

  IF UPPER(l_LINE_CAT_CODE) = 'RETURN' OR l_open_flag ='N' OR UPPER(l_item_type_code) IN ('CLASS','INCLUDED','OPTION') THEN
    l_cancel_flag :='N';
  ELSE
    IF L_no_days IS NULL AND P_LINE_DWLD = 'N' THEN
       l_cancel_flag :='Y';
    ELSIF L_no_days IS NULL AND P_LINE_DWLD = 'Y' THEN
       l_cancel_flag :='N';
    ELSIF UPPER(l_item_type_code) IN ('MODEL','STANDARD') THEN
        IF l_req_date > L_no_days + SYSDATE AND P_LINE_DWLD = 'N' THEN
          l_cancel_flag :='Y';
       ELSE
          l_cancel_flag :='N';
       END IF ;
    END IF ;
  END IF;

  RETURN l_cancel_flag;

EXCEPTION
   WHEN OTHERS THEN
      RETURN NULL;
END GET_CANCEL_FLAG;

FUNCTION GET_DISP_ALLWD_FLG(P_OU_ID IN NUMBER,
                            P_ORDER_ID IN NUMBER,
                            P_LINE_ID IN NUMBER)
    RETURN VARCHAR2
AS
   V_DISP_ALLWD VARCHAR2(1);
BEGIN
   BEGIN
      SELECT 'Y'
        INTO V_DISP_ALLWD
        FROM oe_order_lines_all ool, fnd_lookup_values flv, fnd_lookup_values order_type, hr_operating_units hou, oe_transaction_types_tl oe, oe_order_headers_all ooh
       WHERE ool.header_id = P_ORDER_ID
         AND ool.line_id = P_LINE_ID
         AND ool.org_id = P_OU_ID
         AND flv.lookup_type = 'GEAE_MYGE_DISPUTE_ALLOWED_DAYS'
         AND flv.lookup_code = ool.org_id
         AND ool.flow_status_code = 'CLOSED'
         AND ool.shipped_quantity > 0
         AND ool.item_type_code IN ('MODEL','STANDARD')
         --AND trunc(SYSDATE) - trunc(ool.actual_shipment_date) <= flv.description
         AND order_type.lookup_type = 'GEAE_MYGE_DISPUTE_ALLOW_ORDERS' --MYJIRATEST-4579 Ravi S 20-NOV-2014
         AND oe.name = order_type.meaning      --MYJIRATEST-11342 Neelima Y 26-OCT-2015
         AND hou.name = order_type.description  --MYJIRATEST-11342 Neelima Y 26-OCT-2015
         AND hou.organization_id = P_OU_ID
         AND oe.transaction_type_id = ooh.order_type_id
         AND ool.header_id = ooh.header_id
         AND NOT EXISTS (SELECT 'X'
                           FROM oe_order_lines_all ool2
                          WHERE ool2.reference_line_id = ool.line_id
                            AND ool2.reference_header_id = ool.header_id
                            AND ool2.org_id = ool.org_id
                            AND ool2.inventory_item_id = ool.inventory_item_id)
         AND NOT EXISTS (SELECT 'X'
                           FROM oe_order_lines_all ool3
                          WHERE ool3.return_attribute2 = to_char(ool.line_id)
                            AND ool3.return_attribute1 = to_char(ool.header_id)
                            AND ool3.org_id = ool.org_id
                            AND ool3.inventory_item_id = ool.inventory_item_id
                            AND ool3.return_context = 'ORDER');
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         V_DISP_ALLWD := 'N';
   END;
   RETURN V_DISP_ALLWD;
EXCEPTION
   WHEN OTHERS THEN
      RETURN NULL;
END GET_DISP_ALLWD_FLG;

FUNCTION GET_DISP_CREATED_FLG(P_OU_ID IN NUMBER,
                            P_ORDER_ID IN NUMBER,
                            P_LINE_ID IN NUMBER) --MYJIRATEST-3745 TRUPTI D. 31-MAR-2016
    RETURN VARCHAR2
AS
   V_DISP_CREATED VARCHAR2(1);
BEGIN
   BEGIN
       SELECT 'Y'
        INTO V_DISP_CREATED
        FROM oe_order_lines_all ool
        WHERE ool.reference_line_id = P_LINE_ID
         AND ool.reference_header_id = P_ORDER_ID
         AND ool.org_id = P_OU_ID;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         V_DISP_CREATED := 'N';
   END;
   RETURN V_DISP_CREATED;
EXCEPTION
   WHEN OTHERS THEN
      RETURN NULL;
END GET_DISP_CREATED_FLG;


FUNCTION GET_TRACKING_URL(P_SHP_METHD_CD IN VARCHAR2,
                          P_BOL_NUMBER IN VARCHAR2)
    RETURN VARCHAR2
AS
   V_TRACK_URL VARCHAR2(500);
BEGIN
   BEGIN
      SELECT REPLACE(flv.description,'AWBAPPEND',P_BOL_NUMBER)
        INTO V_TRACK_URL
        FROM fnd_lookup_values flv
       WHERE flv.lookup_type = 'GEAE_MYGE_CARRIER_URL_LINKS'
         AND flv.tag = 'SHIP_METHOD'
         AND flv.lookup_code = P_SHP_METHD_CD;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         V_TRACK_URL := NULL;
   END;
   IF V_TRACK_URL IS NULL THEN
      BEGIN
         SELECT REPLACE(flv.description,'AWBAPPEND',P_BOL_NUMBER)
           INTO V_TRACK_URL
           FROM fnd_lookup_values flv, wsh_carrier_services wcs
          WHERE flv.lookup_type = 'GEAE_MYGE_CARRIER_URL_LINKS'
            AND flv.tag = 'CARRIER'
            AND flv.lookup_code = wcs.carrier_id
            AND wcs.ship_method_code = P_SHP_METHD_CD;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            V_TRACK_URL := NULL;
      END;
   END IF;
   RETURN V_TRACK_URL;
EXCEPTION
   WHEN OTHERS THEN
      RETURN NULL;
END GET_TRACKING_URL;

FUNCTION GET_CLOSED_LINE_STATUS(P_ORDER_ID IN NUMBER,
                                P_OU_ID IN NUMBER)
    RETURN VARCHAR2
AS
   V_ORDER_STATUS VARCHAR2(50);
   V_CNT_NON_CLSD NUMBER;
   V_CNT_ALL NUMBER;
BEGIN
   SELECT COUNT(1)
     INTO V_CNT_NON_CLSD
     FROM oe_order_lines_all
    WHERE header_id = P_ORDER_ID
      AND org_id = P_OU_ID
      AND flow_status_code NOT IN ('CLOSED');
   SELECT COUNT(1)
     INTO V_CNT_ALL
     FROM oe_order_lines_all
    WHERE header_id = P_ORDER_ID
      AND org_id = P_OU_ID;
   IF V_CNT_NON_CLSD = 0 AND V_CNT_ALL <> 0 THEN
      BEGIN
         SELECT description
           INTO V_ORDER_STATUS
           FROM fnd_lookup_values
          WHERE lookup_type = 'FLOW_STATUS'
            AND lookup_code = 'CLOSED'
            AND enabled_flag = 'Y'
            AND TRUNC(SYSDATE) BETWEEN NVL(start_date_active,TRUNC(SYSDATE)) AND NVL(end_date_active,SYSDATE);
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            V_ORDER_STATUS := NULL;
      END;
   END IF;
   RETURN V_ORDER_STATUS;
EXCEPTION
   WHEN OTHERS THEN
      RETURN NULL;
END GET_CLOSED_LINE_STATUS;

FUNCTION GET_ERR_MSG   (P_ERR_CODE IN NUMBER)
    RETURN VARCHAR2
AS
V_MSG VARCHAR2(2000);
BEGIN
   SELECT LOOKUP_CODE
            || ':'
            || DESCRIPTION
    INTO V_MSG
    FROM FND_LOOKUP_VALUES
    WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
    AND UPPER(LOOKUP_CODE) = UPPER(P_ERR_CODE) ;
    RETURN V_MSG;
EXCEPTION
   WHEN no_data_found THEN
      RETURN NULL;
END GET_ERR_MSG;

--MYJIRATEST-4813 Ravi S 09-JAN-2015
PROCEDURE INVOICE_FILE_RETURN(
                             --Standard Parameters
                             P_SSO           VARCHAR2,
                             P_IACO_CODE     VARCHAR2,
                             P_CUST_ID       V_CUST_ID_ARRAY,
                             P_ROLE          VARCHAR2,
                             P_OU_ID         VARCHAR2,
                             --Input Parameters
                             P_INVOICE_ID    NUMBER,
                             --Output Parameters
                             P_FILE_DATA     OUT BLOB,
                             P_FILE_NAME     OUT VARCHAR2,
                             P_MSG           OUT VARCHAR2)
AS
   l_trx_number VARCHAR2(20);
   l_cust_id NUMBER;
   l_authorized VARCHAR2(1);
   l_resp_id NUMBER;
   l_app_id NUMBER;
   l_user_id NUMBER;
   l_request_id NUMBER;
   l_req_phase VARCHAR2(50);
   l_req_status VARCHAR2(50);
   l_dev_phase VARCHAR2(50);
   l_dev_status VARCHAR2(50);
   l_req_message VARCHAR2(500);
   l_file_loc BFILE;
   l_file_name VARCHAR2(100);
   l_file_path VARCHAR2(100);
   e_exit EXCEPTION;
   l_csid NUMBER;
   -- Passport Changes start to save the OU_ID separated by comma -11-16-2018 suguna
  j_ou_id                      VARCHAr2(100)   := NULL;
--end
BEGIN

/******************************************************
Passport changes start US230169
Suguna Added below to fetch the OU_ID based on the P_INVOICE_ID
*******************************************************/
 /*****************************************
14-March-2019- Manisha commenting the below if else condition
to fix the issue to see old CSO orders if customer is switched from cso to passport
*****************************************/
   --  IF P_OU_ID like '%~%' THEN
        BEGIN
            SELECT org_id
            INTO j_ou_id
            FROM ra_customer_trx_all
            WHERE customer_trx_id = P_INVOICE_ID;
             IF j_ou_id IS NULL THEN
                        SELECT LOOKUP_CODE || ': ' || DESCRIPTION
                        INTO P_MSG
                        FROM fnd_lookup_values
                        where LOOKUP_TYPE = 'GEAE_MYGE_ERROR_CODES'
                        and UPPER(LOOKUP_CODE) = UPPER('8503');
                RAISE e_exit;
             END IF;
        EXCEPTION
        WHEN OTHERS THEN
         P_MSG:= 'Error while fetching the OU_ID: '||SQLCODE||SQLERRM;
        END;
--    ELSE
--     j_ou_id := TO_NUMBER(P_OU_ID);
--    END IF;

   BEGIN
      SELECT sold_to_customer_id,trx_number
        INTO l_cust_id, l_trx_number
        FROM ra_customer_trx_all
       WHERE customer_trx_id = P_INVOICE_ID
         AND org_id = j_ou_id;--P_OU_ID; -- commented p_ou_id for passport requirement
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         P_MSG := GET_ERR_MSG(8029);
         RAISE e_exit;
   END;
   l_authorized := 'N';
   IF P_ROLE = 'Global Enquiry' THEN
      l_authorized := 'Y';
   ELSE
      FOR i IN 1..P_CUST_ID.COUNT LOOP
         IF P_CUST_ID(i) = l_cust_id THEN
            l_authorized := 'Y';
         END IF;
      END LOOP;
   END IF;
   IF l_authorized = 'N' THEN
      P_MSG := GET_ERR_MSG(8180);
      RAISE e_exit;
   END IF;
   BEGIN
      SELECT resp.responsibility_id,resp.application_id
        INTO l_resp_id,l_app_id
        FROM fnd_responsibility_tl resp,
             fnd_lookup_values flv,
             hr_operating_units hou
       WHERE hou.name = flv.meaning
         AND resp.responsibility_name = flv.description
         AND hou.organization_id = j_ou_id--P_OU_ID -- commented p_ou_id for passport requirement
         AND flv.lookup_type = 'GEAE_MYGE_ORDER_RESPONSIBILITY';
   EXCEPTION
      WHEN no_data_found THEN
         P_MSG := GET_ERR_MSG(8026);
         RAISE e_exit;
   END;
   BEGIN
      SELECT user_id
        INTO l_user_id
        FROM fnd_user
       WHERE user_name = P_SSO;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         l_user_id := NULL;
   END;
   IF l_user_id IS NULL THEN
      BEGIN
         SELECT usr.user_id
           INTO l_user_id
           FROM fnd_user usr, fnd_lookup_values dflt
          WHERE dflt.lookup_type = 'GEAE_MYGE_DEFAULT_LOGIN'
            AND dflt.enabled_flag = 'Y'
            AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(dflt.start_date_active,SYSDATE)) AND TRUNC(NVL(dflt.end_date_active,SYSDATE))
            AND dflt.lookup_code = j_ou_id--P_OU_ID -- commented p_ou_id for passport requirement
            AND dflt.description = usr.user_name;
      EXCEPTION
         WHEN OTHERS THEN
            l_user_id := NULL;
      END;
   END IF;
   mo_global.set_policy_context ('S', j_ou_id);--P_OU_ID -- replaced p_ou_id with J_ou_id for passport requirement
   mo_global.init('ONT');
   fnd_global.apps_initialize (user_id => l_user_id,
                               resp_id => l_resp_id,
                               resp_appl_id => l_app_id);
   l_request_id := FND_REQUEST.SUBMIT_REQUEST('GEAR','GEAE_AR_CSO_INV_PRT',NULL,NULL,FALSE,
                                              'Y','INV',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
                                              l_trx_number,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
                                              'N');
   DBMS_OUTPUT.PUT_LINE('request id: ' ||l_request_id);

   IF l_request_id IS NULL OR l_request_id = 0 THEN
      P_MSG := GET_ERR_MSG(8043);
      RAISE e_exit;
   ELSE
      COMMIT;
   END IF;
   IF FND_CONCURRENT.WAIT_FOR_REQUEST(l_request_id,30,900,l_req_phase,l_req_status,l_dev_phase,l_dev_status,l_req_message) THEN
      COMMIT;
   ELSE
      P_MSG := GET_ERR_MSG(8044);
      RAISE e_exit;
   END IF;
   BEGIN
   --MYJIRATEST 15809 commented by amita .B on 19/5/2016
      --MYJIRATEST-7194 By Ankita.S on 27-APR-2015
     /* SELECT program_short_name||'_'||request_id||'_1.PDF'
        INTO l_file_name
        FROM fnd_conc_req_summary_v
       WHERE parent_request_id = l_request_id
         AND phase_code = 'C';  */

    --MYJIRATEST 15809 added by Amita .B on 19/5/2016
    SELECT SubStr(FCRO.FILE_NAME,1,InStr(FCRO.FILE_NAME,'/',-1,1)-1) FILE_PATH
              ,SubStr(FCRO.FILE_NAME,InStr(FCRO.FILE_NAME,'/',-1,1)+1) FILE_NAME
         INTO l_file_path,l_file_name
         FROM FND_CONC_REQ_OUTPUTS FCRO
             ,FND_CONCUrrent_requests fcr
        WHERE CONCURRENT_REQUEST_ID=fcr.request_id
          AND fcr.parent_request_id = l_request_id
          AND FCR.phase_code = 'C';

    DBMS_OUTPUT.PUT_LINE('file name: ' ||l_file_name);
    DBMS_OUTPUT.PUT_LINE('file path: ' ||l_file_path);
  --end 15809
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         P_MSG := GET_ERR_MSG(8045);
         RAISE e_exit;
      WHEN OTHERS THEN
         P_MSG := GET_ERR_MSG(8046);
         RAISE e_exit;
   END;

   IF l_file_name IS NULL THEN
      P_MSG := GET_ERR_MSG(8047);
      RAISE e_exit;
   END IF;
   --l_file_loc := BFILENAME(l_file_path,l_file_name);
   l_file_loc := BFILENAME('GEAE_MYGE_INVOICE_OUT_DIR',l_file_name);
   DBMS_LOB.CREATETEMPORARY(P_FILE_DATA,FALSE);
   DBMS_LOB.FILEOPEN(l_file_loc,DBMS_LOB.FILE_READONLY);
   DBMS_LOB.LOADFROMFILE(P_FILE_DATA,l_file_loc,DBMS_LOB.GETLENGTH(l_file_loc));
   DBMS_LOB.FILECLOSE(l_file_loc);
   P_FILE_NAME := to_char(l_trx_number)||'.PDF';

EXCEPTION
   WHEN e_exit THEN
      NULL;
   WHEN OTHERS THEN
      P_MSG := SQLERRM;
END INVOICE_FILE_RETURN;

FUNCTION GET_SIMPLE_STS_FLAG(P_OU_ID  NUMBER)
                         RETURN VARCHAR2  --MYJIRATEST-4668 Ravi S 27-JAN-2015
AS
   l_simple_sts_flag VARCHAR2(240);
BEGIN
   BEGIN
      SELECT description
        INTO l_simple_sts_flag
        FROM fnd_lookup_values
       WHERE lookup_type = 'GEAE_MYGE_TRANS_LINE_STATUS'
         AND enabled_flag = 'Y'
         AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(START_DATE_ACTIVE,SYSDATE)) AND TRUNC(NVL(END_DATE_ACTIVE,SYSDATE))
         AND lookup_code = P_OU_ID;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         l_simple_sts_flag := 'N';
   END;
   RETURN l_simple_sts_flag;
EXCEPTION
   WHEN OTHERS THEN
      RETURN NULL;
END GET_SIMPLE_STS_FLAG;

FUNCTION GET_LINE_DWLD_TO_WMS(P_HEADER_ID  NUMBER
                             ,P_LINE_ID  NUMBER)
                         RETURN VARCHAR2  --MYJIRATEST-4668 Ravi S 27-JAN-2015
AS
   l_line_dwnl_to_wms    VARCHAR2(1);
BEGIN
   BEGIN
      SELECT DECODE(COUNT(1),0,'N','Y')
        INTO l_line_dwnl_to_wms
        FROM wsh_delivery_details wdd, oe_order_lines_all ol2, oe_order_lines_all ool
       WHERE wdd.SOURCE_HEADER_ID = ool.header_id
         AND wdd.SOURCE_LINE_ID = ol2.line_id
         AND ol2.header_id = ool.header_id
         AND DECODE(ool.item_type_code,'MODEL',ol2.top_model_line_id,ol2.line_id) = ool.line_id --MYJIRATEST-4569 Ravi S 19-NOV-2014
         AND wdd.attribute4 IS NOT NULL
         AND ool.header_id = P_HEADER_ID
         AND ool.line_id = P_LINE_ID;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         l_line_dwnl_to_wms := 'N';
   END;
   RETURN l_line_dwnl_to_wms;
EXCEPTION
   WHEN OTHERS THEN
      RETURN NULL;
END GET_LINE_DWLD_TO_WMS;

FUNCTION GET_SHIP_LINE_FLAG(P_HEADER_ID  NUMBER
                           ,P_LINE_ID  NUMBER)
                         RETURN VARCHAR2  --MYJIRATEST-4668 Ravi S 27-JAN-2015
AS
   l_ship_line_flag    VARCHAR2(1);
BEGIN
   BEGIN
      SELECT DECODE(COUNT(1),0,'N','Y')
        INTO l_ship_line_flag
        FROM oe_workflow_assignments owa, wf_process_activities wpa, oe_order_lines_all ool, oe_order_headers_all ooh
       WHERE owa.line_type_id = ool.line_type_id
         AND owa.order_type_id = ooh.order_type_id
         AND wpa.process_name = owa.process_name
         AND wpa.activity_name = 'SHIP_CONFIRM'
         AND wpa.activity_item_type = 'OEOL' --testing04032015
         AND ooh.header_id = ool.header_id
         AND ooh.header_id = P_HEADER_ID
         AND ool.line_id = P_LINE_ID;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         l_ship_line_flag := 'N';
   END;
   RETURN l_ship_line_flag;
EXCEPTION
   WHEN OTHERS THEN
      RETURN NULL;
END GET_SHIP_LINE_FLAG;

FUNCTION GET_ORD_LN_STATUS(P_SIMPLE_FLAG VARCHAR2
                          ,P_SHIP_LINE_FLAG  VARCHAR2
                          ,P_LINE_FLOW_STATUS VARCHAR2
                          ,P_DWNLD_FLAG VARCHAR2)
                         RETURN VARCHAR2  --MYJIRATEST-4668 Ravi S 27-JAN-2015
AS
   l_line_status     VARCHAR2(240);
   l_open_status     VARCHAR2(240) := 'Open';
   l_cancel_status   VARCHAR2(240) := 'Cancelled';
   l_inproc_status   VARCHAR2(240) := 'In-Process';
BEGIN
   l_line_status := NULL;
   IF P_SIMPLE_FLAG = 'Y' THEN
      IF P_SHIP_LINE_FLAG = 'Y' THEN
         IF P_LINE_FLOW_STATUS IN ('CANCELLED') THEN
            l_line_status := l_cancel_status;
         ELSIF P_LINE_FLOW_STATUS IN ('BOOKED','ENTERED') THEN
            l_line_status := l_open_status;
         ELSIF P_LINE_FLOW_STATUS IN ('AWAITING_SHIPPING','AWAITING_FULFILLMENT') AND P_DWNLD_FLAG = 'N' THEN
            l_line_status := l_open_status;
         END IF;
         IF l_line_status IS NULL THEN
            BEGIN
               SELECT description
                 INTO l_line_status
                 FROM fnd_lookup_values
                WHERE lookup_type = 'GEAE_MYGE_SHIP_LINES_TRANS'
                  AND enabled_flag = 'Y'
                  AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(START_DATE_ACTIVE,SYSDATE)) AND TRUNC(NVL(END_DATE_ACTIVE,SYSDATE))
                  AND lookup_code = P_LINE_FLOW_STATUS;
            EXCEPTION
               WHEN NO_DATA_FOUND THEN
                  l_line_status := NULL;
               WHEN OTHERS THEN
                  l_line_status := NULL;
            END;
         END IF;
         IF l_line_status IS NULL THEN
            l_line_status := l_inproc_status;
         END IF;
      ELSE
         IF P_LINE_FLOW_STATUS IN ('CANCELLED') THEN
            l_line_status := l_cancel_status;
         END IF;
         IF l_line_status IS NULL THEN
            BEGIN
               SELECT description
                 INTO l_line_status
                 FROM fnd_lookup_values
                WHERE lookup_type = 'GEAE_MYGE_NON_SHIP_LINES_TRANS'
                  AND enabled_flag = 'Y'
                  AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(START_DATE_ACTIVE,SYSDATE)) AND TRUNC(NVL(END_DATE_ACTIVE,SYSDATE))
                  AND lookup_code = P_LINE_FLOW_STATUS;
            EXCEPTION
               WHEN NO_DATA_FOUND THEN
                  l_line_status := NULL;
               WHEN OTHERS THEN
                  l_line_status := NULL;
            END;
         END IF;
         IF l_line_status IS NULL THEN
            l_line_status := l_inproc_status;
         END IF;
      END IF;
   ELSE
      BEGIN
         SELECT description
           INTO l_line_status
           FROM fnd_lookup_values
          WHERE lookup_type = 'LINE_FLOW_STATUS'
            AND enabled_flag = 'Y'
            AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(START_DATE_ACTIVE,SYSDATE)) AND TRUNC(NVL(END_DATE_ACTIVE,SYSDATE))
            AND lookup_code = P_LINE_FLOW_STATUS;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            l_line_status := NULL;
         WHEN OTHERS THEN
            l_line_status := NULL;
      END;
   END IF;
   RETURN l_line_status;
END GET_ORD_LN_STATUS;

PROCEDURE GET_ORDER_AUDIT_HISTORY_PRC (
     P_SSO             IN       VARCHAR2
  ,P_ROLE            IN       VARCHAR2
  ,P_IACO_CODE       IN       VARCHAR2
  ,P_CUST_ID         IN       V_CUST_ID_ARRAY
  ,P_OU_ID           IN       VARCHAR2
  ,P_HEADER_NUMBER   IN       OE_ORDER_HEADERS_ALL.HEADER_ID%TYPE
    ,P_AUDIT_HIST_VIEW OUT      V_AUDIT_HISTORY_ARRAY
    ,P_ERROR_STATUS     OUT    VARCHAR2
  ,P_MSG             OUT     VARCHAR2)
IS
  V_SELECT_STR              VARCHAR2 (32767) := '';
  P_AUDIT_HIS_CUR            SYS_REFCURSOR;
  L_INDX_N                  NUMBER := 0;
  V_USER_ID                 NUMBER;
  V_RESP_ID                 NUMBER;
  V_APP_ID                  NUMBER;
  V_LINE_NUMBER             VARCHAR2(30);
  V_ATTRIBUTE_DISPLAY_NAME   VARCHAR2(2000);
  V_OLD_ATTRIBUTE_VALUE     VARCHAR2(100);
  V_NEW_ATTRIBUTE_VALUE     VARCHAR2(100);
  V_USER_NAME         VARCHAR2(100);
  V_HIST_CREATION_DATE     VARCHAR2(20);
  v_ou_id     VARCHAR2(100)   := NULL; -- added for passport requirement US230177
    BEGIN
 IF P_SSO IS NULL THEN
      P_MSG:=GET_ERR_MSG(8024);
        END IF;
/*****************************
17-Aug: Suguna/Manisha added below exception block while
fecthing the user_id
**********************************/
BEGIN
  SELECT USER_ID INTO V_USER_ID
  FROM FND_USER
  WHERE USER_NAME=P_SSO;
EXCEPTION
WHEN NO_DATA_FOUND THEN
  P_MSG :=GET_ERR_MSG(8005);
  goto END_PROC;
END;

--end
  IF P_OU_ID IS NULL THEN
      P_MSG:=GET_ERR_MSG(8025);
       END IF;
 /******************************************************
Passport changes start US230177
Suguna Added below to fetch the OU_ID based on the order header ID
*******************************************************/
 /*****************************************
14-March-2019- Manisha commenting the below if else condition
to fix the issue to see old CSO orders if customer is switched from cso to passport
*****************************************/
 -- IF P_OU_ID like '%~%' THEN

   BEGIN
        SELECT ORG_ID INTO v_ou_id
        FROM OE_ORDER_HEADERS_ALL
        WHERE HEADER_ID =P_HEADER_NUMBER;

            IF v_ou_id IS NULL THEN
                    SELECT LOOKUP_CODE || ': ' || DESCRIPTION
                    INTO P_MSG
                    FROM fnd_lookup_values
                    where LOOKUP_TYPE = 'GEAE_MYGE_ERROR_CODES'
                     and UPPER(LOOKUP_CODE) = UPPER('8503');
             goto END_PROC;
            END IF;

    EXCEPTION
    WHEN OTHERS THEN
       P_MSG:= 'Error while fetching the OU_ID: '||SQLCODE||SQLERRM;
       goto END_PROC;
   END;

--  ELSE
--   v_ou_id := P_OU_ID ;
--  END IF;
  --end
  --FETCHING RESPONSIBILITY ID AND APPLICATION_ID
  BEGIN
  SELECT RESP.RESPONSIBILITY_ID,RESP.APPLICATION_ID
   INTO V_RESP_ID,V_APP_ID
  FROM  FND_RESPONSIBILITY_TL RESP,
        FND_LOOKUP_VALUES FLV ,
        HR_OPERATING_UNITS HOU
  WHERE HOU.NAME = FLV.MEANING
      AND RESP.RESPONSIBILITY_NAME = FLV.DESCRIPTION
      AND HOU.ORGANIZATION_ID = v_ou_id --P_OU_ID commented for passport
      AND FLV.LOOKUP_TYPE = 'GEAE_MYGE_QUOTE_RESPONSIBILITY';
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  P_MSG := GET_ERR_MSG(8026);
  END;
BEGIN
 FND_GLOBAL.APPS_INITIALIZE(V_USER_ID,V_RESP_ID,V_APP_ID);
 MO_GLOBAL.SET_POLICY_CONTEXT('S',v_ou_id);
END;

        V_SELECT_STR:='SELECT
            OOLA.LINE_NUMBER   LINE_NUMBER,
            OAADV.ATTRIBUTE_DISPLAY_NAME ATTRIBUTE_DISPLAY_NAME,
            OE_AUDIT_HISTORY_PVT.ID_TO_VALUE(OAAH.ATTRIBUTE_ID,
                                             OAAH.OLD_ATTRIBUTE_VALUE,
                                             OAAH.OLD_CONTEXT_VALUE,
                                             OAAH.ORG_ID) OLD_ATTRIBUTE_VALUE,
            OE_AUDIT_HISTORY_PVT.ID_TO_VALUE(OAAH.ATTRIBUTE_ID,
                                             OAAH.NEW_ATTRIBUTE_VALUE,
                                             OAAH.NEW_CONTEXT_VALUE,
                                             OAAH.ORG_ID) NEW_ATTRIBUTE_VALUE,
            OAADV.USER_NAME                  USER_NAME,
            TO_CHAR(OAAH.HIST_CREATION_DATE,''DD-MM-YYYY'') HIST_CREATION
            FROM
            OE_ORDER_HEADERS_ALL OOHA,
            OE_ORDER_LINES_ALL OOLA,
            OE_AUDIT_ATTR_HISTORY OAAH,
            OE_AUDIT_ATTR_DESC_V  OAADV
            WHERE OOHA.HEADER_ID = OOLA.HEADER_ID
            AND   OOLA.LINE_ID = OAADV.ENTITY_NUMBER
            AND   OOHA.ORDER_NUMBER = OAAH.ORDER_NUMBER
            AND   OAAH.ENTITY_ID =OAADV.ENTITY_ID
            AND   OAAH.USER_ID =OAADV.USER_ID
            AND   OAAH.ENTITY_NUMBER = OAADV.ENTITY_NUMBER
            AND   OAAH.ATTRIBUTE_ID  = OAADV.ATTRIBUTE_ID
            AND   OOHA.HEADER_ID ='''||P_HEADER_NUMBER||'''
            GROUP BY OOLA.LINE_NUMBER,
            OAADV.ATTRIBUTE_DISPLAY_NAME,
            OAAH.OLD_ATTRIBUTE_VALUE, OAAH.NEW_ATTRIBUTE_VALUE,
            OAADV.USER_NAME, OAAH.HIST_CREATION_DATE,OAAH.ATTRIBUTE_ID,OAAH.ORG_ID,
            OAAH.OLD_CONTEXT_VALUE,OAAH.NEW_CONTEXT_VALUE';

            P_AUDIT_HIST_VIEW := V_AUDIT_HISTORY_ARRAY();

            OPEN P_AUDIT_HIS_CUR FOR V_SELECT_STR;

               LOOP
               /**********************************************
                 FETCHING THE DATA FROM CURSOR INTO VARIABLES.
                **********************************************/
                   FETCH P_AUDIT_HIS_CUR
                    INTO V_LINE_NUMBER,
                         V_ATTRIBUTE_DISPLAY_NAME,
                          V_OLD_ATTRIBUTE_VALUE,
                          V_NEW_ATTRIBUTE_VALUE,
                          V_USER_NAME,
                          V_HIST_CREATION_DATE;

                   EXIT WHEN P_AUDIT_HIS_CUR%NOTFOUND;
                   P_AUDIT_HIST_VIEW.EXTEND ();
                   L_INDX_N := L_INDX_N + 1;
                   P_AUDIT_HIST_VIEW (P_AUDIT_HIST_VIEW.LAST) :=
                                     V_AUDIT_HISTORY_OBJECT(V_LINE_NUMBER,
                                     V_ATTRIBUTE_DISPLAY_NAME,
                               V_OLD_ATTRIBUTE_VALUE,
                               V_NEW_ATTRIBUTE_VALUE,
                               V_USER_NAME,
                               V_HIST_CREATION_DATE);

                   --DBMS_OUTPUT.PUT_LINE( 'V_APPROVE_IND: '|| V_APPROVE_IND);

            END LOOP;


              FOR I IN 1..P_AUDIT_HIST_VIEW.COUNT
              LOOP
              DBMS_OUTPUT.PUT_LINE( 'ARRY DETAILS');
              DBMS_OUTPUT.PUT_LINE( 'V_LINE_NUMBER: '||P_AUDIT_HIST_VIEW(I).LINE_NUMBER);
              DBMS_OUTPUT.PUT_LINE( 'V_ATTRIBUTE_DISPLAY_NAME: '||P_AUDIT_HIST_VIEW(I).ATTRIBUTE_DISPLAY_NAME);
              DBMS_OUTPUT.PUT_LINE( 'V_OLD_ATTRIBUTE_VALUE: '||P_AUDIT_HIST_VIEW(I).OLD_ATTRIBUTE_VALUE);
              DBMS_OUTPUT.PUT_LINE( 'V_NEW_ATTRIBUTE_VALUE: '||P_AUDIT_HIST_VIEW(I).NEW_ATTRIBUTE_VALUE);
              DBMS_OUTPUT.PUT_LINE( 'V_USER_NAME: '||P_AUDIT_HIST_VIEW(I).USER_NAME);
              DBMS_OUTPUT.PUT_LINE( 'V_HIST_CREATION_DATE: '||P_AUDIT_HIST_VIEW(I).HIST_CREATION_DATE);
              END LOOP;

        IF L_INDX_N = 0 THEN

             P_ERROR_STATUS :=  'NO ROWS RETURNED FOR THE GIVEN INPUTS';

             ELSE

                P_ERROR_STATUS := 'SUCCESS';

             END IF;
<<END_PROC>>  --17-Aug Manisha added to skip the proc in case SSO is invalid
NULL;
END GET_ORDER_AUDIT_HISTORY_PRC;

FUNCTION GET_CRITAL_PART_FLAG(P_HEADER_ID  NUMBER
                        ,P_LINE_ID  NUMBER
                        ,P_ITEM_NUM VARCHAR2)
                        RETURN VARCHAR2
                        IS--MYJIRATEST-US13541 Prasad  25-OCT-2016

   l_CRITICAL_PART        VARCHAR2(10);
   l_crital_part_flag     VARCHAR2(2);

 BEGIN
         SELECT 'Y'
           INTO l_CRITICAL_PART
           FROM oe_hold_definitions ohd, oe_hold_sources_all ohsa, fnd_lookup_values flv,oe_order_lines_all oola
          WHERE ohd.hold_id = ohsa.hold_id
            AND ohd.name = flv.description
            AND flv.lookup_type = 'GEAE_MYGE_CRITICAL_PART_HOLDS'
            AND flv.enabled_flag = 'Y'
            AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(flv.start_date_active,SYSDATE)) AND TRUNC(NVL(flv.end_date_active,SYSDATE))
            AND ohsa.hold_entity_code = 'I'
            AND ohsa.released_flag <>'Y'
            AND ohsa.hold_entity_id = P_ITEM_NUM
            AND oola.header_id = P_HEADER_ID
            AND oola.line_id = P_LINE_ID
            AND rownum = 1;

  IF l_CRITICAL_PART = 'Y' THEN
    l_crital_part_flag :='Y';
    ELSE
      l_crital_part_flag :='N';
   END IF;
  RETURN l_crital_part_flag;

EXCEPTION
   WHEN OTHERS THEN
      RETURN NULL;
END GET_CRITAL_PART_FLAG;

FUNCTION RETURN_AWB ( P_HEADER_ID IN NUMBER,
                      P_LINE_ID   IN NUMBER
 )
 RETURN VARCHAR2
 AS
 v_AWB VARCHAR2(100);
 BEGIN
 select wnd.waybill
 INTO v_AWB
 from apps.wsh_new_deliveries wnd,
 apps.wsh_delivery_assignments wda,
 apps.wsh_delivery_details wdd,
 apps.oe_order_lines_all oola
 where
 wnd.delivery_id(+)         = wda.delivery_id
 AND wdd.delivery_detail_id = wda.delivery_detail_id
 AND wdd.source_line_id(+)  = oola.line_id
 AND wdd.source_header_id(+)= oola.header_id
 AND oola.header_id         = P_HEADER_ID
 AND oola.line_id  = P_LINE_ID
 AND wnd.waybill IS NOT NULL
 AND ROWNUM =1;
 RETURN v_AWB;
 EXCEPTION
 WHEN OTHERS THEN
RETURN NULL;
 END;

FUNCTION RETURN_INV_NUM (P_ORDER_NUM IN NUMBER,P_HEADER_ID IN NUMBER, P_LINE_ID IN NUMBER)
RETURN VARCHAR2
AS
V_INVOICE_NUMBER VARCHAR2(200);
BEGIN
SELECT RACTXALL.TRX_NUMBER
INTO V_INVOICE_NUMBER
FROM
RA_CUSTOMER_TRX_ALL RACTXALL,
     OE_ORDER_HEADERS_ALL OOHA ,
     RA_CUSTOMER_TRX_LINES_ALL RCTL
WHERE RACTXALL.CT_REFERENCE=TO_CHAR(OOHA.ORDER_NUMBER)
AND RCTL.INTERFACE_LINE_ATTRIBUTE6 = TO_CHAR(P_LINE_ID)
AND RACTXALL.CT_REFERENCE=P_ORDER_NUM
AND OOHA.HEADER_ID = P_HEADER_ID
AND RCTL.CUSTOMER_TRX_ID =RACTXALL.CUSTOMER_TRX_ID
AND RCTL.ORG_ID = RACTXALL.ORG_ID
AND RCTL.ORG_ID=OOHA.ORG_ID
AND ROWNUM=1;
RETURN V_INVOICE_NUMBER;
EXCEPTION
WHEN OTHERS THEN
RETURN NULL;
END;

PROCEDURE UPDATE_SCRIPT
AS
--V_COUNT NUMBER;
BEGIN
--MYCFM--
UPDATE APPS.OE_ORDER_HEADERS_ALL SET SOURCE_DOCUMENT_TYPE_ID='1184',ORDER_SOURCE_ID = '1184' WHERE ORG_ID = 98757 AND ORDER_SOURCE_ID =1084;
commit;
DBMS_OUTPUT.PUT_LINE('Updated ' || SQL%ROWCOUNT || 'in Headercfm');
UPDATE APPS.OE_ORDER_LINES_ALL SET SOURCE_DOCUMENT_TYPE_ID='1184',ORDER_SOURCE_ID = '1184' WHERE ORG_ID = 98757 AND ORDER_SOURCE_ID =1084;
commit;
DBMS_OUTPUT.PUT_LINE('Updated ' || SQL%ROWCOUNT || 'in Linecfm');
UPDATE APPS.WSH_DELIVERY_DETAILS SET SOURCE_DOCUMENT_TYPE_ID = '1184' WHERE ORG_ID =98757 AND SOURCE_DOCUMENT_TYPE_ID ='1084' ;
commit;
DBMS_OUTPUT.PUT_LINE('Updated ' || SQL%ROWCOUNT || 'in deliverydetailscfm');
--MYHONDA--
UPDATE APPS.OE_ORDER_HEADERS_ALL SET SOURCE_DOCUMENT_TYPE_ID='1185',ORDER_SOURCE_ID = '1185' WHERE ORG_ID = 116797 AND ORDER_SOURCE_ID =1084;
commit;
DBMS_OUTPUT.PUT_LINE('Updated ' || SQL%ROWCOUNT || 'in Headerhonda');
UPDATE APPS.OE_ORDER_LINES_ALL SET SOURCE_DOCUMENT_TYPE_ID='1185',ORDER_SOURCE_ID = '1185' WHERE ORG_ID = 116797 AND ORDER_SOURCE_ID =1084;
commit;
DBMS_OUTPUT.PUT_LINE('Updated ' || SQL%ROWCOUNT || 'in Linehonda');
UPDATE APPS.WSH_DELIVERY_DETAILS SET SOURCE_DOCUMENT_TYPE_ID = '1185' WHERE ORG_ID =116797 AND SOURCE_DOCUMENT_TYPE_ID ='1084' ;
COMMIT;
DBMS_OUTPUT.PUT_LINE('Updated ' || SQL%ROWCOUNT || 'in deliverydetailshonda');
END;
END GEAE_MYGE_SHIPPING_DTL_PKG;