

GEAE_MYGE_PRICE_CATALOG_PKG

create or replace PACKAGE BODY GEAE_MYGE_PRICE_CATALOG_PKG AS

--------Change Log-------------------------------------
/*
Date          Changed By         Description
20-OCT-2014   Ravi Saxena        MYJIRATEST-3815 Catalog should be fetched when GTA setup has NULL in END_DATE
28-NOV-2018   Suguna             US230166:Passport Materials: Passport customers should be able to view Passport catalogs
*/

	PROCEDURE GET_PRICE_CATALOG_DETAILS(p_SSO		VARCHAR2
                                   ,P_IACO_CODE		varchar2
                                   ,p_CUST_ID		V_CUST_ID_ARRAY
                                   ,P_ROLE		varchar2
                                   ,p_OU_ID		VARCHAR2
                                   ,p_price_catalog	OUT V_PRICING_CATALOG_ARRAY
                                   ,P_MESSAGE	   OUT varchar2
                                   ) AS

L_PRICE_CATALOG V_PRICING_CATALOG_ARRAY := V_PRICING_CATALOG_ARRAY();
L_PRICE_CATALOG_CNT  number := 0;
L_PRICE_DUP_CATALOG V_PRICING_CATALOG_ARRAY := V_PRICING_CATALOG_ARRAY();
v_not_match_flag	boolean;
l_dup_cnt	NUMBER ;
--Passport Changes start to save the OU_ID separated by comma US230166
  v_ou_id                      VARCHAR2(100)   := NULL;
  v_ou_id1                     VARCHAR2(100)   := NULL;
  v_ou_id2                     VARCHAR2(100)   := NULL;
  j_ou_id                      VARCHAr2(100)   := NULL;
--end
--P_PRICE_CATALOG := V_PRICING_CATALOG_ARRAY();
--V_CUST_ID V_CUST_ID_ARRAY := V_CUST_ID_ARRAY ();
begin
     p_price_catalog := V_PRICING_CATALOG_ARRAY();
     --passport change start
     v_ou_id := P_OU_ID;
     v_ou_id1 := REGEXP_SUBSTR(v_ou_id, '[^~]+', 1,1);
     v_ou_id2 :=  REGEXP_SUBSTR (v_ou_id, '[^~]+', 1, 2);
--      DBMS_OUTPUT.PUT_line('v_ou_id   '||v_ou_id);
--      DBMS_OUTPUT.PUT_line('v_ou_id1   '||v_ou_id1);
--      DBMS_OUTPUT.PUT_line('v_ou_id2  '||v_ou_id2);
     --end
--v_cust_id := p_cust_id;
if P_ROLE <> 'Global Enquiry' then ---- If condition for global enquiry
--
     if P_CUST_ID.COUNT > 0 then ---Cust Ids are not null
--
			for VAR in 1 .. p_cust_id.COUNT LOOP --loop for select
			     -- to fetch the customer Price Catalog details address
           /******************************************************
            Passport changes start US230166
            Suguna Added below to fetch the OU_ID based on the customer code
            *******************************************************/
         IF P_OU_ID like '%~%' THEN
                    BEGIN
                        SELECT distinct HCASA.org_id
                        INTO j_ou_id
                        FROM  HZ_CUST_ACCOUNTS hca, HZ_CUST_ACCT_SITES_ALL HCASA
                        WHERE (HCASA.org_id = to_number(v_ou_id1) or  HCASA.org_id = to_number(v_ou_id2))
                        AND  NVL(HCASA.STATUS, 'I') = 'A'
                        AND NVL(hca.status, 'I') = 'A'
                        AND hcasa.cust_account_id = hca.cust_account_id
                        and hca.cust_Account_id = p_cust_id(var);
                    -- DBMS_OUTPUT.PUT_line('j_ou_id  '||j_ou_id);

                    IF j_ou_id IS NULL THEN
                        SELECT LOOKUP_CODE || ': ' || DESCRIPTION
                        INTO p_message
                        FROM fnd_lookup_values
                        where LOOKUP_TYPE = 'GEAE_MYGE_ERROR_CODES'
                        and UPPER(LOOKUP_CODE) = UPPER('8503');
                        GOTO END_PROC;  --05-DEC-2018 Manisha introduced this to exit the proc in case of error while fetching OU_ID
                    END IF;

                    EXCEPTION
                    WHEN OTHERS THEN
                    p_message:= 'Error while fetching the OU_ID: '||SQLCODE||SQLERRM;
                    GOTO END_PROC; --05-DEC-2018 Manisha introduced this to exit the proc in case of error while fetching OU_ID
                    END;
            ELSE
              j_ou_id := TO_NUMBER(P_OU_ID);
            END IF;
            --passport changes end

           SELECT   V_PRICING_CATALOG ( engine_family.enty_cd
                                          )
				 bulk collect into L_PRICE_CATALOG
				from ( select distinct ENGINE_PLATFORM.ENTY_CD
              from
                 (select distinct ENTY_CD
                    from GEAE_ONT_GTA_MODEL GOGM
                         ,GEAE_ONT_CUST_GTA_INFO GCGI
                    where 1 = 1
                    and GOGM.ENTY_TYP = 'ENGINE_FAMILY'
                    and GOGM.GEAE_ONT_CUST_GTA_INFO_SEQ_ID = GCGI.GEAE_ONT_CUST_GTA_INFO_SEQ_ID
                    and NVL(GCGI.END_DATE,trunc(sysdate)) >= trunc(sysdate) --MYJIRATEST-3815 Ravi S 20-OCT-2014
                    and NVL(GCGI.START_DATE, trunc(sysdate)) <= trunc(sysdate)
                    and gcgi.customer_id = p_cust_id(var)
                    and GCGI.ORG_ID = j_ou_id --P_OU_ID commented for Passport
                union
                select distinct bsb.attribute10
                from  BOM_STRUCTURES_B BSB
                     ,mtl_parameters mp
                     ,GEAE_ONT_GTA_MODEL GOGM
                     ,GEAE_ONT_CUST_GTA_INFO GCGI
                where 1 = 1
                and bsb.organization_id = mp.organization_id
                and mp.organization_code = 'CVO'
                and bsb.assembly_item_id = gogm.engine_model_id
                and GOGM.ENTY_TYP = 'ENGINE_MODEL'
                and GOGM.GEAE_ONT_CUST_GTA_INFO_SEQ_ID = GCGI.GEAE_ONT_CUST_GTA_INFO_SEQ_ID
                and NVL(GCGI.END_DATE,trunc(sysdate)) >= trunc(sysdate) --MYJIRATEST-3815 Ravi S 20-OCT-2014
                and NVL(GCGI.START_DATE, trunc(sysdate)) <= trunc(sysdate)
                and GCGI.CUSTOMER_ID = P_CUST_ID(VAR)
                and GCGI.ORG_ID = j_ou_id --P_OU_ID
                union
                select distinct bsb.attribute10
                from  BOM_STRUCTURES_B BSB
                     ,mtl_parameters mp
                     ,GEAE_ONT_GTA_MODEL GOGM
                     ,GEAE_ONT_CUST_GTA_INFO GCGI
                where 1 = 1
                and BSB.attribute11 = GOGM.ENTY_CD
                and BSB.ORGANIZATION_ID = MP.ORGANIZATION_ID
                and mp.organization_code = 'CVO'
                and GOGM.ENTY_TYP = 'PRODUCT_LINE'
                and GOGM.GEAE_ONT_CUST_GTA_INFO_SEQ_ID = GCGI.GEAE_ONT_CUST_GTA_INFO_SEQ_ID
                and NVL(GCGI.END_DATE,trunc(sysdate)) >= trunc(sysdate) --MYJIRATEST-3815 Ravi S 20-OCT-2014
                and NVL(GCGI.START_DATE, trunc(sysdate)) <= trunc(sysdate)
                and GCGI.CUSTOMER_ID = P_CUST_ID(VAR)
                and GCGI.ORG_ID = j_ou_id --P_OU_ID
              ) ENGINE_PLATFORM
              ) ENGINE_FAMILY
				WHERE 1 = 1;

				IF sql%rowcount  > 0 THEN ---records sql count
					/*for I in 1 .. L_PRICE_CATALOG.COUNT LOOP
           --p_message := 'Inside record';
						L_price_catalog_cnt :=   l_price_catalog_cnt  +1;
						P_PRICE_CATALOG.extend();
						p_price_catalog(l_price_catalog_cnt) := L_PRICE_CATALOG(i);
					end LOOP ;*/
		for I in 1 .. L_PRICE_CATALOG.COUNT LOOP
			L_price_catalog_cnt :=   l_price_catalog_cnt  +1;
			L_PRICE_DUP_CATALOG.extend();
			L_PRICE_DUP_CATALOG(l_price_catalog_cnt) := L_PRICE_CATALOG(i);
		END loop;
         else
          NULL;
      /*   P_PRICE_CATALOG := V_PRICING_CATALOG_ARRAY();
          SELECT LOOKUP_CODE || ': ' || DESCRIPTION
          INTO p_message
          FROM fnd_lookup_values
         where LOOKUP_TYPE = 'GEAE_MYGE_ERROR_CODES'
           and UPPER(LOOKUP_CODE) = UPPER('8100');
           */
				end if ;----Records sql count
      END LOOP;

      IF L_PRICE_DUP_CATALOG.COUNT = 0 THEN
         SELECT LOOKUP_CODE || ': ' || DESCRIPTION
                  INTO p_message
                  FROM fnd_lookup_values
                 WHERE LOOKUP_TYPE = 'GEAE_MYGE_ERROR_CODES'
                   AND UPPER(LOOKUP_CODE) = UPPER('8056');
       END IF;
    --end if;
    else ---else of Customer passed are NULL

    ----Returning all thye catalogs as the role is GLOBAL ENQUIRY

                  SELECT LOOKUP_CODE || ': ' || DESCRIPTION
                  INTO p_message
                  FROM fnd_lookup_values
                 where LOOKUP_TYPE = 'GEAE_MYGE_ERROR_CODES'
                   and UPPER(LOOKUP_CODE) = UPPER('8101');
    end if;----Customer count if
  else ----Global Enquiry else
    SELECT   V_PRICING_CATALOG ( flv.LOOKUP_CODE
                                          )
				 bulk collect into L_PRICE_CATALOG
				from FND_LOOKUP_VALUES FLV
            ,hr_operating_units hou
				where 1 = 1
        and FLV.DESCRIPTION = HOU.name
        and FLV.LOOKUP_TYPE = 'GEAE_MYGE_ENGINE_FAMILY'
        and hou.organization_id = to_number(v_ou_id1) or hou.organization_id = to_number(v_ou_id2);--p_OU_ID; passport change
   IF sql%rowcount  > 0 THEN
					/*for I in 1 .. L_PRICE_CATALOG.COUNT LOOP
           --p_message := 'Inside record';
						L_price_catalog_cnt :=   l_price_catalog_cnt  +1;
						P_PRICE_CATALOG.extend();
						p_price_catalog(l_price_catalog_cnt) := L_PRICE_CATALOG(i);
					end LOOP ;*/

		for I in 1 .. L_PRICE_CATALOG.COUNT LOOP
			L_price_catalog_cnt :=   l_price_catalog_cnt  +1;
			L_PRICE_DUP_CATALOG.extend();
			L_PRICE_DUP_CATALOG(l_price_catalog_cnt) := L_PRICE_CATALOG(i);
		END loop;
    else
      P_PRICE_CATALOG := V_PRICING_CATALOG_ARRAY();
      SELECT LOOKUP_CODE || ': ' || DESCRIPTION
          INTO p_message
          FROM fnd_lookup_values
         where LOOKUP_TYPE = 'GEAE_MYGE_ERROR_CODES'
           and UPPER(LOOKUP_CODE) = UPPER('8100');
    END IF;
  END IF;
  -- to remove the duplicate reocrds
	  IF L_PRICE_DUP_CATALOG.COUNT > 0 THEN
		 /* FOR var IN 1 .. p_price_catalog.COUNT LOOP
			L_PRICE_DUP_CATALOG.extend();
			L_PRICE_DUP_CATALOG(var) := p_price_catalog(var);
		  END LOOP ;*/
		 p_price_catalog := V_PRICING_CATALOG_ARRAY();

		 l_dup_cnt	:= 1;
		 P_PRICE_CATALOG.extend();
		 p_price_catalog(l_dup_cnt) := L_PRICE_DUP_CATALOG(1);
		 FOR var IN 1 .. L_PRICE_DUP_CATALOG.COUNT LOOP
			v_not_match_flag := TRUE;
			<<Inner>>
			FOR dup IN 1 .. P_PRICE_CATALOG.COUNT LOOP
				IF L_PRICE_DUP_CATALOG(var).PLATFORM = P_PRICE_CATALOG(dup).PLATFORM THEN
					v_not_match_flag := FALSE ;
					EXIT WHEN  L_PRICE_DUP_CATALOG(var).PLATFORM = P_PRICE_CATALOG(dup).PLATFORM;
				END IF ;
			END LOOP ;
			IF v_not_match_flag THEN
				 l_dup_cnt	:= l_dup_cnt+ 1;
				 P_PRICE_CATALOG.extend();
				 p_price_catalog(l_dup_cnt) := L_PRICE_DUP_CATALOG(var);
			END IF;
		 END LOOP;
	  END IF ;

      <<END_PROC>> --05-DEC-2018 Manisha introduced this to exit the proc in case of error while fetching OU_ID
      NULL;

  EXCEPTION
   when OTHERS then
     SELECT LOOKUP_CODE || ': ' || DESCRIPTION
          INTO p_message
          FROM fnd_lookup_values
         where LOOKUP_TYPE = 'GEAE_MYGE_ERROR_CODES'
           and UPPER(LOOKUP_CODE) = UPPER('8000');
     p_price_catalog := V_PRICING_CATALOG_ARRAY();
 end  GET_PRICE_CATALOG_DETAILS;
 END  GEAE_MYGE_PRICE_CATALOG_PKG;