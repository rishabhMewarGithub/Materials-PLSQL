

GEAE_MYGE_CART_PKG

create or replace PACKAGE BODY "GEAE_MYGE_CART_PKG"
AS
--------------- GET CART INFO PROCEDURE STARTS HERE----
--------Change Log-------------------------------------
/*
Date          Changed By         Description
03-SEP-2014   Ravi Saxena        MYJIRATEST-3293 AND MYJIRATEST-2706 Fix to add error code for invalid configuration in case of configurable kit
03-SEP-2014   Ravi Saxena        MYJIRATEST-3292 Fix to have same customer_line_number in case of kit splitting
06-SEP-2014   Ravi Saxena        Enable Kit configuration
11-SEP-2014   Ravi Saxena        Fix for Customer Line Number
16-SEP-2014   Ravi Saxena        MYJIRATEST-3334 Added Bulk Cart functionality
19-SEP-2014   Ravi Saxena        Fix for MYJIRATEST-3514
19-SEP-2014   Ravi Saxena        MYJIRATEST-3513 Authorization added
25-SEP-2014   Ravi Saxena        MYJIRATEST-3575 Show PO value as blank if no part is priced
20-OCT-2014   Ravi Saxena        MYJIRATEST-3816: Site_use_code to be used instead of attribute_category
20-OCT-2014   Ravi Saxena        MYJIRATEST-3817: Get_cart_count to be filtered based on OU_ID
21-OCT-2014   Ravi Saxena        MYJIRATEST-3334: Modified GET_CART_INFO to get additional fields for Bulk Cart functionality
27-OCT-2014   Ravi Saxena        MYJIRATEST-3976: Corrected BULK_CART_ADD for authorization
05-NOV-2014   Ravi Saxena        MYJIRATEST-3989: Add KIT Indicator to the GET_ITEM_PRICE_AVAIL procedure call
14-NOV-2014   Ravi Saxena        MYJIRATEST-4316: Add UPQ rollup in Bulk Cart, MYJIRATEST-4427: Convert part number to UPPER in BULK CART
18-NOV-2014   Ravi Saxena        MYJIRATEST-3512: Modified user access process - changes in CREATE_KIT_CONFIG
18-NOV-2014   Ravi Saxena        MYJIRATEST-4434: Do not allow to add part in bulk cart if P_MESSAGE is retrieved from GET_ITEM_PRICE_AVAIL
20-NOV-2014   Ravi Saxena        MYJIRATEST-4588: If carts are deleted, then dont show error messages
01-DEC-2014   Ravi Saxena        MYJIRATEST-4653: Fix code so that Price list id is not mANDatory in bulk cart
30-JAN-2015   Ravi Saxena        MYJIRATEST-5080: Add Order line id in V_QT_LINE_STS_DTL
30-JAN-2015   Ravi Saxena        MYJIRATEST-5080: Add Order line id in V_QT_LINE_STS_DTL
10-FEB-2015   Ravi Saxena        MYJIRATEST-5845: Make Order Source configurable by OU ID
03-MAR-2015   Ravi Saxena        MYJIRATEST-6272 AND MYJIRATEST-6277: Aero enhancement changes
17-MAR-2015   Ankita Shetty      MYJIRATEST-5952 Display Discount price, net price in Get cart info
24-MAR-2015   Abhinav Srivastava MYJIRATEST-7138 Oderable Vs Non Oderable changes
13-APR-2015   Abhinav Srivastava MYJIRATEST-7141/7142  UPQ hANDling for Aero DP request
28-APR-2015   Abhinav Srivastava MYJIRATEST-6517 Fix for Deliver to location code
04-MAY-2015   Ankita Shetty      MYJIRATEST-7638 Added filter for Active Ship_to addresses
04-JUN-2015   Abhinav Srivastava MYJIRATEST-XXXX Bulk upload - should not let you upload non-orderable part
07-SEP-2015   Neelima Y          MYJIRATEST-6162 -- KIT Indicator
07-SEP-2015   Neelima Y          MYJIRATEST 8774 -- Bulk cart
28-SEP-2015   Neelima Y          MYJIRATEST-8480 -- Save cart in checkout screen
01-OCT-2015   Neelima Y          MYJIRATEST-8723 -- Adding ESN
11-APR-2016   TRUPTI D.          MYJIRATEST-7526 code change for duplicate line num issue
07-APR-2017   R Prasad           US63780 AND US62974: Add PO number to bulk buy feature(Bulk upload) - NEW
02-MAY-2017   R Prasad           US73297 AND US73300: TESTING AND MIGRATION(US17592): Ability to save items for later in a Saved List AND TESTING AND MIGRATION (US17591)Ability to move parts from Saved List to Cart AND vice versa
30-MAR-2017   Manisha Kumari     US161834/US166305: Added column workstop_date, workstop_qty in save_cart_proc
30-MAR-2017   Manisha Kumari     US161328: If priority = 'Work Stop' then the fields  Work Stop Date/Quantity AND ESN are required fields in APPS.geae_myge_cart_pkg.bulk_cart_add_po
30-MAR-2017   Manisha Kumari     US161328: Add Work Stop Date/Quantity AND ESN in GET_CART_INFO proc
25-APR-2018   Suguna             message changed for ESN validation when it is Null
22-NOV-2018   Manisha Kumari    Added the change for Passport requirement; Two OU_ID will be passed separaed by tilde symbol in the input parameter.
19-AUG-2019   Ratheesh Poshala    Added changes for US313415- Order Request date Logic Change -myGEAviation...
*/


--GET_CART_INFO
--SAVE_CART
--GET_CART_COUNT
--DELETE_CART_LINE
--DELETE_CART
--CREATE_CART
--ADD_CART_LINE
--BOOK_ORDER
--PURCHASE_PO
--BULK_CART_ADD
--GEAE_DELIVER_TO
--UPDATE_QUOTE_STS
--GET_ERR_MSG
--CREATE_KIT_CONFIG
--VALIDATE_CONFIG
--GEAE_WISHLT_INSERT_PROC
--GEAE_WISHLT_GET_PROC
--GEAE_WISHLT_DELETE_PROC
--BULK_CART_ADD_PO
--WP_get_SDND_reqdate_leadtime



PROCEDURE GET_CART_INFO
(
	P_SSO 				VARCHAR2
    P_ROLE     			VARCHAR2
    P_IACO_CODE 		VARCHAR2
    P_CUST_ID   		V_CUST_ID_ARRAY
    P_OU_ID       		VARCHAR2
    P_QUOTE_HDR_DTL 	OUT V_QUOTE_HEADER_ARRAY
    P_QUOTE_LINE_DTL 	OUT V_QUOTE_LINE_ARRAY
    P_MSG     			OUT VARCHAR2
    P_PO_TOTAL 			OUT NUMBER
						
)

AS



CURSOR C_QUOTE_HDR_DTL	(V_OU_ID VARCHAR2) 
IS --Manisha K. 07-Sep-18 Made parametized cursor to pass the OU_iD one by one in loop
(
	SELECT 	AQH.QUOTE_HEADER_ID,
			AQH.CREATION_DATE REQUESTED_DATE,
			AQH.CUST_ACCOUNT_ID CUSTOMER_ID,
			HCA.ACCOUNT_NUMBER CUSTOMER_CODE,
			AQH.ATTRIBUTE1 SUPPLIER_CODE,
			AQH.TOTAL_QUOTE_PRICE PURCHASE_ORDER_VALUE, 
			ASP.CUST_PO_NUMBER PURCHASE_PO_NUMBER, 
			FLV.DESCRIPTION SUPPLIER_DESCRIPTION,
			ASS.REQUEST_DATE HEADER_REQUEST_DATE,
			DECODE(ASS.SHIPMENT_PRIORITY_CODE,'40_WKSTP','WSP','50_NORMAL','NORMAL',ASS.SHIPMENT_PRIORITY_CODE) SHIPMENT_PRIORITY_CODE --Neelima.Y MYJIRATEST-8480
	FROM 	ASO_QUOTE_HEADERS_ALL 	AQH, 
			FND_USER 				FNU,
			HZ_CUST_ACCOUNTS 		HCA, 
			ASO_PAYMENTS 			ASP,
			FND_LOOKUP_VALUES 		FLV,
			ASO_SHIPMENTS 			ASS --Neelima.Y MYJIRATEST-8480
	WHERE 	AQH.CREATED_BY=FNU.USER_ID
	AND 	AQH.QUOTE_HEADER_ID=ASP.QUOTE_HEADER_ID(+)
	AND 	AQH.CUST_ACCOUNT_ID=HCA.CUST_ACCOUNT_ID
	AND 	ASP.QUOTE_LINE_ID IS NULL
	AND 	AQH.QUOTE_HEADER_ID=ASS.QUOTE_HEADER_ID(+)   --Neelima.Y MYJIRATEST-8480
	AND 	ASS.QUOTE_LINE_ID IS NULL                    --Neelima.Y MYJIRATEST-8480
	AND 	AQH.QUOTE_STATUS_ID IN (10000,10010)
	AND 	AQH.QUOTE_EXPIRATION_DATE > SYSDATE
	AND 	AQH.ATTRIBUTE1 = FLV.LOOKUP_CODE
	AND 	flv.LOOKUP_TYPE='GEAE_MYGE_SUPPLIER_DESCRIPTION'
	AND 	FNU.USER_NAME=P_SSO
	AND 	AQH.ORG_ID = V_OU_ID 
)
ORDER BY AQH.QUOTE_HEADER_ID			;




------------ line level cursor declaration-------------

CURSOR C_QUOTE_LINE_DTL	(X_HEADER_ID NUMBER, V_OU_ID VARCHAR2) 
IS --Manisha K. 07-Sep-18 Added variable V_OU_ID to pass the OU_iD one by one in loop
(
	SELECT 	AQH.QUOTE_HEADER_ID,
			AQL.QUOTE_LINE_ID,
			AQL.QUANTITY,
			AQL.LINE_LIST_PRICE UNIT_PRICE,
			AQL.LINE_QUOTE_PRICE*(AQL.QUANTITY) EXTENDED_PRICE, 
			MSI.SEGMENT1 PART_NUMBER,
			MSI.DESCRIPTION,
			aqh.price_list_id,
			msi.INVENTORY_ITEM_ID,
			AP.CUST_PO_LINE_NUMBER,
			DECODE(ASHIP.SHIPMENT_PRIORITY_CODE,'40_WKSTP','WSP','50_NORMAL','NORMAL',ASHIP.SHIPMENT_PRIORITY_CODE) SHIPMENT_PRIORITY_CODE, --if then else and default
			ASHIP.REQUEST_DATE,
			(AQL.LINE_LIST_PRICE-AQL.LINE_QUOTE_PRICE) DISCOUNT_PRICE,
			AQL.ITEM_TYPE_CODE,
			AQL.LINE_QUOTE_PRICE, --Ankita.S MYJIRATEST-5952
			substr(AQL.attribute7,1,6) MYGEA_ESN, --Neelima Y MYJIRATEST-8723
			To_date(REGEXP_SUBSTR (AQL.attribute7, '[^~]+', 1, 2),'YYYY/MM/DD hh24:mi:ss') WORKSTP_DATE,  --Suguna US161328
			--REGEXP_SUBSTR (AQL.attribute7, '[^~]+', 1, 2) WORKSTP_DATE Manisha
			cast(REGEXP_SUBSTR (AQL.attribute7, '[^~]+', 1, 3)as number) WORKSTP_QTY  --Manisha US161328 -----type casting
	FROM	ASO_QUOTE_HEADERS_ALL 	AQH, 
			ASO_QUOTE_LINES_ALL 	AQL, 
			FND_USER 				FNU, 
			MTL_SYSTEM_ITEMS_B 		MSI, 
			ASO_PAYMENTS 			AP, 
			ASO_SHIPMENTS 			ASHIP
	WHERE	AQH.QUOTE_HEADER_ID=AQL.QUOTE_HEADER_ID
	AND 	AQL.INVENTORY_ITEM_ID=MSI.INVENTORY_ITEM_ID
	AND 	AQL.ORGANIZATION_ID=MSI.ORGANIZATION_ID
	AND 	AQL.QUOTE_HEADER_ID = X_HEADER_ID
	AND 	AQH.QUOTE_STATUS_ID IN (10000,10010)
	AND 	AQH.QUOTE_EXPIRATION_DATE > SYSDATE
	AND 	AQH.CREATED_BY= FNU.USER_ID
	AND 	AQL.ITEM_TYPE_CODE in ('STD','MDL') -- added for Kit Config Issues on 08-Sep-2014 by Mohammed Yadul
	AND 	AP.QUOTE_HEADER_ID(+) = AQL.QUOTE_HEADER_ID
	AND 	AP.QUOTE_LINE_ID(+) = AQL.QUOTE_LINE_ID
	AND 	ASHIP.QUOTE_HEADER_ID(+) = AQL.QUOTE_HEADER_ID
	AND 	ASHIP.QUOTE_LINE_ID(+) = AQL.QUOTE_LINE_ID
	AND 	FNU.USER_NAME=P_SSO
	AND 	AQH.ORG_ID = V_OU_ID 
)
ORDER BY /*AQL.QUOTE_LINE_ID*/AQL.CREATION_DATE			; --commented by prasad on 04-JUL-2016


l_upq QP_LIST_LINES_V.attribute2%type;
l_lead_time QP_LIST_LINES_V.attribute3%type;

---------------------------------------------------------------------------------------


CURSOR C_QTH_TOT	(V_OU_ID VARCHAR2) 
IS

SELECT 	SUM(LINE_QUOTE_PRICE*(QUANTITY)) totamt
FROM 	ASO_QUOTE_HEADERS_ALL 	AQH, 
		FND_USER 				FNU,  
		aso_quote_lines_all 	aql,
		HZ_CUST_ACCOUNTS 		HCA, 
		FND_LOOKUP_VALUES 		FLV
WHERE 	AQH.CREATED_BY = FNU.USER_ID
AND 	AQH.CUST_ACCOUNT_ID = HCA.CUST_ACCOUNT_ID
AND 	AQH.QUOTE_HEADER_ID = aql.QUOTE_HEADER_ID
AND 	AQH.QUOTE_STATUS_ID IN (10000,10010)
AND 	AQH.QUOTE_EXPIRATION_DATE > SYSDATE
AND 	AQH.ATTRIBUTE1 = FLV.LOOKUP_CODE
AND 	flv.LOOKUP_TYPE = 'GEAE_MYGE_SUPPLIER_DESCRIPTION'
AND 	FNU.USER_NAME=P_SSO
AND 	AQH.ORG_ID =V_OU_ID 			;



V_HDR_COUNTER INTEGER := 0;
V_LINE_COUNTER INTEGER := 0;
QT_TOTL NUMBER := 0;  --Manisha K )7-Sept-2018 Init
V_USER_ID  FND_USER.USER_ID%TYPE;
V_RESP_ID  FND_RESPONSIBILITY_TL.RESPONSIBILITY_ID%TYPE;
V_APP_ID   FND_RESPONSIBILITY_TL.APPLICATION_ID%TYPE;
V_ITEM_QTY NUMBER;
V_VAL_CNT    NUMBER;
V_PR_EXISTS  VARCHAR2(1);
V_PO_VALUE   NUMBER;
V_KIT_IND    VARCHAR2(1);   -- Neelima Y MYJIRATEST-6162
v_item_source VARCHAR2(500); -- Added for OWMS Implementation US192483/US192484
v_er1_source VARCHAR2(500); -- Added for OWMS Implementation US192483/US192484
v_er2_source VARCHAR2(500); -- Added for OWMS Implementation US192483/US192484
v_er3_source VARCHAR2(500); -- Added for OWMS Implementation US192483/US192484
v_hnd_flag	  VARCHAR2(5);-- Added for OWMS Implementation US192483/US192484
v_ou_id   VARCHAR2(240);  -- Manisha added to save the ou id separated by comma
V_PO_TOTAL  NUMBER := 0;  --Manisha Added to save intermediate value of P_TOTAL



BEGIN

	P_QUOTE_HDR_DTL    := V_QUOTE_HEADER_ARRAY();
	P_QUOTE_LINE_DTL   := V_QUOTE_LINE_ARRAY();
	V_PR_EXISTS := 'N';
	
	
	--------SSO Validation-------
	
	IF P_SSO IS NULL 
	THEN
		P_MSG := GET_ERR_MSG(8024);
		goto end_proc;
	END IF;
	
	SELECT	USER_ID
	INTO 	V_USER_ID
	FROM 	FND_USER
	WHERE 	USER_NAME = P_SSO;
	
	IF P_OU_ID IS NULL 
	THEN
		P_MSG := GET_ERR_MSG(8025);
		goto end_ou;
	END IF;
	
	
	
  ----------------FETCHING RESPONSIBILITY ID AND APPLICATION_ID-----------------------

  /*******************************************
  Manisha added the below code for Passport Requirement
  If user have access for both OU ID's , then the data for both OU_ID will be fetched
  ***************************************************/

    V_OU_ID := Replace(P_OU_ID,'~',',');

    FOR j 
	IN
    (
		SELECT 	trim(regexp_substr(V_OU_ID, '[^,]+', 1, LEVEL)) ou_id   ----looping 
		FROM 	dual
		CONNECT BY LEVEL <= regexp_count(V_OU_ID, ',')+1
    )
	LOOP

		IF j.ou_id IS NULL 
		THEN
			p_MSG := GET_ERR_MSG(8503);
			goto end_ou;
		END IF;

		BEGIN
			SELECT 	RESP.RESPONSIBILITY_ID,
					RESP.APPLICATION_ID
			INTO 	V_RESP_ID,
					V_APP_ID
			FROM  	FND_RESPONSIBILITY_TL RESP,
					FND_LOOKUP_VALUES FLV ,
					HR_OPERATING_UNITS HOU
			WHERE 	HOU.NAME = FLV.MEANING
			AND 	RESP.RESPONSIBILITY_NAME = FLV.DESCRIPTION
			AND 	HOU.ORGANIZATION_ID = j.OU_ID -- P_OU_ID
			AND 	FLV.LOOKUP_TYPE = 'GEAE_MYGE_QUOTE_RESPONSIBILITY'		;
			EXCEPTION
				WHEN no_data_found 
				THEN
					P_MSG := GET_ERR_MSG(8026);
					goto end_ou;
		END;
		
		BEGIN
			FND_GLOBAL.APPS_INITIALIZE(v_user_id,v_resp_id,v_app_id);
			mo_global.set_policy_context('S',j.OU_ID);
		END;
	
		FOR HEADER_REC  IN C_QUOTE_HDR_DTL(j.OU_ID)
		LOOP
		
			V_HDR_COUNTER := V_HDR_COUNTER+1;
			
			SELECT 	COUNT(1)
			INTO 	V_VAL_CNT
			FROM 	ASO_QUOTE_HEADERS_ALL AQH, 
					ASO_QUOTE_LINES_ALL AQL, 
					FND_USER FNU, 
					MTL_SYSTEM_ITEMS_B MSI
			WHERE 	AQH.QUOTE_HEADER_ID=AQL.QUOTE_HEADER_ID
			AND 	AQL.INVENTORY_ITEM_ID=MSI.INVENTORY_ITEM_ID
			AND 	AQL.ORGANIZATION_ID=MSI.ORGANIZATION_ID
			AND 	AQL.QUOTE_HEADER_ID = HEADER_REC.QUOTE_HEADER_ID
			AND 	AQH.QUOTE_STATUS_ID IN (10000,10010)
			AND 	AQH.QUOTE_EXPIRATION_DATE > SYSDATE
			AND 	AQH.CREATED_BY= FNU.USER_ID
			AND 	AQL.ITEM_TYPE_CODE in ('STD','MDL') -- added for Kit Config Issues on 08-Sep-2014 by Mohammed Yadul
			AND 	FNU.USER_NAME=P_SSO
			AND 	AQH.ORG_ID = j.OU_ID
			AND 	AQL.LINE_LIST_PRICE IS NOT NULL		;
		
			IF V_VAL_CNT > 0 
			THEN
				V_PO_VALUE := HEADER_REC.PURCHASE_ORDER_VALUE;
				V_PR_EXISTS := 'Y';
			ELSE
				V_PO_VALUE := NULL;
			END IF;
			
			P_QUOTE_HDR_DTL.extend(); 			------ for multiple values
			P_QUOTE_HDR_DTL(P_QUOTE_HDR_DTL.last)	:=	V_QUOTE_HEADER_DETAILS
														(
															HEADER_REC.QUOTE_HEADER_ID ,
															HEADER_REC.PURCHASE_PO_NUMBER , 
															HEADER_REC.REQUESTED_DATE , 
															HEADER_REC.CUSTOMER_ID , 
															HEADER_REC.CUSTOMER_CODE, 
															HEADER_REC.SUPPLIER_CODE ,
															NULL ,
															V_PO_VALUE, 
															HEADER_REC.SUPPLIER_DESCRIPTION,
															HEADER_REC.HEADER_REQUEST_DATE,
															HEADER_REC.SHIPMENT_PRIORITY_CODE  
														);
														
									
									
		-------------------------------------line level loop starts here-----------------------------------------


			FOR 	LINE_REC  
			IN 		C_QUOTE_LINE_DTL(HEADER_REC.QUOTE_HEADER_ID, J.OU_ID)
			LOOP
				BEGIN
					DBMS_OUTPUT.PUT_LINE('P_PO_TOTAL = ' || LINE_REC.workstp_qty);--Manisha
					SELECT 	QLL.ATTRIBUTE2 ,
							QLL.ATTRIBUTE3 
					INTO 	l_lead_time, 
							l_upq
					FROM 	QP_LIST_LINES_V QLL
					WHERE 	1=1 
					AND 	qll.list_header_id = LINE_REC.price_list_id
					AND 	qll.product_attr_value = to_char(LINE_REC.INVENTORY_ITEM_ID)
					AND 	sysdate between qll.start_date_active AND qll.end_date_active;
					EXCEPTION
						WHEN no_data_found 
						THEN
							l_lead_time := null;
							l_upq := 1;
				END;
				
				/*  
					SELECT 	SUM(qty)
					INTO 	V_ITEM_QTY
					FROM (
					   SELECT NVL(SUM(MOQ.TRANSACTION_QUANTITY),0)-NVL(stg2.reserve_qty,0) qty
						 FROM MTL_ONHAND_QUANTITIES MOQ,
							  hr_operating_units hou,
							  MTL_SYSTEM_ITEMS_B MSI,
							  MTL_PARAMETERS MTP,
							  fnd_lookup_values flv ,
							  (SELECT MRS.INVENTORY_ITEM_ID ,
									  MRS.ORGANIZATION_ID ,
									  SUM(MRS.RESERVATION_QUANTITY) reserve_qty
								 FROM MTL_RESERVATIONS MRS
							   GROUP BY MRS.INVENTORY_ITEM_ID,
										MRS.ORGANIZATION_ID
							  ) stg2
						WHERE 1                        = 1
						  AND stg2.INVENTORY_ITEM_ID (+) = MSI.INVENTORY_ITEM_ID
						  AND stg2.organization_id (+)   = MSI.ORGANIZATION_ID
						  AND MOQ.ORGANIZATION_ID(+)     = MSI.ORGANIZATION_ID
						  AND MOQ.INVENTORY_ITEM_ID(+)   = MSI.INVENTORY_ITEM_ID
						  AND HOU.ORGANIZATION_ID        = to_number(j.OU_ID)
						  AND hou.name                   = flv.description
						  AND MTP.ORGANIZATION_CODE      = FLV.tag
						  AND flv.lookup_type            = 'GEAE_MYGE_PART_APPLICABLE_ORGS'
						  AND MTP.organization_code     NOT IN  ('HAI','SDC','CPL') --Added by Capgemini OWMS Team for MyGE Changes
						  AND MTP.organization_code NOT IN
												(SELECT FFV.flex_value
												   FROM fnd_flex_values FFV ,
														fnd_flex_value_sets FVS
												  WHERE FFV.flex_value_set_id=FVS.flex_value_set_id
													AND FVS.FLEX_VALUE_SET_NAME='GEAE_AMPS_RETIRED_ORGS'
												 )
						  AND MTP.attribute_category IN ('SPR','OSW','SCP')
						  AND MSI.ORGANIZATION_ID     = MTP.ORGANIZATION_ID
						  AND MSI.INVENTORY_ITEM_ID   = LINE_REC.INVENTORY_ITEM_ID
					   GROUP BY stg2.reserve_qty
						UNION ALL                       -- Neelima Y MYJIRATEST-8631 on 18-AUG-2015
					   SELECT SUM(HND.QTY)
						 FROM (SELECT DISTINCT MSIB.INVENTORY_ITEM_ID,
									  GIF.ONHAND_QTY  QTY
								 FROM GEAE_INV_FOXTROT_DATA_STG GIF,
									  MTL_SYSTEM_ITEMS_B MSIB,
									  HR_OPERATING_UNITS HOU,
									  MTL_PARAMETERS MTP,
									  FND_LOOKUP_VALUES FLV
								WHERE MSIB.SEGMENT1=GIF.PRT_NUM
								  AND HOU.ORGANIZATION_ID        = TO_NUMBER(j.OU_ID)
								  AND HOU.NAME                   = FLV.DESCRIPTION
								  AND MTP.ORGANIZATION_CODE      = FLV.TAG
								  AND FLV.LOOKUP_TYPE            = 'GEAE_MYGE_PART_APPLICABLE_ORGS'
								  AND GIF.ORG_CODE               = MTP.ORGANIZATION_CODE
								  AND MSIB.INVENTORY_ITEM_ID     = LINE_REC.INVENTORY_ITEM_ID
								  AND GIF.SRC_SYS ='HONDA') HND
								  /*Added by Capgemini OWMS Team for MyGE Changes - Start*/
						--UNION
					---- OWMS team Changes for DE25546 : Start
					/*SELECT LEAST(a.qty,b.qty)
					--INTO l_qty_on_hAND
					FROM (SELECT NVL(SUM(current_forecast_quantity), 99999999) qty
							  FROM mrp_forecast_dates
							 WHERE 1 = 1
							   AND trunc(forecast_date) < trunc(sysdate) +90
							   AND INVENTORY_ITEM_ID = LINE_REC.INVENTORY_ITEM_ID
							   AND ORGANIZATION_ID IN
								   (SELECT ORGANIZATION_ID
									  FROM MTL_PARAMETERS
									 WHERE ORGANIZATION_CODE = 'CPL')
						) a ,
						 (SELECT NVL(SUM(MOQ.TRANSACTION_QUANTITY),0) qty
							FROM MTL_ONHAND_QUANTITIES MOQ
						   WHERE INVENTORY_ITEM_ID = LINE_REC.INVENTORY_ITEM_ID
							 AND ORGANIZATION_ID IN (SELECT ORGANIZATION_ID
													   FROM MTL_PARAMETERS
													  WHERE ORGANIZATION_CODE = 'CPL'
													 )
						) b*\
						   SELECT LEAST(a.qty,(b.qty-c.qty))
						   --INTO l_qty_on_hAND
					FROM (SELECT NVL(SUM(current_forecast_quantity), 99999999) qty
							  FROM mrp_forecast_dates
							 WHERE 1 = 1
							   AND trunc(forecast_date) < trunc(sysdate) +90
							   AND INVENTORY_ITEM_ID = LINE_REC.INVENTORY_ITEM_ID
							   AND ORGANIZATION_ID IN
								   (SELECT ORGANIZATION_ID
									  FROM MTL_PARAMETERS
									 WHERE ORGANIZATION_CODE = 'CPL')
						) a ,
						 (SELECT NVL(SUM(MOQ.TRANSACTION_QUANTITY),0) qty
							FROM MTL_ONHAND_QUANTITIES MOQ
						   WHERE INVENTORY_ITEM_ID = LINE_REC.INVENTORY_ITEM_ID
							 AND ORGANIZATION_ID IN (SELECT ORGANIZATION_ID
													   FROM MTL_PARAMETERS
													  WHERE ORGANIZATION_CODE = 'CPL'
													 )
						) b,
					 (SELECT NVL(SUM(RESERVATION_QUANTITY),0) qty
								 FROM MTL_RESERVATIONS
						 WHERE INVENTORY_ITEM_ID = LINE_REC.INVENTORY_ITEM_ID
							 AND ORGANIZATION_ID IN (SELECT ORGANIZATION_ID
													   FROM MTL_PARAMETERS
													  WHERE ORGANIZATION_CODE = 'CPL'
													 )
				   ) C
					---- OWMS team Changes for DE25546 : End
					\*Added by Capgemini OWMS Team for MyGE Changes - End*\
								  );
				*/
				
				
				
				--------------------------------Added by OWMS Team : Start-----------------------------
				
				BEGIN
					v_item_source := NULL;
					
					SELECT 	DECODE(COUNT(1),1,'Y','N')
					INTO 	v_hnd_flag
					FROM 	HR_OPERATING_UNITS HOU,
							FND_LOOKUP_VALUES FLV
					WHERE  	HOU.ORGANIZATION_ID = TO_NUMBER(j.OU_ID) --116797
					AND 	HOU.NAME = FLV.DESCRIPTION
					AND 	FLV.TAG = 'HAI'
					AND 	FLV.LOOKUP_TYPE = 'GEAE_MYGE_PART_APPLICABLE_ORGS';
  
					IF v_hnd_flag = 'Y' 
					THEN
						v_item_source := 'HAI';
					ELSIF v_hnd_flag = 'N' 
					THEN
						v_er1_source := GEAE_INV_GET_SOURCE_CODE ('ER1',LINE_REC.PART_NUMBER,'Y');
						v_er2_source := GEAE_INV_GET_SOURCE_CODE ('ER2',LINE_REC.PART_NUMBER,'Y');
						v_er3_source := GEAE_INV_GET_SOURCE_CODE ('ER3',LINE_REC.PART_NUMBER,'Y');
						IF v_er1_source = 'CPL' OR v_er2_source = 'CPL' OR v_er3_source = 'CPL' 
						THEN
							v_item_source := 'CPL';
						ELSE
							v_item_source := 'ERL';
						END IF;
					END IF;
					
					SELECT	SUM(QTY)
					INTO 	V_ITEM_QTY
					FROM 	
					(
						SELECT (A.QTY - B.QTY)  QTY
						FROM 
						(
							SELECT  (	geae_wms_total_onhAND_erl_fun 	(msib.inventory_item_id, mp.organization_id,'PACK') 
										+ 
										geae_wms_total_pick_release		(msib.inventory_item_id, mp.organization_id,'PACK')
									) 	QTY
							FROM 	apps.mtl_system_items_b msib,
									apps.mtl_parameters mp
							WHERE 	1 = 1 
							AND 	msib.inventory_item_id = line_rec.inventory_item_id
							AND 	msib.organization_id = mp.organization_id
							AND 	mp.organization_code = v_item_source
							AND 	v_item_source NOT IN ('CPL','HAI')
						) A,
						(	
							SELECT  (	geae_wms_resv_qty_fun 	(msib.inventory_item_id, mp.organization_id,'PACK') 
										+ 
										geae_wms_total_resv		(msib.inventory_item_id, mp.organization_id,'PACK')
									) 	QTY
							FROM 	apps.mtl_system_items_b msib,
									apps.mtl_parameters mp
							WHERE 	1 = 1 
							AND 	msib.inventory_item_id = line_rec.inventory_item_id
							AND 	msib.organization_id = mp.organization_id
							AND 	mp.organization_code = v_item_source
							AND 	v_item_source NOT IN ('CPL','HAI')
						) B
										
						UNION ALL                       -- Neelima Y MYJIRATEST-8631 on 18-AUG-2015
										
						SELECT 	SUM(HND.QTY)
						FROM 
						(
									SELECT 	DISTINCT 
											MSIB.INVENTORY_ITEM_ID, 
											GIF.ONHAND_QTY QTY
									FROM 	GEAE_INV_FOXTROT_DATA_STG GIF,
											MTL_SYSTEM_ITEMS_B MSIB,
											HR_OPERATING_UNITS HOU,
											MTL_PARAMETERS MTP,
											FND_LOOKUP_VALUES FLV
									WHERE 	MSIB.SEGMENT1=GIF.PRT_NUM
									AND 	HOU.ORGANIZATION_ID  	= TO_NUMBER(j.OU_ID)
									AND 	HOU.NAME              	= FLV.DESCRIPTION
									AND 	MTP.ORGANIZATION_CODE 	= FLV.TAG
									AND 	FLV.TAG					= v_item_Source
									AND 	v_item_Source NOT IN ('CPL','ERL')
									AND 	FLV.LOOKUP_TYPE         = 'GEAE_MYGE_PART_APPLICABLE_ORGS'
									AND 	GIF.ORG_CODE            = MTP.ORGANIZATION_CODE
									AND 	MSIB.INVENTORY_ITEM_ID  = LINE_REC.INVENTORY_ITEM_ID
									AND 	GIF.SRC_SYS ='HONDA'
						) 	HND
												
						UNION
												
						SELECT (A.QTY - B.QTY)  QTY
						FROM 
						(
							SELECT 	NVL(SUM(MOQ.TRANSACTION_QUANTITY), 0) 	QTY
							FROM 	GEAE_INV_MTL_ONHANDS_V			 		MOQ
							WHERE 	INVENTORY_ITEM_ID = LINE_REC.INVENTORY_ITEM_ID
							AND 	SUBINVENTORY_CODE IN ('STOCK','STG')
							AND 	ORGANIZATION_ID IN
									(	
										SELECT 	ORGANIZATION_ID
										FROM 	MTL_PARAMETERS
										WHERE 	ORGANIZATION_CODE = V_ITEM_SOURCE)
										AND 	v_item_source NOT IN ('ERL','HAI')     
									) A,
									(	
										SELECT 	NVL	(SUM(RESERVATION_QUANTITY), 0) QTY
										FROM 	MTL_RESERVATIONS
										WHERE 	INVENTORY_ITEM_ID = LINE_REC.INVENTORY_ITEM_ID
										AND 	ORGANIZATION_ID IN
												(
													SELECT 	ORGANIZATION_ID
													FROM 	MTL_PARAMETERS
													WHERE 	ORGANIZATION_CODE = V_ITEM_SOURCE
												)
										AND 	v_item_source NOT IN ('ERL','HAI')     
									)	B
					)	;
--
					EXCEPTION
						WHEN OTHERS THEN
							V_ITEM_QTY := 0;
				
				END;
				
				
				
				-------------------Added by OWMS Team : End--------------------------


				
				IF 	V_ITEM_QTY > LINE_REC.QUANTITY 
				THEN
					l_lead_time := 'In Stock';
				END	IF;
				
				IF 	LINE_REC.ITEM_TYPE_CODE ='MDL' 
				THEN    -- Neelima Y MYJIRATEST-6162 on 22-SEP-2015
					V_KIT_IND := 'Y';
				
				ELSE
					V_KIT_IND := 'N';
				END IF;
				
				V_LINE_COUNTER := V_LINE_COUNTER+1;
				P_QUOTE_LINE_DTL.EXTEND(1);
				P_QUOTE_LINE_DTL(P_QUOTE_LINE_DTL.last) := 	V_QUOTE_LINE_DETAILS
															(
																LINE_REC.QUOTE_HEADER_ID,
																LINE_REC.QUOTE_LINE_ID,
																LINE_REC.PART_NUMBER,
																LINE_REC.DESCRIPTION,
																LINE_REC.QUANTITY, 
																NVL(l_upq,1), 
																l_lead_time,
																LINE_REC.UNIT_PRICE,
																LINE_REC.EXTENDED_PRICE, 
																LINE_REC.INVENTORY_ITEM_ID, 
																LINE_REC.CUST_PO_LINE_NUMBER,
																LINE_REC.SHIPMENT_PRIORITY_CODE, 
																LINE_REC.REQUEST_DATE,
																LINE_REC.DISCOUNT_PRICE,
																LINE_REC.LINE_QUOTE_PRICE,
																V_KIT_IND,
																LINE_REC.MYGEA_ESN,
																LINE_REC.WORKSTP_DATE, 
																LINE_REC.WORKSTP_QTY
															); ----Manisha US161328
															
			END LOOP;
			
			
			
			-----------------------line level loop ends here---------------------------


		END LOOP;
		
		
		
		
		------------------GRAND TOTAL OF QUOTE LINE AMOUNTS------------
		
		IF 	V_HDR_COUNTER > 0 
		THEN
			FOR i IN c_qth_tot(J.OU_ID) 
			LOOP
				QT_TOTL:=i.totamt;
				IF V_PR_EXISTS = 'Y' 
				THEN
					V_PO_TOTAL := V_PO_TOTAL+QT_TOTL;  --Manisha K. Adding the total value for both OU_ID's
				ELSE
					V_PO_TOTAL := NULL;
				END IF;

				P_PO_TOTAL:= V_PO_TOTAL;
			END LOOP;
		END IF;
		
		
		
		-----------------------------QUOTE HEADER LEVEL RECORDS NOT FOUND THEN-------- --Manisha commented out this AND placed this code outside the loop
		--   IF V_HDR_COUNTER=0 THEN
		--      P_MSG := GET_ERR_MSG(8020);
		--   END IF;
		--
		
		
	END LOOP; --j.OU_ID end loop

	
	
	
	
	-------------------QUOTE HEADER LEVEL RECORDS NOT FOUND THEN-------------------
	
	IF V_HDR_COUNTER = 0 
	THEN
		P_MSG := GET_ERR_MSG(8020);
	END IF;
	
	<<end_ou>>
	NULL;
	<<end_proc>>
	NULL;
	
	
END GET_CART_INFO;











---------------------------------GET CART INFO PROCEDURE ENDS HERE----------------------









-------------------------------SAVE CART PROCEDURE STARTS HERE------------------------


PROCEDURE SAVE_CART 
(   
	P_SSO 				VARCHAR2
    P_ROLE     			VARCHAR2
    P_IACO_CODE 		VARCHAR2
    P_CUST_ID         	V_CUST_ID_ARRAY
    P_OU_ID           	VARCHAR2
    P_CART_HDR_DTL 		IN 	V_QUOTE_HEADER_DTL_ARRAY
    P_CART_LINE_DTL 	IN 	V_QUOTE_LINE_DTL_ARRAY
    P_QT_HDR_STS_DTL 	OUT V_QT_HDR_STS_DTL_ARRAY
    P_QT_LINE_STS_DTL 	OUT V_QT_LINE_STS_DTL_ARRAY
    P_MSG 				OUT VARCHAR2
)

AS

	CURSOR 	c_quote_sid(c_qte_header_id NUMBER, c_qte_line_id NUMBER) IS
		SELECT 	shipment_id
        FROM 	ASO_SHIPMENTS
		WHERE 	quote_line_id = c_qte_line_id
        AND 	quote_header_id = c_qte_header_id	;
		
	CURSOR 	c_quote_sid_hdr(c_qte_header_id NUMBER) IS
		SELECT 	shipment_id
        FROM 	ASO_SHIPMENTS
		WHERE 	quote_header_id = c_qte_header_id
        AND 	quote_line_id IS NULL	;
		
	CURSOR 	C_POST_CONFIG(P_HEADER_ID NUMBER, P_LINE_ID NUMBER) IS
		SELECT 	aql.quote_line_id, 
				aql.line_number, 
				aql.quantity, 
				aqh.attribute1, 
				aql.inventory_item_id, 
				aqh.cust_account_id, 
				aql.price_list_id
        FROM 	aso_quote_headers_all 	aqh, 
				aso_quote_lines_all 	aql
		WHERE 	aqh.quote_header_id = aql.quote_header_id
        AND 	aqh.quote_header_id = P_HEADER_ID
        AND 	aql.quote_line_id > P_LINE_ID
		ORDER BY aql.quote_line_id		;
		
	CURSOR 	C_CONFIG_EXISTS(P_LINE_ID NUMBER) IS
		SELECT 	aql.quote_line_id, 
				aql.line_number, 
				aql.quantity, 
				aqh.attribute1, 
				aql.inventory_item_id, 
				aqh.cust_account_id, 
				aql.price_list_id
        FROM 	aso_quote_line_details 	aqld, 
				aso_quote_lines_all 	aql, 
				aso_quote_headers_all 	aqh
		WHERE 	aqld.quote_line_id <> aqld.top_model_line_id
        AND 	aqld.quote_line_id = aql.quote_line_id
        AND 	aql.quote_header_id = aqh.quote_header_id
        AND 	aqld.top_model_line_id = P_LINE_ID;
		
	lc_last_update_date     DATE;
	lc_shipment_id          NUMBER;
	l_control_rec           aso_quote_pub.control_rec_type;
	l_qte_header_rec        aso_quote_pub.qte_header_rec_type;
	l_qte_line_tbl          aso_quote_pub.qte_line_tbl_type;
	l_qte_line_rec          aso_quote_pub.qte_line_rec_type;
	l_qte_line_dtl_tbl      aso_quote_pub.qte_line_dtl_tbl_type;
	l_hd_price_attr_tbl     aso_quote_pub.price_attributes_tbl_type;
	l_hd_payment_tbl        aso_quote_pub.payment_tbl_type;
	l_hd_shipment_tbl       aso_quote_pub.shipment_tbl_type;
	l_hd_freight_charge_tbl aso_quote_pub.freight_charge_tbl_type;
	l_hd_tax_detail_tbl     aso_quote_pub.tax_detail_tbl_type;
	l_line_attr_ext_tbl     aso_quote_pub.line_attribs_ext_tbl_type;
	l_line_rltship_tbl      aso_quote_pub.line_rltship_tbl_type;
	l_price_adjustment_tbl  aso_quote_pub.price_adj_tbl_type;
	l_price_adj_attr_tbl    aso_quote_pub.price_adj_attr_tbl_type;
	l_price_adj_rltship_tbl aso_quote_pub.price_adj_rltship_tbl_type;
	l_ln_price_attr_tbl     aso_quote_pub.price_attributes_tbl_type;
	l_ln_payment_tbl        aso_quote_pub.payment_tbl_type;
	l_ln_shipment_tbl       aso_quote_pub.shipment_tbl_type;
	l_ln_freight_charge_tbl aso_quote_pub.freight_charge_tbl_type;
	l_ln_tax_detail_tbl     aso_quote_pub.tax_detail_tbl_type;
	l_hd_sales_credit_tbl   aso_quote_pub.sales_credit_tbl_type := aso_quote_pub.g_miss_sales_credit_tbl;
	l_ln_sales_credit_tbl   aso_quote_pub.sales_credit_tbl_type := aso_quote_pub.g_miss_sales_credit_tbl;
	lx_qte_header_rec         aso_quote_pub.qte_header_rec_type;
	lx_qte_line_tbl           aso_quote_pub.qte_line_tbl_type;
	lx_qte_line_dtl_tbl       aso_quote_pub.qte_line_dtl_tbl_type;
	lx_hd_price_attr_tbl      aso_quote_pub.price_attributes_tbl_type;
	lx_hd_payment_tbl         aso_quote_pub.payment_tbl_type;
	lx_hd_shipment_tbl        aso_quote_pub.shipment_tbl_type;
	lx_hd_freight_charge_tbl  aso_quote_pub.freight_charge_tbl_type;
	lx_hd_tax_detail_tbl      aso_quote_pub.tax_detail_tbl_type;
	lx_hd_attr_ext_tbl        aso_quote_pub.line_attribs_ext_tbl_type;
	lx_line_attr_ext_tbl      aso_quote_pub.line_attribs_ext_tbl_type;
	lx_line_rltship_tbl       aso_quote_pub.line_rltship_tbl_type;
	lx_price_adjustment_tbl   aso_quote_pub.price_adj_tbl_type;
	lx_price_adj_attr_tbl     aso_quote_pub.price_adj_attr_tbl_type;
	lx_price_adj_rltship_tbl  aso_quote_pub.price_adj_rltship_tbl_type;
	lx_hd_sales_credit_tbl    aso_quote_pub.sales_credit_tbl_type;
	lx_quote_party_tbl        aso_quote_pub.quote_party_tbl_type;
	lx_ln_sales_credit_tbl    aso_quote_pub.sales_credit_tbl_type;
	lx_ln_quote_party_tbl     aso_quote_pub.quote_party_tbl_type;
	lx_ln_price_attr_tbl      aso_quote_pub.price_attributes_tbl_type;
	lx_ln_payment_tbl         aso_quote_pub.payment_tbl_type;
	lx_ln_shipment_tbl        aso_quote_pub.shipment_tbl_type;
	lx_ln_freight_charge_tbl  aso_quote_pub.freight_charge_tbl_type;
	lx_ln_tax_detail_tbl      aso_quote_pub.tax_detail_tbl_type;
	lx_return_status  varchar2(1);
	lx_msg_count      number;
	lx_msg_data       varchar2(2000);
	l_payment_rec     aso_quote_pub.payment_rec_type;
	l_shipment_rec    aso_quote_pub.shipment_rec_type;
	l_tax_detail_rec  aso_quote_pub.tax_detail_rec_type;
	l_qte_line_rec1 aso_quote_pub.QTE_LINE_Rec_Type;
	V_Hdr_STS_MSG       VARCHAR2(2500);
	TYPE LINE_STS_MSG IS VARRAY(4000) OF VARCHAR2(500);
	V_LINE_STS_MSG LINE_STS_MSG;
	V_LINE_HDR_COUNT     NUMBER;
	V_LINE_ERR_EXIST     VARCHAR2(1);
	V_HD_CNT number;
	V_LN_COUNT number;
	l_line_num number;
	l_cust_po_num varchar2(100);
	l_part_site_id number;
	l_party_id number;
	l_cust_account_id number;
	ln_last_update_date date;
	V_USER_ID  FND_USER.USER_ID%TYPE;
	V_RESP_ID  FND_RESPONSIBILITY_TL.RESPONSIBILITY_ID%TYPE;
	V_APP_ID   FND_RESPONSIBILITY_TL.APPLICATION_ID%TYPE;
	v_qt_hdr_id number;
	v_qt_ln_id number;
	l_del_to  aso_quote_headers_all.attribute1%type;
	l_item_id  mtl_system_items_b.inventory_item_id%type;
	l_line_count NUMBER;
	l_bom_type  mtl_system_items_b.bom_item_type%type;
	l_sup_code  aso_quote_headers_all.attribute1%type;
	l_price_list_id  aso_quote_headers_all.price_list_id%type;
	l_cust_acct_id  aso_quote_headers_all.cust_account_id%type;
	l_msg varchar2(100);
	l_sso FND_USER.user_name%type;
	lx_msg_data1 varchar2(2500) := null;
	L_CART_LINE_DTL V_QUOTE_LINE_DTL_ARRAY;
	L_CART_LINE_ID NUMBER;
	l_config_err VARCHAR2(500);
	l_cnfg_hdr_id NUMBER;
	l_line_qty NUMBER;
	l_curr_qty NUMBER;
	l_config_exists VARCHAR2(1);
	l_kitting_priority VARCHAR2(100);
	l_authorized VARCHAR2(1);
	l_cnt NUMBER;
	l_request_date DATE;
	l_shipment_priority_code VARCHAR2(100);
	l_Attib_category Varchar2(10); --Neelima Y MYJIRATEST-8723
	l_mygea_esn VARCHAR2(6); --Neelima Y MYJIRATEST-8723
	l_esn_flag VARCHAR2(1);--Neelima Y MYJIRATEST-8723
	l_esn_msg VARCHAR2(100);--Neelima Y MYJIRATEST-8723
	l_workstop_date_char     VARCHAR2(20); -- added by Suguna for workstop date
	v_OU_ID          VARCHAR2(50); -- Manisha K 10 Sept Added to save the OU_ID; Passport Requirements
	lc_order_type_id       hz_cust_site_uses_all.order_type_id%TYPE; --Manisha K 10-Oct Added variable to fetch the order_type of cart.
	order_type_name varchar2(50); -- added by suguna for order_type issue - US212495
	lc_cust_acct_id  HZ_CUST_ACCOUNTS.cust_account_id%type;  --Manisha K; 06_Nov Added the variable to fetch cust_id

	
BEGIN

-- SSO Validation --
 IF P_SSO IS NULL THEN
    P_MSG:=GET_ERR_MSG(8024);
    goto end_save;
 END IF;
 -----
 SELECT USER_ID INTO V_USER_ID
   FROM FND_USER
  WHERE USER_NAME=P_SSO;
 IF P_OU_ID IS NULL THEN
    P_MSG:=GET_ERR_MSG(8025);
    goto end_ou;
 END IF;

/***********************************************************************
Manisha K. 10-Sep-2018 Commented the below code AND have added
below after finding the OU_ID
*************************************************************************/
  --FETCHING RESPONSIBILITY ID AND APPLICATION_ID
-- BEGIN
  --  SELECT RESP.RESPONSIBILITY_ID,RESP.APPLICATION_ID
    --  INTO V_RESP_ID,V_APP_ID
    --  FROM FND_RESPONSIBILITY_TL RESP,
     --      FND_LOOKUP_VALUES FLV,
      --     HR_OPERATING_UNITS HOU
   --  WHERE HOU.NAME = FLV.MEANING
     --  AND RESP.RESPONSIBILITY_NAME = FLV.DESCRIPTION
--       AND HOU.ORGANIZATION_ID =v_OU_ID -- P_OU_ID
      -- AND FLV.LOOKUP_TYPE = 'GEAE_MYGE_QUOTE_RESPONSIBILITY';
 --EXCEPTION
  --  WHEN NO_DATA_FOUND THEN
   --    P_MSG := GET_ERR_MSG(8026);
    --   goto end_ou;
-- END;
-- BEGIN
  --  SELECT FLV.DESCRIPTION
   --   INTO l_kitting_priority
    --  FROM FND_LOOKUP_VALUES FLV,
      --     HR_OPERATING_UNITS HR
--     WHERE FLV.MEANING = HR.name
--       AND HR.ORGANIZATION_ID = v_OU_ID -- P_OU_ID
--       AND FLV.LOOKUP_TYPE = 'GEAE_MYGE_KITTING_PRIORITY'
--       AND FLV.ENABLED_FLAG = 'Y';
-- EXCEPTION
 --   WHEN NO_DATA_FOUND THEN
 --      l_kitting_priority := NULL;
  --  WHEN OTHERS THEN
 --      l_kitting_priority := NULL;
 --END;
--   --Fetching Attribute Category Code --Neelima Y MYJIRATEST-8723
 -- SELECT lookup_code INTO l_Attib_category
 -- FROM fnd_lookup_values flv,
 --    hr_operating_units hou
 -- WHERE hou.name = flv.meaning
--  AND hou.organization_id = v_OU_ID --p_OU_ID
 -- AND flv.lookup_type ='GEAE_OPERATING_UNIT';
 P_MSG:=null;
 V_HD_CNT := 1;
 P_QT_HDR_STS_DTL := V_QT_HDR_STS_DTL_ARRAY();
 P_QT_LINE_STS_DTL := V_QT_LINE_STS_DTL_ARRAY();
 L_CART_LINE_DTL := V_QUOTE_LINE_DTL_ARRAY();
 l_line_count := P_CART_LINE_DTL.count;
 FOR r in 1..P_CART_LINE_DTL.count LOOP
   P_QT_LINE_STS_DTL.EXTEND;
   L_CART_LINE_DTL.EXTEND;
   L_CART_LINE_DTL(r) := V_QUOTE_LINE_DTL(P_CART_LINE_DTL(r).QUOTE_HEADER_ID,P_CART_LINE_DTL(r).QUOTE_LINE_ID,P_CART_LINE_DTL(r).CUST_PO_LINE_NUMBER,P_CART_LINE_DTL(r).QTY,P_CART_LINE_DTL(r).ORDER_LINE_PRIORITY,P_CART_LINE_DTL(r).ORDER_LINE_REQUESTED_DATE
                          ,P_CART_LINE_DTL(r).MYGEA_ESN, P_CART_LINE_DTL(r).WORKSTP_DATE, P_CART_LINE_DTL(r).WORKSTP_QTY);  --US161834/US166305
 END LOOP;
 FOR i in 1..P_CART_HDR_DTL.count LOOP
  V_Hdr_STS_MSG := NULL;
  if P_CART_HDR_DTL(i).QUOTE_HEADER_ID is null then
      V_Hdr_STS_MSG := V_Hdr_STS_MSG||GET_ERR_MSG(8012)||'|';
      goto end_hdr;
  END IF;

  /********************************************************
  Manisha K. 12 Sept Passport Requirements.
  Earlier responsibility , l_kitting_priority, l_Attib_category used to call outside the loop using P_OU_ID.
  Now, OU_ID is fetched using header so placed the below code inside the header loop
  ********************************************************/
  IF P_OU_ID like '%~%' THEN
      BEGIN
      SELECT org_Id
      INTO v_OU_ID FROM aso_quote_headers_all
      WHERE QUOTE_HEADER_ID =P_CART_HDR_DTL(i).QUOTE_HEADER_ID ;
      EXCEPTION
      WHEN OTHERS THEN
      P_MSG := 'Error while fetching the OU_ID: '||SQLCODE||SQLERRM;
      goto end_ou;
      END;
  ELSE
    V_OU_ID := P_OU_ID;
  END IF;

   IF v_OU_ID IS NULL THEN
        p_MSG:=GET_ERR_MSG(8503);
        goto end_ou;
    END IF;


  --FETCHING RESPONSIBILITY ID AND APPLICATION_ID
 BEGIN
    SELECT RESP.RESPONSIBILITY_ID,RESP.APPLICATION_ID
      INTO V_RESP_ID,V_APP_ID
      FROM FND_RESPONSIBILITY_TL RESP,
           FND_LOOKUP_VALUES FLV,
           HR_OPERATING_UNITS HOU
     WHERE HOU.NAME = FLV.MEANING
       AND RESP.RESPONSIBILITY_NAME = FLV.DESCRIPTION
       AND HOU.ORGANIZATION_ID =v_OU_ID -- P_OU_ID
       AND FLV.LOOKUP_TYPE = 'GEAE_MYGE_QUOTE_RESPONSIBILITY';
 EXCEPTION
    WHEN NO_DATA_FOUND THEN
       P_MSG := GET_ERR_MSG(8026);
       goto end_ou;
 END;
 BEGIN
    SELECT FLV.DESCRIPTION
      INTO l_kitting_priority
      FROM FND_LOOKUP_VALUES FLV,
           HR_OPERATING_UNITS HR
     WHERE FLV.MEANING = HR.name
       AND HR.ORGANIZATION_ID = v_OU_ID -- P_OU_ID
       AND FLV.LOOKUP_TYPE = 'GEAE_MYGE_KITTING_PRIORITY'
       AND FLV.ENABLED_FLAG = 'Y';
 EXCEPTION
    WHEN NO_DATA_FOUND THEN
       l_kitting_priority := NULL;
    WHEN OTHERS THEN
       l_kitting_priority := NULL;
 END;
   --Fetching Attribute Category Code --Neelima Y MYJIRATEST-8723
  SELECT lookup_code INTO l_Attib_category
  FROM fnd_lookup_values flv,
     hr_operating_units hou
  WHERE hou.name = flv.meaning
  AND hou.organization_id = v_OU_ID --p_OU_ID
  AND flv.lookup_type ='GEAE_OPERATING_UNIT';


  SELECT COUNT(1)
    INTO l_cnt
    FROM aso_quote_headers_all
   WHERE quote_header_id = P_CART_HDR_DTL(i).QUOTE_HEADER_ID;
  IF l_cnt <> 1 THEN
     V_HDR_STS_MSG:= V_HDR_STS_MSG||GET_ERR_MSG(8010)||'|';
     goto end_hdr;
  END IF;
  --Ravi S 19-SEP-2014 MYJIRATEST-3513 Authorization logic
  l_authorized := 'N';
  BEGIN
     SELECT 'Y'
       INTO l_authorized
       FROM aso_quote_headers_all aqh, fnd_user fu
      WHERE aqh.created_by = fu.user_id
        AND aqh.org_id = v_OU_ID --P_OU_ID
        AND fu.user_name = P_SSO
        AND aqh.quote_header_id = P_CART_HDR_DTL(i).QUOTE_HEADER_ID;
  EXCEPTION
     WHEN NO_DATA_FOUND THEN
        V_HDR_STS_MSG:= V_HDR_STS_MSG||GET_ERR_MSG(8180)||'~'||P_SSO||'~'||V_USER_ID||'|';
        goto end_hdr;
  END;
  /******************************************8
  Manisha/Suguna Added below select query to fetch
  order_type of the cart on 10-OCT-2018*********************************/
  
    BEGIN
        SELECT aqh.cust_account_id
        INTO lc_cust_acct_id
        FROM aso_quote_headers_all aqh
        WHERE aqh.quote_header_id = P_CART_HDR_DTL(i).QUOTE_HEADER_ID;
    EXCEPTION

  WHEN OTHERS THEN
  P_MSG := 'Exception occured  in save cart while Fetching Customer_Id: E :'||SQLCODE||':'||SQLERRM;
  goto end_hdr;
  END;
  
  IF (v_OU_ID = 60377 OR v_OU_ID =117019) THEN
    IF P_CART_HDR_DTL(i).SHIP_TO_ADDRESS_ID IS NOT NULL THEN
          BEGIN
                SELECT hcsua2.order_type_id
                INTO lc_order_type_id
                FROM hz_parties hp,
                     hz_party_sites hps,
                     hz_locations hl,
                     hz_cust_acct_sites_all hcasa2,
                     hz_cust_site_uses_all hcsua2,
					 hz_cust_accounts hz
                WHERE hp.party_id = hps.party_id(+)
                  AND HCASA2.PARTY_SITE_ID(+) = HPS.PARTY_SITE_ID
          AND hcasa2.org_id = to_number(v_OU_ID) --to_number(p_OU_ID)
                  AND hcsua2.cust_acct_site_id(+) = hcasa2.cust_acct_site_id
                  AND hcsua2.site_use_code = 'SHIP_TO'   -- DELIVER_TO
                  AND hps.location_id = hl.location_id
                  AND NVL(hcasa2.status, 'I') = 'A'        ----Added NVL
                  AND NVL(hcsua2.STATUS, 'I') = 'A'        ----Added NVL
                  AND NVL(hps.STATUS, 'I') ='A'            ----Added NVL
                  AND NVL(hp.STATUS, 'I') ='A'
                  AND hl.location_id  = to_number(P_CART_HDR_DTL(i).SHIP_TO_ADDRESS_ID)
				  AND hz.CUST_ACCOUNT_ID=hcasa2.CUST_ACCOUNT_ID
                  AND hz.CUST_ACCOUNT_ID=lc_cust_acct_id
                  AND hcsua2.order_type_id is not null;

                IF lc_order_type_id is null THEN
                    P_MSG:=GET_ERR_MSG(8502);
                    goto end_hdr;
                END IF;

        EXCEPTION
            when no_data_found then
               P_MSG:=GET_ERR_MSG(8502);
               goto end_hdr;
           WHEN OTHERS THEN
            P_MSG := 'Exception occured in save cart while Fetching Order Type: E :'||SQLCODE||':'||SQLERRM;
          goto end_hdr;
       END;

 ELSE  -- Manisha K. 06-Nov-18 Case where save_cart procs called inside bulk_cart_add AND bulk_cart_add_po, without passing the value of shipping address

  BEGIN

  SELECT distinct HCS.ORDER_TYPE_ID
  INTO lc_order_type_id
  FROM APPS.HZ_CUST_ACCT_SITES_ALL HCA,
                 APPS.HZ_CUST_SITE_USES_ALL  HCS,
                 APPS.HZ_CUST_ACCOUNTS       HC
  WHERE HCA.ORG_ID =to_number(v_OU_ID) --to_number(p_OU_ID)
  AND HCA.CUST_ACCT_SITE_ID = HCS.CUST_ACCT_SITE_ID
  AND HCA.CUST_ACCOUNT_ID = HC.CUST_ACCOUNT_ID
  AND hc.cust_account_id = lc_cust_acct_id
  AND hcs.site_use_code = 'SHIP_TO'
  AND HCS.PRIMARY_FLAG='Y'
  AND NVL(hca.STATUS, 'I') = 'A'
  AND NVL(hcS.STATUS, 'I') = 'A'
  AND NVL(HC.status, 'I') = 'A'
  AND HCS.ORDER_TYPE_ID is not NULL;

  IF lc_order_type_id is null  THEN
    P_MSG := GET_ERR_MSG(8502);
    goto end_hdr;
  END IF;

 EXCEPTION
            when no_data_found then
  P_MSG := GET_ERR_MSG(8502);
  goto end_hdr;
  WHEN OTHERS THEN
  P_MSG := 'Exception occured  in save cart while Fetching Order Type Else part: E :'||SQLCODE||':'||SQLERRM;
          goto end_hdr;
  END;

END IF;  --End if of 'P_CART_HDR_DTL(i).SHIP_TO_ADDRESS_ID IS NOT NULL'


    --Verify order type
BEGIN
  select NAME INTO order_type_name
  from oe_transaction_types_tl
  where transaction_type_id = lc_order_type_id;

 IF(order_type_name != 'Special Charge' AND order_type_name != 'Customer Order')
AND (order_type_name != 'P20 Special Charge'  AND order_type_name != 'P20 Customer Order') THEN
    P_MSG:= GET_ERR_MSG(8501);
    GOTO end_hdr;
  END IF;

EXCEPTION
    when no_data_found then
       P_MSG:=GET_ERR_MSG(8502);
       goto end_hdr;
    WHEN OTHERS THEN
        P_MSG := 'Exception occured in save cart while checking Order Type: E :'||SQLCODE||':'||SQLERRM;
      goto end_hdr;
END;

  l_qte_header_rec.order_type_id := lc_order_type_id;

END IF;
  --End of order type changes
  FOR j in 1..P_CART_LINE_DTL.count LOOP
     IF P_CART_HDR_DTL(i).QUOTE_HEADER_ID = P_CART_LINE_DTL(j).QUOTE_HEADER_ID THEN
        SELECT msib.bom_item_type
          INTO l_bom_type
          FROM mtl_system_items_b msib, aso_quote_lines_all aql
         WHERE msib.inventory_item_id = aql.inventory_item_id
           AND aql.quote_line_id = P_CART_LINE_DTL(j).QUOTE_LINE_ID
           AND aql.quote_header_id = P_CART_LINE_DTL(j).QUOTE_HEADER_ID
            AND msib.organization_id = 60379;
        IF P_CART_HDR_DTL(i).PURCHASE_ORDER_NUMBER IS NOT NULL AND l_bom_type = 1 THEN
           SELECT aqh.attribute1, aql.inventory_item_id, aqh.cust_account_id, aql.price_list_id, aql.quantity,substr(aql.attribute7,1,6)
             INTO l_sup_code, l_item_id, l_cust_acct_id, l_price_list_id, l_line_qty , l_mygea_esn --Neelima Y MYJIRATEST-8723
             FROM aso_quote_headers_all aqh, aso_quote_lines_all aql
            WHERE aqh.quote_header_id = aql.quote_header_id
              AND aqh.quote_header_id = P_CART_LINE_DTL(j).QUOTE_HEADER_ID
              AND aql.quote_line_id = P_CART_LINE_DTL(j).quote_line_id;
           SELECT max(quote_line_id)
             INTO L_CART_LINE_ID
             FROM ASO_QUOTE_LINES_ALL
            WHERE QUOTE_HEADER_ID = P_CART_LINE_DTL(j).QUOTE_HEADER_ID;
           BEGIN
              SELECT 'Y'
                INTO l_config_exists
                FROM aso_quote_lines_all aql, aso_quote_line_details aqld
               WHERE aql.quote_line_id = aqld.quote_line_id
                 AND aql.quote_line_id = P_CART_LINE_DTL(j).quote_line_id;
           EXCEPTION
              WHEN NO_DATA_FOUND THEN
                 l_config_exists := 'N';
           END;
           l_curr_qty := P_CART_LINE_DTL(j).QTY;
           l_config_err := NULL;
           l_cnfg_hdr_id := NULL;
           --Enable Kit configuration Ravi S 06-SEP-2014
           IF l_config_exists = 'N' THEN
              CREATE_KIT_CONFIG(V_USER_ID,V_APP_ID,V_RESP_ID,l_item_id,1,'Y',l_cnfg_hdr_id,l_config_err);
              IF l_config_err IS NOT NULL THEN
                 P_QT_LINE_STS_DTL(j) := V_QT_LINE_STS_DTL(P_CART_LINE_DTL(j).QUOTE_HEADER_ID ,
                                                           P_CART_LINE_DTL(j).quote_line_id,
                                                           'Error in creating configuration '||SUBSTR(l_config_err,1,50),NULL,NULL,NULL);
              END IF;
              IF l_cnfg_hdr_id IS NOT NULL THEN
                 l_config_err := NULL;
                 VALIDATE_CONFIG(P_CART_LINE_DTL(j).QUOTE_HEADER_ID,P_CART_LINE_DTL(j).quote_line_id,l_cnfg_hdr_id,P_SSO,v_OU_ID,l_config_err);
                 IF l_config_err IS NOT NULL THEN
                    P_QT_LINE_STS_DTL(j) := V_QT_LINE_STS_DTL(P_CART_LINE_DTL(j).QUOTE_HEADER_ID ,
                                                              P_CART_LINE_DTL(j).quote_line_id,
                                                              'Error in validating configuration '||SUBSTR(l_config_err,1,50),NULL,NULL,NULL);
                 END IF;
                 FOR r_post_config IN C_POST_CONFIG(P_CART_LINE_DTL(j).QUOTE_HEADER_ID,L_CART_LINE_ID) LOOP
                     l_line_count := l_line_count + 1;
                     L_CART_LINE_DTL.EXTEND;
                     L_CART_LINE_DTL(l_line_count) := V_QUOTE_LINE_DTL(P_CART_LINE_DTL(j).QUOTE_HEADER_ID,r_post_config.quote_line_id,P_CART_LINE_DTL(j).CUST_PO_LINE_NUMBER,r_post_config.quantity,NVL(l_kitting_priority,P_CART_LINE_DTL(j).ORDER_LINE_PRIORITY),P_CART_LINE_DTL(j).ORDER_LINE_REQUESTED_DATE,P_CART_LINE_DTL(j).MYGEA_ESN,
                     P_CART_LINE_DTL(j).WORKSTP_DATE, P_CART_LINE_DTL(j).WORKSTP_QTY); --US161834/US166305
                     P_QT_LINE_STS_DTL.EXTEND;
                 END LOOP;
              END IF;
           ELSE
              FOR r_config_exists IN C_CONFIG_EXISTS(P_CART_LINE_DTL(j).quote_line_id) LOOP
                 l_line_count := l_line_count + 1;
                 L_CART_LINE_DTL.EXTEND;
                 L_CART_LINE_DTL(l_line_count) := V_QUOTE_LINE_DTL(P_CART_LINE_DTL(j).QUOTE_HEADER_ID,r_config_exists.quote_line_id,P_CART_LINE_DTL(j).CUST_PO_LINE_NUMBER,r_config_exists.quantity,NVL(l_kitting_priority,P_CART_LINE_DTL(j).ORDER_LINE_PRIORITY),P_CART_LINE_DTL(j).ORDER_LINE_REQUESTED_DATE
                 ,P_CART_LINE_DTL(j).MYGEA_ESN, P_CART_LINE_DTL(j).WORKSTP_DATE, P_CART_LINE_DTL(j).WORKSTP_QTY); --US161834/US166305
                 P_QT_LINE_STS_DTL.EXTEND;
              END LOOP;
           END IF;
           IF P_CART_LINE_DTL(j).QTY = 1 THEN
              L_CART_LINE_DTL(j) := V_QUOTE_LINE_DTL(P_CART_LINE_DTL(j).QUOTE_HEADER_ID,P_CART_LINE_DTL(j).QUOTE_LINE_ID,P_CART_LINE_DTL(j).CUST_PO_LINE_NUMBER,1,NVL(l_kitting_priority,P_CART_LINE_DTL(j).ORDER_LINE_PRIORITY),P_CART_LINE_DTL(j).ORDER_LINE_REQUESTED_DATE
              ,P_CART_LINE_DTL(j).MYGEA_ESN,P_CART_LINE_DTL(j).WORKSTP_DATE, P_CART_LINE_DTL(j).WORKSTP_QTY );  --US161834/US166305
           END IF;
           FOR k IN 1..P_CART_LINE_DTL(j).QTY-1 LOOP
              GEAE_MYGE_CART_PKG.ADD_CART_LINE (P_SSO, P_ROLE, P_IACO_CODE, P_CUST_ID, v_OU_ID, l_item_id, l_cust_acct_id, l_sup_code, 1, l_price_list_id,null, l_msg);
              l_curr_qty := l_curr_qty - 1;
              L_CART_LINE_DTL(j) := V_QUOTE_LINE_DTL(P_CART_LINE_DTL(j).QUOTE_HEADER_ID,P_CART_LINE_DTL(j).QUOTE_LINE_ID,P_CART_LINE_DTL(j).CUST_PO_LINE_NUMBER,l_curr_qty,NVL(l_kitting_priority,P_CART_LINE_DTL(j).ORDER_LINE_PRIORITY),P_CART_LINE_DTL(j).ORDER_LINE_REQUESTED_DATE
              ,P_CART_LINE_DTL(j).MYGEA_ESN,P_CART_LINE_DTL(j).WORKSTP_DATE, P_CART_LINE_DTL(j).WORKSTP_QTY); ----US161834/US166305
               SELECT max(quote_line_id)
                INTO L_CART_LINE_ID
                FROM ASO_QUOTE_LINES_ALL
               WHERE QUOTE_HEADER_ID = P_CART_LINE_DTL(j).QUOTE_HEADER_ID;
              l_line_count := l_line_count + 1;
              L_CART_LINE_DTL.EXTEND;
              L_CART_LINE_DTL(l_line_count) := V_QUOTE_LINE_DTL(P_CART_LINE_DTL(j).QUOTE_HEADER_ID,L_CART_LINE_ID,P_CART_LINE_DTL(j).CUST_PO_LINE_NUMBER,1,NVL(l_kitting_priority,P_CART_LINE_DTL(j).ORDER_LINE_PRIORITY),P_CART_LINE_DTL(j).ORDER_LINE_REQUESTED_DATE, --MYJIRATEST-3292 Ravi S 03-SEP-2014
              P_CART_LINE_DTL(j).MYGEA_ESN, P_CART_LINE_DTL(j).WORKSTP_DATE, P_CART_LINE_DTL(j).WORKSTP_QTY); --US161834/US166305
              P_QT_LINE_STS_DTL.EXTEND;
              --Enable Kit configuration Ravi S 06-SEP-2014
              l_config_err := NULL;
              l_cnfg_hdr_id := NULL;
              CREATE_KIT_CONFIG (V_USER_ID,V_APP_ID,V_RESP_ID,l_item_id,1,'Y',l_cnfg_hdr_id,l_config_err);
              IF l_config_err IS NOT NULL THEN
                 P_QT_LINE_STS_DTL(l_line_count) := V_QT_LINE_STS_DTL(P_CART_LINE_DTL(j).QUOTE_HEADER_ID ,
                                                                      L_CART_LINE_ID,
                                                                      'Error in creating configuration '||SUBSTR(l_config_err,1,50),NULL,NULL,NULL);
              END IF;
              IF l_cnfg_hdr_id IS NOT NULL THEN
                 l_config_err := NULL;
                 VALIDATE_CONFIG (P_CART_LINE_DTL(j).QUOTE_HEADER_ID,L_CART_LINE_ID,l_cnfg_hdr_id,P_SSO,v_OU_ID,l_config_err);
                 IF l_config_err IS NOT NULL THEN
                    P_QT_LINE_STS_DTL(l_line_count) := V_QT_LINE_STS_DTL(P_CART_LINE_DTL(j).QUOTE_HEADER_ID ,
                                                                         L_CART_LINE_ID,
                                                                         'Error in validating configuration '||SUBSTR(l_config_err,1,50),NULL,NULL,NULL);
                 END IF;
                 FOR r_post_config IN C_POST_CONFIG(P_CART_LINE_DTL(j).QUOTE_HEADER_ID,L_CART_LINE_ID) LOOP
                    l_line_count := l_line_count + 1;
                    L_CART_LINE_DTL.EXTEND;
                    L_CART_LINE_DTL(l_line_count) := V_QUOTE_LINE_DTL(P_CART_LINE_DTL(j).QUOTE_HEADER_ID,r_post_config.quote_line_id,P_CART_LINE_DTL(j).CUST_PO_LINE_NUMBER,r_post_config.quantity,NVL(l_kitting_priority,P_CART_LINE_DTL(j).ORDER_LINE_PRIORITY),P_CART_LINE_DTL(j).ORDER_LINE_REQUESTED_DATE,
                    P_CART_LINE_DTL(j).MYGEA_ESN, P_CART_LINE_DTL(j).WORKSTP_DATE, P_CART_LINE_DTL(j).WORKSTP_QTY); --MYJIRATEST-3292 Ravi S 03-SEP-2014
                    P_QT_LINE_STS_DTL.EXTEND;
                 END LOOP;
              END IF;
           END LOOP;
        END IF;
     END IF;
  END LOOP;
  l_qte_header_rec.quote_header_id  := P_CART_HDR_DTL(i).QUOTE_HEADER_ID ;
  OPEN c_quote_sid_hdr(l_qte_header_rec.quote_header_id);
  FETCH c_quote_sid_hdr INTO lc_shipment_id;
  CLOSE c_quote_sid_hdr;
  l_shipment_rec.shipment_id := lc_shipment_id;
  BEGIN
    SELECT hps.party_site_id, hps.party_id, hca.cust_account_id into l_part_site_id, l_party_id, l_cust_account_id
    FROM hz_party_sites hps, hz_cust_accounts hca, hz_cust_acct_sites_all hcs
    WHERE hps.location_id   = P_CART_HDR_DTL(i).SHIP_TO_ADDRESS_ID
    AND hps.party_id        = hca.party_id
    AND hca.cust_account_id = hcs.cust_account_id
    AND hps.party_site_id   = hcs.party_site_id
    AND hcs.org_id          = v_OU_ID; --P_OU_ID;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      l_part_site_id := NULL;
      l_party_id := NULL;
      l_cust_account_id := NULL;
  END;
   l_shipment_rec.operation_code              := 'UPDATE';
   l_shipment_rec.SHIP_TO_PARTY_SITE_ID       := l_part_site_id;
   l_shipment_rec.SHIP_TO_CUST_ACCOUNT_ID     := l_cust_account_id;
--   l_shipment_rec.request_date                := to_date(P_CART_HDR_DTL(i).HDR_REQUESTED_DATE,'DD-MON-YY');
   IF P_CART_HDR_DTL(i).HDR_REQUESTED_DATE IS NOT NULL THEN         --Neelima 18-JUL-2015 MYJIRATEST-9690
   l_shipment_rec.request_date                := P_CART_HDR_DTL(i).HDR_REQUESTED_DATE;
   END IF;
   IF P_CART_HDR_DTL(i).ORDER_PRIORITY IS NOT NULL THEN             --Neelima 18-JUL-2015 MYJIRATEST-9690
       SELECT DECODE(P_CART_HDR_DTL(i).ORDER_PRIORITY,'NORMAL','50_NORMAL','WSP','40_WKSTP',P_CART_HDR_DTL(i).ORDER_PRIORITY)
       INTO l_shipment_rec.shipment_priority_code
       FROM DUAL;
   END IF;
-- l_qte_header_rec.attribute7                := P_CART_HDR_DTL(i).DELIVER_TO_ADDRESS_ID ;  Commented for MYJIRATEST-6517 Fix for Deliver to location code
   l_qte_header_rec.attribute12                := P_CART_HDR_DTL(i).DELIVER_TO_ADDRESS_ID ;--28-APR-2015   Abhinav S MYJIRATEST-6517 Fix for Deliver to location code
  begin
    select last_update_date into lc_last_update_date from aso_quote_headers_all
    where quote_header_id = l_qte_header_rec.quote_header_id;
    exception
    when no_data_found then
       V_Hdr_STS_MSG:= V_Hdr_STS_MSG||GET_ERR_MSG(8010)||'|';
       goto end_hdr;
   end;
  l_qte_header_rec.last_update_date := lc_last_update_date;
  l_hd_shipment_tbl(1) := l_shipment_rec;
  BEGIN
     SELECT payment_id, last_update_date
       INTO l_payment_rec.payment_id, l_payment_rec.last_update_date
       FROM aso_payments
      WHERE quote_header_id = l_qte_header_rec.quote_header_id
        AND quote_line_id IS NULL;
     l_payment_rec.operation_code := 'UPDATE';
  EXCEPTION
     WHEN OTHERS THEN
        l_payment_rec.payment_id := NULL;
        l_payment_rec.last_update_date := NULL;
        l_payment_rec.operation_code := 'CREATE';
  END;
  l_payment_rec.quote_header_id       := l_qte_header_rec.quote_header_id;
  l_payment_rec.cust_po_number        := P_CART_HDR_DTL(i).PURCHASE_ORDER_NUMBER;
  l_payment_rec.quote_line_id         := NULL;
  l_payment_rec.cust_po_line_number   := NULL;
  l_hd_payment_tbl(1) := l_payment_rec;
  l_line_num := 1;
  V_LINE_STS_MSG := LINE_STS_MSG();
  V_LINE_ERR_EXIST := 'N';
  V_LINE_HDR_COUNT := 0;
  l_qte_line_tbl.DELETE;
  l_ln_shipment_tbl.DELETE;
  l_ln_payment_tbl.DELETE;
  FOR j in 1..L_CART_LINE_DTL.count LOOP
    IF P_CART_HDR_DTL(i).QUOTE_HEADER_ID = L_CART_LINE_DTL(j).QUOTE_HEADER_ID THEN
       V_LINE_STS_MSG.EXTEND;
       V_LINE_HDR_COUNT := V_LINE_HDR_COUNT +1;
       IF P_QT_LINE_STS_DTL(j).STS_MSG IS NOT NULL THEN
         V_LINE_STS_MSG(V_LINE_HDR_COUNT) := V_LINE_STS_MSG(V_LINE_HDR_COUNT)||P_QT_LINE_STS_DTL(j).STS_MSG||'|';
         V_LINE_ERR_EXIST := 'Y';
       END IF;
       IF L_CART_LINE_DTL(j).QUOTE_LINE_ID IS NULL THEN
         V_LINE_STS_MSG(V_LINE_HDR_COUNT) := V_LINE_STS_MSG(V_LINE_HDR_COUNT)||GET_ERR_MSG(8013)||'|';
         V_LINE_ERR_EXIST := 'Y';
       END IF;
       IF L_CART_LINE_DTL(j).QTY IS NULL THEN
         V_LINE_STS_MSG(V_LINE_HDR_COUNT) := V_LINE_STS_MSG(V_LINE_HDR_COUNT)||GET_ERR_MSG(8027)||'|';
         V_LINE_ERR_EXIST := 'Y';
       END IF;
       BEGIN
          SELECT last_update_date INTO ln_last_update_date FROM aso_quote_lines_all
           WHERE quote_line_id = L_CART_LINE_DTL(j).QUOTE_LINE_ID;
       EXCEPTION
          WHEN NO_DATA_FOUND THEN
             V_LINE_STS_MSG(V_LINE_HDR_COUNT) := V_LINE_STS_MSG(V_LINE_HDR_COUNT)||GET_ERR_MSG(8011)||'|';
             V_LINE_ERR_EXIST := 'Y';
       END;
       IF L_CART_LINE_DTL(j).QTY < 1 THEN
          V_LINE_STS_MSG(V_LINE_HDR_COUNT) := V_LINE_STS_MSG(V_LINE_HDR_COUNT)||GET_ERR_MSG(8166)||'|';
          V_LINE_ERR_EXIST := 'Y';
       END IF;
       l_qte_line_rec.quote_header_id              := L_CART_LINE_DTL(j).QUOTE_HEADER_ID ;
       l_qte_line_rec.quote_line_id                := L_CART_LINE_DTL(j).QUOTE_LINE_ID;
       l_qte_line_rec.operation_code               := 'UPDATE';
       l_qte_line_rec.last_update_date             := lc_last_update_date;
       IF L_CART_LINE_DTL(j).MYGEA_ESN IS NOT NULL THEN     --Neelima Y MYJIRATEST-8723
       l_qte_line_rec.Attribute_Category             := l_Attib_category;   --Neelima Y MYJIRATEST-8723
     --  l_qte_line_rec.attribute7                     := L_CART_LINE_DTL(j).MYGEA_ESN;
         IF UPPER(L_CART_LINE_DTL(j).ORDER_LINE_PRIORITY) IN ('NORMAL','50_NORMAL')  THEN  --Manisha added for Workstop
          l_qte_line_rec.attribute7                     := L_CART_LINE_DTL(j).MYGEA_ESN;
         ELSIF UPPER(L_CART_LINE_DTL(j).ORDER_LINE_PRIORITY) IN ('WSP','40_WKSTP') THEN

            IF (L_CART_LINE_DTL(j).WORKSTP_DATE IS NULL) OR (L_CART_LINE_DTL(j).WORKSTP_QTY IS NULL) THEN
               V_LINE_STS_MSG(V_LINE_HDR_COUNT) := V_LINE_STS_MSG(V_LINE_HDR_COUNT)||GET_ERR_MSG(8205)||'|';
               V_LINE_ERR_EXIST := 'Y';
             END IF;
            l_workstop_date_char:= to_char(L_CART_LINE_DTL(j).WORKSTP_DATE,'YYYY/MM/DD hh24:mi:ss'); -- added by Suguna since the workstop date is not showing correctlly in AMPS
			 -- "~~~~" added by Suguna since the workstop date is not showing  in AMPS workstop report - 21-May-2018
            l_qte_line_rec.attribute7    := L_CART_LINE_DTL(j).MYGEA_ESN||'~'||l_workstop_date_char||'~'||L_CART_LINE_DTL(j).WORKSTP_QTY||'~'||'~'||'~'||'~';  --US161834/US166305
			--l_qte_line_rec.attribute7    := L_CART_LINE_DTL(j).MYGEA_ESN||'~'||L_CART_LINE_DTL(j).WORKSTP_DATE||'~'||L_CART_LINE_DTL(j).WORKSTP_QTY;
        END IF;
       ELSE

              l_qte_line_rec.attribute7                     := L_CART_LINE_DTL(j).MYGEA_ESN;

       END IF;
       IF L_CART_LINE_DTL(j).QTY IS NOT NULL THEN     --Neelima 18-JUL-2015 MYJIRATEST-9690
       l_qte_line_rec.quantity                     := L_CART_LINE_DTL(j).QTY;
       END IF;
       IF L_CART_LINE_DTL(j).CUST_PO_LINE_NUMBER IS NOT NULL THEN
       l_qte_line_rec.line_number                  := L_CART_LINE_DTL(j).CUST_PO_LINE_NUMBER;
       ELSE                                                                                       ----changed by Trupti D. for MYJIRATEST-7526 11-APR-2016
       l_qte_line_rec.line_number                  := NULL;
       END IF;
       l_qte_line_tbl(l_line_num)                  := l_qte_line_rec;
       OPEN c_quote_sid(l_qte_header_rec.quote_header_id,l_qte_line_rec.quote_line_id);
       FETCH c_quote_sid INTO lc_shipment_id;
       CLOSE c_quote_sid;
       l_shipment_rec.shipment_id := lc_shipment_id;
       BEGIN                                            --Neelima 18-JUL-2015 MYJIRATEST-9690
         SELECT request_date  ,shipment_priority_code
           INTO l_request_date ,   l_shipment_priority_code
           FROM aso_shipments
          WHERE quote_header_id= L_CART_LINE_DTL(j).QUOTE_HEADER_ID
            AND quote_line_id  =  L_CART_LINE_DTL(j).QUOTE_LINE_ID;
       EXCEPTION
          WHEN OTHERS THEN
           l_request_date           :=NULL;
           l_shipment_priority_code :=NULL;
       END;
       l_shipment_rec.operation_code           := 'UPDATE';
       l_shipment_rec.quote_line_id            := l_qte_line_rec.quote_line_id;
--       l_shipment_rec.request_date             := to_date(L_CART_LINE_DTL(j).ORDER_LINE_REQUESTED_DATE,'DD-MON-YY');
       IF  L_CART_LINE_DTL(j).ORDER_LINE_REQUESTED_DATE IS NOT NULL THEN   --Neelima 18-JUL-2015 MYJIRATEST-9690
       l_shipment_rec.request_date             := L_CART_LINE_DTL(j).ORDER_LINE_REQUESTED_DATE;
       ELSE
       l_shipment_rec.request_date             :=  l_request_date ;
       END IF;
       IF  L_CART_LINE_DTL(j).ORDER_LINE_PRIORITY IS NOT NULL THEN    --Neelima 18-JUL-2015 MYJIRATEST-9690
           SELECT DECODE(L_CART_LINE_DTL(j).ORDER_LINE_PRIORITY,'NORMAL','50_NORMAL','WSP','40_WKSTP',L_CART_LINE_DTL(j).ORDER_LINE_PRIORITY)
             INTO   l_shipment_rec.shipment_priority_code
             FROM DUAL;
       ELSE
           SELECT DECODE(l_shipment_priority_code,'NORMAL','50_NORMAL','WSP','40_WKSTP',l_shipment_priority_code)
             INTO   l_shipment_rec.shipment_priority_code
             FROM DUAL;
       END IF;
       l_ln_shipment_tbl(l_line_num)           := l_shipment_rec;
       BEGIN
          SELECT payment_id, last_update_date,cust_po_line_number,cust_po_number
            INTO l_payment_rec.payment_id, l_payment_rec.last_update_date, l_payment_rec.cust_po_line_number , l_payment_rec.cust_po_number
            FROM aso_payments
           WHERE quote_header_id = l_qte_header_rec.quote_header_id
             AND quote_line_id = l_qte_line_rec.quote_line_id;
          l_payment_rec.operation_code := 'UPDATE';
       EXCEPTION
          WHEN OTHERS THEN
             l_payment_rec.payment_id := NULL;
             l_payment_rec.last_update_date := NULL;
             l_payment_rec.operation_code := 'CREATE';
       END;
       l_payment_rec.quote_header_id       := l_qte_header_rec.quote_header_id;
       IF L_CART_LINE_DTL(j).CUST_PO_LINE_NUMBER IS NOT NULL AND P_CART_HDR_DTL(i).PURCHASE_ORDER_NUMBER IS NULL THEN
         l_payment_rec.cust_po_number     := 'myGE Dummy PO Number '||TO_CHAR(SYSDATE,'DDMMYYYYHH24MISS');
       END IF;
       IF P_CART_HDR_DTL(i).PURCHASE_ORDER_NUMBER IS  NOT NULL THEN  --Neelima 18-JUL-2015 MYJIRATEST-9690
         l_payment_rec.cust_po_number        := P_CART_HDR_DTL(i).PURCHASE_ORDER_NUMBER;
       END IF;
       l_payment_rec.quote_line_id         := l_qte_line_rec.quote_line_id;
       IF  L_CART_LINE_DTL(j).CUST_PO_LINE_NUMBER IS NOT NULL THEN      --Neelima 18-JUL-2015 MYJIRATEST-9690
       l_payment_rec.cust_po_line_number   := L_CART_LINE_DTL(j).CUST_PO_LINE_NUMBER;
       ELSE                                                                                    ----changed by Trupti D. for MYJIRATEST-7526 11-APR-2016
       l_payment_rec.cust_po_line_number   := NULL;
       END IF;
       l_ln_payment_tbl(l_line_num) := l_payment_rec;
       l_line_num := l_line_num+1;
    END IF;
  END LOOP;
  IF V_LINE_ERR_EXIST = 'Y' THEN
     goto end_line;
  END IF;
  FND_GLOBAL.APPS_INITIALIZE(v_user_id,v_resp_id,v_app_id);
  mo_global.set_policy_context('S',v_OU_ID);
  aso_quote_pub.update_quote(p_api_version_number       =>  1.0
                            ,p_init_msg_list            => fnd_api.g_true
                            ,p_commit                   => fnd_api.g_true
                            ,p_control_rec              => l_control_rec
                            ,p_qte_header_rec           => l_qte_header_rec
                            ,P_hd_Payment_Tbl           => l_hd_payment_tbl
                            ,P_hd_Shipment_Tbl          => l_hd_shipment_tbl
                            ,p_qte_line_tbl             => l_qte_line_tbl
                            ,p_qte_line_dtl_tbl         => l_qte_line_dtl_tbl
                            ,p_hd_tax_detail_tbl        => l_hd_tax_detail_tbl
                            ,p_ln_payment_tbl           => l_ln_payment_tbl
                            ,p_hd_sales_credit_tbl      => l_hd_sales_credit_tbl
                            ,p_ln_sales_credit_tbl      => l_ln_sales_credit_tbl
                            ,p_ln_shipment_tbl          => l_ln_shipment_tbl
                            ,x_qte_header_rec           => lx_qte_header_rec
                            ,x_qte_line_tbl             => lx_qte_line_tbl
                            ,x_qte_line_dtl_tbl         => lx_qte_line_dtl_tbl
                            ,x_hd_price_attributes_tbl  => lx_hd_price_attr_tbl
                            ,x_hd_payment_tbl           => lx_hd_payment_tbl
                            ,x_hd_shipment_tbl          => lx_hd_shipment_tbl
                            ,x_hd_freight_charge_tbl    => lx_hd_freight_charge_tbl
                            ,x_hd_tax_detail_tbl        => lx_hd_tax_detail_tbl
                            ,x_hd_attr_ext_tbl          => lx_hd_attr_ext_tbl
                            ,x_hd_sales_credit_tbl      => lx_hd_sales_credit_tbl
                            ,x_hd_quote_party_tbl       => lx_quote_party_tbl
                            ,x_line_attr_ext_tbl        => lx_line_attr_ext_tbl
                            ,x_line_rltship_tbl         => lx_line_rltship_tbl
                            ,x_price_adjustment_tbl     => lx_price_adjustment_tbl
                            ,x_price_adj_attr_tbl       => lx_price_adj_attr_tbl
                            ,x_price_adj_rltship_tbl    => lx_price_adj_rltship_tbl
                            ,x_ln_price_attributes_tbl  => lx_ln_price_attr_tbl
                            ,x_ln_payment_tbl           => lx_ln_payment_tbl
                            ,x_ln_shipment_tbl          => lx_ln_shipment_tbl
                            ,x_ln_freight_charge_tbl    => lx_ln_freight_charge_tbl
                            ,x_ln_tax_detail_tbl        => lx_ln_tax_detail_tbl
                            ,x_ln_sales_credit_tbl      => lx_ln_sales_credit_tbl
                            ,x_ln_quote_party_tbl       => lx_ln_quote_party_tbl
                            ,x_return_status            => lx_return_status
                            ,x_msg_count                => lx_msg_count
                            ,x_msg_data                 => lx_msg_data);
  fnd_msg_pub.count_AND_get(p_encoded => 'F'
                           ,p_count   => lx_msg_count
                           ,p_data    => lx_msg_data);
  if lx_return_status <> 'S' then
  FOR k IN 1 .. lx_msg_count LOOP
    lx_msg_data := fnd_msg_pub.get(p_msg_index => k
                                  ,p_encoded => 'F');
    IF lx_msg_data LIKE '%Record has been updated%Please requery to see change%' THEN
       lx_msg_data1 := lx_msg_data1||NULL||'|';
    ELSIF lx_msg_data IS NOT NULL THEN
       lx_msg_data1 := lx_msg_data1||SUBSTR(lx_msg_data,1,250)||'|';
    END IF;
    V_Hdr_STS_MSG := V_Hdr_STS_MSG||'8300:'||lx_msg_data1||'|';
  END LOOP;
  end if;
   <<end_line>>
   V_LN_COUNT:=1;
  -------
   V_LINE_HDR_COUNT := 1;
   for r in 1..L_CART_LINE_DTL.count
   loop
   if P_CART_HDR_DTL(i).QUOTE_HEADER_ID = L_CART_LINE_DTL(r).QUOTE_HEADER_ID then
      v_qt_hdr_id               := L_CART_LINE_DTL(r).QUOTE_HEADER_ID ;
      v_qt_ln_id                := L_CART_LINE_DTL(r).QUOTE_LINE_ID;

	   --Removed ESn Validation since service team is taking care of it  Suguna 20-May-2018
               l_esn_flag := 'Y';
               l_esn_msg  := NULL;

      P_QT_LINE_STS_DTL(V_LN_COUNT) := V_QT_LINE_STS_DTL(v_qt_hdr_id ,
                                                        v_qt_ln_id,
                                                        V_LINE_STS_MSG(V_LINE_HDR_COUNT),NULL,l_esn_flag,l_esn_msg);
      V_LINE_HDR_COUNT := V_LINE_HDR_COUNT +1;
   end if;
  V_LN_COUNT := V_LN_COUNT + 1;
    end loop;
    ------
   <<end_hdr>>
   P_QT_HDR_STS_DTL.EXTEND;
   P_QT_HDR_STS_DTL(V_HD_CNT) := V_QT_HDR_STS_DTL(P_CART_HDR_DTL(i).QUOTE_HEADER_ID, V_Hdr_STS_MSG, null, null);
   V_HD_CNT := V_HD_CNT + 1;
END LOOP; -- header loop
    COMMIT;
<<end_ou>>
null;
<<end_save>>
null;
END SAVE_CART;
---- SAVE CART PROCEDURE ENDS HERE -----
-- Get cart Count procedure
PROCEDURE GET_CART_COUNT (
  --StANDard inputs
  P_SSO      VARCHAR2
  ,P_ROLE            VARCHAR2
  ,P_IACO_CODE       VARCHAR2
  ,P_CUST_ID         V_CUST_ID_ARRAY
  ,P_OU_ID           VARCHAR2
  --Procedure Specific parameters
  ,P_ITM_COUNT OUT NUMBER
  ,p_MSG OUT VARCHAR2
  )
AS
-- Sample execution statement: EXECUTE GEAE_MYGE_CART_PKG.GET_CART_COUNT ('502268940',NULL,NULL,NULL,NULL,[out_para1],[out_para2]);
  CURSOR c1(V_OU_ID1 VARCHAR2, V_OU_ID2 VARCHAR2) IS  -- Manisha K 7-Sept Modified into paramterized cursor to pick the two values of OU_ID
    ( SELECT COUNT(AQL.quote_line_id)
      FROM aso_quote_headers_all aqh JOIN fnd_user fnu
            ON aqh.created_by=fnu.user_id
          JOIN aso_quote_lines_all aql
            ON aql.quote_header_id=aqh.QUOTE_HEADER_ID
      WHERE fnu.user_name= p_SSO
        AND aqh.QUOTE_STATUS_ID in (10000,10010)
        AND aql.ITEM_TYPE_CODE in ('STD','MDL')
      --  AND aqh.ORG_ID = P_OU_ID --MYJIRATEST-3817 Ravi S 20-OCT-2014
        AND (aqh.ORG_ID = V_OU_ID1   OR aqh.ORG_ID = V_OU_ID2)
        AND QUOTE_EXPIRATION_DATE >SYSDATE);
  l_line_count NUMBER;
  v_ou_id                      VARCHAR2(30)   := NULL; --Added By Manisha;07-SEP-2018;Passport requirement to save the OU_ID separated by comma
  v_ou_id1                      VARCHAR2(30)   := NULL;
  v_ou_id2                      VARCHAR2(30)   := NULL;
BEGIN
     -- For SSO ID
     IF p_SSO IS NULL THEN
      p_MSG:=GET_ERR_MSG(8024);
      goto end_proc;
     END IF;
     --For Operating unit ID
     IF P_OU_ID IS NULL THEN
      p_MSG:=GET_ERR_MSG(8025);
      goto end_proc;
     END IF;
   /**********************0***********************
  Below code Added By Manisha K. 07-Sept-2018 to segregate the two ou_id's
  As part of Passport Requirement: Two OU_ID will be passed separated by ~ symbol.
  **************************************************/
  v_ou_id := P_OU_ID;
  v_ou_id1 := REGEXP_SUBSTR(v_ou_id, '[^~]+', 1,1);
  v_ou_id2 :=  NVL(REGEXP_SUBSTR (v_ou_id, '[^~]+', 1, 2), '0');

    OPEN c1(v_ou_id1, v_ou_id2);
    FETCH c1 INTO l_line_count;
    P_ITM_COUNT :=l_line_count;
  <<end_proc>>
  null;
END GET_CART_COUNT;
-- DELETE_CART_LINE procedure body
PROCEDURE DELETE_CART_LINE (
  --stANDard inputs
  P_SSO      IN VARCHAR2
  ,P_ROLE    IN        VARCHAR2
  ,P_IACO_CODE   IN    VARCHAR2
  ,P_CUST_ID     IN    V_CUST_ID_ARRAY
  ,P_OU_ID       IN    VARCHAR2
  --Proc specific inputs
  ,p_CART_HEADER_ID  IN NUMBER
  ,p_CART_LINE_ID    IN NUMBER
  --Output Parameter
  ,p_MSG    OUT VARCHAR2
  )
  -- Sample Execution Code: EXECUTE GEAE_MYGE_CART_PKG.DELETE_CART_LINE ('502314232',NULL,NULL,NULL,60377,13651,13069,o_msg1);
AS
--Local variable declarations
  l_Commit                VARCHAR2(1000);
  lc_last_update_date     DATE;
  lc_ln_last_update_date  DATE;
  lc_shipment_id          NUMBER;
  l_control_rec           aso_quote_pub.control_rec_type;
  l_qte_header_rec        aso_quote_pub.qte_header_rec_type;
  l_qte_line_tbl          aso_quote_pub.qte_line_tbl_type;
  l_qte_line_rec          aso_quote_pub.qte_line_rec_type;
  l_qte_line_dtl_tbl      aso_quote_pub.qte_line_dtl_tbl_type;
  l_hd_price_attr_tbl     aso_quote_pub.price_attributes_tbl_type;
  l_hd_payment_tbl        aso_quote_pub.payment_tbl_type;
  l_hd_shipment_tbl       aso_quote_pub.shipment_tbl_type;
  l_hd_freight_charge_tbl aso_quote_pub.freight_charge_tbl_type;
  l_hd_tax_detail_tbl     aso_quote_pub.tax_detail_tbl_type;
  l_line_attr_ext_tbl     aso_quote_pub.line_attribs_ext_tbl_type;
  l_line_rltship_tbl      aso_quote_pub.line_rltship_tbl_type;
  l_price_adjustment_tbl  aso_quote_pub.price_adj_tbl_type;
  l_price_adj_attr_tbl    aso_quote_pub.price_adj_attr_tbl_type;
  l_price_adj_rltship_tbl aso_quote_pub.price_adj_rltship_tbl_type;
  l_ln_price_attr_tbl     aso_quote_pub.price_attributes_tbl_type;
  l_ln_payment_tbl        aso_quote_pub.payment_tbl_type;
  l_ln_shipment_tbl       aso_quote_pub.shipment_tbl_type;
  l_ln_freight_charge_tbl aso_quote_pub.freight_charge_tbl_type;
  l_ln_tax_detail_tbl     aso_quote_pub.tax_detail_tbl_type;
  l_hd_sales_credit_tbl   aso_quote_pub.sales_credit_tbl_type := aso_quote_pub.g_miss_sales_credit_tbl;
  l_ln_sales_credit_tbl   aso_quote_pub.sales_credit_tbl_type := aso_quote_pub.g_miss_sales_credit_tbl;
  lx_qte_header_rec         aso_quote_pub.qte_header_rec_type;
  lx_qte_line_tbl           aso_quote_pub.qte_line_tbl_type;
  lx_qte_line_dtl_tbl       aso_quote_pub.qte_line_dtl_tbl_type;
  lx_hd_price_attr_tbl      aso_quote_pub.price_attributes_tbl_type;
  lx_hd_payment_tbl         aso_quote_pub.payment_tbl_type;
  lx_hd_shipment_tbl        aso_quote_pub.shipment_tbl_type;
  lx_hd_freight_charge_tbl  aso_quote_pub.freight_charge_tbl_type;
  lx_hd_tax_detail_tbl      aso_quote_pub.tax_detail_tbl_type;
  lx_hd_attr_ext_tbl        aso_quote_pub.line_attribs_ext_tbl_type;
  lx_line_attr_ext_tbl      aso_quote_pub.line_attribs_ext_tbl_type;
  lx_line_rltship_tbl       aso_quote_pub.line_rltship_tbl_type;
  lx_price_adjustment_tbl   aso_quote_pub.price_adj_tbl_type;
  lx_price_adj_attr_tbl     aso_quote_pub.price_adj_attr_tbl_type;
  lx_price_adj_rltship_tbl  aso_quote_pub.price_adj_rltship_tbl_type;
  lx_hd_sales_credit_tbl    aso_quote_pub.sales_credit_tbl_type;
  lx_quote_party_tbl        aso_quote_pub.quote_party_tbl_type;
  lx_ln_sales_credit_tbl    aso_quote_pub.sales_credit_tbl_type;
  lx_ln_quote_party_tbl     aso_quote_pub.quote_party_tbl_type;
  lx_ln_price_attr_tbl      aso_quote_pub.price_attributes_tbl_type;
  lx_ln_payment_tbl         aso_quote_pub.payment_tbl_type;
  lx_ln_shipment_tbl        aso_quote_pub.shipment_tbl_type;
  lx_ln_freight_charge_tbl  aso_quote_pub.freight_charge_tbl_type;
  lx_ln_tax_detail_tbl      aso_quote_pub.tax_detail_tbl_type;
  lx_return_status     varchar2(1);
  lx_msg_count      number;
  lx_msg_data       varchar2(2000);
  l_payment_rec     aso_quote_pub.payment_rec_type;
  l_shipment_rec    aso_quote_pub.shipment_rec_type;
  l_tax_detail_rec  aso_quote_pub.tax_detail_rec_type;
  l_count_lines number;
  l_er_Header_count number;
  l_er_Line_count number;
  l_user_id number;
  l_resp_id varchar2(50);
  l_app_id varchar2(50);
  l_authorized VARCHAR2(1);
  v_OU_ID   VARCHAR2(20);    -- Manisha K. 12-Sept-2018 Added the variable to save OU_ID
  CURSOR c_quote_lud(c_qte_header_id NUMBER) IS
    SELECT  last_update_date
    FROM    aso_quote_headers_all
    WHERE   quote_header_id = c_qte_header_id;
  CURSOR c_quote_ln_lud(c_qte_header_id NUMBER, c_qte_line_id NUMBER) IS
    SELECT last_update_date
      FROM aso_quote_lines_all
     WHERE quote_header_id = c_qte_header_id
       AND quote_line_id = c_qte_line_id;
  l_qt_ln_cnt NUMBER;
  CURSOR c_qt_ln_id_del (p_cart_line_id NUMBER) IS
     SELECT aqld.quote_line_id
       FROM aso_quote_line_details aqld, aso_quote_line_details aql
      WHERE aqld.quote_line_id <> p_cart_line_id
        AND aql.quote_line_id = p_cart_line_id
        AND aqld.config_header_id = aql.config_header_id
     ORDER BY aqld.quote_line_id DESC;
BEGIN
  -- Error HANDling
  SELECT COUNT(quote_header_id)
    INTO l_er_Header_count
    FROM aso_quote_headers_all
   WHERE quote_header_id=p_CART_HEADER_ID;
  SELECT COUNT(quote_line_id)
    INTO l_er_Line_count
    FROM aso_quote_lines_all
   WHERE quote_line_id=p_CART_LINE_ID;
  -- For SSO id
  IF p_SSO IS NULL THEN
      p_MSG:=GET_ERR_MSG(8024);
      goto end_proc;
  END IF;
  --For Operating unit ID
  IF P_OU_ID IS NULL THEN
     p_MSG:=GET_ERR_MSG(8025);
     goto end_proc;
  END IF;
  -- For Header_ID
  IF p_CART_HEADER_ID IS NULL THEN
     p_MSG:=GET_ERR_MSG(8012);
     goto end_proc;
  ELSIF l_er_Header_count=0 THEN
     p_MSG:=GET_ERR_MSG(8010);
     goto end_proc;
  ELSE
     p_MSG:= NULL;
  END IF;

  /*******************************************
  Manisha K. 12-Sept-2018 Added the below to find out the OU_ID based on the
  input parameter header_id
  *********************************************/
IF P_OU_ID like '%~%' THEN
  BEGIN
  SELECT org_id
  INTO V_OU_ID
  FROM aso_quote_headers_all
  WHERE quote_header_id=p_CART_HEADER_ID;

  EXCEPTION
   WHEN OTHERS THEN
   P_MSG := 'Error while fetching the OU_ID: '||SQLCODE||SQLERRM;
   goto end_proc;
  END;

   IF v_OU_ID IS NULL THEN
    p_MSG:=GET_ERR_MSG(8503);
    goto end_proc;
    END IF;
ELSE
    V_OU_ID := P_OU_ID;
  END IF;

  --Ravi S 19-SEP-2014 MYJIRATEST-3513 Authorization logic
  l_authorized := 'N';
  BEGIN
     SELECT 'Y'
       INTO l_authorized
       FROM aso_quote_headers_all aqh, fnd_user fu
      WHERE aqh.created_by = fu.user_id
        AND aqh.org_id = V_OU_ID --P_OU_ID
        AND fu.user_name = P_SSO
        AND aqh.quote_header_id = p_CART_HEADER_ID;
  EXCEPTION
     WHEN NO_DATA_FOUND THEN
        p_MSG:=GET_ERR_MSG(8180);
        goto end_proc;
  END;
  --For Line_ID
  IF p_cart_line_id IS NULL THEN
     p_MSG:=GET_ERR_MSG(8013);
     goto end_proc;
  ELSIF l_er_Line_count=0 THEN
     p_MSG:=GET_ERR_MSG(8011);
     goto end_proc;
  ELSE
     p_MSG:= NULL;
  END IF;
  --Fetching User ID
  SELECT user_id INTO l_user_id
    FROM fnd_user
   WHERE user_name=p_SSO;
  --Fetching Responsibility ID AND App ID
  BEGIN
     SELECT RESP.RESPONSIBILITY_ID,RESP.APPLICATION_ID
       INTO l_resp_id,l_app_id
       FROM FND_RESPONSIBILITY_TL RESP,
            FND_LOOKUP_VALUES FLV ,
            HR_OPERATING_UNITS HOU
      WHERE HOU.NAME = FLV.MEANING
        AND RESP.RESPONSIBILITY_NAME = FLV.DESCRIPTION
        AND HOU.ORGANIZATION_ID = V_OU_ID --P_OU_ID
        AND FLV.LOOKUP_TYPE = 'GEAE_MYGE_QUOTE_RESPONSIBILITY';
  EXCEPTION
     WHEN no_data_found THEN
        P_MSG := GET_ERR_MSG(8026);
        GOTO end_proc;
  END;
  -- Quote Header Rec
  l_qte_header_rec.quote_header_id            := p_CART_HEADER_ID;
  -- Get the Last Updated Date
  OPEN c_quote_lud(l_qte_header_rec.quote_header_id);
  FETCH c_quote_lud INTO lc_last_update_date;
  CLOSE c_quote_lud;
  OPEN c_quote_ln_lud(p_CART_HEADER_ID,p_CART_LINE_ID);
  FETCH c_quote_ln_lud INTO lc_ln_last_update_date;
  CLOSE c_quote_ln_lud;
  l_qte_header_rec.last_update_date           := lc_last_update_date;
  l_qte_line_rec.quote_header_id              := p_CART_HEADER_ID;
  l_qte_line_rec.quote_line_id                := p_CART_LINE_ID;
  l_qte_line_rec.operation_code               := 'DELETE';
  l_qte_line_rec.last_update_date             := lc_ln_last_update_date;
  l_qte_line_tbl(1)                           := l_qte_line_rec;
   -------- It is for delete nested lines ends here, added by Mohammed Yadul on 08-Sep-2014 --
   SELECT COUNT(1) INTO l_qt_ln_cnt
     FROM aso_quote_line_details aqld, aso_quote_line_details aql
    WHERE aqld.quote_line_id <> p_cart_line_id
      AND aql.quote_line_id = p_cart_line_id
      AND aqld.config_header_id = aql.config_header_id;
   IF l_qt_ln_cnt > 0 THEN
     BEGIN
        Fnd_Global.Apps_Initialize(l_user_id,l_resp_id,l_app_id);
        mo_global.set_policy_context('S',V_OU_ID);
     END;
     FOR h in c_qt_ln_id_del  (p_cart_line_id) LOOP
        OPEN c_quote_lud(l_qte_header_rec.quote_header_id);
        FETCH c_quote_lud INTO lc_last_update_date;
        CLOSE c_quote_lud;
        l_qte_header_rec.last_update_date           := lc_last_update_date;
        OPEN c_quote_ln_lud(p_CART_HEADER_ID,h.QUOTE_LINE_ID);
        FETCH c_quote_ln_lud INTO lc_ln_last_update_date;
        CLOSE c_quote_ln_lud;
        l_qte_line_rec.last_update_date             := lc_ln_last_update_date;
        l_qte_line_rec.quote_line_id                := h.QUOTE_LINE_ID;
        l_qte_line_tbl(1)                           := l_qte_line_rec;
  -- Calling update_quote API
          aso_quote_pub.update_quote(p_api_version_number       =>  1.0
                            ,p_init_msg_list            => fnd_api.g_true
                            ,p_commit                   => fnd_api.g_true
                            ,p_control_rec              => l_control_rec
                            ,p_qte_header_rec           => l_qte_header_rec
                            ,p_qte_line_tbl             => l_qte_line_tbl
                            ,p_qte_line_dtl_tbl         => l_qte_line_dtl_tbl
                            ,p_hd_tax_detail_tbl        => l_hd_tax_detail_tbl
                            ,p_ln_payment_tbl           => l_ln_payment_tbl
                            ,p_hd_sales_credit_tbl      => l_hd_sales_credit_tbl
                            ,p_ln_sales_credit_tbl      => l_ln_sales_credit_tbl
                            ,p_ln_shipment_tbl          => l_ln_shipment_tbl
                            ,x_qte_header_rec           => lx_qte_header_rec
                            ,x_qte_line_tbl             => lx_qte_line_tbl
                            ,x_qte_line_dtl_tbl         => lx_qte_line_dtl_tbl
                            ,x_hd_price_attributes_tbl  => lx_hd_price_attr_tbl
                            ,x_hd_payment_tbl           => lx_hd_payment_tbl
                            ,x_hd_shipment_tbl          => lx_hd_shipment_tbl
                            ,x_hd_freight_charge_tbl    => lx_hd_freight_charge_tbl
                            ,x_hd_tax_detail_tbl        => lx_hd_tax_detail_tbl
                            ,x_hd_attr_ext_tbl          => lx_hd_attr_ext_tbl
                            ,x_hd_sales_credit_tbl      => lx_hd_sales_credit_tbl
                            ,x_hd_quote_party_tbl       => lx_quote_party_tbl
                            ,x_line_attr_ext_tbl        => lx_line_attr_ext_tbl
                            ,x_line_rltship_tbl         => lx_line_rltship_tbl
                            ,x_price_adjustment_tbl     => lx_price_adjustment_tbl
                            ,x_price_adj_attr_tbl       => lx_price_adj_attr_tbl
                            ,x_price_adj_rltship_tbl    => lx_price_adj_rltship_tbl
                            ,x_ln_price_attributes_tbl  => lx_ln_price_attr_tbl
                            ,x_ln_payment_tbl           => lx_ln_payment_tbl
                            ,x_ln_shipment_tbl          => lx_ln_shipment_tbl
                            ,x_ln_freight_charge_tbl    => lx_ln_freight_charge_tbl
                            ,x_ln_tax_detail_tbl        => lx_ln_tax_detail_tbl
                            ,x_ln_sales_credit_tbl      => lx_ln_sales_credit_tbl
                            ,x_ln_quote_party_tbl       => lx_ln_quote_party_tbl
                            ,x_return_status            => lx_return_status
                            ,x_msg_count                => lx_msg_count
                            ,x_msg_data                 => lx_msg_data);
          fnd_msg_pub.count_AND_get(p_encoded => 'F'
                           ,p_count   => lx_msg_count
                           ,p_data    => lx_msg_data);
          lx_msg_data := fnd_msg_pub.get(p_msg_index => 1
                                  ,p_encoded => 'F');
          p_MSG:=lx_msg_data;
       END LOOP;
     END IF;
     --Getting current cart count
     SELECT COUNT(*)
       INTO l_count_lines
       FROM aso_quote_lines_all
      WHERE quote_header_id=l_qte_header_rec.quote_header_id
        AND item_type_code in ('STD','MDL');
     IF (l_count_lines>1) THEN
        BEGIN
           Fnd_Global.Apps_Initialize(l_user_id,l_resp_id,l_app_id);
           mo_global.set_policy_context('S',V_OU_ID);
        END;
        OPEN c_quote_lud(l_qte_header_rec.quote_header_id);
        FETCH c_quote_lud INTO lc_last_update_date;
        CLOSE c_quote_lud;
        l_qte_header_rec.last_update_date           := lc_last_update_date;
        OPEN c_quote_ln_lud(p_CART_HEADER_ID,p_CART_LINE_ID);
        FETCH c_quote_ln_lud INTO lc_ln_last_update_date;
        CLOSE c_quote_ln_lud;
        l_qte_line_rec.last_update_date             := lc_ln_last_update_date;
        l_qte_line_rec.quote_line_id                := p_CART_LINE_ID;
        l_qte_line_tbl(1)                           := l_qte_line_rec;
     -------- It is for delete nested lines ends here, added by Mohammed Yadul on 08-Sep-2014 --
     -- Calling update_quote API
     aso_quote_pub.update_quote(p_api_version_number       =>  1.0
                            ,p_init_msg_list            => fnd_api.g_true
                            ,p_commit                   => fnd_api.g_true
                            ,p_control_rec              => l_control_rec
                            ,p_qte_header_rec           => l_qte_header_rec
                            ,p_qte_line_tbl             => l_qte_line_tbl
                            ,p_qte_line_dtl_tbl         => l_qte_line_dtl_tbl
                            ,p_hd_tax_detail_tbl        => l_hd_tax_detail_tbl
                            ,p_ln_payment_tbl           => l_ln_payment_tbl
                            ,p_hd_sales_credit_tbl      => l_hd_sales_credit_tbl
                            ,p_ln_sales_credit_tbl      => l_ln_sales_credit_tbl
                            ,p_ln_shipment_tbl          => l_ln_shipment_tbl
                            ,x_qte_header_rec           => lx_qte_header_rec
                            ,x_qte_line_tbl             => lx_qte_line_tbl
                            ,x_qte_line_dtl_tbl         => lx_qte_line_dtl_tbl
                            ,x_hd_price_attributes_tbl  => lx_hd_price_attr_tbl
                            ,x_hd_payment_tbl           => lx_hd_payment_tbl
                            ,x_hd_shipment_tbl          => lx_hd_shipment_tbl
                            ,x_hd_freight_charge_tbl    => lx_hd_freight_charge_tbl
                            ,x_hd_tax_detail_tbl        => lx_hd_tax_detail_tbl
                            ,x_hd_attr_ext_tbl          => lx_hd_attr_ext_tbl
                            ,x_hd_sales_credit_tbl      => lx_hd_sales_credit_tbl
                            ,x_hd_quote_party_tbl       => lx_quote_party_tbl
                            ,x_line_attr_ext_tbl        => lx_line_attr_ext_tbl
                            ,x_line_rltship_tbl         => lx_line_rltship_tbl
                            ,x_price_adjustment_tbl     => lx_price_adjustment_tbl
                            ,x_price_adj_attr_tbl       => lx_price_adj_attr_tbl
                            ,x_price_adj_rltship_tbl    => lx_price_adj_rltship_tbl
                            ,x_ln_price_attributes_tbl  => lx_ln_price_attr_tbl
                            ,x_ln_payment_tbl           => lx_ln_payment_tbl
                            ,x_ln_shipment_tbl          => lx_ln_shipment_tbl
                            ,x_ln_freight_charge_tbl    => lx_ln_freight_charge_tbl
                            ,x_ln_tax_detail_tbl        => lx_ln_tax_detail_tbl
                            ,x_ln_sales_credit_tbl      => lx_ln_sales_credit_tbl
                            ,x_ln_quote_party_tbl       => lx_ln_quote_party_tbl
                            ,x_return_status            => lx_return_status
                            ,x_msg_count                => lx_msg_count
                            ,x_msg_data                 => lx_msg_data);
     fnd_msg_pub.count_AND_get(p_encoded => 'F'
                           ,p_count   => lx_msg_count
                           ,p_data    => lx_msg_data);
     lx_msg_data := fnd_msg_pub.get(p_msg_index => 1
                                  ,p_encoded => 'F');
     p_MSG:=lx_msg_data;
  ELSE
     BEGIN
        Fnd_Global.Apps_Initialize(l_user_id,l_resp_id,l_app_id);
        mo_global.set_policy_context('S',V_OU_ID);
     END;
     -- Calling Delete_quote API
     ASO_QUOTE_HEADERS_PVT.Delete_quote(
      P_Api_Version_Number  => 1.0,
      P_Init_Msg_List    => FND_API.G_FALSE,
      P_Commit    => l_commit,
      P_Qte_Header_ID    => l_qte_header_rec.quote_header_id ,
      X_Return_Status         => lx_return_status,
      X_Msg_Count             => lx_msg_count,
      X_Msg_Data              => lx_msg_data);
     fnd_msg_pub.count_AND_get(
        p_encoded => 'F',
        p_count => lx_msg_count,
        p_data => lx_msg_data);
     lx_msg_data := fnd_msg_pub.get(
        p_msg_index => 1,
        p_encoded => 'F');
     p_MSG:=lx_msg_data;
  END IF;
  COMMIT;
  <<end_proc>>
  NULL;
END DELETE_CART_LINE;
-- Delete Cart Procedure
PROCEDURE DELETE_CART (
                        p_SSO      IN     VARCHAR2,
                        p_ROLE       IN   VARCHAR2,
                        p_IACO_CODE  IN   VARCHAR2,
                        p_CUST_ID    IN   V_CUST_ID_ARRAY,
                        P_OU_ID      IN   VARCHAR2, --NUMBER,--Manisha K. 13Sep Changed the datatype as OUID will passed separated '~'
                        P_MSG OUT VARCHAR2
                        )
AS
l_Api_Version_Number NUMBER;
l_Init_Msg_List VARCHAR2(1000);
l_Commit VARCHAR2(1000);
lX_return_status VARCHAR2(1);
lx_msg_count NUMBER;
lx_msg_data VARCHAR2(2000);
l_Qte_Header_Rec ASO_QUOTE_PUB.Qte_Header_Rec_Type;
l_user_id NUMBER;
l_resp_id NUMBER;
l_app_id NUMBER;
l_quote_count NUMBER;
v_OU_ID    VARCHAR2(50); -- Manisha K. 12 Sept. Added variable to save OU_ID
CURSOR c_header_id(v_OU_ID VARCHAR2) IS
  SELECT  aqh.quote_header_id
  FROM    aso_quote_headers_all aqh JOIN fnd_user fnd
            ON aqh.created_by=fnd.user_id
  WHERE   fnd.user_name= p_SSO
          AND aqh.org_id=v_OU_ID --p_OU_ID
          AND aqh.QUOTE_STATUS_ID in (10000,10010)--status validation
          AND aqh.QUOTE_EXPIRATION_DATE > SYSDATE;
CURSOR c_qt_ln_tst (v_quote_header_id NUMBER) IS
  SELECT quote_line_id
  FROM ASO_QUOTE_LINES_ALL
  WHERE quote_header_id = v_quote_header_id
          AND item_type_code = 'MDL';
CURSOR c_qt_ln_id_del (v_quote_line_id number) is
  SELECT AQLD.REF_LINE_ID,AQLD.quote_line_id
    FROM ASO_QUOTE_LINE_DETAILS AQLD, ASO_QUOTE_LINE_DETAILS AQL
   WHERE AQLD.QUOTE_LINE_ID <> v_quote_line_id
     AND AQL.QUOTE_LINE_ID = v_quote_line_id
     AND AQLD.CONFIG_HEADER_ID = AQL.CONFIG_HEADER_ID
  ORDER BY AQLD.quote_line_id DESC;
 BEGIN

 --Vaildation for Operating unit ID
    IF P_OU_ID IS NULL THEN
       p_MSG:=GET_ERR_MSG(8025);
       goto end_proc;
    END IF;

  /*******************************************
  Manisha K. 12-Sept-2018 Added the below code to find out the OU_ID based on the
  input parameter header_id
  *********************************************/

  v_ou_id := Replace(P_OU_ID,'~',',');

  FOR j IN
     (SELECT trim(regexp_substr(v_ou_id, '[^,]+', 1, LEVEL)) ou_id
  FROM dual
      CONNECT BY LEVEL <= regexp_count(v_ou_id, ',')+1
    )
   LOOP

    IF j.ou_id IS NULL THEN
        p_MSG:=GET_ERR_MSG(8503);
        goto end_proc;
    END IF;

-- Error HANDling
    SELECT COUNT(*)
      INTO l_quote_count
      FROM aso_quote_headers_all
     WHERE created_by = (SELECT user_id FROM fnd_user WHERE user_name= p_SSO)
       AND org_id=j.ou_id  --p_OU_ID
       AND QUOTE_STATUS_ID in (10000,10010)--status validation
       AND QUOTE_EXPIRATION_DATE > SYSDATE;
  -- For SSO id
    IF p_SSO IS NULL THEN
       p_MSG:=GET_ERR_MSG(8024);
       goto end_proc;
    END IF;
    --For Operating unit ID
    IF P_OU_ID IS NULL THEN
       p_MSG:=GET_ERR_MSG(8025);
       goto end_proc;
    END IF;
    -- For quote existence
    IF l_quote_count =0 THEN
      -- P_MSG:=GET_ERR_MSG(8022);
     --  goto end_proc;
    CONTINUE; -- Manisha 13-Sept Added continue statement to forward the loop to next OU_ID value in case of error
    END IF;
    --Fetching User ID
    SELECT user_id
      INTO l_user_id
      FROM fnd_user
     WHERE user_name=p_SSO;
  --Fetching Responsibility ID AND App ID
    BEGIN
       SELECT RESP.RESPONSIBILITY_ID,RESP.APPLICATION_ID
         INTO l_resp_id,l_app_id
         FROM FND_RESPONSIBILITY_TL RESP,
              FND_LOOKUP_VALUES FLV ,
              HR_OPERATING_UNITS HOU
        WHERE HOU.NAME = FLV.MEANING
          AND RESP.RESPONSIBILITY_NAME = FLV.DESCRIPTION
          AND HOU.ORGANIZATION_ID = j.ou_id --P_OU_ID
          AND FLV.LOOKUP_TYPE = 'GEAE_MYGE_QUOTE_RESPONSIBILITY';
    EXCEPTION
       WHEN no_data_found THEN
          P_MSG := GET_ERR_MSG(8026);
         -- GOTO end_proc;
         CONTINUE; -- Manisha 13-Sept Added continue statement to forward the loop to next OU_ID value in case of error
    END;
  --Apps initialize
    BEGIN
      Fnd_Global.Apps_Initialize(l_user_id,l_resp_id,l_app_id);
      mo_global.set_policy_context('S',j.ou_id);
    END;
    FOR i in c_header_id(j.OU_ID) Loop
       ASO_QUOTE_HEADERS_PVT.Delete_quote(
                      P_Api_Version_Number  => 1.0,
                      P_Init_Msg_List    => FND_API.G_FALSE,
                      P_Commit    => l_commit,
                      P_Qte_Header_ID    => i.quote_header_id,
                      X_Return_Status         => lx_return_status,
                      X_Msg_Count             => lx_msg_count,
                      X_Msg_Data              => lx_msg_data);
       fnd_msg_pub.count_AND_get(
              p_encoded => 'F',
              p_count => lx_msg_count,
              p_data => lx_msg_data);
       lx_msg_data := fnd_msg_pub.get(
              p_msg_index => 1,
              p_encoded => 'F');
     ----------- It is for delete nested lines of Kit Quote quote lines starts here, add by mohammed yadul on 08-Sep-2014 ----
       IF lx_msg_data LIKE '%ASO_LINE_RLTSHIP_PVT.Delete_line_rltship%' THEN
          BEGIN
             FOR k IN c_qt_ln_tst(i.quote_header_id) LOOP
                FOR r IN c_qt_ln_id_del (k.QUOTE_LINE_ID) LOOP
                   APPS.GEAE_MYGE_CART_PKG.DELETE_CART_LINE(
                      P_SSO => P_SSO,
                      P_ROLE => P_ROLE,
                      P_IACO_CODE => P_IACO_CODE,
                      P_CUST_ID => P_CUST_ID,
                      P_OU_ID => j.ou_id, --P_OU_ID,
                      P_CART_HEADER_ID => i.quote_header_id, --P_CART_HEADER_ID,
                      P_CART_LINE_ID => r.QUOTE_LINE_ID, --P_CART_LINE_ID,
                      P_MSG => P_MSG
                      );
                END LOOP;
             END LOOP;
        ------------ It is for delete kit quotes starts here, add by mohammed yadul on 08-Sep-2014 ---
             ASO_QUOTE_HEADERS_PVT.Delete_quote(
                P_Api_Version_Number  => 1.0,
                P_Init_Msg_List    => FND_API.G_FALSE,
                P_Commit    => l_commit,
                P_Qte_Header_ID    => i.quote_header_id,
                X_Return_Status         => lx_return_status,
                X_Msg_Count             => lx_msg_count,
                X_Msg_Data              => lx_msg_data);
             fnd_msg_pub.count_AND_get(
                p_encoded => 'F',
                p_count => lx_msg_count,
                p_data => lx_msg_data);
             lx_msg_data := fnd_msg_pub.get(
                p_msg_index => 1,
                p_encoded => 'F');
        ------------ It is for delete kit quotes ends here, add by mohammed yadul on 08-Sep-2014 ---
          END;
       END IF;
       --MYJIRATEST-4588 Ravi S 20-NOV-2014
       SELECT COUNT(*)
         INTO l_quote_count
         FROM aso_quote_headers_all
        WHERE created_by = (SELECT user_id FROM fnd_user WHERE user_name= p_SSO)
          AND org_id= j.ou_id  --p_OU_ID
          AND QUOTE_STATUS_ID in (10000,10010)--status validation
          AND QUOTE_EXPIRATION_DATE > SYSDATE;
        ----------- It is for delete nested lines of Kit Quote quote lines ends here, add by mohammed yadul on 08-Sep-2014 ----
       IF l_quote_count > 0 THEN
          IF lx_msg_data LIKE '%ASO_LINE_RLTSHIP_PVT.Delete_line_rltship%' THEN
             p_MSG:=P_MSG||' '||GET_ERR_MSG('8032');
          ELSE
             p_MSG:=P_MSG||' '||lx_msg_data;
          END IF;
       END IF;
    END LOOP;
 COMMIT;

 END LOOP; -- End of loop j.OU_ID
<<end_proc>>
NULL;
END DELETE_CART;
-- CREATE_CART Procedure
PROCEDURE CREATE_CART (
  --StANDard inputs
  p_SSO IN VARCHAR2,
  p_ROLE      IN VARCHAR2,
  p_IACO_CODE    IN VARCHAR2,
  --p_CUST_ID    IN V_CUST_ID_ARRAY,
  p_OU_ID      IN VARCHAR2,
  --Procedure Specific parameters
  p_INVENTORY_ITEM_ID  IN NUMBER,
  P_CUST_ID    IN NUMBER,
  p_SUPPLIER_CODE IN VARCHAR2,
  p_QUANTITY IN NUMBER,
  p_PRICELIST_ID IN NUMBER,
  -- out
  p_MSG OUT VARCHAR2
  )
AS
v_control_rec ASO_QUOTE_PUB.Control_Rec_Type;
l_control_rec ASO_QUOTE_PUB.Control_Rec_Type;
l_qte_header_rec ASO_QUOTE_PUB.Qte_Header_Rec_Type;
l_qte_line_rec ASO_QUOTE_PUB.Qte_Line_Rec_Type;
l_qte_line_tbl ASO_QUOTE_PUB.Qte_Line_Tbl_Type;
L_Hd_Payment_Tbl Aso_Quote_Pub.Payment_Tbl_Type;
l_payment_rec ASO_QUOTE_PUB.Payment_Rec_Type;
l_hd_shipment_rec ASO_QUOTE_PUB.Shipment_Rec_Type;
l_hd_tax_detail_tbl ASO_QUOTE_PUB.Tax_Detail_Tbl_Type;
l_tax_detail_rec ASO_QUOTE_PUB.Tax_Detail_Rec_Type;
l_tax_control_rec ASO_TAX_INT.Tax_control_rec_type;
l_Line_Attr_Ext_Tbl ASO_QUOTE_PUB.Line_Attribs_Ext_Tbl_Type;
l_line_rltship_tbl ASO_QUOTE_PUB.Line_Rltship_Tbl_Type;
l_Price_Adjustment_Tbl ASO_QUOTE_PUB.Price_Adj_Tbl_Type;
l_Price_Adj_Attr_Tbl ASO_QUOTE_PUB.Price_Adj_Attr_Tbl_Type;
l_price_adj_rltship_tbl ASO_QUOTE_PUB.Price_Adj_Rltship_Tbl_Type;
l_ln_Price_Attr_Tbl ASO_QUOTE_PUB.Price_Attributes_Tbl_Type;
l_ln_payment_tbl ASO_QUOTE_PUB.Payment_Tbl_Type;
l_ln_shipment_tbl ASO_QUOTE_PUB.Shipment_Tbl_Type;
l_ln_freight_charge_tbl ASO_QUOTE_PUB.Freight_Charge_Tbl_Type;
l_ln_tax_detail_tbl ASO_QUOTE_PUB.Tax_Detail_Tbl_Type;
lx_qte_header_rec ASO_QUOTE_PUB.Qte_Header_Rec_Type;
lx_qte_line_tbl ASO_QUOTE_PUB.Qte_Line_Tbl_Type;
lx_qte_line_dtl_tbl ASO_QUOTE_PUB.Qte_Line_Dtl_Tbl_Type;
lx_hd_Price_Attr_Tbl ASO_QUOTE_PUB.Price_Attributes_Tbl_Type;
lx_hd_payment_tbl ASO_QUOTE_PUB.Payment_Tbl_Type;
lx_hd_shipment_rec ASO_QUOTE_PUB.Shipment_Rec_Type;
lx_hd_freight_charge_tbl ASO_QUOTE_PUB.Freight_Charge_Tbl_Type;
lx_hd_tax_detail_tbl ASO_QUOTE_PUB.Tax_Detail_Tbl_Type;
lx_Line_Attr_Ext_Tbl ASO_QUOTE_PUB.Line_Attribs_Ext_Tbl_Type;
lx_line_rltship_tbl ASO_QUOTE_PUB.Line_Rltship_Tbl_Type;
lx_Price_Adjustment_Tbl ASO_QUOTE_PUB.Price_Adj_Tbl_Type;
lx_Price_Adj_Attr_Tbl ASO_QUOTE_PUB.Price_Adj_Attr_Tbl_Type;
lx_price_adj_rltship_tbl ASO_QUOTE_PUB.Price_Adj_Rltship_Tbl_Type;
lx_ln_Price_Attr_Tbl ASO_QUOTE_PUB.Price_Attributes_Tbl_Type;
lx_ln_payment_tbl ASO_QUOTE_PUB.Payment_Tbl_Type;
lx_ln_shipment_tbl ASO_QUOTE_PUB.Shipment_Tbl_Type;
lx_ln_freight_charge_tbl ASO_QUOTE_PUB.Freight_Charge_Tbl_Type;
lx_ln_tax_detail_tbl ASO_QUOTE_PUB.Tax_Detail_Tbl_Type;
lX_return_status VARCHAR2(1);
lx_msg_count NUMBER;
lx_msg_data VARCHAR2(2000);
my_message VARCHAR2(2000);
l_file varchar2(2000);
l_party_id number;
l_party_site_id number;
l_user_id number;
l_resp_id varchar2(50);
l_app_id varchar2(50);
l_order_type_id varchar2(100);
l_Attib_category Varchar2(10);
order_type_name varchar2(50); -- added by suguna for order_type issue - US212495

BEGIN
  --Fetching User ID
    SELECT user_id INTO l_user_id
    FROM fnd_user
    WHERE user_name=p_SSO;
  --Fetching Responsibility ID AND App ID
  BEGIN
  SELECT RESP.RESPONSIBILITY_ID,RESP.APPLICATION_ID
   INTO l_resp_id,l_app_id
  FROM  FND_RESPONSIBILITY_TL RESP,
        FND_LOOKUP_VALUES FLV ,
        HR_OPERATING_UNITS HOU
  WHERE HOU.NAME = FLV.MEANING
      AND RESP.RESPONSIBILITY_NAME = FLV.DESCRIPTION
      AND HOU.ORGANIZATION_ID = P_OU_ID
      AND FLV.LOOKUP_TYPE = 'GEAE_MYGE_QUOTE_RESPONSIBILITY';
   EXCEPTION
    WHEN no_data_found THEN
       P_MSG := GET_ERR_MSG(8026);
       GOTO end_proc;
    END;
  IF p_QUANTITY < 1 THEN
     P_MSG := GET_ERR_MSG(8166);
     GOTO end_proc;
  END IF;
  -- Fetching party_id
  SELECT party_id INTO l_party_id
  FROM HZ_CUST_ACCOUNTS
  WHERE cust_account_id=p_CUST_ID;

/**********************************************
Manisha/Suguna 06-SEPT
Modified the below to fetch the order type based on customer_id from table HZ_CUST_SITE_USES_ALL
for OU_id =117039(PASSPORT), 60377(CSO).
Intitailly it was getting fetched from lookup table ='GEAE_MYGE_ORDER_TYPES'
***********************************************/
IF (p_OU_ID = 60377) OR (p_OU_ID =117019) THEN

BEGIN
SELECT distinct HCS.ORDER_TYPE_ID
  INTO l_order_type_id
  FROM APPS.HZ_CUST_ACCT_SITES_ALL HCA,
                 APPS.HZ_CUST_SITE_USES_ALL  HCS,
                 APPS.HZ_CUST_ACCOUNTS       HC
  WHERE HCA.ORG_ID = p_OU_ID
  AND HCA.CUST_ACCT_SITE_ID = HCS.CUST_ACCT_SITE_ID
  AND HCA.CUST_ACCOUNT_ID = HC.CUST_ACCOUNT_ID
  AND hc.cust_account_id = p_CUST_ID
  AND hcs.site_use_code = 'SHIP_TO'
  AND HCA.ORG_ID =HCS.ORG_ID
  AND HCS.PRIMARY_FLAG='Y'  --Manisha K. 10-OCT-18 added cond. to fetch the data for default ship to site id
  AND NVL(hca.STATUS, 'I') = 'A'
  AND NVL(hcS.STATUS, 'I') = 'A'
  AND NVL(HC.status, 'I') = 'A'
  AND HCS.ORDER_TYPE_ID is not NULL;

  IF l_order_type_id is null or l_order_type_id=' ' THEN
    P_MSG := GET_ERR_MSG(8502);
    GOTO end_proc;
  END IF;
 EXCEPTION
 WHEN NO_DATA_FOUND THEN
  P_MSG := GET_ERR_MSG(8502);
  GOTO end_proc;
  WHEN OTHERS THEN
  P_MSG := 'Exception occured In create cart while Fetching Order Type: E :'||SQLCODE||':'||SQLERRM;
  GOTO end_proc;
  END;

  --Verify order type
   BEGIN
  select NAME INTO order_type_name
  from oe_transaction_types_tl
  where transaction_type_id = l_order_type_id;

 IF (order_type_name != 'Special Charge' AND order_type_name != 'P20 Special Charge')
  AND (order_type_name != 'Customer Order'  AND order_type_name != 'P20 Customer Order') THEN
    P_MSG := GET_ERR_MSG(8501);
    GOTO end_proc;
  END IF;

EXCEPTION
 WHEN NO_DATA_FOUND THEN
  P_MSG := GET_ERR_MSG(8502);
  GOTO end_proc;
  WHEN OTHERS THEN
  P_MSG := 'Exception occured while checking Order Type: E :'||SQLCODE||':'||SQLERRM;
  GOTO end_proc;
END;

  --end

  ELSE -- Else of (p_OU_ID = 60377) OR (p_OU_ID =117019)

  SELECT transaction_type_id INTO l_order_type_id
  FROM oe_transaction_types_tl oe,
      fnd_lookup_values flv,
      hr_operating_units hou
  WHERE oe.name = flv.description
  AND hou.name = flv.meaning
  AND hou.organization_id = p_OU_ID
  AND flv.lookup_type ='GEAE_MYGE_ORDER_TYPES';

   END IF;  -- End if of (p_OU_ID = 60377) OR (p_OU_ID =117019)

  --Fetching Attribute Category Code
  SELECT lookup_code INTO l_Attib_category
  FROM fnd_lookup_values flv,
     hr_operating_units hou
  WHERE hou.name = flv.meaning
  AND hou.organization_id = p_OU_ID
  AND flv.lookup_type ='GEAE_OPERATING_UNIT';
     --App initializing
     BEGIN
       Fnd_Global.Apps_Initialize(l_user_id,l_resp_id,l_app_id);
       mo_global.set_policy_context('S',P_OU_ID);
     END;
     --Initializing variables
     --MYJIRATEST-5845 Ravi S 10-FEB-2015
     BEGIN
        SELECT oos.name
          INTO l_qte_header_rec.quote_source_code
          FROM oe_order_sources oos, fnd_lookup_values flv
         WHERE flv.lookup_type = 'GEAE_MYGE_ORDER_SOURCE'
           AND flv.lookup_code = P_OU_ID
           AND flv.description = oos.name;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            P_MSG := GET_ERR_MSG(8059);
            GOTO end_proc;
      END;
      v_control_rec.CALCULATE_TAX_FLAG := 'N';
      v_control_rec.CALCULATE_FREIGHT_CHARGE_FLAG := 'Y';
      v_control_rec.pricing_request_type := 'ASO';
      v_control_rec.line_pricing_event := 'LINE';
      v_control_rec.last_update_date := SYSDATE;
      l_control_rec.CALCULATE_TAX_FLAG := 'N';
      l_control_rec.CALCULATE_FREIGHT_CHARGE_FLAG := 'Y';
      l_control_rec.pricing_request_type := 'ASO';
      l_control_rec.header_pricing_event := 'BATCH';
      l_control_rec.last_update_date := SYSDATE;
      l_qte_header_rec.quote_name := l_qte_header_rec.quote_source_code||' '||to_char(SYSDATE,'YYYYMMDDHH24MISS');
      L_Qte_Header_Rec.Currency_Code := 'USD';
      L_Qte_Header_Rec.Party_Id :=l_party_id;
      l_qte_header_rec.cust_account_id :=p_CUST_ID;
      L_Qte_Header_Rec.Invoice_To_Cust_Account_Id :=p_CUST_ID;
      L_Qte_Header_Rec.order_type_Id :=l_order_type_id;
      L_Qte_Header_Rec.Price_List_Id := p_PRICELIST_ID;
      L_Qte_Header_Rec.sold_To_party_site_Id :=l_party_site_id;
      L_Qte_Header_Rec.Attribute_Category:=l_Attib_category;
      l_qte_header_rec.ATTRIBUTE1:=p_SUPPLIER_CODE;
      l_hd_shipment_rec.ship_to_cust_account_id :=p_CUST_ID;
      L_Hd_Payment_Tbl(1).Operation_Code:= 'CREATE';
      l_Qte_Line_Tbl(1).operation_code := 'CREATE';
      l_Qte_Line_Tbl(1).inventory_item_id := p_INVENTORY_ITEM_ID;
      L_Qte_Line_Tbl(1).Quantity := p_QUANTITY;
      l_Qte_Line_Tbl(1).uom_code := 'EA';
      l_Qte_Line_Tbl(1).price_list_id := p_PRICELIST_ID;
        ASO_QUOTE_PUB.Create_Quote(
        p_api_version_number => 1.0,
        p_init_msg_list => FND_API.G_TRUE,
        p_control_rec => l_control_rec,
        p_qte_header_rec => l_qte_header_rec,
        P_Qte_Line_Tbl => l_Qte_Line_Tbl,
        P_hd_Payment_TBL => L_hd_Payment_TBL,
        P_hd_Shipment_Rec => l_hd_Shipment_Rec,
        P_hd_Tax_Detail_Tbl => l_hd_Tax_Detail_Tbl,
        x_Qte_Header_Rec => lx_qte_header_rec,
        X_Qte_Line_Tbl => lx_Qte_Line_Tbl,
        X_Qte_Line_Dtl_Tbl => lx_Qte_Line_Dtl_Tbl,
        X_hd_Price_Attributes_Tbl => lx_hd_Price_Attr_Tbl,
        X_hd_Payment_Tbl => lx_hd_Payment_Tbl,
        X_hd_Shipment_Rec => lx_hd_Shipment_Rec,
        X_hd_Freight_Charge_Tbl => lx_hd_Freight_Charge_Tbl,
        X_hd_Tax_Detail_Tbl => lx_hd_Tax_Detail_Tbl,
        x_Line_Attr_Ext_Tbl => lx_Line_Attr_Ext_Tbl,
        X_line_rltship_tbl => lx_line_rltship_tbl,
        X_Price_Adjustment_Tbl => lx_Price_Adjustment_Tbl,
        X_Price_Adj_Attr_Tbl => lx_Price_Adj_Attr_Tbl,
        X_Price_Adj_Rltship_Tbl => lx_Price_Adj_Rltship_Tbl,
        X_ln_Price_Attributes_Tbl => lx_ln_Price_Attr_Tbl,
        X_ln_Payment_Tbl => lx_ln_Payment_Tbl,
        X_ln_Shipment_Tbl => lx_ln_Shipment_Tbl,
        X_ln_Freight_Charge_Tbl => lx_ln_Freight_Charge_Tbl,
        X_ln_Tax_Detail_Tbl => lx_ln_Tax_Detail_Tbl,
        X_Return_Status => lx_Return_Status,
        X_Msg_Count => lx_Msg_Count,
        X_Msg_Data => lx_Msg_Data);
        fnd_msg_pub.count_AND_get(
        p_encoded => 'F',
        p_count => lx_msg_count,
        p_data => lx_msg_data);
        lx_msg_data := fnd_msg_pub.get(
        p_msg_index => 1,
        p_encoded => 'F');
      --  p_MSG := SUBSTR(lx_msg_data,1,50);
      --Condition for Pricing list ID
      IF lx_Return_Status = 'E' AND substr(lx_msg_data,1,240) LIKE '%IPL%price%list%' THEN
        ASO_QUOTE_PUB.Create_Quote(
        p_api_version_number => 1.0,
        p_init_msg_list => FND_API.G_TRUE,
        p_control_rec => v_control_rec,
        p_qte_header_rec => l_qte_header_rec,
        P_Qte_Line_Tbl => l_Qte_Line_Tbl,
        P_hd_Payment_TBL => L_hd_Payment_TBL,
        P_hd_Shipment_Rec => l_hd_Shipment_Rec,
        P_hd_Tax_Detail_Tbl => l_hd_Tax_Detail_Tbl,
        x_Qte_Header_Rec => lx_qte_header_rec,
        X_Qte_Line_Tbl => lx_Qte_Line_Tbl,
        X_Qte_Line_Dtl_Tbl => lx_Qte_Line_Dtl_Tbl,
        X_hd_Price_Attributes_Tbl => lx_hd_Price_Attr_Tbl,
        X_hd_Payment_Tbl => lx_hd_Payment_Tbl,
        X_hd_Shipment_Rec => lx_hd_Shipment_Rec,
        X_hd_Freight_Charge_Tbl => lx_hd_Freight_Charge_Tbl,
        X_hd_Tax_Detail_Tbl => lx_hd_Tax_Detail_Tbl,
        x_Line_Attr_Ext_Tbl => lx_Line_Attr_Ext_Tbl,
        X_line_rltship_tbl => lx_line_rltship_tbl,
        X_Price_Adjustment_Tbl => lx_Price_Adjustment_Tbl,
        X_Price_Adj_Attr_Tbl => lx_Price_Adj_Attr_Tbl,
        X_Price_Adj_Rltship_Tbl => lx_Price_Adj_Rltship_Tbl,
        X_ln_Price_Attributes_Tbl => lx_ln_Price_Attr_Tbl,
        X_ln_Payment_Tbl => lx_ln_Payment_Tbl,
        X_ln_Shipment_Tbl => lx_ln_Shipment_Tbl,
        X_ln_Freight_Charge_Tbl => lx_ln_Freight_Charge_Tbl,
        X_ln_Tax_Detail_Tbl => lx_ln_Tax_Detail_Tbl,
        X_Return_Status => lx_Return_Status,
        X_Msg_Count => lx_Msg_Count,
        X_Msg_Data => lx_Msg_Data);
        fnd_msg_pub.count_AND_get(
        p_encoded => 'F',
        p_count => lx_msg_count,
        p_data => lx_msg_data);
        END IF;
        p_MSG:=SUBSTR(lx_msg_data,1,50);
<<end_proc>>
null;
END CREATE_CART;
-- ADD_CART_LINE Procedure
PROCEDURE ADD_CART_LINE (
  --stANDard inputs
  p_SSO      IN VARCHAR2,
  p_ROLE      IN VARCHAR2,
  p_IACO_CODE    IN VARCHAR2,
  p_CUST_ID    IN V_CUST_ID_ARRAY,
  p_OU_ID      IN VARCHAR2,
  --Proc specific inputs
  p_INVENTORY_ITEM_ID  IN NUMBER,
  p_SLCT_CUST_ID    IN NUMBER,
  p_SUPPLIER_CODE IN VARCHAR2,
  p_QUANTITY IN NUMBER,
  p_PRICELIST_ID IN NUMBER,
  p_quoteHeaderId IN NUMBER,
  --Output Parameter
  p_MSG    OUT VARCHAR2
  )
  -- Sample Execution Code: execute ADD_CART_LINE ('502299003',NULL,NULL,NULL,60377,181867,400764,12345,20,8388,msg1);
AS
--Local variable declarations
  lc_last_update_date     DATE;
  lc_shipment_id          NUMBER;
  l_control_rec           aso_quote_pub.control_rec_type;
  v_control_rec           aso_quote_pub.control_rec_type;
  l_qte_header_rec        aso_quote_pub.qte_header_rec_type;
  l_qte_line_tbl          aso_quote_pub.qte_line_tbl_type;
  l_qte_line_rec          aso_quote_pub.qte_line_rec_type;
  l_qte_line_dtl_tbl      aso_quote_pub.qte_line_dtl_tbl_type;
  l_hd_price_attr_tbl     aso_quote_pub.price_attributes_tbl_type;
  l_hd_payment_tbl        aso_quote_pub.payment_tbl_type;
  l_hd_shipment_tbl       aso_quote_pub.shipment_tbl_type;
  l_hd_freight_charge_tbl aso_quote_pub.freight_charge_tbl_type;
  l_hd_tax_detail_tbl     aso_quote_pub.tax_detail_tbl_type;
  l_line_attr_ext_tbl     aso_quote_pub.line_attribs_ext_tbl_type;
  l_line_rltship_tbl      aso_quote_pub.line_rltship_tbl_type;
  l_price_adjustment_tbl  aso_quote_pub.price_adj_tbl_type;
  l_price_adj_attr_tbl    aso_quote_pub.price_adj_attr_tbl_type;
  l_price_adj_rltship_tbl aso_quote_pub.price_adj_rltship_tbl_type;
  l_ln_price_attr_tbl     aso_quote_pub.price_attributes_tbl_type;
  l_ln_payment_tbl        aso_quote_pub.payment_tbl_type;
  l_ln_shipment_tbl       aso_quote_pub.shipment_tbl_type;
  l_ln_freight_charge_tbl aso_quote_pub.freight_charge_tbl_type;
  l_ln_tax_detail_tbl     aso_quote_pub.tax_detail_tbl_type;
  l_hd_sales_credit_tbl   aso_quote_pub.sales_credit_tbl_type := aso_quote_pub.g_miss_sales_credit_tbl;
  l_ln_sales_credit_tbl   aso_quote_pub.sales_credit_tbl_type := aso_quote_pub.g_miss_sales_credit_tbl;
  lx_qte_header_rec         aso_quote_pub.qte_header_rec_type;
  lx_qte_line_tbl           aso_quote_pub.qte_line_tbl_type;
  lx_qte_line_dtl_tbl       aso_quote_pub.qte_line_dtl_tbl_type;
  lx_hd_price_attr_tbl      aso_quote_pub.price_attributes_tbl_type;
  lx_hd_payment_tbl         aso_quote_pub.payment_tbl_type;
  lx_hd_shipment_tbl        aso_quote_pub.shipment_tbl_type;
  lx_hd_freight_charge_tbl  aso_quote_pub.freight_charge_tbl_type;
  lx_hd_tax_detail_tbl      aso_quote_pub.tax_detail_tbl_type;
  lx_hd_attr_ext_tbl        aso_quote_pub.line_attribs_ext_tbl_type;
  lx_line_attr_ext_tbl      aso_quote_pub.line_attribs_ext_tbl_type;
  lx_line_rltship_tbl       aso_quote_pub.line_rltship_tbl_type;
  lx_price_adjustment_tbl   aso_quote_pub.price_adj_tbl_type;
  lx_price_adj_attr_tbl     aso_quote_pub.price_adj_attr_tbl_type;
  lx_price_adj_rltship_tbl  aso_quote_pub.price_adj_rltship_tbl_type;
  lx_hd_sales_credit_tbl    aso_quote_pub.sales_credit_tbl_type;
  lx_quote_party_tbl        aso_quote_pub.quote_party_tbl_type;
  lx_ln_sales_credit_tbl    aso_quote_pub.sales_credit_tbl_type;
  lx_ln_quote_party_tbl     aso_quote_pub.quote_party_tbl_type;
  lx_ln_price_attr_tbl      aso_quote_pub.price_attributes_tbl_type;
  lx_ln_payment_tbl         aso_quote_pub.payment_tbl_type;
  lx_ln_shipment_tbl        aso_quote_pub.shipment_tbl_type;
  lx_ln_freight_charge_tbl  aso_quote_pub.freight_charge_tbl_type;
  lx_ln_tax_detail_tbl      aso_quote_pub.tax_detail_tbl_type;
  lx_return_status          VARCHAR2(1);
  lx_msg_count              NUMBER;
  lx_msg_data               VARCHAR2(2000);
  l_payment_rec             aso_quote_pub.payment_rec_type;
  l_shipment_rec            aso_quote_pub.shipment_rec_type;
  l_tax_detail_rec          aso_quote_pub.tax_detail_rec_type;
  l_user_id                 NUMBER;
  l_resp_id                 VARCHAR2(50);
  l_app_id                  VARCHAR2(50);
  l_quote_fetched           VARCHAR2(5):='N';
  l_count                   NUMBER;
  l_custID_count            NUMBER;
  l_InvntItemID_count       NUMBER;
  --
  l_INVENTORY_ITEM_ID       NUMBER;
  l_SLCT_CUST_ID            NUMBER;
  l_SUPPLIER_CODE           NUMBER;
  l_QUANTITY                NUMBER;
  l_PRICELIST_ID            NUMBER;
  l_authorized              VARCHAR2(1);
  l_quoteId                 NUMBER;
  v_ou_id                      VARCHAR2(100)   := NULL; --Added By Manisha;31-AUG-18;Passport requirement to save the OU_ID separated by comma
  v_ou_id1                     VARCHAR2(100)   := NULL;
  v_ou_id2                     VARCHAR2(100)   := NULL;
  j_ou_id                      VARCHAr2(100)   := NULL;

   CURSOR c_quote_lud(c_qte_header_id NUMBER) IS
    SELECT  last_update_date
    FROM    aso_quote_headers_all
    WHERE   quote_header_id = c_qte_header_id;
BEGIN
 
-- Error HANDling
  IF p_INVENTORY_ITEM_ID IS NULL OR p_SLCT_CUST_ID IS NULL OR p_SUPPLIER_CODE IS NULL OR p_QUANTITY IS NULL THEN
     p_MSG:=GET_ERR_MSG(8029);
     goto end_proc;
  END IF;
  SELECT  COUNT(*) INTO l_custID_count
  FROM    HZ_CUST_ACCOUNTS
  WHERE   cust_account_id=p_SLCT_CUST_ID;
  SELECT  COUNT(*) INTO l_InvntItemID_count
  FROM    mtl_system_items_b
  WHERE   INVENTORY_ITEM_ID=p_INVENTORY_ITEM_ID;
  /*SELECT  COUNT(quote_header_id) into l_count
  FROM    aso_quote_headers_all aqh JOIN fnd_user fnd
            ON aqh.created_by=fnd.user_id
  WHERE   fnd.user_name= p_SSO
          AND aqh.CUST_ACCOUNT_ID= p_SLCT_CUST_ID
          AND aqh.attribute1=p_SUPPLIER_CODE
          AND aqh.org_id=p_OU_ID
          AND aqh.QUOTE_STATUS_ID in (10000,10010)--status validation
          AND QUOTE_EXPIRATION_DATE >SYSDATE;*/
  -- For SSO id
  IF p_SSO IS NULL THEN
     p_MSG:=GET_ERR_MSG(8024);
     goto end_proc;
  END IF;
  IF p_QUANTITY < 1 THEN
     P_MSG := GET_ERR_MSG(8166);
     goto end_proc;
  END IF;
  --For Operating unit ID
   IF P_OU_ID IS NULL THEN
      p_MSG:=GET_ERR_MSG(8025);
      goto end_proc;
   END IF;
  -- Error code for multiple records
 /* IF l_count > 1 THEN
     p_MSG:=GET_ERR_MSG(8016);
     goto end_proc;
  END IF;*/
  -- Error code for CUST_ID
    IF p_SLCT_CUST_ID IS NULL THEN
       p_MSG:=GET_ERR_MSG(8014);
       goto end_proc;
    ELSIF l_custID_count=0 THEN
       p_MSG:=GET_ERR_MSG(8015);
       goto end_proc;
    ELSE
      p_MSG:= NULL;
  END IF;
  -- Error code for Inventory Item ID
    IF p_INVENTORY_ITEM_ID IS NULL THEN
       p_MSG:=GET_ERR_MSG(8017);
       goto end_proc;
    ELSIF l_InvntItemID_count=0 THEN
       p_MSG:=GET_ERR_MSG(8018);
       goto end_proc;
    ELSE
      p_MSG:= NULL;
  END IF;
   --Error Code for Quantity
    IF p_QUANTITY IS NULL THEN
       p_MSG:=GET_ERR_MSG(8019);
       goto end_proc;
    END IF;
-- End of error hANDling

/******************************************************
Passport Requirement
Manisha K. 31-AUG Added below to fetch the OU_ID assigned to the customer  p_SLCT_CUST_ID
*******************************************************/
  v_ou_id := P_OU_ID;
  v_ou_id1 := REGEXP_SUBSTR(v_ou_id, '[^~]+', 1,1);
  v_ou_id2 :=  REGEXP_SUBSTR (v_ou_id, '[^~]+', 1, 2);

BEGIN

    SELECT distinct hcasa.org_id
    INTO j_ou_id
    FROM  HZ_CUST_ACCOUNTS hca, HZ_CUST_ACCT_SITES_ALL HCASA
    WHERE (hcasa.org_id = to_number(v_ou_id1) or  hcasa.org_id = to_number(v_ou_id2))
    AND  NVL(HCASA.STATUS, 'I') = 'A'
    AND NVL(hca.status, 'I') = 'A'
    AND hcasa.cust_account_id = hca.cust_account_id
    AND hca.cust_Account_id = p_SLCT_CUST_ID;

EXCEPTION

WHEN OTHERS THEN
P_MSG := 'Error while fetching the OU_ID: '||SQLCODE||SQLERRM;
goto end_proc;
END;

    IF j_ou_id IS NULL THEN
       p_MSG:=GET_ERR_MSG(8503);
       goto end_proc;
    END IF;

  --Fetching User ID
  SELECT user_id INTO l_user_id
  FROM fnd_user
  WHERE user_name=p_SSO;
  --Fetching Responsibility ID AND App ID
  BEGIN
  SELECT RESP.RESPONSIBILITY_ID,RESP.APPLICATION_ID
   INTO l_resp_id,l_app_id
  FROM  FND_RESPONSIBILITY_TL RESP,
        FND_LOOKUP_VALUES FLV ,
        HR_OPERATING_UNITS HOU
  WHERE HOU.NAME = FLV.MEANING
      AND RESP.RESPONSIBILITY_NAME = FLV.DESCRIPTION
      AND HOU.ORGANIZATION_ID = j_ou_id --P_OU_ID
      AND FLV.LOOKUP_TYPE = 'GEAE_MYGE_QUOTE_RESPONSIBILITY';
   EXCEPTION
    WHEN no_data_found THEN
       P_MSG := GET_ERR_MSG(8026);
       GOTO end_proc;
    END;
    --Apps initialize
        BEGIN
          Fnd_Global.Apps_Initialize(l_user_id,l_resp_id,l_app_id);
          mo_global.set_policy_context('S',j_ou_id);
        END;
  --Check If Quote exists
  /*SELECT  COUNT(quote_header_id) into l_count
  FROM    aso_quote_headers_all aqh JOIN fnd_user fnd
            ON aqh.created_by=fnd.user_id
  WHERE   fnd.user_name= p_SSO
          AND aqh.CUST_ACCOUNT_ID= p_SLCT_CUST_ID
          AND aqh.attribute1=p_SUPPLIER_CODE
          AND aqh.org_id=p_OU_ID
          AND aqh.QUOTE_STATUS_ID in (10000,10010)--status validation
          AND aqh.QUOTE_EXPIRATION_DATE >SYSDATE; --expiry date validation*/
IF p_quoteHeaderId IS NULL THEN
  SELECT  count(aqh.quote_header_id) into l_count
        FROM     aso_quote_headers_all aqh,
                 fnd_user fnd,
                 aso_payments asp
       WHERE aqh.created_by=fnd.user_id
          AND aqh.QUOTE_HEADER_ID = asp.QUOTE_HEADER_ID
          AND asp.cust_po_number IS NULL
          AND fnd.user_name= p_SSO
          AND aqh.CUST_ACCOUNT_ID= p_SLCT_CUST_ID
          AND aqh.attribute1=p_SUPPLIER_CODE
          AND aqh.org_id=j_ou_id --p_OU_ID
          AND aqh.QUOTE_STATUS_ID in (10000,10010)
          AND aqh.QUOTE_EXPIRATION_DATE >SYSDATE
          AND rownum=1;
   IF l_count = 1 THEN
     SELECT  max(aqh.quote_header_id) into l_quoteId
          FROM     aso_quote_headers_all aqh,
                   fnd_user fnd,
                   aso_payments asp
         WHERE aqh.created_by=fnd.user_id
            AND aqh.QUOTE_HEADER_ID = asp.QUOTE_HEADER_ID
            AND asp.cust_po_number IS NULL
            AND fnd.user_name= p_SSO
            AND aqh.CUST_ACCOUNT_ID= p_SLCT_CUST_ID
            AND aqh.attribute1=p_SUPPLIER_CODE
            AND aqh.org_id=j_ou_id --p_OU_ID
            AND aqh.QUOTE_STATUS_ID in (10000,10010)
            AND aqh.QUOTE_EXPIRATION_DATE >SYSDATE
            AND rownum=1;
  END IF;
ELSE
  l_quoteId := p_quoteHeaderId;
  l_count := 1;
END IF;
IF l_count =0 THEN
    l_authorized := 'N';
    FOR i IN 1..P_CUST_ID.COUNT LOOP
       IF P_CUST_ID(i) = p_SLCT_CUST_ID THEN
          l_authorized := 'Y';
       END IF;
    END LOOP;
    IF l_authorized = 'N' THEN
       p_MSG:=GET_ERR_MSG(8180);
       goto end_proc;
    END IF;
    --Calling CREATE_CART proc
    CREATE_CART(p_SSO,p_ROLE,p_IACO_CODE,j_OU_ID,p_INVENTORY_ITEM_ID,p_SLCT_CUST_ID,p_SUPPLIER_CODE,p_QUANTITY,p_PRICELIST_ID,p_MSG);
ELSE
    /*SELECT  max(quote_header_id) into l_qte_header_rec.quote_header_id
    FROM    aso_quote_headers_all aqh JOIN fnd_user fnd
              ON aqh.created_by=fnd.user_id
    WHERE   fnd.user_name= p_SSO
            AND aqh.CUST_ACCOUNT_ID= p_SLCT_CUST_ID
            AND aqh.attribute1=p_SUPPLIER_CODE
            AND aqh.org_id=p_OU_ID
            AND aqh.QUOTE_STATUS_ID in (10000,10010)--status validation
            AND aqh.QUOTE_EXPIRATION_DATE >SYSDATE --expiry date validation
            order by aqh.creation_date desc;*/
  l_qte_header_rec.quote_header_id := l_quoteId;
  -- Quote Header Rec
  l_qte_header_rec.CUST_ACCOUNT_ID :=p_SLCT_CUST_ID;
  l_qte_header_rec.ATTRIBUTE1 := p_supplier_code;
  -- Get the Last Updated Date
  OPEN c_quote_lud(l_qte_header_rec.quote_header_id);
  FETCH c_quote_lud INTO lc_last_update_date;
  CLOSE c_quote_lud;
  l_qte_header_rec.last_update_date := lc_last_update_date;
  -- Control Rec
  l_control_rec.pricing_request_type          := 'ASO';
  l_control_rec.header_pricing_event          := 'BATCH';
  l_control_rec.last_update_date              := SYSDATE;
  l_control_rec.price_mode                    := 'QUOTE_LINE';
  v_control_rec.pricing_request_type          := 'ASO';
  v_control_rec.line_pricing_event            := 'LINE';
  v_control_rec.last_update_date              := SYSDATE;
  v_control_rec.price_mode                    := 'QUOTE_LINE';
  -- Quote Line Rec
  l_qte_line_rec.quote_header_id  := l_qte_header_rec.quote_header_id;
  l_qte_line_rec.operation_code := 'CREATE';
  l_qte_line_rec.inventory_item_id := p_inventory_item_id;
  l_qte_line_rec.Quantity := p_quantity;
  l_qte_line_rec.uom_code := 'EA';
  l_qte_line_rec.price_list_id := p_pricelist_id;
  l_qte_line_rec.org_id := j_ou_id; --p_OU_ID;
  l_qte_line_tbl(1)                           := l_qte_line_rec;
  --Calling update_quote API
  aso_quote_pub.update_quote(p_api_version_number       =>  1.0
                            ,p_init_msg_list            => fnd_api.g_true
                            ,p_commit                   => fnd_api.g_true
                            ,p_control_rec              => l_control_rec
                            ,p_qte_header_rec           => l_qte_header_rec
                            ,p_qte_line_tbl             => l_qte_line_tbl
                            ,p_qte_line_dtl_tbl         => l_qte_line_dtl_tbl
                            ,p_hd_tax_detail_tbl        => l_hd_tax_detail_tbl
                            ,p_ln_payment_tbl           => l_ln_payment_tbl
                            ,p_hd_sales_credit_tbl      => l_hd_sales_credit_tbl
                            ,p_ln_sales_credit_tbl      => l_ln_sales_credit_tbl
                            ,p_ln_shipment_tbl          => l_ln_shipment_tbl
                            ,x_qte_header_rec           => lx_qte_header_rec
                            ,x_qte_line_tbl             => lx_qte_line_tbl
                            ,x_qte_line_dtl_tbl         => lx_qte_line_dtl_tbl
                            ,x_hd_price_attributes_tbl  => lx_hd_price_attr_tbl
                            ,x_hd_payment_tbl           => lx_hd_payment_tbl
                            ,x_hd_shipment_tbl          => lx_hd_shipment_tbl
                            ,x_hd_freight_charge_tbl    => lx_hd_freight_charge_tbl
                            ,x_hd_tax_detail_tbl        => lx_hd_tax_detail_tbl
                            ,x_hd_attr_ext_tbl          => lx_hd_attr_ext_tbl
                            ,x_hd_sales_credit_tbl      => lx_hd_sales_credit_tbl
                            ,x_hd_quote_party_tbl       => lx_quote_party_tbl
                            ,x_line_attr_ext_tbl        => lx_line_attr_ext_tbl
                            ,x_line_rltship_tbl         => lx_line_rltship_tbl
                            ,x_price_adjustment_tbl     => lx_price_adjustment_tbl
                            ,x_price_adj_attr_tbl       => lx_price_adj_attr_tbl
                            ,x_price_adj_rltship_tbl    => lx_price_adj_rltship_tbl
                            ,x_ln_price_attributes_tbl  => lx_ln_price_attr_tbl
                            ,x_ln_payment_tbl           => lx_ln_payment_tbl
                            ,x_ln_shipment_tbl          => lx_ln_shipment_tbl
                            ,x_ln_freight_charge_tbl    => lx_ln_freight_charge_tbl
                            ,x_ln_tax_detail_tbl        => lx_ln_tax_detail_tbl
                            ,x_ln_sales_credit_tbl      => lx_ln_sales_credit_tbl
                            ,x_ln_quote_party_tbl       => lx_ln_quote_party_tbl
                            ,x_return_status            => lx_return_status
                            ,x_msg_count                => lx_msg_count
                            ,x_msg_data                 => lx_msg_data);
  fnd_msg_pub.count_AND_get(p_encoded => 'F'
                           ,p_count   => lx_msg_count
                           ,p_data    => lx_msg_data);
  lx_msg_data := fnd_msg_pub.get(p_msg_index => 1
                                  ,p_encoded => 'F');
  --p_MSG:=SUBSTR(lx_msg_data,1,200);
   IF lx_Return_Status = 'E' AND lx_msg_data like 'IPL%price%list%%' THEN
       aso_quote_pub.update_quote(p_api_version_number       =>  1.0
                                 ,p_init_msg_list            => fnd_api.g_true
                                 ,p_commit                   => fnd_api.g_true
                                 ,p_control_rec              => v_control_rec
                                 ,p_qte_header_rec           => l_qte_header_rec
                                 ,p_qte_line_tbl             => l_qte_line_tbl
                                 ,p_qte_line_dtl_tbl         => l_qte_line_dtl_tbl
                                 ,p_hd_tax_detail_tbl        => l_hd_tax_detail_tbl
                                 ,p_ln_payment_tbl           => l_ln_payment_tbl
                                 ,p_hd_sales_credit_tbl      => l_hd_sales_credit_tbl
                                 ,p_ln_sales_credit_tbl      => l_ln_sales_credit_tbl
                                 ,p_ln_shipment_tbl          => l_ln_shipment_tbl
                                 ,x_qte_header_rec           => lx_qte_header_rec
                                 ,x_qte_line_tbl             => lx_qte_line_tbl
                                 ,x_qte_line_dtl_tbl         => lx_qte_line_dtl_tbl
                                 ,x_hd_price_attributes_tbl  => lx_hd_price_attr_tbl
                                 ,x_hd_payment_tbl           => lx_hd_payment_tbl
                                 ,x_hd_shipment_tbl          => lx_hd_shipment_tbl
                                 ,x_hd_freight_charge_tbl    => lx_hd_freight_charge_tbl
                                 ,x_hd_tax_detail_tbl        => lx_hd_tax_detail_tbl
                                 ,x_hd_attr_ext_tbl          => lx_hd_attr_ext_tbl
                                 ,x_hd_sales_credit_tbl      => lx_hd_sales_credit_tbl
                                 ,x_hd_quote_party_tbl       => lx_quote_party_tbl
                                 ,x_line_attr_ext_tbl        => lx_line_attr_ext_tbl
                                 ,x_line_rltship_tbl         => lx_line_rltship_tbl
                                 ,x_price_adjustment_tbl     => lx_price_adjustment_tbl
                                 ,x_price_adj_attr_tbl       => lx_price_adj_attr_tbl
                                 ,x_price_adj_rltship_tbl    => lx_price_adj_rltship_tbl
                                 ,x_ln_price_attributes_tbl  => lx_ln_price_attr_tbl
                                 ,x_ln_payment_tbl           => lx_ln_payment_tbl
                                 ,x_ln_shipment_tbl          => lx_ln_shipment_tbl
                                 ,x_ln_freight_charge_tbl    => lx_ln_freight_charge_tbl
                                 ,x_ln_tax_detail_tbl        => lx_ln_tax_detail_tbl
                                 ,x_ln_sales_credit_tbl      => lx_ln_sales_credit_tbl
                                 ,x_ln_quote_party_tbl       => lx_ln_quote_party_tbl
                                 ,x_return_status            => lx_return_status
                                 ,x_msg_count                => lx_msg_count
                                 ,x_msg_data                 => lx_msg_data);
       fnd_msg_pub.count_AND_get(p_encoded => 'F'
                                ,p_count   => lx_msg_count
                                ,p_data    => lx_msg_data);
       lx_msg_data := fnd_msg_pub.get(p_msg_index => 1
                                     ,p_encoded => 'F');
   END IF;
   p_MSG:=SUBSTR(lx_msg_data,1,50);
END IF;
<<end_proc>>
null;
END ADD_CART_LINE;
PROCEDURE BOOK_ORDER(P_USER_ID IN NUMBER,
                                          P_RESP_ID IN NUMBER,
                                          P_APPL_ID IN NUMBER,
                                          P_ORDER_HDR_ID IN NUMBER,
                                          P_STATUS OUT VARCHAR2,
                                          P_MSG OUT VARCHAR2) IS
l_api_version_number NUMBER := 1;
l_return_status        VARCHAR2(2000);
l_msg_count        NUMBER;
l_msg_data        VARCHAR2(32767);
-- IN Variables --
l_header_rec oe_order_pub.header_rec_type;
l_line_tbl oe_order_pub.line_tbl_type;
l_action_request_tbl oe_order_pub.Request_Tbl_Type;
-- OUT Variables --
l_header_rec_out oe_order_pub.header_rec_type;
l_header_val_rec_out oe_order_pub.header_val_rec_type;
l_header_adj_tbl_out oe_order_pub.header_adj_tbl_type;
l_header_adj_val_tbl_out oe_order_pub.header_adj_val_tbl_type;
l_header_price_att_tbl_out oe_order_pub.header_price_att_tbl_type;
l_header_adj_att_tbl_out oe_order_pub.header_adj_att_tbl_type;
l_header_adj_assoc_tbl_out oe_order_pub.header_adj_assoc_tbl_type;
l_header_scredit_tbl_out oe_order_pub.header_scredit_tbl_type;
l_header_scredit_val_tbl_out oe_order_pub.header_scredit_val_tbl_type;
l_line_tbl_out oe_order_pub.line_tbl_type;
l_line_val_tbl_out oe_order_pub.line_val_tbl_type;
l_line_adj_tbl_out oe_order_pub.line_adj_tbl_type;
l_line_adj_val_tbl_out oe_order_pub.line_adj_val_tbl_type;
l_line_price_att_tbl_out oe_order_pub.line_price_att_tbl_type;
l_line_adj_att_tbl_out oe_order_pub.line_adj_att_tbl_type;
l_line_adj_assoc_tbl_out oe_order_pub.line_adj_assoc_tbl_type;
l_line_scredit_tbl_out oe_order_pub.line_scredit_tbl_type;
l_line_scredit_val_tbl_out oe_order_pub.line_scredit_val_tbl_type;
l_lot_serial_tbl_out oe_order_pub.lot_serial_tbl_type;
l_lot_serial_val_tbl_out oe_order_pub.lot_serial_val_tbl_type;
l_action_request_tbl_out oe_order_pub.request_tbl_type;
l_msg_index NUMBER;
l_data VARCHAR2(32767);
l_loop_count NUMBER;
l_file_name varchar2(250); -- added by prasad on 30-May-16
l_org_id NUMBER;
b_return_status VARCHAR2(200);
b_msg_count NUMBER;
b_msg_data VARCHAR2(32767);
L_DATA1 VARCHAR2(32767):= null;
BEGIN
mo_global.init('ONT');
FND_GLOBAL.APPS_INITIALIZE(p_user_id,p_resp_id,P_APPL_ID);
oe_msg_pub.initialize;
l_org_id :=fnd_profile.value('org_id');
mo_global.set_policy_context('S',l_org_id);
--l_header_rec := oe_order_pub.G_MISS_HEADER_REC;
--l_header_rec.operation := OE_GLOBALS.G_OPR_UPDATE;
--l_header_rec.header_id  := P_ORDER_HDR_ID;
-- To BOOK the Sales Order
l_action_request_tbl(1) := oe_order_pub.G_MISS_REQUEST_REC;
l_action_request_tbl(1).request_type := oe_globals.g_book_order;
l_action_request_tbl(1).entity_code := oe_globals.g_entity_header;
l_action_request_tbl(1).entity_index := 1;
l_action_request_tbl(1).Entity_id := P_ORDER_HDR_ID;
Oe_debug_pub.debug_ON; --added by prasad on 13-may-16
oe_debug_pub.initialize;
oe_debug_pub.setdebuglevel(5);
Oe_Msg_Pub.initialize;
--l_header_rec.booked_flag            := 'Y';
--l_header_rec.flow_status_code       := 'BOOKED';
l_file_name := Oe_debug_pub.set_debug_mode('FILE'); --added by prasad on 30-may-16
Dbms_Output.put_line('Debug log is located at: ' || Oe_debug_pub.g_dir ||'/' ||Oe_debug_pub.g_file);  --added by prasad on 30-may-16
oe_order_pub.Process_Order( p_api_version_number => l_api_version_number,
p_header_rec => l_header_rec,
p_line_tbl => l_line_tbl,
p_action_request_tbl =>l_action_request_tbl ,
--OUT variables
x_header_rec => l_header_rec_out,
x_header_val_rec => l_header_val_rec_out,
x_header_adj_tbl => l_header_adj_tbl_out,
x_header_adj_val_tbl => l_header_adj_val_tbl_out,
x_header_price_att_tbl => l_header_price_att_tbl_out,
x_header_adj_att_tbl => l_header_adj_att_tbl_out,
x_header_adj_assoc_tbl => l_header_adj_assoc_tbl_out,
x_header_scredit_tbl => l_header_scredit_tbl_out,
x_header_scredit_val_tbl => l_header_scredit_val_tbl_out,
x_line_tbl => l_line_tbl_out,
x_line_val_tbl => l_line_val_tbl_out,
x_line_adj_tbl => l_line_adj_tbl_out,
x_line_adj_val_tbl => l_line_adj_val_tbl_out,
x_line_price_att_tbl => l_line_price_att_tbl_out,
x_line_adj_att_tbl => l_line_adj_att_tbl_out,
x_line_adj_assoc_tbl => l_line_adj_assoc_tbl_out,
x_line_scredit_tbl => l_line_scredit_tbl_out,
x_line_scredit_val_tbl => l_line_scredit_val_tbl_out,
x_lot_serial_tbl => l_lot_serial_tbl_out,
x_lot_serial_val_tbl => l_lot_serial_val_tbl_out,
x_action_request_tbl => l_action_request_tbl_out,
x_return_status => l_return_status,
x_msg_count => l_msg_count,
x_msg_data => l_msg_data);
/*
IF l_return_status = FND_API.G_RET_STS_SUCCESS THEN
   COMMIT;
ELSE
   ROLLBACK;
END IF;
*/
FOR I IN 1 .. L_MSG_COUNT LOOP
    L_DATA := OE_MSG_PUB.GET( P_MSG_INDEX => I, P_ENCODED => 'F');
    DBMS_OUTPUT.PUT_LINE('Book Order error '||I||': '||L_DATA);
    IF L_DATA LIKE '%Customer PO is required on a booked order%' THEN
       L_DATA1 := L_DATA1||substr(geae_myge_cart_pkg.get_err_msg(8162),6)||'|';
    ELSIF L_DATA LIKE '%Payment Term is required on a booked order%' THEN
       L_DATA1 := L_DATA1||substr(geae_myge_cart_pkg.get_err_msg(8163),6)||'|';
    ELSIF L_DATA LIKE '%Please specify the tax code%The line type requires tax calculation%' THEN
       L_DATA1 := L_DATA1||substr(geae_myge_cart_pkg.get_err_msg(8164),6)||'|';
    ELSIF L_DATA LIKE '%User-Defined Exception in Package MSC_ATP_PUB Procedure Call_ATP_No_Commit%' THEN
       L_DATA1 := L_DATA1||substr(geae_myge_cart_pkg.get_err_msg(8165),6)||'|';
    ELSE
       L_DATA1 := L_DATA1||SUBSTR(L_DATA,1,250)||'|';
    END IF;
END LOOP;
IF l_return_status <> 'S' THEN
   P_STATUS := l_return_status;
   P_MSG := 'We could not process the order#'||l_header_rec_out.cust_po_number||' because of '||l_data1||' Please Contact CAM';
ELSE
      P_STATUS := l_return_status;
      P_MSG := NULL;
END IF;
END BOOK_ORDER;
PROCEDURE PURCHASE_PO   (P_SSO         IN VARCHAR2,
                         P_ROLE        IN VARCHAR2,
                         P_IACO_CODE   IN VARCHAR2,
                         P_CUST_ID     IN V_CUST_ID_ARRAY,
                         P_OU_ID       IN VARCHAR2,
                         P_CART_HDR    IN V_CART_HDR_ARRAY, --MYJIRATEST-6277 Ravi S 03-MAR-2015
                         P_QT_HDR_STS  OUT V_QT_HDR_STS_DTL_ARRAY,
                         P_QT_LINE_STS OUT V_QT_LINE_STS_DTL_ARRAY,
                         P_MSG         OUT VARCHAR2)
 IS
  CURSOR C1(X_HEADER_ID NUMBER) IS
    SELECT QUOTE_HEADER_ID, QUOTE_LINE_ID
      FROM ASO_QUOTE_LINES_ALL
     WHERE QUOTE_HEADER_ID = X_HEADER_ID
    ORDER BY LINE_NUMBER;
  --MYJIRATEST-5080 Ravi S 30-JAN-2015
  CURSOR c_line_sts(X_QT_HEADER_ID NUMBER, X_ORD_HEADER_ID NUMBER) IS
     SELECT * FROM
        (SELECT aqla.line_number, aqla.QUOTE_HEADER_ID, aqla.QUOTE_LINE_ID, ool.line_id order_line_id
           FROM ASO_QUOTE_LINES_ALL aqla, ASO_SHIPMENTS asos, (SELECT * FROM oe_order_lines_all WHERE header_id = X_ORD_HEADER_ID) ool
          WHERE aqla.QUOTE_HEADER_ID = X_QT_HEADER_ID
            AND aqla.quote_header_id = asos.quote_header_id(+)
            AND aqla.quote_line_id = asos.quote_line_id(+)
            AND asos.shipment_id = ool.source_document_line_id(+)
            AND X_ORD_HEADER_ID IS NOT NULL
         UNION ALL
         SELECT aqla.line_number, aqla.QUOTE_HEADER_ID, aqla.QUOTE_LINE_ID, NULL order_line_id
           FROM ASO_QUOTE_LINES_ALL aqla
          WHERE aqla.QUOTE_HEADER_ID = X_QT_HEADER_ID
            AND X_ORD_HEADER_ID IS NULL)
     ORDER BY line_number;
  CURSOR C2(X_HEADER_ID NUMBER) IS
  SELECT AQH.ATTRIBUTE1,
       AQS.SHIP_TO_PARTY_SITE_ID,
       AQH.ORG_ID,
       to_char(to_date(AQS.REQUEST_DATE,'DD-MON-YY'),'RRRRMMDD') RQT_DT,
       AQS.SHIPMENT_PRIORITY_CODE,
       AQL.LINE_NUMBER
  FROM ASO_QUOTE_HEADERS_ALL AQH, ASO_SHIPMENTS AQS, ASO_QUOTE_LINES_ALL AQL
 WHERE AQH.QUOTE_HEADER_ID = AQS.QUOTE_HEADER_ID
   AND AQS.QUOTE_LINE_ID IS NOT NULL
   AND AQS.QUOTE_LINE_ID = AQL.QUOTE_LINE_ID
   AND AQH.QUOTE_HEADER_ID = AQL.QUOTE_HEADER_ID
   AND AQH.QUOTE_HEADER_ID = X_HEADER_ID
   ORDER BY AQL.LINE_NUMBER;
  L_QTE_HEADER_REC     ASO_QUOTE_PUB.QTE_HEADER_REC_TYPE;
  L_SUBMIT_CONTROL_REC ASO_QUOTE_PUB.SUBMIT_CONTROL_REC_TYPE;
  L_ORDER_HEADER_REC   ASO_QUOTE_PUB.ORDER_HEADER_REC_TYPE;
  LX_RETURN_STATUS     VARCHAR2(1);
  LX_MSG_COUNT         NUMBER;
  LX_MSG_DATA          VARCHAR2(32767);
  V_HEADER_ID          NUMBER(20) DEFAULT NULL;
  TYPE LINE_STS_MSG IS VARRAY(4000) OF VARCHAR2(4000);
  V_LINE_STS_MSG LINE_STS_MSG;
  V_LINE_HDR_COUNT     NUMBER;
  V_HDR_STS_MSG        VARCHAR2(32767) DEFAULT 'Failed|';
  V_LN_COUNT           NUMBER := 1;
  V_HD_CNT             NUMBER := 1;
  V_USER_ID  FND_USER.USER_ID%TYPE;
  V_RESP_ID  FND_RESPONSIBILITY_TL.RESPONSIBILITY_ID%TYPE;
  V_APP_ID   FND_RESPONSIBILITY_TL.APPLICATION_ID%TYPE;
  v_order_header_id oe_order_headers_all.header_id%type;
  v_sts  varchar2(5);
  v_msg_data varchar2(32767);
  LX_MSG_DATA1 VARCHAR2(32767):= null;
  V_SITE_USE_ID VARCHAR2(20);
  V_CUST_ACCOUNT_ID VARCHAR2(20);
  V_ACCOUNT_NUMBER VARCHAR2(20);
  P_REQ_DT_OUT VARCHAR2(20);
  V_ERR_RAISE NUMBER;
  V_SUCCESS VARCHAR2(1);
  L_ATTRIBUTE1 VARCHAR2(50);
  L_SHIP_TO_PARTY_SITE_ID NUMBER;
  L_ORG_ID NUMBER;
  L_RQT_DT VARCHAR2(50);
  L_SHIPMENT_PRIORITY_CODE VARCHAR2(50);
  l_authorized              VARCHAR2(1);
  --MYJIRATEST-6277 Ravi S 03-MAR-2015
  l_success                 BOOLEAN;
  l_chk1 number; --added by prasad on 17-may-16
  l_cnt number; --added by prasad on 17-may-16
  v_OU_ID  VARCHAR2(50); --Manisha K. added the variable
  --Added by Ratheesh Poshala on 19th August for US313415- Order Request date Logic Change -myGEAviation...
  v_ou_name  Varchar2(200);
  v_test Number; -- Ratheesh - To be Removed.
 
  
BEGIN
  --Error hANDling
  IF P_CART_HDR.COUNT = 0 THEN --MYJIRATEST-6277 Ravi S 03-MAR-2015
     P_MSG:=GET_ERR_MSG(8021);
  END IF;
  P_QT_HDR_STS  := V_QT_HDR_STS_DTL_ARRAY();
  P_QT_LINE_STS := V_QT_LINE_STS_DTL_ARRAY();
  -- SSO Validation --
 IF P_SSO IS NULL THEN
      P_MSG:=GET_ERR_MSG(8024);
      goto end_ppo;
  END IF;
 -----
  --Fetching User ID
  SELECT USER_ID INTO V_USER_ID
  FROM FND_USER
  WHERE USER_NAME=P_SSO;
  if P_OU_ID is null then
      P_MSG:=GET_ERR_MSG(8025);
      goto end_ou;
  end if;

--Manisha K; placed this code below, after finding OU_ID
  --FETCHING RESPONSIBILITY ID AND APPLICATION_ID
  --  BEGIN
--  SELECT RESP.RESPONSIBILITY_ID,RESP.APPLICATION_ID
--   INTO V_RESP_ID,V_APP_ID
--  FROM  FND_RESPONSIBILITY_TL RESP,
--        FND_LOOKUP_VALUES FLV ,
--        HR_OPERATING_UNITS HOU
--  WHERE HOU.NAME = FLV.MEANING
--      AND RESP.RESPONSIBILITY_NAME = FLV.DESCRIPTION
--      AND HOU.ORGANIZATION_ID = P_OU_ID
--      AND FLV.LOOKUP_TYPE = 'GEAE_MYGE_QUOTE_RESPONSIBILITY';
-- EXCEPTION
--  WHEN NO_DATA_FOUND THEN
--  P_MSG := GET_ERR_MSG(8025);
--  GOTO END_OU;
--  END;
--  mo_global.init('ONT');
--  FND_GLOBAL.APPS_INITIALIZE(v_user_id,v_resp_id,v_app_id);
--  mo_global.set_policy_context('S',P_OU_ID);
  FOR I IN 1 .. P_CART_HDR.COUNT LOOP --MYJIRATEST-6277 Ravi S 03-MAR-2015
    V_HDR_STS_MSG := 'Failed|';
    V_SUCCESS := 'N';
    V_ERR_RAISE := 0;
    V_HEADER_ID := P_CART_HDR(I).QUOTE_HDR_ID; --MYJIRATEST-6277 Ravi S 03-MAR-2015
    V_LINE_STS_MSG := LINE_STS_MSG();

/*******************************************
******************************************/
IF P_OU_ID like '%~%' THEN
      BEGIN
      SELECT org_Id
      INTO v_OU_ID FROM aso_quote_headers_all
      WHERE QUOTE_HEADER_ID =V_HEADER_ID ;
      EXCEPTION
      WHEN OTHERS THEN
      P_MSG := 'Error while fetching the OU_ID: '||SQLCODE||SQLERRM;
      goto END_OU;
      END;

    IF v_OU_ID IS NULL THEN
     p_MSG:=GET_ERR_MSG(8503);
     goto END_OU;
    END IF;

  ELSE
    v_OU_ID := P_OU_ID;
  END IF;
  ---Manisha K;adding the code here to find the responsiblity
   BEGIN
  SELECT RESP.RESPONSIBILITY_ID,RESP.APPLICATION_ID
   INTO V_RESP_ID,V_APP_ID
  FROM  FND_RESPONSIBILITY_TL RESP,
        FND_LOOKUP_VALUES FLV ,
        HR_OPERATING_UNITS HOU
  WHERE HOU.NAME = FLV.MEANING
      AND RESP.RESPONSIBILITY_NAME = FLV.DESCRIPTION
      AND HOU.ORGANIZATION_ID = v_OU_ID --P_OU_ID
      AND FLV.LOOKUP_TYPE = 'GEAE_MYGE_QUOTE_RESPONSIBILITY';
 EXCEPTION
  WHEN NO_DATA_FOUND THEN
  P_MSG := GET_ERR_MSG(8025);
  GOTO END_OU;
  END;
  mo_global.init('ONT');
  FND_GLOBAL.APPS_INITIALIZE(v_user_id,v_resp_id,v_app_id);
  mo_global.set_policy_context('S',v_OU_ID);
    FOR C_REC IN C1(V_HEADER_ID) LOOP
       V_LINE_STS_MSG.EXTEND;
    END LOOP;
    --Ravi S 19-SEP-2014 MYJIRATEST-3513 Authorization logic
    l_authorized := 'N';
    BEGIN
       SELECT 'Y'
         INTO l_authorized
         FROM aso_quote_headers_all aqh
        WHERE aqh.created_by = V_USER_ID
          AND aqh.org_id = v_OU_ID  --P_OU_ID
          AND aqh.quote_header_id = V_HEADER_ID;
    EXCEPTION
       WHEN NO_DATA_FOUND THEN
          V_ERR_RAISE := 1;
          V_HDR_STS_MSG := V_HDR_STS_MSG||GET_ERR_MSG(8180)||'|';
    END;
    BEGIN
       SELECT AQH.ATTRIBUTE1,
              AQS.SHIP_TO_PARTY_SITE_ID,
              AQH.ORG_ID,
              to_char(to_date(AQS.REQUEST_DATE,'DD-MON-YY'),'RRRRMMDD') RQT_DT,
              AQS.SHIPMENT_PRIORITY_CODE
         INTO L_ATTRIBUTE1, L_SHIP_TO_PARTY_SITE_ID, L_ORG_ID, L_RQT_DT, L_SHIPMENT_PRIORITY_CODE
         FROM ASO_QUOTE_HEADERS_ALL AQH, ASO_SHIPMENTS AQS
        WHERE AQH.QUOTE_HEADER_ID = AQS.QUOTE_HEADER_ID
          AND AQS.QUOTE_LINE_ID IS NULL
          AND AQH.QUOTE_HEADER_ID = V_HEADER_ID;
		  
       SELECT HCS.SITE_USE_ID, HCA.CUST_ACCOUNT_ID, HC.ACCOUNT_NUMBER
         into V_SITE_USE_ID,V_CUST_ACCOUNT_ID,V_ACCOUNT_NUMBER
         FROM HZ_CUST_ACCT_SITES_ALL HCA,
              HZ_CUST_SITE_USES_ALL  HCS,
              HZ_CUST_ACCOUNTS       HC
        WHERE HCA.PARTY_SITE_ID = L_SHIP_TO_PARTY_SITE_ID
          AND HCA.ORG_ID = L_ORG_ID
          AND HCA.CUST_ACCT_SITE_ID = HCS.CUST_ACCT_SITE_ID
          AND HCA.CUST_ACCOUNT_ID = HC.CUST_ACCOUNT_ID
          AND HCS.STATUS='A' --MYJIRATEST-7638 Ankita.S 04-May-2015
          AND HCS.SITE_USE_CODE = 'SHIP_TO'; --MYJIRATEST-3816 Ravi S 20-Oct-2014
    EXCEPTION
       WHEN OTHERS THEN
          V_ERR_RAISE := 1;
          V_HDR_STS_MSG := V_HDR_STS_MSG||GET_ERR_MSG(8168)||'|';
    END;
--Added by Ratheesh Poshala on 19th August for US313415- Order Request date Logic Change -myGEAviation...
	BEGIN
	  v_ou_name := Null;
	  SELECT name   INTO 
	        v_ou_name
	  FROM apps.hr_operating_units WHERE organization_id = L_ORG_ID;
	EXCEPTION
	WHEN OTHERS THEN
	  v_ou_name := Null;
	END;
	
	--Re-initialize the package variable.
  	geae_ont_sales_order_pkg.gv_req_date_source:= NULL;
	
	IF (v_ou_name = 'GEAE - Commercial Spares Organization') THEN
	-- Based on the OU Name, assign the value for below variable.
	    	geae_ont_sales_order_pkg.gv_req_date_source:='myGEAviation';
	END IF;
	
	/* 
	ELSIF (v_ou_name = 'GEAE-CFM INC Commercial Spares Organization') THEN 
	  geae_ont_sales_order_pkg.gv_req_date_source:='myCFM';
	ELSIF (v_ou_name = 'GEAE-GHAE Commercial Spares Organization') THEN 
	  geae_ont_sales_order_pkg.gv_req_date_source:='myHonda';
    END IF;	
	*/
	 
	--Added by Ratheesh for Testing - To be Removed. 
	BEGIN
	    INSERT INTO GEAE_WEB_PORTAL_TEST2 VALUES ('Purchase_PO1',' C1 Cursor - v_OU_ID : '||v_OU_ID || ' - v_ou_name : '||v_ou_name, 'Pkg Var: '||geae_ont_sales_order_pkg.gv_req_date_source,L_ORG_ID,sysdate);	
        COMMIT;
	EXCEPTION 
	WHEN OTHERS THEN
	  DBMS_OUTPUT.PUT_LINE('Purchase_PO1 :- '||SQLERRM);
	END; 
--End of Changes --by Ratheesh Poshala on 19th August for US313415- Order Request date Logic Change -myGEAviation...
	
    BEGIN
       GEAE_ONT_SALES_ORDER_PKG.GET_REQUEST_DATE(P_SHIP_PRIORITY    => L_SHIPMENT_PRIORITY_CODE,
                                                 P_REQUEST_DATE_IN  => L_RQT_DT,
                                                 P_REQUEST_DATE_OUT => P_REQ_DT_OUT,
                                                 P_ACCOUNT_NUMBER   => V_ACCOUNT_NUMBER,
                                                 P_ORG_ID           => L_ORG_ID,
                                                 P_SHIP_TO_ORG_ID   => V_SITE_USE_ID,
                                                 P_PRICELIST_ID     => NULL,
                                                 P_PART_NUMBER      => NULL,
                                                 P_SUPPLIER_CODE    => L_ATTRIBUTE1);
       IF TO_CHAR(TO_DATE(P_REQ_DT_OUT,'YYYY-MM-DD'),'RRRRMMDD') <> L_RQT_DT THEN
          V_ERR_RAISE := 1;
          V_HDR_STS_MSG := V_HDR_STS_MSG||SUBSTR(GET_ERR_MSG(8167),6)||' '||P_REQ_DT_OUT||'|';
       END IF;
	   
	 	--Added by Ratheesh for Testing - To be Removed. 
		BEGIN
		v_test:=0;
		select GEAE_MYGE_CART_PKG.WP_get_SDND_reqdate_leadtime('DLA','CWC') into v_test from dual;
		INSERT INTO GEAE_WEB_PORTAL_TEST2 VALUES ('Purchase_PO2 ', 'C1 Cursor - LeadTime Value from Function from UI : '||v_test , null,L_ORG_ID,sysdate);	
	    INSERT INTO GEAE_WEB_PORTAL_TEST2 VALUES ('Purchase_PO3 ',' C1 Cursor - DB Request Date Out value : '||P_REQ_DT_OUT,' UI Request Date Input Value:  ' ||L_RQT_DT , L_ORG_ID,sysdate);	
        COMMIT;
	EXCEPTION 
	WHEN OTHERS THEN
	   DBMS_OUTPUT.PUT_LINE('Purchase_PO2 - PO3:- '||SQLERRM);
	END;	
	---End Ratheesh
    EXCEPTION
       WHEN OTHERS THEN
          V_ERR_RAISE := 1;
          V_HDR_STS_MSG := V_HDR_STS_MSG||GET_ERR_MSG(8170)||'|';
    END;
    V_LINE_HDR_COUNT := 1;
    FOR C2_REC IN C2(V_HEADER_ID) LOOP
       BEGIN
          SELECT HCS.SITE_USE_ID, HCA.CUST_ACCOUNT_ID, HC.ACCOUNT_NUMBER
            into V_SITE_USE_ID,V_CUST_ACCOUNT_ID,V_ACCOUNT_NUMBER
            FROM HZ_CUST_ACCT_SITES_ALL HCA,
                 HZ_CUST_SITE_USES_ALL  HCS,
                 HZ_CUST_ACCOUNTS       HC
           WHERE HCA.PARTY_SITE_ID = c2_rec.SHIP_TO_PARTY_SITE_ID
             AND HCA.ORG_ID = c2_rec.ORG_ID
             AND HCA.CUST_ACCT_SITE_ID = HCS.CUST_ACCT_SITE_ID
             AND HCA.CUST_ACCOUNT_ID = HC.CUST_ACCOUNT_ID
             AND HCS.STATUS='A' --MYJIRATEST-7638 Ankita.S 04-May-2015
             AND HCS.SITE_USE_CODE = 'SHIP_TO'; --MYJIRATEST-3816 Ravi S 20-Oct-2014
       EXCEPTION
          WHEN OTHERS THEN
             V_ERR_RAISE := 1;
             V_LINE_STS_MSG(V_LINE_HDR_COUNT) := V_LINE_STS_MSG(V_LINE_HDR_COUNT)||GET_ERR_MSG(8168)||'|';
       END;
	   
	 	
       BEGIN
          GEAE_ONT_SALES_ORDER_PKG.GET_REQUEST_DATE(P_SHIP_PRIORITY    => C2_REC.SHIPMENT_PRIORITY_CODE,
                                            P_REQUEST_DATE_IN  => C2_REC.RQT_DT,
                                            P_REQUEST_DATE_OUT => P_REQ_DT_OUT,
                                            P_ACCOUNT_NUMBER   => V_ACCOUNT_NUMBER,
                                            P_ORG_ID           => C2_REC.ORG_ID,
                                            P_SHIP_TO_ORG_ID   => V_SITE_USE_ID,
                                            P_PRICELIST_ID     => NULL,
                                            P_PART_NUMBER      => NULL,
                                            P_SUPPLIER_CODE    => C2_REC.ATTRIBUTE1);
          IF TO_CHAR(TO_DATE(P_REQ_DT_OUT,'YYYY-MM-DD'),'RRRRMMDD') <> C2_REC.RQT_DT THEN
             V_ERR_RAISE := 1;
             V_LINE_STS_MSG(V_LINE_HDR_COUNT) := V_LINE_STS_MSG(V_LINE_HDR_COUNT)||SUBSTR(GET_ERR_MSG(8167),6)||' '||P_REQ_DT_OUT||'|';
          END IF;


	 	--Added by Ratheesh for Testing - To be Removed. 
	   BEGIN
	    INSERT INTO GEAE_WEB_PORTAL_TEST2 VALUES ('Purchase_PO4 ' , 'C2 Cursor:  DB-Request Date Out value : '||P_REQ_DT_OUT,' UI-Request Date Input Value:  ' ||L_RQT_DT , L_ORG_ID,sysdate);	
        COMMIT;
	EXCEPTION 
	WHEN OTHERS THEN
	  DBMS_OUTPUT.PUT_LINE('Purchase_PO2 - PO4:- '||SQLERRM);
	END;	
	---End Ratheesh

       EXCEPTION
          WHEN OTHERS THEN
             V_ERR_RAISE := 1;
             V_LINE_STS_MSG(V_LINE_HDR_COUNT) := V_LINE_STS_MSG(V_LINE_HDR_COUNT)||GET_ERR_MSG(8170)||'|';
       END;
       V_LINE_HDR_COUNT := V_LINE_HDR_COUNT + 1;
    END LOOP;
    L_QTE_HEADER_REC.QUOTE_HEADER_ID     := V_HEADER_ID;
    L_SUBMIT_CONTROL_REC.BOOK_FLAG       := 'Y';
    L_SUBMIT_CONTROL_REC.CALCULATE_PRICE := 'Y';
    --MYJIRATEST-6277 Ravi S 03-MAR-2015
    IF UPPER(P_CART_HDR(I).TYPE) = 'DRAFT' THEN
       l_success := fnd_profile.save_user('ONT_DEFAULT_TRANSACTION_PHASE', 'N');
    ELSE
       l_success := fnd_profile.save_user('ONT_DEFAULT_TRANSACTION_PHASE', 'F');
    END IF;
    IF NOT l_success THEN
       V_ERR_RAISE := 1;
       V_HDR_STS_MSG := V_HDR_STS_MSG||GET_ERR_MSG(8091)||'|';
    END IF;
    IF V_ERR_RAISE = 1 THEN
       GOTO END_HDR_LOOP;
    END IF;
    ASO_QUOTE_PUB.SUBMIT_QUOTE(P_API_VERSION_NUMBER => 1.0,
                               P_INIT_MSG_LIST      => FND_API.G_TRUE,
                               P_COMMIT             => FND_API.G_FALSE,
                               P_CONTROL_REC        => L_SUBMIT_CONTROL_REC,
                               P_QTE_HEADER_REC     => L_QTE_HEADER_REC,
                               X_ORDER_HEADER_REC   => L_ORDER_HEADER_REC,
                               X_RETURN_STATUS      => LX_RETURN_STATUS,
                               X_MSG_COUNT          => LX_MSG_COUNT,
                               X_MSG_DATA           => LX_MSG_DATA);
    FND_MSG_PUB.COUNT_AND_GET(P_ENCODED => 'F',
                              P_COUNT   => LX_MSG_COUNT,
                              P_DATA    => LX_MSG_DATA);
    IF LX_RETURN_STATUS = 'S'
    THEN
      V_HDR_STS_MSG  := NULL;
      begin
       UPDATE_QUOTE_STS (  P_USER_ID => v_user_id,
                           P_RESP_ID => v_resp_id,
                           P_APPL_ID => v_app_id,
                           P_QT_HDR_ID => V_HEADER_ID,
                           P_STATUS => v_sts,
                           P_MSG => v_msg_data);
      exception
        when others then
          null;
      end;
    -- added by prasad on 17-may-16
                 l_chk1 := 0 ;
         l_cnt  := 0 ;
    BEGIN
      WHILE ( l_chk1 = 0)
      LOOP
        EXIT
      WHEN l_cnt >= 30;
        SELECT count(HEADER_ID)  into l_chk1
                                                          FROM OE_ORDER_HEADERS_ALL
       WHERE ORDER_NUMBER = L_ORDER_HEADER_REC.ORDER_NUMBER;
        l_cnt                          := l_cnt + 1;
        dbms_lock.sleep(1);
       END LOOP;
       end;
    -- added by prasad on 17-may-16
     SELECT HEADER_ID
        INTO V_ORDER_HEADER_ID
        FROM OE_ORDER_HEADERS_ALL
       WHERE ORDER_NUMBER = L_ORDER_HEADER_REC.ORDER_NUMBER;
      V_SUCCESS := 'Y';
      --MYJIRATEST-6277 Ravi S 03-MAR-2015
      IF UPPER(P_CART_HDR(I).TYPE) = 'DRAFT' THEN
         NULL;
      ELSE
         BOOK_ORDER(  P_USER_ID => v_user_id,
                      P_RESP_ID => v_resp_id,
                      P_APPL_ID => v_app_id,
                      P_ORDER_HDR_ID => v_order_header_id,
                      P_STATUS => v_sts,
                      P_MSG => v_msg_data);
         V_HDR_STS_MSG  := v_msg_data;
      END IF;
      P_MSG := null;
     else
     V_SUCCESS := 'N';
     V_ORDER_HEADER_ID := NULL;
    FOR K IN 1 .. LX_MSG_COUNT LOOP
      LX_MSG_DATA := FND_MSG_PUB.GET(P_MSG_INDEX => K, P_ENCODED => 'F');
      IF LX_MSG_DATA LIKE 'Error in Line%' THEN
         V_LINE_HDR_COUNT := TO_NUMBER(SUBSTR(LX_MSG_DATA,16,INSTR(LX_MSG_DATA,'.')-16));
         IF LX_MSG_DATA LIKE '%The item specified is invalid or does not exist in the warehouse you specified. Please enter a valid item-warehouse combination.%' THEN
            IF NVL(V_LINE_STS_MSG(V_LINE_HDR_COUNT),'#') NOT LIKE '%8139%' THEN
               V_LINE_STS_MSG(V_LINE_HDR_COUNT) := V_LINE_STS_MSG(V_LINE_HDR_COUNT)||GET_ERR_MSG(8139)||'|';
            END IF;
         ELSIF LX_MSG_DATA LIKE '%Invalid unit of measure for this item.%' THEN
            IF NVL(V_LINE_STS_MSG(V_LINE_HDR_COUNT),'#') NOT LIKE '%8140%' THEN
               V_LINE_STS_MSG(V_LINE_HDR_COUNT) := V_LINE_STS_MSG(V_LINE_HDR_COUNT)||GET_ERR_MSG(8140)||'|';
            END IF;
         ELSIF LX_MSG_DATA LIKE '%The desired date % falls outside of the project effective dates.%' THEN
            IF NVL(V_LINE_STS_MSG(V_LINE_HDR_COUNT),'#') NOT LIKE '%8159%' THEN
               V_LINE_STS_MSG(V_LINE_HDR_COUNT) := V_LINE_STS_MSG(V_LINE_HDR_COUNT)||GET_ERR_MSG(8159)||'|';
            END IF;
         ELSIF LX_MSG_DATA LIKE '%Quantity should be multiple of UPQ%' OR LX_MSG_DATA LIKE '%Ordered Quantity is not a multiple of Unit Pack Quantity%' THEN
            IF NVL(V_LINE_STS_MSG(V_LINE_HDR_COUNT),'#') NOT LIKE '%8142%' THEN
               V_LINE_STS_MSG(V_LINE_HDR_COUNT) := V_LINE_STS_MSG(V_LINE_HDR_COUNT)||GET_ERR_MSG(8142)||'|';
            END IF;
         ELSIF LX_MSG_DATA LIKE '%PTO KIT quantity should be 1%' THEN
            IF NVL(V_LINE_STS_MSG(V_LINE_HDR_COUNT),'#') NOT LIKE '%8143%' THEN
               V_LINE_STS_MSG(V_LINE_HDR_COUNT) := V_LINE_STS_MSG(V_LINE_HDR_COUNT)||GET_ERR_MSG(8143)||'|';
            END IF;
         ELSIF LX_MSG_DATA LIKE '%SPR price list not present , order cannot be booked%' THEN
            IF NVL(V_LINE_STS_MSG(V_LINE_HDR_COUNT),'#') NOT LIKE '%8144%' THEN
               V_LINE_STS_MSG(V_LINE_HDR_COUNT) := V_LINE_STS_MSG(V_LINE_HDR_COUNT)||GET_ERR_MSG(8144)||'|';
            END IF;
         ELSIF LX_MSG_DATA LIKE '%Kit price check failed.  Please check the kit header AND component list prices%' THEN
            IF NVL(V_LINE_STS_MSG(V_LINE_HDR_COUNT),'#') NOT LIKE '%8145%' THEN
               V_LINE_STS_MSG(V_LINE_HDR_COUNT) := V_LINE_STS_MSG(V_LINE_HDR_COUNT)||GET_ERR_MSG(8145)||'|';
            END IF;
         ELSIF LX_MSG_DATA LIKE '%ADN Validation Failed%' THEN
            IF NVL(V_LINE_STS_MSG(V_LINE_HDR_COUNT),'#') NOT LIKE '%8146%' THEN
               V_LINE_STS_MSG(V_LINE_HDR_COUNT) := V_LINE_STS_MSG(V_LINE_HDR_COUNT)||GET_ERR_MSG(8146)||'|';
            END IF;
          ELSIF LX_MSG_DATA LIKE '%No Project Code Please Check Customer set Up%' THEN
            IF NVL(V_LINE_STS_MSG(V_LINE_HDR_COUNT),'#') NOT LIKE '%8147%' THEN
               V_LINE_STS_MSG(V_LINE_HDR_COUNT) := V_LINE_STS_MSG(V_LINE_HDR_COUNT)||GET_ERR_MSG(8147)||'|';
            END IF;
         ELSIF LX_MSG_DATA LIKE '%Warehouse on this order line is invalid for this Operating Unit.%' THEN
            IF NVL(V_LINE_STS_MSG(V_LINE_HDR_COUNT),'#') NOT LIKE '%8148%' THEN
               V_LINE_STS_MSG(V_LINE_HDR_COUNT) := V_LINE_STS_MSG(V_LINE_HDR_COUNT)||GET_ERR_MSG(8148)||'|';
            END IF;
         ELSIF LX_MSG_DATA LIKE '%Part Value Code is not assigned to Item%' THEN
            IF NVL(V_LINE_STS_MSG(V_LINE_HDR_COUNT),'#') NOT LIKE '%8149%' THEN
               V_LINE_STS_MSG(V_LINE_HDR_COUNT) := V_LINE_STS_MSG(V_LINE_HDR_COUNT)||GET_ERR_MSG(8149)||'|';
            END IF;
         ELSIF LX_MSG_DATA LIKE '%Same planning priority value cannot be assigned for a given part within a Warehouse%' THEN
            IF NVL(V_LINE_STS_MSG(V_LINE_HDR_COUNT),'#') NOT LIKE '%8150%' THEN
               V_LINE_STS_MSG(V_LINE_HDR_COUNT) := V_LINE_STS_MSG(V_LINE_HDR_COUNT)||GET_ERR_MSG(8150)||'|';
            END IF;
         ELSIF LX_MSG_DATA LIKE '%Ship To AND Deliver To Mapping is not valid combination%' THEN
            IF NVL(V_LINE_STS_MSG(V_LINE_HDR_COUNT),'#') NOT LIKE '%8151%' THEN
               V_LINE_STS_MSG(V_LINE_HDR_COUNT) := V_LINE_STS_MSG(V_LINE_HDR_COUNT)||GET_ERR_MSG(8151)||'|';
            END IF;
          ELSIF LX_MSG_DATA LIKE '%AOG Validation Failed Item Request Cannot Be Later Than SYSDATE%' THEN
            IF NVL(V_LINE_STS_MSG(V_LINE_HDR_COUNT),'#') NOT LIKE '%8152%' THEN
               V_LINE_STS_MSG(V_LINE_HDR_COUNT) := V_LINE_STS_MSG(V_LINE_HDR_COUNT)||GET_ERR_MSG(8152)||'|';
            END IF;
          ELSIF LX_MSG_DATA LIKE '%Ordered Quantity is not a multiple of Unit Pack Quantity%' THEN
            IF NVL(V_LINE_STS_MSG(V_LINE_HDR_COUNT),'#') NOT LIKE '%8153%' THEN
               V_LINE_STS_MSG(V_LINE_HDR_COUNT) := V_LINE_STS_MSG(V_LINE_HDR_COUNT)||GET_ERR_MSG(8153)||'|';
            END IF;
           ELSIF LX_MSG_DATA LIKE '%Configuration Validation fail for this item%' THEN
            IF NVL(V_LINE_STS_MSG(V_LINE_HDR_COUNT),'#') NOT LIKE '%8154%' THEN
               V_LINE_STS_MSG(V_LINE_HDR_COUNT) := V_LINE_STS_MSG(V_LINE_HDR_COUNT)||GET_ERR_MSG(8154)||'|';
            END IF;
           ELSIF LX_MSG_DATA LIKE '%Configuration Validation - Model Applicability Error%' THEN
            IF NVL(V_LINE_STS_MSG(V_LINE_HDR_COUNT),'#') NOT LIKE '%8154%' THEN
               V_LINE_STS_MSG(V_LINE_HDR_COUNT) := V_LINE_STS_MSG(V_LINE_HDR_COUNT)||GET_ERR_MSG(8154)||'|';
            end if;
           ELSIF LX_MSG_DATA like '%Please note%you cannot place%order with an invalid configuration%' then --MYJIRATEST-3293 AND MYJIRATEST-2706 Ravi S 03-SEP-2014
            if NVL(V_LINE_STS_MSG(V_LINE_HDR_COUNT),'#') not like '%8169%' then
               V_LINE_STS_MSG(V_LINE_HDR_COUNT) := V_LINE_STS_MSG(V_LINE_HDR_COUNT)||GET_ERR_MSG(8169)||'|';
            END IF;
    ELSE
            V_LINE_STS_MSG(V_LINE_HDR_COUNT) := V_LINE_STS_MSG(V_LINE_HDR_COUNT)||'8300:'||SUBSTR(LX_MSG_DATA,1,100)||'|';
         END IF;
      ELSIF LX_MSG_DATA LIKE '%Last_Update_Date%must%exist%missing column%' THEN
         IF NVL(LX_MSG_DATA1,'#') NOT LIKE '%8155%' THEN
            LX_MSG_DATA1 := LX_MSG_DATA1||GET_ERR_MSG(8155)||'|';
         END IF;
      ELSIF LX_MSG_DATA LIKE '%This quote has already been ordered%' THEN
         IF NVL(LX_MSG_DATA1,'#') NOT LIKE '%8156%' THEN
            LX_MSG_DATA1 := LX_MSG_DATA1||GET_ERR_MSG(8156)||'|';
         END IF;
      ELSIF LX_MSG_DATA LIKE '%There is an error in order submission%' THEN
          null;
      ELSIF LX_MSG_DATA LIKE '%GTA%' THEN
         IF NVL(LX_MSG_DATA1,'#') NOT LIKE '%8157%' THEN
            LX_MSG_DATA1 := LX_MSG_DATA1||GET_ERR_MSG(8157)||'|';
         END IF;
      ELSIF LX_MSG_DATA LIKE '%Error messages from Order Management%' THEN
          null;
      ELSIF LX_MSG_DATA LIKE '%Ship To AND Deliver To Mapping is not valid combination%' THEN
         IF NVL(LX_MSG_DATA1,'#') NOT LIKE '%8151%' THEN
            LX_MSG_DATA1 := LX_MSG_DATA1||GET_ERR_MSG(8151)||'|';
         END IF;
      ELSIF LX_MSG_DATA LIKE '%Validation failed for the field - Shipment Priority%' THEN
         IF NVL(LX_MSG_DATA1,'#') NOT LIKE '%8158%' THEN
            LX_MSG_DATA1 := LX_MSG_DATA1||GET_ERR_MSG(8158)||'|';
         END IF;
      ELSIF LX_MSG_DATA LIKE '%The desired date%falls outside of the project effective dates.%' THEN
         IF NVL(LX_MSG_DATA1,'#') NOT LIKE '%8159%' THEN
            LX_MSG_DATA1 := LX_MSG_DATA1||GET_ERR_MSG(8159)||'|';
         END IF;
      ELSIF LX_MSG_DATA LIKE '%Review Required for this Order. Check the Order Lines%' THEN
         IF NVL(LX_MSG_DATA1,'#') NOT LIKE '%8160%' THEN
            LX_MSG_DATA1 := LX_MSG_DATA1||GET_ERR_MSG(8160)||'|';
         END IF;
      ELSIF LX_MSG_DATA LIKE '%This is Buy ATO item%' THEN
         IF NVL(LX_MSG_DATA1,'#') NOT LIKE '%8161%' THEN
            LX_MSG_DATA1 := LX_MSG_DATA1||GET_ERR_MSG(8161)||'|';
         END IF;
      ELSIF LX_MSG_DATA like '%order with an invalid configuration%' then  --MYJIRATEST-3293 AND MYJIRATEST-2706 Ravi S 03-SEP-2014
         IF NVL(LX_MSG_DATA1,'#') NOT LIKE '%8169%' THEN
            LX_MSG_DATA1 := LX_MSG_DATA1||GET_ERR_MSG(8169)||'|';
        END IF;
      ELSE  LX_MSG_DATA1 := LX_MSG_DATA1||'8300:'||SUBSTR(LX_MSG_DATA,1,100)||'|';
          END if;
    END LOOP;
    V_HDR_STS_MSG  := LX_MSG_DATA1;
    P_MSG := null;
       END IF;
    <<end_hdr_loop>>
    P_QT_HDR_STS.EXTEND;
    P_QT_HDR_STS(V_HD_CNT) := V_QT_HDR_STS_DTL(V_HEADER_ID, V_HDR_STS_MSG,V_ORDER_HEADER_ID,V_SUCCESS);
    V_LINE_HDR_COUNT := 1;
    FOR C_REC IN c_line_sts(V_HEADER_ID,V_ORDER_HEADER_ID) LOOP
      P_QT_LINE_STS.EXTEND;
      P_QT_LINE_STS(V_LN_COUNT) := V_QT_LINE_STS_DTL(C_REC.QUOTE_HEADER_ID,
                                                     C_REC.QUOTE_LINE_ID,
                                                     V_LINE_STS_MSG(V_LINE_HDR_COUNT),C_REC.order_line_id,NULL,NULL);
      V_LN_COUNT := V_LN_COUNT + 1;
      V_LINE_HDR_COUNT := V_LINE_HDR_COUNT + 1;
    END LOOP;
    V_ORDER_HEADER_ID := NULL;
      V_HD_CNT := V_HD_CNT + 1;
 END LOOP;
 COMMIT;
 <<end_ou>>
 null;
<<end_ppo>>
null;
EXCEPTION
   WHEN OTHERS THEN
      P_MSG := '8000:'||SUBSTR(SQLERRM,1,100);
END PURCHASE_PO;
--MYJIRATEST-3334 Bulk Cart functionality
PROCEDURE BULK_CART_ADD (P_SSO VARCHAR2
                        ,P_ROLE     VARCHAR2
                        ,P_IACO_CODE VARCHAR2
                        ,P_CUST_ID         V_CUST_ID_ARRAY
                        ,P_OU_ID           VARCHAR2
                        ,P_CART_LINE_DTL IN V_BULK_CART_LINE_ARRAY
                        ,P_BLK_CRT_LN_STS_DTL OUT V_BULK_CART_LINE_STS_ARRAY
                        ,P_MSG OUT VARCHAR2)
AS
   v_cust_id         NUMBER;
   v_item_id         NUMBER;
   L_CART_LINE_DTL   V_BULK_CART_LINE_ARRAY := V_BULK_CART_LINE_ARRAY();
   P_CUST_ID_PRT     V_CUST_ID_ARRAY := V_CUST_ID_ARRAY();
   P_PART_DETAILS    V_PART_DETAILS := V_PART_DETAILS();
   P_PART_AVAIL      V_PART_AVAIL := V_PART_AVAIL();
   P_PART_PRICE      V_PART_PRICE := V_PART_PRICE();
   P_PART_APPLICABLE V_PART_APPLICABLE := V_PART_APPLICABLE();
   P_MESSAGE         VARCHAR2(200);
   P_AVAIL_MESSAGE   VARCHAR2(200);
   P_PRICE_MESSAGE   VARCHAR2(200);
   P_KIT_IND         VARCHAR2(1);
   v_price_list_id   NUMBER;
   v_supplier_code   VARCHAR2(240);
   v_upq             NUMBER;
   v_quote_header_id NUMBER;
   v_quote_line_id   NUMBER;
   v_part_upq        NUMBER;
   P_QT_HDR_DTL_ARRAY  V_QUOTE_HEADER_DTL_ARRAY := V_QUOTE_HEADER_DTL_ARRAY();
   P_QT_LINE_DTL_ARRAY V_QUOTE_LINE_DTL_ARRAY := V_QUOTE_LINE_DTL_ARRAY();
   P_QT_HDR_STS_SV     V_QT_HDR_STS_DTL_ARRAY;
   P_QT_LINE_STS_SV    V_QT_LINE_STS_DTL_ARRAY;
   v_hd_count        NUMBER;
   v_ln_count        NUMBER;
   v_conc_sts_msg    VARCHAR2(500);
   v_line_success    VARCHAR2(10);
   v_loc_msg         VARCHAR2(100);
   v_count           NUMBER;
   l_authorized      VARCHAR2(1);
   l_part_discounts   V_PART_DISCOUNTS;
   l_discount_message VARCHAR2(100);
   l_critical_part    VARCHAR2(10);
   l_part_bom         V_PART_BOM; --MYJIRATEST-6272 Ravi S 03-MAR-2015
   l_ISODERABLE       VARCHAR2(1); --MYJIRATEST-7138 24-MAR-2015   Abhinav Srivastava Oderable Vs Non Oderable changes
   v_upq_override     VARCHAR2(1); --MYJIRATEST-7141/7142 13-APR-2015   Abhinav S  UPQ hANDling for Aero DP request
   v_bulkload_orderable     VARCHAR2(1);
   l_esn_flag VARCHAR2(1);--Neelima Y MYJIRATEST-8723
   l_esn_msg VARCHAR2(100);--Neelima Y MYJIRATEST-8723
   v_ou_id                      VARCHAR2(100)   := NULL; --Added By Manisha;31-AUG-18;Passport requirement to save the OU_ID separated by comma
   v_ou_id1                     VARCHAR2(100)   := NULL;
   v_ou_id2                     VARCHAR2(100)   := NULL;
   j_ou_id                      VARCHAr2(100)   := NULL;
BEGIN

--Manisha K. 01-Nov Commented the below code AND added it after finding the OU_ID using custmoer_code
----MYJIRATEST-7141/7142 13-APR-2015   Abhinav S  UPQ hANDling for Aero DP request Starts
-- BEGIN
--     SELECT description
--       INTO v_upq_override
--       FROM fnd_lookup_values
--      WHERE lookup_type = 'GEAE_MYGE_ENABLE_UPQ_OVERRIDE'
--        AND lookup_code = P_OU_ID
--        AND enabled_flag = 'Y'
--        AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(start_date_active,SYSDATE)) AND TRUNC(NVL(end_date_active,SYSDATE));
--  EXCEPTION
--     WHEN NO_DATA_FOUND THEN
--        v_upq_override := 'N';
--  END;
----MYJIRATEST-7141/7142 13-APR-2015   Abhinav S  UPQ hANDling for Aero DP request Ends
----MYJIRATEST-XXXX Bulk upload - should not let you upload non-orderable part Starts
-- BEGIN
--     SELECT description
--       INTO v_bulkload_orderable
--       FROM fnd_lookup_values
--      WHERE lookup_type = 'GEAE_MYGE_BULKLOAD_ORDERABLE'
--        AND lookup_code = P_OU_ID
--        AND enabled_flag = 'Y'
--        AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(start_date_active,SYSDATE)) AND TRUNC(NVL(end_date_active,SYSDATE));
--  EXCEPTION
--     WHEN NO_DATA_FOUND THEN
--        v_bulkload_orderable := 'N';
--  END;
----MYJIRATEST-XXXX Bulk upload - should not let you upload non-orderable part Ends
   P_BLK_CRT_LN_STS_DTL := V_BULK_CART_LINE_STS_ARRAY();
   P_BLK_CRT_LN_STS_DTL.EXTEND(P_CART_LINE_DTL.count);
   L_CART_LINE_DTL.EXTEND(P_CART_LINE_DTL.count);
   P_CUST_ID_PRT.EXTEND(1);
   FOR r IN 1..P_CART_LINE_DTL.count LOOP
      L_CART_LINE_DTL(r) := V_BULK_CART_LINE_BO(P_CART_LINE_DTL(r).LINE_NUMBER,P_CART_LINE_DTL(r).PART_NUMBER,P_CART_LINE_DTL(r).QUANTITY,
                                                P_CART_LINE_DTL(r).REQUESTED_DATE,P_CART_LINE_DTL(r).PRIORITY,P_CART_LINE_DTL(r).CUSTOMER_CODE,
                                                r,NULL,NULL,NULL,NULL,NULL,NULL,NULL,P_CART_LINE_DTL(r).MYGEA_ESN);
   END LOOP;
   FOR no_cust IN (SELECT row_num
                     FROM TABLE(CAST(L_CART_LINE_DTL AS V_BULK_CART_LINE_ARRAY))
                    WHERE customer_code IS NULL) LOOP
      L_CART_LINE_DTL(no_cust.row_num) := V_BULK_CART_LINE_BO(P_CART_LINE_DTL(no_cust.row_num).LINE_NUMBER,P_CART_LINE_DTL(no_cust.row_num).PART_NUMBER,
                                                              P_CART_LINE_DTL(no_cust.row_num).QUANTITY,P_CART_LINE_DTL(no_cust.row_num).REQUESTED_DATE,
                                                              P_CART_LINE_DTL(no_cust.row_num).PRIORITY,P_CART_LINE_DTL(no_cust.row_num).CUSTOMER_CODE,
                                                              no_cust.row_num,NULL,NULL,NULL,NULL,NULL,NULL,
                                                              L_CART_LINE_DTL(no_cust.row_num).STS_MSG||'Customer code is mANDatory|',P_CART_LINE_DTL(no_cust.row_num).MYGEA_ESN);
   END LOOP;
   FOR no_item IN (SELECT row_num
                     FROM TABLE(CAST(L_CART_LINE_DTL AS V_BULK_CART_LINE_ARRAY))
                    WHERE part_number IS NULL) LOOP
      L_CART_LINE_DTL(no_item.row_num) := V_BULK_CART_LINE_BO(P_CART_LINE_DTL(no_item.row_num).LINE_NUMBER,P_CART_LINE_DTL(no_item.row_num).PART_NUMBER,
                                                              P_CART_LINE_DTL(no_item.row_num).QUANTITY,P_CART_LINE_DTL(no_item.row_num).REQUESTED_DATE,
                                                              P_CART_LINE_DTL(no_item.row_num).PRIORITY,P_CART_LINE_DTL(no_item.row_num).CUSTOMER_CODE,
                                                              no_item.row_num,NULL,NULL,NULL,NULL,NULL,NULL,
                                                              L_CART_LINE_DTL(no_item.row_num).STS_MSG||'Part Number is mANDatory|',P_CART_LINE_DTL(no_item.row_num).MYGEA_ESN);
   END LOOP;
   FOR bulk_cust IN (SELECT DISTINCT customer_code
                       FROM TABLE(CAST(P_CART_LINE_DTL AS V_BULK_CART_LINE_ARRAY))
                      WHERE customer_code IS NOT NULL) LOOP
      BEGIN
         SELECT cust_account_id
           INTO v_cust_id
           FROM hz_cust_accounts
          WHERE account_number = bulk_cust.customer_code;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            v_cust_id := NULL;
      END;
      FOR one_cust IN (SELECT row_num
                         FROM TABLE(CAST(L_CART_LINE_DTL AS V_BULK_CART_LINE_ARRAY))
                        WHERE customer_code = bulk_cust.customer_code) LOOP
         IF v_cust_id IS NULL THEN
            v_conc_sts_msg := L_CART_LINE_DTL(one_cust.row_num).STS_MSG||'Invalid Customer Code|';
         ELSE
            --MYJIRATEST-3976 Ravi S 27-OCT-2014
            l_authorized := 'N';
            FOR i IN 1..P_CUST_ID.COUNT LOOP
               IF P_CUST_ID(i) = v_cust_id THEN
                  l_authorized := 'Y';
               END IF;
            END LOOP;
            IF l_authorized = 'N' THEN
               v_conc_sts_msg := L_CART_LINE_DTL(one_cust.row_num).STS_MSG||GET_ERR_MSG(8180)||'|';
            ELSE
               v_conc_sts_msg := L_CART_LINE_DTL(one_cust.row_num).STS_MSG;

/******************************************************
Passport Requirement
Manisha K. 01-NOV Added below to fetch the OU_ID assigned to the customer v_cust_id
*******************************************************/
  v_ou_id := P_OU_ID;
  v_ou_id1 := REGEXP_SUBSTR(v_ou_id, '[^~]+', 1,1);
  v_ou_id2 :=  REGEXP_SUBSTR (v_ou_id, '[^~]+', 1, 2);

BEGIN
    SELECT distinct hcasa.org_id
    INTO j_ou_id
    FROM  HZ_CUST_ACCOUNTS hca, HZ_CUST_ACCT_SITES_ALL HCASA,HZ_CUST_SITE_USES_ALL  hcsu
    WHERE (hcasa.org_id = to_number(v_ou_id1) or  hcasa.org_id = to_number(v_ou_id2))
    AND HCSU.SITE_USE_CODE = 'SHIP_TO'
    AND  NVL(HCASA.STATUS, 'I') = 'A'
    AND NVL(hca.status, 'I') = 'A'
    AND hcsu.cust_acct_site_id = hcasa.cust_acct_site_id
    AND hcasa.cust_account_id = hca.cust_account_id
    AND hca.cust_Account_id = v_cust_id;

EXCEPTION
WHEN OTHERS THEN
P_MSG := 'Error while fetching the OU_ID: '||SQLCODE||SQLERRM;
END;
    IF j_ou_id IS NULL THEN
       p_MSG:=GET_ERR_MSG(8503)|| p_MSG;
    END IF;

            END IF;
         END IF;
         L_CART_LINE_DTL(one_cust.row_num) := V_BULK_CART_LINE_BO(P_CART_LINE_DTL(one_cust.row_num).LINE_NUMBER,P_CART_LINE_DTL(one_cust.row_num).PART_NUMBER,
                                                                  P_CART_LINE_DTL(one_cust.row_num).QUANTITY,P_CART_LINE_DTL(one_cust.row_num).REQUESTED_DATE,
                                                                  P_CART_LINE_DTL(one_cust.row_num).PRIORITY,P_CART_LINE_DTL(one_cust.row_num).CUSTOMER_CODE,
                                                                  one_cust.row_num,v_cust_id,NULL,NULL,NULL,NULL,NULL,v_conc_sts_msg,P_CART_LINE_DTL(one_cust.row_num).MYGEA_ESN);
      END LOOP;
   END LOOP;
  --Manisha K. 01-Nov moved the code which is commented above. As below values will be determined after finding OU_ID
   --MYJIRATEST-7141/7142 13-APR-2015   Abhinav S  UPQ hANDling for Aero DP request Starts
 BEGIN
     SELECT description
       INTO v_upq_override
       FROM fnd_lookup_values
      WHERE lookup_type = 'GEAE_MYGE_ENABLE_UPQ_OVERRIDE'
        AND lookup_code = j_OU_ID --P_OU_ID
        AND enabled_flag = 'Y'
        AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(start_date_active,SYSDATE)) AND TRUNC(NVL(end_date_active,SYSDATE));
  EXCEPTION
     WHEN NO_DATA_FOUND THEN
        v_upq_override := 'N';
  END;
--MYJIRATEST-7141/7142 13-APR-2015   Abhinav S  UPQ hANDling for Aero DP request Ends
--MYJIRATEST-XXXX Bulk upload - should not let you upload non-orderable part Starts
 BEGIN
     SELECT description
       INTO v_bulkload_orderable
       FROM fnd_lookup_values
      WHERE lookup_type = 'GEAE_MYGE_BULKLOAD_ORDERABLE'
        AND lookup_code = j_OU_ID --P_OU_ID
        AND enabled_flag = 'Y'
        AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(start_date_active,SYSDATE)) AND TRUNC(NVL(end_date_active,SYSDATE));
  EXCEPTION
     WHEN NO_DATA_FOUND THEN
        v_bulkload_orderable := 'N';
  END;
--MYJIRATEST-XXXX Bulk upload - should not let you upload non-orderable part Ends

   FOR bulk_part IN (SELECT DISTINCT part_number
                       FROM TABLE(CAST(P_CART_LINE_DTL AS V_BULK_CART_LINE_ARRAY))
                      WHERE part_number IS NOT NULL) LOOP
      BEGIN
         SELECT msib.inventory_item_id
           INTO v_item_id
           FROM mtl_system_items_b msib, mtl_parameters mp
          WHERE msib.segment1 = UPPER(bulk_part.part_number) --MYJIRATEST-4427 Ravi S 14-NOV-2014
            AND msib.organization_id = mp.organization_id
            AND mp.organization_code = 'CVO';
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            v_item_id := NULL;
      END;
      FOR one_part IN (SELECT row_num
                         FROM TABLE(CAST(L_CART_LINE_DTL AS V_BULK_CART_LINE_ARRAY))
                        WHERE part_number = bulk_part.part_number) LOOP
         IF v_item_id IS NULL THEN
            v_conc_sts_msg := L_CART_LINE_DTL(one_part.row_num).STS_MSG||'Invalid Part Number|';
         ELSE
            v_conc_sts_msg := L_CART_LINE_DTL(one_part.row_num).STS_MSG;
         END IF;
         L_CART_LINE_DTL(one_part.row_num) := V_BULK_CART_LINE_BO(P_CART_LINE_DTL(one_part.row_num).LINE_NUMBER,P_CART_LINE_DTL(one_part.row_num).PART_NUMBER,
                                                                  P_CART_LINE_DTL(one_part.row_num).QUANTITY,P_CART_LINE_DTL(one_part.row_num).REQUESTED_DATE,
                                                                  P_CART_LINE_DTL(one_part.row_num).PRIORITY,P_CART_LINE_DTL(one_part.row_num).CUSTOMER_CODE,
                                                                  one_part.row_num,L_CART_LINE_DTL(one_part.row_num).CUST_ACCOUNT_ID,v_item_id,
                                                                  NULL,NULL,NULL,NULL,v_conc_sts_msg,P_CART_LINE_DTL(one_part.row_num).MYGEA_ESN);
      END LOOP;
   END LOOP;
   FOR bulk_cust_part IN (SELECT DISTINCT cust_account_id,inventory_item_id
                            FROM TABLE(CAST(L_CART_LINE_DTL AS V_BULK_CART_LINE_ARRAY))
                           WHERE sts_msg IS NULL) LOOP
      P_CUST_ID_PRT(1) := bulk_cust_part.cust_account_id;
      v_loc_msg := ' getting part details ';
      GEAE_MYGE_ITEM_DTL_PKG.GET_ITEM_PRICE_AVAIL(
                                P_SSO => P_SSO,
                                P_IACO_CODE => P_IACO_CODE,
                                P_CUST_ID => P_CUST_ID_PRT,
                                P_ROLE => P_ROLE,
                                P_OU_ID => j_OU_ID, --P_OU_ID,
                                P_ITEM_ID => bulk_cust_part.inventory_item_id,
                                P_PART_DETAILS => P_PART_DETAILS,
                                P_PART_AVAIL => P_PART_AVAIL,
                                P_PART_PRICE => P_PART_PRICE,
                                P_PART_APPLICABLE => P_PART_APPLICABLE,
                                P_MESSAGE => P_MESSAGE,
                                P_AVAIL_MESSAGE => P_AVAIL_MESSAGE,
                                P_PRICE_MESSAGE => P_PRICE_MESSAGE,
                                P_KIT_IND => P_KIT_IND,
                                P_PART_DISCOUNTS => l_part_discounts,
                                P_DISC_MESSAGE => l_discount_message,
                                P_CRITICAL_PART => l_critical_part,
                                P_PART_BOM => l_part_bom , --MYJIRATEST-6272 Ravi S 03-MAR-2015
                                P_ISODERABLE => l_ISODERABLE --MYJIRATEST-7138 24-MAR-2015   Abhinav Srivastava Oderable Vs Non Oderable changes
                                );
      --MYJIRATEST-XXXX 04-JUNE-2015   Abhinav S Bulk upload - should not let you upload non-orderable part Starts
       IF v_bulkload_orderable = 'Y' AND (l_ISODERABLE = 'N' OR l_ISODERABLE = 'D') AND P_MESSAGE IS NULL THEN
       FOR one_cust_part IN (SELECT row_num
                                 FROM TABLE(CAST(L_CART_LINE_DTL AS V_BULK_CART_LINE_ARRAY))
                                WHERE inventory_item_id = bulk_cust_part.inventory_item_id
                                  AND cust_account_id = bulk_cust_part.cust_account_id) LOOP
                                                L_CART_LINE_DTL(one_cust_part.row_num) := V_BULK_CART_LINE_BO(P_CART_LINE_DTL(one_cust_part.row_num).LINE_NUMBER,P_CART_LINE_DTL(one_cust_part.row_num).PART_NUMBER,
                                                                     P_CART_LINE_DTL(one_cust_part.row_num).QUANTITY,P_CART_LINE_DTL(one_cust_part.row_num).REQUESTED_DATE,
                                                                     P_CART_LINE_DTL(one_cust_part.row_num).PRIORITY,P_CART_LINE_DTL(one_cust_part.row_num).CUSTOMER_CODE,
                                                                     one_cust_part.row_num,L_CART_LINE_DTL(one_cust_part.row_num).CUST_ACCOUNT_ID,
                                                                     L_CART_LINE_DTL(one_cust_part.row_num).INVENTORY_ITEM_ID,NULL,NULL,NULL,NULL,
                                                                     L_CART_LINE_DTL(one_cust_part.row_num).STS_MSG||'Part Is Not Orderable | ',P_CART_LINE_DTL(one_cust_part.row_num).MYGEA_ESN);
                                  END LOOP;
       END IF;
      --MYJIRATEST-XXXX 04-JUNE-2015   Abhinav S Bulk upload - should not let you upload non-orderable part Ends
      IF P_PART_APPLICABLE.COUNT > 0 AND P_MESSAGE IS NULL THEN --MYJIRATEST-4434 Ravi S 18-NOV-2014
         FOR one_cust_part IN (SELECT row_num
                                 FROM TABLE(CAST(L_CART_LINE_DTL AS V_BULK_CART_LINE_ARRAY))
                                WHERE inventory_item_id = bulk_cust_part.inventory_item_id
                                  AND cust_account_id = bulk_cust_part.cust_account_id) LOOP
            SELECT COUNT(1)
              INTO v_count
              FROM TABLE(CAST(P_PART_APPLICABLE AS V_PART_APPLICABLE)) prt_apl,
                   fnd_lookup_values supp_code
             WHERE prt_apl.cust_id = bulk_cust_part.cust_account_id
               AND prt_apl.inventory_item_id = bulk_cust_part.inventory_item_id
               AND prt_apl.supplier_code = supp_code.meaning
               AND supp_code.lookup_type = 'GEAE_MYGE_SUPPLIER_ORGS'
               AND supp_code.description = j_OU_ID; --P_OU_ID;
            IF v_count > 0 THEN
               FOR part_appl IN (SELECT prt_apl.supplier_code, prt_apl.price_list_id, NVL(prt_apl.upq,1) upq
                                   FROM TABLE(CAST(P_PART_APPLICABLE AS V_PART_APPLICABLE)) prt_apl,
                                        fnd_lookup_values supp_code
                                  WHERE prt_apl.cust_id = bulk_cust_part.cust_account_id
                                    AND prt_apl.inventory_item_id = bulk_cust_part.inventory_item_id
                                    AND prt_apl.supplier_code = supp_code.meaning
                                    AND supp_code.lookup_type = 'GEAE_MYGE_SUPPLIER_ORGS'
                                    AND supp_code.description = j_OU_ID --P_OU_ID
                                 ORDER BY supp_code.attribute3 DESC) LOOP
                  v_supplier_code := part_appl.supplier_code;
                  v_price_list_id := part_appl.price_list_id;
                  v_part_upq := part_appl.upq;
               END LOOP;
               --MYJIRATEST-7141/7142 13-APR-2015   Abhinav S  UPQ hANDling for Aero DP request Starts
               IF v_upq_override = 'Y' THEN
               L_CART_LINE_DTL(one_cust_part.row_num) := V_BULK_CART_LINE_BO(P_CART_LINE_DTL(one_cust_part.row_num).LINE_NUMBER,P_CART_LINE_DTL(one_cust_part.row_num).PART_NUMBER,
                                                                     P_CART_LINE_DTL(one_cust_part.row_num).QUANTITY,P_CART_LINE_DTL(one_cust_part.row_num).REQUESTED_DATE,
                                                                     P_CART_LINE_DTL(one_cust_part.row_num).PRIORITY,P_CART_LINE_DTL(one_cust_part.row_num).CUSTOMER_CODE,
                                                                     one_cust_part.row_num,L_CART_LINE_DTL(one_cust_part.row_num).CUST_ACCOUNT_ID,
                                                                     L_CART_LINE_DTL(one_cust_part.row_num).INVENTORY_ITEM_ID,v_supplier_code,v_price_list_id,NULL,NULL,
                                                                     L_CART_LINE_DTL(one_cust_part.row_num).STS_MSG,P_CART_LINE_DTL(one_cust_part.row_num).MYGEA_ESN);
                  ELSE
               --MYJIRATEST-4316 Ravi S 14-NOV-2014 MYJIRATEST-4653 Ravi S 01-DEC-2014
               L_CART_LINE_DTL(one_cust_part.row_num) := V_BULK_CART_LINE_BO(P_CART_LINE_DTL(one_cust_part.row_num).LINE_NUMBER,P_CART_LINE_DTL(one_cust_part.row_num).PART_NUMBER,
                                                                     CEIL(P_CART_LINE_DTL(one_cust_part.row_num).QUANTITY/v_part_upq)*v_part_upq,P_CART_LINE_DTL(one_cust_part.row_num).REQUESTED_DATE,
                                                                     P_CART_LINE_DTL(one_cust_part.row_num).PRIORITY,P_CART_LINE_DTL(one_cust_part.row_num).CUSTOMER_CODE,
                                                                     one_cust_part.row_num,L_CART_LINE_DTL(one_cust_part.row_num).CUST_ACCOUNT_ID,
                                                                     L_CART_LINE_DTL(one_cust_part.row_num).INVENTORY_ITEM_ID,v_supplier_code,v_price_list_id,NULL,NULL,
                                                                     L_CART_LINE_DTL(one_cust_part.row_num).STS_MSG,P_CART_LINE_DTL(one_cust_part.row_num).MYGEA_ESN);
                  END IF;
                  --MYJIRATEST-7141/7142 13-APR-2015   Abhinav S  UPQ hANDling for Aero DP request Ends
            ELSE
               L_CART_LINE_DTL(one_cust_part.row_num) := V_BULK_CART_LINE_BO(P_CART_LINE_DTL(one_cust_part.row_num).LINE_NUMBER,P_CART_LINE_DTL(one_cust_part.row_num).PART_NUMBER,
                                                                     P_CART_LINE_DTL(one_cust_part.row_num).QUANTITY,P_CART_LINE_DTL(one_cust_part.row_num).REQUESTED_DATE,
                                                                     P_CART_LINE_DTL(one_cust_part.row_num).PRIORITY,P_CART_LINE_DTL(one_cust_part.row_num).CUSTOMER_CODE,
                                                                     one_cust_part.row_num,L_CART_LINE_DTL(one_cust_part.row_num).CUST_ACCOUNT_ID,
                                                                     L_CART_LINE_DTL(one_cust_part.row_num).INVENTORY_ITEM_ID,NULL,NULL,NULL,NULL,
                                                                     L_CART_LINE_DTL(one_cust_part.row_num).STS_MSG||'Customer Code not allowed',P_CART_LINE_DTL(one_cust_part.row_num).MYGEA_ESN);
            END IF;
         END LOOP;
      ELSE
         FOR one_cust_part IN (SELECT row_num
                                 FROM TABLE(CAST(L_CART_LINE_DTL AS V_BULK_CART_LINE_ARRAY))
                                WHERE inventory_item_id = bulk_cust_part.inventory_item_id
                                  AND cust_account_id = bulk_cust_part.cust_account_id) LOOP
            L_CART_LINE_DTL(one_cust_part.row_num) := V_BULK_CART_LINE_BO(P_CART_LINE_DTL(one_cust_part.row_num).LINE_NUMBER,P_CART_LINE_DTL(one_cust_part.row_num).PART_NUMBER,
                                                                  P_CART_LINE_DTL(one_cust_part.row_num).QUANTITY,P_CART_LINE_DTL(one_cust_part.row_num).REQUESTED_DATE,
                                                                  P_CART_LINE_DTL(one_cust_part.row_num).PRIORITY,P_CART_LINE_DTL(one_cust_part.row_num).CUSTOMER_CODE,
                                                                  one_cust_part.row_num,L_CART_LINE_DTL(one_cust_part.row_num).CUST_ACCOUNT_ID,
                                                                  L_CART_LINE_DTL(one_cust_part.row_num).INVENTORY_ITEM_ID,NULL,NULL,NULL,NULL,
                                                                  L_CART_LINE_DTL(one_cust_part.row_num).STS_MSG||P_MESSAGE,P_CART_LINE_DTL(one_cust_part.row_num).MYGEA_ESN);--||'|');  Commented by Neelima for MYJIRATEST 8774
         END LOOP;
      END IF;
   END LOOP;
   FOR i IN 1..P_CART_LINE_DTL.COUNT LOOP
      IF L_CART_LINE_DTL(i).STS_MSG IS NULL THEN
         P_CUST_ID_PRT(1) := L_CART_LINE_DTL(i).cust_account_id;
         v_loc_msg := ' adding part to cart ';
         GEAE_MYGE_CART_PKG.ADD_CART_LINE(p_SSO => P_SSO,
                                          p_ROLE => P_ROLE,
                                          p_IACO_CODE => P_IACO_CODE,
                                          p_CUST_ID => P_CUST_ID_PRT,
                                          p_OU_ID => j_OU_ID, --P_OU_ID,
                                          p_INVENTORY_ITEM_ID  => L_CART_LINE_DTL(i).inventory_item_id,
                                          p_SLCT_CUST_ID => L_CART_LINE_DTL(i).cust_account_id,
                                          p_SUPPLIER_CODE => L_CART_LINE_DTL(i).supplier_code,
                                          p_QUANTITY => L_CART_LINE_DTL(i).quantity,
                                          p_PRICELIST_ID => L_CART_LINE_DTL(i).price_list_id,
                                          p_quoteHeaderId => null,
                                          p_MSG => p_MSG);
         IF p_MSG IS NOT NULL THEN
            L_CART_LINE_DTL(i) := V_BULK_CART_LINE_BO(L_CART_LINE_DTL(i).LINE_NUMBER,L_CART_LINE_DTL(i).PART_NUMBER,
                                                      L_CART_LINE_DTL(i).QUANTITY,L_CART_LINE_DTL(i).REQUESTED_DATE,
                                                      L_CART_LINE_DTL(i).PRIORITY,L_CART_LINE_DTL(i).CUSTOMER_CODE,
                                                      i,L_CART_LINE_DTL(i).CUST_ACCOUNT_ID,L_CART_LINE_DTL(i).INVENTORY_ITEM_ID,
                                                      L_CART_LINE_DTL(i).SUPPLIER_CODE,L_CART_LINE_DTL(i).PRICE_LIST_ID,NULL,NULL,
                                                      L_CART_LINE_DTL(i).STS_MSG||p_MSG||'|',L_CART_LINE_DTL(i).MYGEA_ESN);
         ELSE
            v_loc_msg := ' fetching quote header AND line id after succssfully adding ';
            SELECT quote_header_id
              INTO v_quote_header_id
              FROM aso_quote_headers_all aqh JOIN fnd_user fnd ON aqh.created_by=fnd.user_id
             WHERE fnd.user_name = p_SSO
               AND aqh.CUST_ACCOUNT_ID = L_CART_LINE_DTL(i).cust_account_id
               AND aqh.attribute1 = L_CART_LINE_DTL(i).supplier_code
               AND aqh.org_id = j_OU_ID --p_OU_ID
               AND aqh.QUOTE_STATUS_ID in (10000,10010)
               AND aqh.QUOTE_EXPIRATION_DATE > SYSDATE;
            SELECT MAX(quote_line_id)
              INTO v_quote_line_id
              FROM aso_quote_lines
             WHERE quote_header_id = v_quote_header_id;
            L_CART_LINE_DTL(i) := V_BULK_CART_LINE_BO(L_CART_LINE_DTL(i).LINE_NUMBER,L_CART_LINE_DTL(i).PART_NUMBER,
                                                      L_CART_LINE_DTL(i).QUANTITY,L_CART_LINE_DTL(i).REQUESTED_DATE,
                                                      L_CART_LINE_DTL(i).PRIORITY,L_CART_LINE_DTL(i).CUSTOMER_CODE,
                                                      i,L_CART_LINE_DTL(i).CUST_ACCOUNT_ID,L_CART_LINE_DTL(i).INVENTORY_ITEM_ID,
                                                      L_CART_LINE_DTL(i).SUPPLIER_CODE,L_CART_LINE_DTL(i).PRICE_LIST_ID,v_quote_header_id,
                                                      v_quote_line_id,L_CART_LINE_DTL(i).STS_MSG,L_CART_LINE_DTL(i).MYGEA_ESN);
         END IF;
      END IF;
   END LOOP;
   v_hd_count := 0;
   v_ln_count := 0;
   FOR i IN (SELECT DISTINCT quote_header_id
               FROM TABLE(CAST(L_CART_LINE_DTL AS V_BULK_CART_LINE_ARRAY))
              WHERE quote_header_id IS NOT NULL
                AND quote_line_id IS NOT NULL) LOOP
      v_hd_count := v_hd_count + 1;
      P_QT_HDR_DTL_ARRAY.EXTEND(1);
      P_QT_HDR_DTL_ARRAY(v_hd_count) := V_QUOTE_HEADER_DTL(i.quote_header_id,NULL,NULL,NULL,NULL,NULL);
      FOR j IN (SELECT *
                  FROM TABLE(CAST(L_CART_LINE_DTL AS V_BULK_CART_LINE_ARRAY))
                 WHERE quote_header_id = i.quote_header_id) LOOP
         v_ln_count := v_ln_count + 1;
         P_QT_LINE_DTL_ARRAY.EXTEND(1);
         P_QT_LINE_DTL_ARRAY(v_ln_count) := V_QUOTE_LINE_DTL(i.quote_header_id,j.quote_line_id,j.line_number,j.quantity,j.priority,j.requested_date,j.MYGEA_ESN, null,null); --US161834/US166305 Added last two parameter as null for workstop qty AND date
      END LOOP;
   END LOOP;
   GEAE_MYGE_CART_PKG.SAVE_CART(P_SSO => P_SSO,
                                P_ROLE => P_ROLE,
                                P_IACO_CODE => P_IACO_CODE,
                                P_CUST_ID => P_CUST_ID,
                                P_OU_ID => j_OU_ID, --P_OU_ID,
                                P_CART_HDR_DTL => P_QT_HDR_DTL_ARRAY,
                                P_CART_LINE_DTL => P_QT_LINE_DTL_ARRAY,
                                P_QT_HDR_STS_DTL => P_QT_HDR_STS_SV,
                                P_QT_LINE_STS_DTL => P_QT_LINE_STS_SV,
                                P_MSG => p_MSG);
   IF p_MSG IS NULL THEN
      FOR i IN 1..P_CART_LINE_DTL.COUNT LOOP
         IF L_CART_LINE_DTL(i).quote_header_id IS NOT NULL AND L_CART_LINE_DTL(i).quote_line_id IS NOT NULL THEN
            v_loc_msg := ' getting line AND header errors ';
            SELECT SUBSTR(line_sv.sts_msg||hdr_sv.sts_msg,1,500)
              INTO v_conc_sts_msg
              FROM TABLE(CAST(P_QT_HDR_STS_SV AS V_QT_HDR_STS_DTL_ARRAY)) hdr_sv,
                   TABLE(CAST(P_QT_LINE_STS_SV AS V_QT_LINE_STS_DTL_ARRAY)) line_sv
             WHERE hdr_sv.quote_header_id = line_sv.quote_header_id
               AND hdr_sv.quote_header_id = L_CART_LINE_DTL(i).quote_header_id
               AND line_sv.quote_line_id = L_CART_LINE_DTL(i).quote_line_id;
         ELSE
            v_conc_sts_msg := L_CART_LINE_DTL(i).sts_msg;
         END IF;
     --Removed ESn Validation since service team is taking care of it  Suguna 20-May-2018
               l_esn_flag := 'Y';
               l_esn_msg  := NULL;
         IF v_conc_sts_msg IS NOT NULL THEN
            v_line_success := 'N';
         ELSE
            v_line_success := 'Y';
         END IF;
         P_BLK_CRT_LN_STS_DTL(i) := V_BULK_CART_LINE_STS_BO(L_CART_LINE_DTL(i).line_number,L_CART_LINE_DTL(i).part_number,L_CART_LINE_DTL(i).quantity,v_line_success,v_conc_sts_msg,l_esn_flag,l_esn_msg);
      END LOOP;
   ELSE
      p_MSG := 'Error in Save: '||p_MSG;
   END IF;
EXCEPTION
   WHEN OTHERS THEN
      p_MSG := 'Oracle Error while '|| v_loc_msg ||SQLERRM;
END BULK_CART_ADD;
-- Get Deliver_to procedure
FUNCTION GEAE_DELIVER_TO (
      p_database_object_name   IN   VARCHAR2,
      p_attribute_code         IN   VARCHAR2
   )
RETURN VARCHAR2
AS
-- Local Variable declarations
  l_ORG_ID  NUMBER;
  l_LOCATION_ID VARCHAR2(50);
  l_CUST_ID NUMBER;
  l_DELIVER_TO NUMBER;
  l_source VARCHAR2(240);
  l_myge_source VARCHAR2(1) := 'N';
BEGIN
  l_CUST_ID := Ont_Header_Def_Hdlr.g_record.sold_to_org_id;
  l_ORG_ID := Ont_Header_Def_Hdlr.g_record.org_id;
--  l_LOCATION_ID := Ont_Header_Def_Hdlr.g_record.attribute7; Commented for MYJIRATEST-6517 Fix for Deliver to location code
  l_LOCATION_ID := Ont_Header_Def_Hdlr.g_record.attribute12;--28-APR-2015   Abhinav S MYJIRATEST-6517 Fix for Deliver to location code
  BEGIN
    SELECT oos.name
      INTO l_source
      FROM oe_order_sources oos
     WHERE oos.order_source_id = Ont_Header_Def_Hdlr.g_record.order_source_id;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      l_source := NULL;
  END;
  --MYJIRATEST-5845 Ravi S 10-FEB-2015
  BEGIN
     SELECT 'Y'
       INTO l_myge_source
       FROM fnd_lookup_values flv
      WHERE flv.lookup_type = 'GEAE_MYGE_ORDER_SOURCE'
        AND flv.lookup_code = l_ORG_ID
        AND flv.description = l_source;
  EXCEPTION
     WHEN NO_DATA_FOUND THEN
        l_myge_source := 'N';
  END;
-- Fetching Deliver to value
  IF p_database_object_name = 'OE_AK_ORDER_HEADERS_V' AND (l_myge_source = 'Y' OR l_source = 'Order Capture Quotes') THEN
    BEGIN
      SELECT hcsua2.SITE_USE_ID INTO l_DELIVER_TO
        FROM hz_parties hp,
             hz_party_sites hps,
             hz_cust_accounts hca,
             hz_locations hl,
             hz_cust_acct_sites_all hcasa2,
             hz_cust_site_uses_all hcsua2
       WHERE hp.party_id = hps.party_id(+)
         AND hp.party_id = hca.party_id(+)
         AND HCASA2.PARTY_SITE_ID(+) = HPS.PARTY_SITE_ID
         AND hcasa2.org_id = l_ORG_ID
         AND hcsua2.cust_acct_site_id(+) = hcasa2.cust_acct_site_id
         AND hcsua2.site_use_code =  'DELIVER_TO'
         AND hps.location_id = hl.location_id
         AND NVL(hcasa2.status, 'I') = 'A'        ----Added NVL
         AND NVL(hca.status, 'I') = 'A'           ----Added NVL
         AND NVL(hcsua2.STATUS, 'I') = 'A'        ----Added NVL
         AND NVL(hps.STATUS, 'I') ='A'            ----Added NVL
         AND NVL(hp.STATUS, 'I') ='A'             ----Added NVL
         AND hca.cust_account_id=l_CUST_ID
         AND hl.location_id = l_LOCATION_ID;
      Ont_Header_Def_Hdlr.g_record.attribute12 := NULL;--28-APR-2015   Abhinav S MYJIRATEST-6517 Fix for Deliver to location code
      RETURN l_DELIVER_TO;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RETURN NULL;
    END;
  ELSE
    RETURN NULL;
  END IF;
END GEAE_DELIVER_TO;
PROCEDURE UPDATE_QUOTE_STS (P_USER_ID IN NUMBER,
                                          P_RESP_ID IN NUMBER,
                                          P_APPL_ID IN NUMBER,
                                          P_QT_HDR_ID IN NUMBER,
                                          P_STATUS OUT VARCHAR2,
                                          P_MSG OUT VARCHAR2) IS
l_control_rec           aso_quote_pub.control_rec_type;
  l_qte_header_rec        aso_quote_pub.qte_header_rec_type;
  l_qte_line_tbl          aso_quote_pub.qte_line_tbl_type;
  l_qte_line_dtl_tbl      aso_quote_pub.qte_line_dtl_tbl_type;
  l_hd_tax_detail_tbl     aso_quote_pub.tax_detail_tbl_type;
  l_ln_payment_tbl        aso_quote_pub.payment_tbl_type;
  l_ln_shipment_tbl       aso_quote_pub.shipment_tbl_type;
  l_hd_sales_credit_tbl   aso_quote_pub.sales_credit_tbl_type := aso_quote_pub.g_miss_sales_credit_tbl;
  l_ln_sales_credit_tbl   aso_quote_pub.sales_credit_tbl_type := aso_quote_pub.g_miss_sales_credit_tbl;
  lx_qte_header_rec         aso_quote_pub.qte_header_rec_type;
  lx_qte_line_tbl           aso_quote_pub.qte_line_tbl_type;
  lx_qte_line_dtl_tbl       aso_quote_pub.qte_line_dtl_tbl_type;
  lx_hd_price_attr_tbl      aso_quote_pub.price_attributes_tbl_type;
  lx_hd_payment_tbl         aso_quote_pub.payment_tbl_type;
  lx_hd_shipment_tbl        aso_quote_pub.shipment_tbl_type;
  lx_hd_freight_charge_tbl  aso_quote_pub.freight_charge_tbl_type;
  lx_hd_tax_detail_tbl      aso_quote_pub.tax_detail_tbl_type;
  lx_hd_attr_ext_tbl        aso_quote_pub.line_attribs_ext_tbl_type;
  lx_line_attr_ext_tbl      aso_quote_pub.line_attribs_ext_tbl_type;
  lx_line_rltship_tbl       aso_quote_pub.line_rltship_tbl_type;
  lx_price_adjustment_tbl   aso_quote_pub.price_adj_tbl_type;
  lx_price_adj_attr_tbl     aso_quote_pub.price_adj_attr_tbl_type;
  lx_price_adj_rltship_tbl  aso_quote_pub.price_adj_rltship_tbl_type;
  lx_hd_sales_credit_tbl    aso_quote_pub.sales_credit_tbl_type;
  lx_quote_party_tbl        aso_quote_pub.quote_party_tbl_type;
  lx_ln_sales_credit_tbl    aso_quote_pub.sales_credit_tbl_type;
  lx_ln_quote_party_tbl     aso_quote_pub.quote_party_tbl_type;
  lx_ln_price_attr_tbl      aso_quote_pub.price_attributes_tbl_type;
  lx_ln_payment_tbl         aso_quote_pub.payment_tbl_type;
  lx_ln_shipment_tbl        aso_quote_pub.shipment_tbl_type;
  lx_ln_freight_charge_tbl  aso_quote_pub.freight_charge_tbl_type;
  lx_ln_tax_detail_tbl      aso_quote_pub.tax_detail_tbl_type;
  lx_return_status  varchar2(1);
  lx_msg_count      number;
  lx_msg_data       varchar2(2000);
  l_payment_rec     aso_quote_pub.payment_rec_type;
  l_shipment_rec    aso_quote_pub.shipment_rec_type;
  l_tax_detail_rec  aso_quote_pub.tax_detail_rec_type;
  l_update_date date;
  begin
  SELECT  last_update_date
  into l_update_date
        FROM    aso_quote_headers_all
       WHERE   quote_header_id = P_QT_HDR_ID;
  Fnd_Global.Apps_Initialize(P_USER_ID,P_RESP_ID,P_APPL_ID);
  l_qte_header_rec.quote_header_id  := P_QT_HDR_ID;
  l_qte_header_rec.QUOTE_STATUS_ID := 10012;
  l_qte_header_rec.last_update_date := l_update_date;
aso_quote_pub.update_quote(p_api_version_number       =>  1.0
                            ,p_init_msg_list            => fnd_api.g_true
                            ,p_commit                   => fnd_api.g_true
                            ,p_control_rec              => l_control_rec
                            ,p_qte_header_rec           => l_qte_header_rec
                            ,p_qte_line_tbl             => l_qte_line_tbl
                            ,p_qte_line_dtl_tbl         => l_qte_line_dtl_tbl
                            ,p_hd_tax_detail_tbl        => l_hd_tax_detail_tbl
                            ,p_ln_payment_tbl           => l_ln_payment_tbl
                            ,p_hd_sales_credit_tbl      => l_hd_sales_credit_tbl
                            ,p_ln_sales_credit_tbl      => l_ln_sales_credit_tbl
                            ,p_ln_shipment_tbl          => l_ln_shipment_tbl
                            ,x_qte_header_rec           => lx_qte_header_rec
                            ,x_qte_line_tbl             => lx_qte_line_tbl
                            ,x_qte_line_dtl_tbl         => lx_qte_line_dtl_tbl
                            ,x_hd_price_attributes_tbl  => lx_hd_price_attr_tbl
                            ,x_hd_payment_tbl           => lx_hd_payment_tbl
                            ,x_hd_shipment_tbl          => lx_hd_shipment_tbl
                            ,x_hd_freight_charge_tbl    => lx_hd_freight_charge_tbl
                            ,x_hd_tax_detail_tbl        => lx_hd_tax_detail_tbl
                            ,x_hd_attr_ext_tbl          => lx_hd_attr_ext_tbl
                            ,x_hd_sales_credit_tbl      => lx_hd_sales_credit_tbl
                            ,x_hd_quote_party_tbl       => lx_quote_party_tbl
                            ,x_line_attr_ext_tbl        => lx_line_attr_ext_tbl
                            ,x_line_rltship_tbl         => lx_line_rltship_tbl
                            ,x_price_adjustment_tbl     => lx_price_adjustment_tbl
                            ,x_price_adj_attr_tbl       => lx_price_adj_attr_tbl
                            ,x_price_adj_rltship_tbl    => lx_price_adj_rltship_tbl
                            ,x_ln_price_attributes_tbl  => lx_ln_price_attr_tbl
                            ,x_ln_payment_tbl           => lx_ln_payment_tbl
                            ,x_ln_shipment_tbl          => lx_ln_shipment_tbl
                            ,x_ln_freight_charge_tbl    => lx_ln_freight_charge_tbl
                            ,x_ln_tax_detail_tbl        => lx_ln_tax_detail_tbl
                            ,x_ln_sales_credit_tbl      => lx_ln_sales_credit_tbl
                            ,x_ln_quote_party_tbl       => lx_ln_quote_party_tbl
                            ,x_return_status            => lx_return_status
                            ,x_msg_count                => lx_msg_count
                            ,x_msg_data                 => lx_msg_data);
  if lx_return_status = 'S' AND lx_msg_count = 0 then
     P_STATUS := 'Quote status changed';
     P_MSG := null;
  else
     P_STATUS := 'error in Quote status change';
     P_MSG := 'error in Quote status change';
  end if;
  commit;
  end UPDATE_QUOTE_STS;
FUNCTION GET_ERR_MSG   ( P_ERR_CODE IN NUMBER)
    RETURN VARCHAR2
AS
V_MSG VARCHAR2(2000);
BEGIN
   SELECT LOOKUP_CODE
            || ':'
            || DESCRIPTION
    INTO V_MSG
    FROM FND_LOOKUP_VALUES
    WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
    AND UPPER(LOOKUP_CODE) = UPPER(P_ERR_CODE) ;
    RETURN V_MSG;
 EXCEPTION
 WHEN no_data_found THEN
 RETURN NULL;
END GET_ERR_MSG;
--Enable Kit configuration Ravi S 06-SEP-2014
PROCEDURE CREATE_KIT_CONFIG ( P_USER_ID IN NUMBER,
                              P_APP_ID IN NUMBER,
                              P_RESP_ID IN NUMBER,
                              P_ITEM_ID IN NUMBER,
                              P_ORD_QTY IN NUMBER,
                              P_CFG_FLG IN VARCHAR2, --MYJIRATEST-3512 Ravi S 18-NOV-2014
                              P_CNFG_HDR_ID OUT NUMBER,
                              P_ERR_MSG OUT VARCHAR2) IS
   l_option CZ_BATCH_VALIDATE.INPUT_SELECTION;
   l_batch_val_tbl CZ_BATCH_VALIDATE.CFG_INPUT_LIST;
   l_db_options_tbl OE_Process_Options_Pvt.SELECTED_OPTIONS_TBL_TYPE;
   l_url             VARCHAR2(100) := FND_PROFILE.Value('CZ_UIMGR_URL');
   l_init_msg        VARCHAR2(2000);
   l_validation_type VARCHAR2(1) := CZ_API_PUB.VALIDATE_ORDER;
   l_config_xml_msg CZ_CF_API.CFG_OUTPUT_PIECES;
   l_msg_count NUMBER;
   l_msg_data  VARCHAR2(1000);
   TYPE param_name_type
      IS TABLE OF VARCHAR2(30)INDEX BY BINARY_INTEGER;
   TYPE param_value_type
      IS TABLE OF VARCHAR2(200)INDEX BY BINARY_INTEGER;
   param_name param_name_type;
   param_value param_value_type;
   l_rec_index BINARY_INTEGER;
   l_database_id          VARCHAR2(100);
   l_save_config_behavior VARCHAR2(30):= CZ_API_PUB.G_NEW_REVISION_COPY_MODE;
   l_ui_type              VARCHAR2(30):= NULL;
   l_msg_behavior         VARCHAR2(30):= 'brief';
   l_context_org_id       VARCHAR2(80);
   --l_inventory_item_id    VARCHAR2(80);
   l_config_header_id     VARCHAR2(80);
   l_config_rev_nbr       VARCHAR2(80);
   l_model_quantity       VARCHAR2(80);
   l_count                NUMBER;
   -- message related
   l_xml_hdr       VARCHAR2(32767):= '<initialize>';
   l_dummy         VARCHAR2(500)  := NULL;
   l_return_status VARCHAR2(1)    := FND_API.G_RET_STS_SUCCESS;
   l_html_pieces CZ_BATCH_VALIDATE.CFG_OUTPUT_PIECES;
   l_long_xml LONG := NULL;
   l_validation_status NUMBER;
   l_organization_code   VARCHAR2(100) := 'CVO';
   l_model_item          VARCHAR2(100);
   l_organization_id     NUMBER;
   l_rel_date            VARCHAR2 (240);
   l_grp_id              NUMBER         DEFAULT 0;
   l_levels_to_explode   NUMBER         DEFAULT 100;
   l_verify_flag         NUMBER         DEFAULT 0;
   l_err_msg             VARCHAR2 (240);
   l_err_code            NUMBER         DEFAULT 0;
   l_alternate           VARCHAR2 (240) DEFAULT NULL;
   l_order_by            NUMBER         DEFAULT 1;
   l_session_id          NUMBER         DEFAULT 0;
   l_bom_or_eng          NUMBER         DEFAULT 1;
   l_impl_flag           NUMBER         DEFAULT 1;
   l_plan_factor_flag    NUMBER         DEFAULT 2;
   l_explode_option      NUMBER         DEFAULT 2;
   l_module              NUMBER         DEFAULT 2;
   l_cst_type_id         NUMBER         DEFAULT 0;
   l_std_comp_flag       NUMBER         DEFAULT 0;
   l_comp_code           VARCHAR2 (240) DEFAULT NULL;
   l_expl_qty            NUMBER         DEFAULT 1;
   l_unit_number         VARCHAR2(240)  DEFAULT '';
   l_release_option      NUMBER         DEFAULT 0;
   l_config_cnt          NUMBER;
   e_exit                EXCEPTION;
   CURSOR c_bom_opt (P_GRP_ID NUMBER) IS
      SELECT bet1.component_code ll_cc, bet1.extended_quantity ll_eq, bet2.component_code hl_cc, bet2.extended_quantity hl_eq
        FROM bom_explosion_temp bet1, bom_explosion_temp bet2
       WHERE bet1.group_id = P_GRP_ID
         AND bet1.attribute6 = 'Y'
         AND bet1.plan_level = 2
         AND bet1.group_id = bet2.group_id
         AND bet1.assembly_item_id = bet2.component_item_id
         AND bet2.plan_level = bet1.plan_level - 1
      ORDER BY bet2.sort_order;
BEGIN
   SELECT organization_id
     INTO l_organization_id
     FROM mtl_parameters
    WHERE organization_code = l_organization_code;
   SELECT SEGMENT1
     INTO l_model_item
     FROM mtl_system_items_b
    WHERE inventory_item_id = P_ITEM_ID
      AND organization_id = l_organization_id;
   l_rel_date := TO_CHAR (SYSDATE, 'DD-MON-YYYY HH24:MI:SS');
   -- l_grp_id is a unique identifier for this run of the exploder
   SELECT bom_explosion_temp_s.NEXTVAL
     INTO l_grp_id
     FROM DUAL;
   -- determine maximum levels to explode from bom_explosions
   SELECT maximum_bom_level
     INTO l_levels_to_explode
     FROM bom_parameters
    WHERE organization_id = l_organization_id;
   l_expl_qty := P_ORD_QTY;
      --calling apps stANDard userexit for explosion of star item
   bompexpl.exploder_userexit (l_verify_flag,
                               l_organization_id,
                               l_order_by,
                               l_grp_id,
                               l_session_id,
                               l_levels_to_explode,
                               l_bom_or_eng,
                               l_impl_flag,
                               l_plan_factor_flag,
                               l_explode_option,
                               l_module,
                               l_cst_type_id,
                               l_std_comp_flag,
                               l_expl_qty,
                               P_ITEM_ID,
                               l_alternate,
                               l_comp_code,
                               l_rel_date,
                               l_unit_number,
                               l_release_option,
                               l_err_msg,
                               l_err_code
                                      );
   IF (l_err_code <> 0) THEN
      P_ERR_MSG := 'Error in BOM Explosion API ' || l_err_code || '::' || l_err_msg;
      ROLLBACK;
      RAISE e_exit;
   ELSE
      COMMIT;
   END IF;
   --MYJIRATEST-3512 Ravi S 18-NOV-2014
   IF P_CFG_FLG = 'N' THEN
      RAISE e_exit;
   END IF;
   -- set param_names
   param_name(1)  := 'database_id';
   param_name(2)  := 'context_org_id';
   param_name(3)  := 'config_creation_date';
   param_name(4)  := 'calling_application_id';
   param_name(5)  := 'responsibility_id';
   param_name(6)  := 'model_id';
   param_name(7)  := 'config_header_id';
   param_name(8)  := 'config_rev_nbr';
   param_name(9)  := 'config_effective_date';
   param_name(10) := 'save_config_behavior';
   param_name(11) := 'ui_type';
   param_name(12) := 'language';
   param_name(13) := 'terminate_msg_behavior';
   param_name(14) := 'model_quantity';
   param_name(15) := 'icx_session_ticket';
   param_name(16) := 'publication_mode';
   param_name(17) := 'usage_name';
   param_name(18) := 'sbm_flag';
   param_name(19) := 'validation_context';
   param_name(20) := 'suppress_baseline_errors';
   l_count        := 20;
   -- set param values
   param_value(1)  := fnd_web_config.database_id;
   param_value(2)  := l_organization_id;
   param_value(3)  := TO_CHAR(sysdate,'MM-DD-YYYY-HH24-MI-SS');
   param_value(4)  := P_APP_ID;
   param_value(5)  := P_RESP_ID;
   param_value(6)  := P_ITEM_ID;
   param_value(7)  := NULL;
   param_value(8)  := NULL;
   param_value(9)  := TO_CHAR(sysdate,'MM-DD-YYYY-HH24-MI-SS');
   param_value(10) := 'new_config';
   param_value(11) := NULL;
   param_value(12) := NULL; --p_appl_params.language;
   param_value(13) := 'brief';
   param_value(14) := 1;
   param_value(15) := cz_cf_api.icx_session_ticket;
   param_value(16) := NULL; --p_appl_params.publication_mode;
   param_value(17) := NULL; --p_appl_params.usage_name;
   param_value(18) := 'TRUE';
   param_value(19) := 'INSTALLED';
   param_value(20) := 'TRUE';
   l_rec_index     := 1;
   LOOP
      IF (param_value(l_rec_index) IS NOT NULL) THEN
         l_dummy                    := '<param name='||'"'||param_name(l_rec_index)||'"'||'>'|| param_value(l_rec_index)||'</param>';
         l_xml_hdr                  := l_xml_hdr || l_dummy;
      END IF;
      l_dummy     := NULL;
      l_rec_index := l_rec_index + 1;
      EXIT WHEN l_rec_index > l_count;
   END LOOP;
   -- add termination tags
   l_xml_hdr := l_xml_hdr || '</initialize>';
   l_xml_hdr := REPLACE(l_xml_hdr, ' ' , '+');
   -- update instance name
   l_config_cnt := 1;
   l_option.component_code := P_ITEM_ID;
   l_option.input_seq := l_config_cnt;
   l_option.quantity := l_expl_qty;
   l_batch_val_tbl(l_config_cnt) := l_option;
   FOR r_bom_opt in c_bom_opt(l_grp_id) LOOP
      l_config_cnt := l_config_cnt + 1;
      l_option.component_code := r_bom_opt.hl_cc;
      l_option.input_seq := l_config_cnt;
      l_option.quantity := r_bom_opt.hl_eq;
      l_batch_val_tbl(l_config_cnt) := l_option;
      l_config_cnt := l_config_cnt + 1;
      l_option.component_code := r_bom_opt.ll_cc;
      l_option.input_seq := l_config_cnt;
      l_option.quantity := r_bom_opt.ll_eq;
      l_batch_val_tbl(l_config_cnt) := l_option;
   END LOOP;
   fnd_global.apps_initialize(P_USER_ID,P_RESP_ID,P_APP_ID);
   CZ_BATCH_VALIDATE.Validate ( config_input_list => l_batch_val_tbl ,
                                init_message => l_xml_hdr ,
                                config_messages => l_html_pieces ,
                                validation_status => l_validation_status ,
                                URL => l_url );
   BEGIN
      P_CNFG_HDR_ID := TO_NUMBER(SUBSTR(l_html_pieces(1),
                                   INSTR(l_html_pieces(1),'<config_header_id>',1,1)+18,
                                   INSTR(l_html_pieces(1),'</config_header_id>',1,1)-INSTR(l_html_pieces(1),'<config_header_id>',1,1)-18
                                       )
                                );
      P_ERR_MSG := NULL;
   EXCEPTION
      WHEN OTHERS THEN
         P_ERR_MSG := 'Error in assigning config header id ' || SUBSTR(SQLERRM,1,100);
         RAISE e_exit;
   END;
EXCEPTION
   WHEN e_exit THEN
      NULL;
   WHEN OTHERS THEN
      P_ERR_MSG := 'Unexpected err: ' || SUBSTR(SQLERRM,1,100);
END CREATE_KIT_CONFIG;
--Enable Kit configuration Ravi S 06-SEP-2014
PROCEDURE VALIDATE_CONFIG (P_QT_HDR_ID   IN NUMBER,
                           P_QT_LINE_ID  IN NUMBER,
                           P_CNFG_HDR_ID IN NUMBER,
                           P_SSO         IN VARCHAR2,
                           P_OU_ID       IN NUMBER,
                           P_MSG         OUT VARCHAR2) IS
  LX_CONTROL_REC    ASO_QUOTE_PUB.CONTROL_REC_TYPE;
  LX_CONFIG_REC     ASO_QUOTE_PUB.QTE_LINE_DTL_REC_TYPE;
  LX_MODEL_LINE_REC ASO_QUOTE_PUB.QTE_LINE_REC_TYPE;
  LX_RETURN_STATUS  VARCHAR2(1);
  LX_MSG_COUNT      NUMBER;
  LX_MSG_DATA       VARCHAR2(2000);
  MY_MESSAGE        VARCHAR2(2000);
  L_FILE            VARCHAR2(2000);
  V_USER_ID         FND_USER.USER_ID%TYPE;
  V_RESP_ID         FND_RESPONSIBILITY_TL.RESPONSIBILITY_ID%TYPE;
  V_APP_ID          FND_RESPONSIBILITY_TL.APPLICATION_ID%TYPE;
  e_exit            EXCEPTION;
BEGIN
  IF P_SSO IS NULL THEN
    P_MSG := GEAE_MYGE_CART_PKG.GET_ERR_MSG(8024);
    RAISE e_exit;
  END IF;
  -----
  --Fetching User ID
  SELECT USER_ID INTO V_USER_ID FROM FND_USER WHERE USER_NAME = P_SSO;
  IF P_OU_ID IS NULL THEN
    P_MSG := GEAE_MYGE_CART_PKG.GET_ERR_MSG(8025);
    RAISE e_exit;
  END IF;
  --FETCHING RESPONSIBILITY ID AND APPLICATION_ID
  BEGIN
    SELECT RESP.RESPONSIBILITY_ID, RESP.APPLICATION_ID
      INTO V_RESP_ID, V_APP_ID
      FROM FND_RESPONSIBILITY_TL RESP,
           FND_LOOKUP_VALUES     FLV,
           HR_OPERATING_UNITS    HOU
     WHERE HOU.NAME = FLV.MEANING
       AND RESP.RESPONSIBILITY_NAME = FLV.DESCRIPTION
       AND HOU.ORGANIZATION_ID = P_OU_ID
       AND FLV.LOOKUP_TYPE = 'GEAE_MYGE_QUOTE_RESPONSIBILITY';
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      P_MSG := GEAE_MYGE_CART_PKG.GET_ERR_MSG(8025);
      RAISE e_exit;
  END;
  FND_GLOBAL.APPS_INITIALIZE(V_USER_ID, V_RESP_ID, V_APP_ID);
  MO_GLOBAL.SET_POLICY_CONTEXT('S', P_OU_ID);
  LX_MODEL_LINE_REC.QUOTE_HEADER_ID            := P_QT_HDR_ID;
  LX_MODEL_LINE_REC.QUOTE_LINE_ID              := P_QT_LINE_ID;
  LX_CONFIG_REC.QUOTE_LINE_ID                  := P_QT_LINE_ID;
  LX_CONFIG_REC.QTE_LINE_INDEX                 := 1;
  LX_CONFIG_REC.COMPLETE_CONFIGURATION_FLAG    := 'Y';
  LX_CONFIG_REC.VALID_CONFIGURATION_FLAG       := 'Y';
  LX_CONFIG_REC.CONFIG_HEADER_ID               := P_CNFG_HDR_ID;
  LX_CONFIG_REC.CONFIG_REVISION_NUM            := 1;
  LX_CONTROL_REC.PRICING_REQUEST_TYPE          := 'ASO';
  LX_CONTROL_REC.CALCULATE_FREIGHT_CHARGE_FLAG := 'N';
  LX_CONTROL_REC.CALCULATE_TAX_FLAG            := 'N';
 -- LX_CONTROL_REC.HEADER_PRICING_EVENT          := 'BATCH';
 -- LX_CONTROL_REC.PRICE_MODE                    := 'ENTIRE_QUOTE';
  ASO_CFG_PUB.GET_CONFIG_DETAILS(P_API_VERSION_NUMBER => 1.0,
                                 P_INIT_MSG_LIST      => FND_API.G_FALSE,
                                 P_COMMIT             => FND_API.G_FALSE,
                                 P_CONTROL_REC        => LX_CONTROL_REC,
                                 P_CONFIG_REC         => LX_CONFIG_REC,
                                 P_MODEL_LINE_REC     => LX_MODEL_LINE_REC,
                                 P_CONFIG_HDR_ID      => P_CNFG_HDR_ID,
                                 P_CONFIG_REV_NBR     => 1,
                                 P_QUOTE_HEADER_ID    => P_QT_HDR_ID,
                                 X_RETURN_STATUS      => LX_RETURN_STATUS,
                                 X_MSG_COUNT          => LX_MSG_COUNT,
                                 X_MSG_DATA           => LX_MSG_DATA);
  FOR K IN 1 .. LX_MSG_COUNT LOOP
    LX_MSG_DATA := FND_MSG_PUB.GET(P_MSG_INDEX => K, P_ENCODED => 'F');
  END LOOP;
  COMMIT;
  P_MSG := NULL;
EXCEPTION
   WHEN e_exit THEN
      NULL;
   WHEN OTHERS THEN
      P_MSG := SUBSTR(SQLERRM,1,200);
END VALIDATE_CONFIG;
PROCEDURE GEAE_WISHLT_INSERT_PROC (
P_SSO     IN VARCHAR2,
P_ICAOCODE   IN VARCHAR2,
P_OU_ID     IN VARCHAR2,
P_PART_NUMBER IN VARCHAR2,
P_MESSAGE   OUT VARCHAR2,
P_SUCCESS OUT VARCHAR2
)
AS
V_INVENTORY_ITEM_ID NUMBER(11);
V_COUNT NUMBER(10):=0;
V_CHECK NUMBER(5):=0;
--20-Nov-2018; Suguna added the variables to store the ou_id separated by comma for passport US230173:.
  v_ou_id     VARCHAR2(240) := ' ';
  v_ou_id1       VARCHAR2(100)   := NULL;
  v_ou_id2      VARCHAR2(100)   := NULL;
--end
BEGIN

/*********************************************************
  Below code Added suguna for Passport Requirement:US230173 -- start
  Two OU_ID will be passed separated by ~ symbol for input p_Operating_unit_id.
  need to insert part details for the first operaing unit if user has access to both operating units
  **************************************************/
     v_ou_id := P_OU_ID;
     v_ou_id1 := REGEXP_SUBSTR(v_ou_id, '[^~]+', 1,1);
     v_ou_id2 :=  REGEXP_SUBSTR (v_ou_id, '[^~]+', 1, 2);
BEGIN
  SELECT COUNT(*)
  INTO V_CHECK
   FROM GEAE_MYGE_WL_CUST_TEMP_TBL
   WHERE PART_NUMBER = P_PART_NUMBER AND (OU_ID = v_ou_id1 OR OU_ID = v_ou_id2) AND SSO = P_SSO AND ICAOCODE = P_ICAOCODE;
   EXCEPTION
   WHEN OTHERS THEN
     NULL;
  END;
IF V_CHECK >0 THEN
  P_SUCCESS := 'NO';
  P_MESSAGE :='This part is already available in your saved list.';
  GOTO END_PROC;
ELSE
  P_SUCCESS :='YES';
  BEGIN
SELECT INVENTORY_ITEM_ID
INTO V_INVENTORY_ITEM_ID
FROM MTL_SYSTEM_ITEMS_B
WHERE SEGMENT1=P_PART_NUMBER
AND ROWNUM=1;

    /**if the user has access to both ou then insert part details only for the first ou since all the other details are same
    except OU ID **/

INSERT INTO  GEAE_MYGE_WL_CUST_TEMP_TBL(LINE_ID,SSO,ICAOCODE,PART_NUMBER,ITEM_ID,OU_ID,CREATION_DATE)
                VALUES (WSHLT_LINE_ID_SEQ.nextval,P_SSO,P_ICAOCODE,P_PART_NUMBER,V_INVENTORY_ITEM_ID,v_ou_id1,SYSDATE);
                --end of passport change
V_COUNT:=SQL%ROWCOUNT;

             IF  V_COUNT > 0 THEN
COMMIT;
P_MESSAGE:='RECORDS SUCCESSFULLY INSERTED::'||V_COUNT;
            ELSE
                P_MESSAGE:='RECORD IS NOT INSERTED::'||V_COUNT;
            END IF;
    --end
EXCEPTION
WHEN NO_DATA_FOUND THEN
P_MESSAGE:='GIVEN PART NUMBER DOESNT EXISTS IN AMPS::'||P_PART_NUMBER;
END;
END IF;
<<END_PROC>>
NULL;
END GEAE_WISHLT_INSERT_PROC;
PROCEDURE GEAE_WISHLT_GET_PROC(P_SSO               IN VARCHAR2,
                                                 P_ICAO_CODE         VARCHAR2,
                                                 P_ROLE              IN VARCHAR2,
                                                 P_OU_ID             IN VARCHAR2,
                                                 P_CUST_ID           V_CUST_ID_ARRAY,
                                                 P_BULK_PART_DETAILS OUT V_BULK_PART_DETAILS,
                                                 P_MESSAGE           OUT VARCHAR2) AS
  CURSOR FETCH_WL_CUR IS
    SELECT PART_NUMBER
      FROM GEAE_MYGE_WL_CUST_TEMP_TBL
     WHERE SSO = P_SSO
       AND ICAOCODE = P_ICAO_CODE;
  V_INX number;
  V_PART_NUM          V_PART_NUM_LIST_ARRAY;
BEGIN
  P_BULK_PART_DETAILS := V_BULK_PART_DETAILS();
  V_PART_NUM          := V_PART_NUM_LIST_ARRAY();
  P_MESSAGE           := NULL;
  V_INX               := 0;
  FOR I IN FETCH_WL_CUR LOOP
    V_INX := V_INX + 1;
    V_PART_NUM.EXTEND;
    V_PART_NUM(V_INX) := I.PART_NUMBER;
    END LOOP;
IF V_PART_NUM.COUNT > 0 THEN
GEAE_MYGE_ITEM_DTL_PKG.ITEM_DTL_PART_NUM_BULK(P_SSO,P_ICAO_CODE,P_CUST_ID,P_ROLE,P_OU_ID,V_PART_NUM,P_BULK_PART_DETAILS,P_MESSAGE);
END IF;
END GEAE_WISHLT_GET_PROC;
PROCEDURE GEAE_WISHLT_DELETE_PROC (
P_SSO     IN VARCHAR2,
P_ICAOCODE   IN VARCHAR2,
P_PART_NUMBER V_PART_NUM_LIST_ARRAY,
P_RESPONSE OUT V_RESPONSE_ARRAY
)
AS
V_PARTNUMBER VARCHAR2(100);
V_MESSAGE VARCHAR2(1000);
V_COUNT NUMBER(10):=0;
V_DELCOUNT NUMBER(10):=0;
BEGIN
  P_RESPONSE := V_RESPONSE_ARRAY();
  FOR I IN 1..P_PART_NUMBER.COUNT LOOP
SELECT COUNT(*)
INTO V_COUNT
FROM GEAE_MYGE_WL_CUST_TEMP_TBL
WHERE PART_NUMBER=P_PART_NUMBER(I) AND SSO=P_SSO AND ICAOCODE =P_ICAOCODE;
IF V_COUNT>0 THEN
  DELETE FROM GEAE_MYGE_WL_CUST_TEMP_TBL WHERE PART_NUMBER=P_PART_NUMBER(I) AND SSO=P_SSO AND ICAOCODE =P_ICAOCODE;
V_DELCOUNT:=SQL%ROWCOUNT;
COMMIT;
V_PARTNUMBER := P_PART_NUMBER(I);
V_MESSAGE := 'NUMBER OF RECORDS SUCCESSFULLY DELETED :::'||V_DELCOUNT;
ELSE
V_PARTNUMBER := P_PART_NUMBER(I);
V_MESSAGE := 'RECORD DOESNT EXIST FOR THE GIVEN PART:: '||P_PART_NUMBER(I);
END IF;
P_RESPONSE.EXTEND();
P_RESPONSE(I) := V_RESPONSE_OBJECT(V_PARTNUMBER,V_MESSAGE);
END LOOP;
END GEAE_WISHLT_DELETE_PROC;
PROCEDURE BULK_CART_ADD_PO(P_SSO                VARCHAR2,
                                             P_ROLE               VARCHAR2,
                                             P_IACO_CODE          VARCHAR2,
                                             P_CUST_ID            V_CUST_ID_ARRAY,
                                             P_OU_ID              VARCHAR2,
                                             P_CART_LINE_DTL      IN V_BULK_CART_PO_ARRAY,
                                             P_BLK_CRT_LN_STS_DTL OUT V_BULK_CART_PO_STS_ARRAY,
                                             P_MSG                OUT VARCHAR2) AS   --US63780 AND US62974
  v_cust_id       NUMBER;
  v_item_id       NUMBER;
  L_CART_LINE_DTL V_BULK_CART_PO_ARRAY := V_BULK_CART_PO_ARRAY();
  P_CUST_ID_PRT     V_CUST_ID_ARRAY := V_CUST_ID_ARRAY();
  P_PART_DETAILS    V_PART_DETAILS := V_PART_DETAILS();
  P_PART_AVAIL      V_PART_AVAIL := V_PART_AVAIL();
  P_PART_PRICE      V_PART_PRICE := V_PART_PRICE();
  P_PART_APPLICABLE V_PART_APPLICABLE := V_PART_APPLICABLE();
  P_MESSAGE         VARCHAR2(200);
  P_AVAIL_MESSAGE   VARCHAR2(200);
  P_PRICE_MESSAGE   VARCHAR2(200);
  P_KIT_IND         VARCHAR2(1);
  v_price_list_id NUMBER;
  v_supplier_code VARCHAR2(240);
  v_upq           NUMBER;
  v_quote_header_id NUMBER;
  v_quote_line_id   NUMBER;
  v_part_upq        NUMBER;
  P_QT_HDR_DTL_ARRAY   V_QUOTE_HEADER_DTL_ARRAY := V_QUOTE_HEADER_DTL_ARRAY();
  P_QT_LINE_DTL_ARRAY  V_QUOTE_LINE_DTL_ARRAY := V_QUOTE_LINE_DTL_ARRAY();
  P_QT_HDR_STS_SV      V_QT_HDR_STS_DTL_ARRAY;
  P_QT_LINE_STS_SV     V_QT_LINE_STS_DTL_ARRAY;
  v_hd_count           NUMBER;
  v_ln_count           NUMBER;
  v_bulk_count         NUMBER;
  v_conc_sts_msg       VARCHAR2(500);
  v_line_success       VARCHAR2(10);
  v_loc_msg            VARCHAR2(100);
  v_count              NUMBER;
  l_authorized         VARCHAR2(1);
  l_part_discounts     V_PART_DISCOUNTS;
  l_discount_message   VARCHAR2(100);
  l_critical_part      VARCHAR2(10);
  l_part_bom           V_PART_BOM;
  l_ISODERABLE         VARCHAR2(1);
  v_upq_override       VARCHAR2(1);
  v_bulkload_orderable VARCHAR2(1);
  l_esn_flag           VARCHAR2(1);
  l_esn_msg            VARCHAR2(100);
  v_bulk_po_array      V_BULK_CART_PO_ARRAY := V_BULK_CART_PO_ARRAY();
  TYPE STR_ARR IS VARRAY(5000) OF varchar2(50);
  V_PO_NUMBERS STR_ARR := STR_ARR();
  v_po_number  varchar2(50);
  new_count    number;
  l_max_quote_header_id number;
  l_cart_created boolean;
  j number;
  v_ou_id                      VARCHAR2(100)   := NULL; --Added By Manisha;31-AUG-18;Passport requirement to save the OU_ID separated by comma
  v_ou_id1                     VARCHAR2(100)   := NULL;
  v_ou_id2                     VARCHAR2(100)   := NULL;
  j_ou_id                      VARCHAr2(100)   := NULL;

BEGIN

--Manisha 01-Nov Commented the code AND placed belwo after finding OU_ID using customer_code
--  BEGIN
--    SELECT description
--      INTO v_upq_override
--      FROM fnd_lookup_values
--     WHERE lookup_type = 'GEAE_MYGE_ENABLE_UPQ_OVERRIDE'
--       AND lookup_code = P_OU_ID
--       AND enabled_flag = 'Y'
--       AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(start_date_active, SYSDATE)) AND
--           TRUNC(NVL(end_date_active, SYSDATE));
--  EXCEPTION
--    WHEN NO_DATA_FOUND THEN
--      v_upq_override := 'N';
--  END;
--    BEGIN
--    SELECT description
--      INTO v_bulkload_orderable
--      FROM fnd_lookup_values
--     WHERE lookup_type = 'GEAE_MYGE_BULKLOAD_ORDERABLE'
--       AND lookup_code = P_OU_ID
--       AND enabled_flag = 'Y'
--       AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(start_date_active, SYSDATE)) AND
--           TRUNC(NVL(end_date_active, SYSDATE));
--  EXCEPTION
--    WHEN NO_DATA_FOUND THEN
--      v_bulkload_orderable := 'N';
--  END;
  P_BLK_CRT_LN_STS_DTL := V_BULK_CART_PO_STS_ARRAY();
  P_BLK_CRT_LN_STS_DTL.EXTEND(P_CART_LINE_DTL.count);
  L_CART_LINE_DTL.EXTEND(P_CART_LINE_DTL.count);
  P_CUST_ID_PRT.EXTEND(1);
  FOR r IN 1 .. P_CART_LINE_DTL.count LOOP
    L_CART_LINE_DTL(r) := V_BULK_CART_PO_BO(P_CART_LINE_DTL(r).PO_NUMBER,
                                            P_CART_LINE_DTL(r).LINE_NUMBER,
                                            P_CART_LINE_DTL(r).PART_NUMBER,
                                            P_CART_LINE_DTL(r).QUANTITY,
                                            P_CART_LINE_DTL(r).REQUESTED_DATE,
                                            P_CART_LINE_DTL(r).PRIORITY,
                                            P_CART_LINE_DTL(r).CUSTOMER_CODE,
                                            r,
                                            NULL,
                                            NULL,
                                            NULL,
                                            NULL,
                                            NULL,
                                            NULL,
                                            NULL,
                                            P_CART_LINE_DTL(r).MYGEA_ESN,
                                            P_CART_LINE_DTL(r).WORKSTP_DATE,  --US161328
                                            P_CART_LINE_DTL(r).WORKSTP_QTY);  --US161328
  END LOOP;
  FOR no_cust IN (SELECT row_num
                    FROM TABLE(CAST(L_CART_LINE_DTL AS V_BULK_CART_PO_ARRAY))
                   WHERE customer_code IS NULL) LOOP
    L_CART_LINE_DTL(no_cust.row_num) := V_BULK_CART_PO_BO(P_CART_LINE_DTL(no_cust.row_num)
                                                          .PO_NUMBER,
                                                          P_CART_LINE_DTL(no_cust.row_num)
                                                          .LINE_NUMBER,
                                                          P_CART_LINE_DTL(no_cust.row_num)
                                                          .PART_NUMBER,
                                                          P_CART_LINE_DTL(no_cust.row_num)
                                                          .QUANTITY,
                                                          P_CART_LINE_DTL(no_cust.row_num)
                                                          .REQUESTED_DATE,
                                                          P_CART_LINE_DTL(no_cust.row_num)
                                                          .PRIORITY,
                                                          P_CART_LINE_DTL(no_cust.row_num)
                                                          .CUSTOMER_CODE,
                                                          no_cust.row_num,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          L_CART_LINE_DTL(no_cust.row_num)
                                                          .STS_MSG ||
                                                           'Customer code is mANDatory|',
                                                          P_CART_LINE_DTL(no_cust.row_num)
                                                          .MYGEA_ESN,
                                                          P_CART_LINE_DTL(no_cust.row_num).WORKSTP_DATE, --US161328
                                                          P_CART_LINE_DTL(no_cust.row_num).WORKSTP_QTY); --US161328
  END LOOP;
  FOR no_item IN (SELECT row_num
                    FROM TABLE(CAST(L_CART_LINE_DTL AS V_BULK_CART_PO_ARRAY))
                   WHERE part_number IS NULL) LOOP
    L_CART_LINE_DTL(no_item.row_num) := V_BULK_CART_PO_BO(P_CART_LINE_DTL(no_item.row_num)
                                                          .PO_NUMBER,
                                                          P_CART_LINE_DTL(no_item.row_num)
                                                          .LINE_NUMBER,
                                                          P_CART_LINE_DTL(no_item.row_num)
                                                          .PART_NUMBER,
                                                          P_CART_LINE_DTL(no_item.row_num)
                                                          .QUANTITY,
                                                          P_CART_LINE_DTL(no_item.row_num)
                                                          .REQUESTED_DATE,
                                                          P_CART_LINE_DTL(no_item.row_num)
                                                          .PRIORITY,
                                                          P_CART_LINE_DTL(no_item.row_num)
                                                          .CUSTOMER_CODE,
                                                          no_item.row_num,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          L_CART_LINE_DTL(no_item.row_num)
                                                          .STS_MSG ||
                                                           'Part Number is mANDatory|',
                                                          P_CART_LINE_DTL(no_item.row_num)
                                                          .MYGEA_ESN,
                                                          P_CART_LINE_DTL(no_item.row_num)
                                                          .WORKSTP_DATE,    --US161328
                                                          P_CART_LINE_DTL(no_item.row_num)
                                                          .WORKSTP_QTY);    --US161328
  END LOOP;
  FOR bulk_cust IN (SELECT DISTINCT customer_code
                      FROM TABLE(CAST(P_CART_LINE_DTL AS
                                      V_BULK_CART_PO_ARRAY))
                     WHERE customer_code IS NOT NULL) LOOP
    BEGIN
      SELECT cust_account_id
        INTO v_cust_id
        FROM hz_cust_accounts
       WHERE account_number = bulk_cust.customer_code;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        v_cust_id := NULL;
    END;
    FOR one_cust IN (SELECT row_num
                       FROM TABLE(CAST(L_CART_LINE_DTL AS
                                       V_BULK_CART_PO_ARRAY))
                      WHERE customer_code = bulk_cust.customer_code) LOOP
      IF v_cust_id IS NULL THEN
        v_conc_sts_msg := L_CART_LINE_DTL(one_cust.row_num)
                          .STS_MSG || 'Invalid Customer Code|';
      ELSE
              l_authorized := 'N';
        FOR i IN 1 .. P_CUST_ID.COUNT LOOP
          IF P_CUST_ID(i) = v_cust_id THEN
            l_authorized := 'Y';
          END IF;
        END LOOP;
        IF l_authorized = 'N' THEN
          v_conc_sts_msg := L_CART_LINE_DTL(one_cust.row_num)
                            .STS_MSG || GEAE_MYGE_CART_PKG.GET_ERR_MSG(8180) || '|';
        ELSE
          v_conc_sts_msg := L_CART_LINE_DTL(one_cust.row_num).STS_MSG;
/******************************************************
Passport Requirement
Manisha K. 01-NOV Added below to fetch the OU_ID assigned to the customer v_cust_id
*******************************************************/
  v_ou_id := P_OU_ID;
  v_ou_id1 := REGEXP_SUBSTR(v_ou_id, '[^~]+', 1,1);
  v_ou_id2 :=  REGEXP_SUBSTR (v_ou_id, '[^~]+', 1, 2);

BEGIN


    SELECT distinct hcasa.org_id
    INTO j_ou_id
    FROM  HZ_CUST_ACCOUNTS hca, HZ_CUST_ACCT_SITES_ALL HCASA
    WHERE (hcasa.org_id = to_number(v_ou_id1) or  hcasa.org_id = to_number(v_ou_id2))
    AND  NVL(HCASA.STATUS, 'I') = 'A'
    AND NVL(hca.status, 'I') = 'A'
    AND hcasa.cust_account_id = hca.cust_account_id
    AND hca.cust_Account_id = v_cust_id;

EXCEPTION
WHEN OTHERS THEN
P_MSG := 'Error while fetching the OU_ID: '||SQLCODE||SQLERRM;
END;

    IF j_ou_id IS NULL THEN
        p_MSG:=GET_ERR_MSG(8503);
    END IF;

        END IF;
      END IF;
      L_CART_LINE_DTL(one_cust.row_num) := V_BULK_CART_PO_BO(P_CART_LINE_DTL (one_cust.row_num)
                                                             .PO_NUMBER,
                                                             P_CART_LINE_DTL (one_cust.row_num)
                                                             .LINE_NUMBER,
                                                             P_CART_LINE_DTL (one_cust.row_num)
                                                             .PART_NUMBER,
                                                             P_CART_LINE_DTL (one_cust.row_num)
                                                             .QUANTITY,
                                                             P_CART_LINE_DTL (one_cust.row_num)
                                                             .REQUESTED_DATE,
                                                             P_CART_LINE_DTL (one_cust.row_num)
                                                             .PRIORITY,
                                                             P_CART_LINE_DTL (one_cust.row_num)
                                                             .CUSTOMER_CODE,
                                                             one_cust.row_num,
                                                             v_cust_id,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             v_conc_sts_msg,
                                                             P_CART_LINE_DTL (one_cust.row_num)
                                                             .MYGEA_ESN,
                                                             P_CART_LINE_DTL(one_cust.row_num)
                                                          .WORKSTP_DATE,
                                                          P_CART_LINE_DTL(one_cust.row_num)
                                                          .WORKSTP_QTY);   --US161328
    END LOOP;
  END LOOP;
--Manisha K. 01-Nov moved the code here
  BEGIN
    SELECT description
      INTO v_upq_override
      FROM fnd_lookup_values
     WHERE lookup_type = 'GEAE_MYGE_ENABLE_UPQ_OVERRIDE'
       AND lookup_code = j_OU_ID
       AND enabled_flag = 'Y'
       AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(start_date_active, SYSDATE)) AND
           TRUNC(NVL(end_date_active, SYSDATE));
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      v_upq_override := 'N';
  END;
    BEGIN
    SELECT description
      INTO v_bulkload_orderable
      FROM fnd_lookup_values
     WHERE lookup_type = 'GEAE_MYGE_BULKLOAD_ORDERABLE'
       AND lookup_code = j_OU_ID
       AND enabled_flag = 'Y'
       AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(start_date_active, SYSDATE)) AND
           TRUNC(NVL(end_date_active, SYSDATE));
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      v_bulkload_orderable := 'N';
  END;
  FOR bulk_part IN (SELECT DISTINCT part_number
                      FROM TABLE(CAST(P_CART_LINE_DTL AS
                                      V_BULK_CART_PO_ARRAY))
                     WHERE part_number IS NOT NULL) LOOP
    BEGIN
      SELECT msib.inventory_item_id
        INTO v_item_id
        FROM mtl_system_items_b msib, mtl_parameters mp
       WHERE msib.segment1 = UPPER(bulk_part.part_number)
         AND msib.organization_id = mp.organization_id
         AND mp.organization_code = 'CVO';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        v_item_id := NULL;
    END;
    FOR one_part IN (SELECT row_num
                       FROM TABLE(CAST(L_CART_LINE_DTL AS
                                       V_BULK_CART_PO_ARRAY))
                      WHERE part_number = bulk_part.part_number) LOOP
      IF v_item_id IS NULL THEN
             v_conc_sts_msg := L_CART_LINE_DTL(one_part.row_num)
                          .STS_MSG || GEAE_MYGE_CART_PKG.GET_ERR_MSG(8033);
      ELSE
        v_conc_sts_msg := L_CART_LINE_DTL(one_part.row_num).STS_MSG;
      END IF;
      L_CART_LINE_DTL(one_part.row_num) := V_BULK_CART_PO_BO(P_CART_LINE_DTL (one_part.row_num)
                                                             .PO_NUMBER,
                                                             P_CART_LINE_DTL (one_part.row_num)
                                                             .LINE_NUMBER,
                                                             P_CART_LINE_DTL (one_part.row_num)
                                                             .PART_NUMBER,
                                                             P_CART_LINE_DTL (one_part.row_num)
                                                             .QUANTITY,
                                                             P_CART_LINE_DTL (one_part.row_num)
                                                             .REQUESTED_DATE,
                                                             P_CART_LINE_DTL (one_part.row_num)
                                                             .PRIORITY,
                                                             P_CART_LINE_DTL (one_part.row_num)
                                                             .CUSTOMER_CODE,
                                                             one_part.row_num,
                                                             L_CART_LINE_DTL (one_part.row_num)
                                                             .CUST_ACCOUNT_ID,
                                                             v_item_id,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             v_conc_sts_msg,
                                                             P_CART_LINE_DTL (one_part.row_num)
                                                             .MYGEA_ESN,
                                                             P_CART_LINE_DTL(one_part.row_num)
                                                          .WORKSTP_DATE,  --US161328
                                                          P_CART_LINE_DTL(one_part.row_num)
                                                          .WORKSTP_QTY);   --US161328
    END LOOP;
  END LOOP;
  FOR bulk_cust_part IN (SELECT DISTINCT cust_account_id, inventory_item_id
                           FROM TABLE(CAST(L_CART_LINE_DTL AS
                                           V_BULK_CART_PO_ARRAY))
                          WHERE sts_msg IS NULL) LOOP
    P_CUST_ID_PRT(1) := bulk_cust_part.cust_account_id;
    v_loc_msg := ' getting part details ';
    GEAE_MYGE_ITEM_DTL_PKG.GET_ITEM_PRICE_AVAIL(P_SSO             => P_SSO,
                                                P_IACO_CODE       => P_IACO_CODE,
                                                P_CUST_ID         => P_CUST_ID_PRT,
                                                P_ROLE            => P_ROLE,
                                                P_OU_ID           => j_OU_ID, --P_OU_ID,
                                                P_ITEM_ID         => bulk_cust_part.inventory_item_id,
                                                P_PART_DETAILS    => P_PART_DETAILS,
                                                P_PART_AVAIL      => P_PART_AVAIL,
                                                P_PART_PRICE      => P_PART_PRICE,
                                                P_PART_APPLICABLE => P_PART_APPLICABLE,
                                                P_MESSAGE         => P_MESSAGE,
                                                P_AVAIL_MESSAGE   => P_AVAIL_MESSAGE,
                                                P_PRICE_MESSAGE   => P_PRICE_MESSAGE,
                                                P_KIT_IND         => P_KIT_IND,
                                                P_PART_DISCOUNTS  => l_part_discounts,
                                                P_DISC_MESSAGE    => l_discount_message,
                                                P_CRITICAL_PART   => l_critical_part,
                                                P_PART_BOM        => l_part_bom,
                                                P_ISODERABLE      => l_ISODERABLE
                                                );
    IF v_bulkload_orderable = 'Y' AND
       (l_ISODERABLE = 'N' OR l_ISODERABLE = 'D') AND P_MESSAGE IS NULL THEN
      FOR one_cust_part IN (SELECT row_num
                              FROM TABLE(CAST(L_CART_LINE_DTL AS
                                              V_BULK_CART_PO_ARRAY))
                             WHERE inventory_item_id =
                                   bulk_cust_part.inventory_item_id
                               AND cust_account_id =
                                   bulk_cust_part.cust_account_id) LOOP
        L_CART_LINE_DTL(one_cust_part.row_num) := V_BULK_CART_PO_BO(P_CART_LINE_DTL      (one_cust_part.row_num)
                                                                    .PO_NUMBER,
                                                                    P_CART_LINE_DTL      (one_cust_part.row_num)
                                                                    .LINE_NUMBER,
                                                                    P_CART_LINE_DTL      (one_cust_part.row_num)
                                                                    .PART_NUMBER,
                                                                    P_CART_LINE_DTL      (one_cust_part.row_num)
                                                                    .QUANTITY,
                                                                    P_CART_LINE_DTL      (one_cust_part.row_num)
                                                                    .REQUESTED_DATE,
                                                                    P_CART_LINE_DTL      (one_cust_part.row_num)
                                                                    .PRIORITY,
                                                                    P_CART_LINE_DTL      (one_cust_part.row_num)
                                                                    .CUSTOMER_CODE,
                                                                    one_cust_part.row_num,
                                                                    L_CART_LINE_DTL      (one_cust_part.row_num)
                                                                    .CUST_ACCOUNT_ID,
                                                                    L_CART_LINE_DTL      (one_cust_part.row_num)
                                                                    .INVENTORY_ITEM_ID,
                                                                    NULL,
                                                                    NULL,
                                                                    NULL,
                                                                    NULL,
                                                                    L_CART_LINE_DTL      (one_cust_part.row_num)
                                                                    .STS_MSG ||
                                                                     'Part Is Not Orderable | ',
                                                                    P_CART_LINE_DTL      (one_cust_part.row_num)
                                                                    .MYGEA_ESN,
                                                                    P_CART_LINE_DTL(one_cust_part.row_num)
                                                          .WORKSTP_DATE,
                                                          P_CART_LINE_DTL(one_cust_part.row_num)
                                                          .WORKSTP_QTY);  --US161328
      END LOOP;
    END IF;
    IF P_PART_APPLICABLE.COUNT > 0 AND P_MESSAGE IS NULL THEN
      FOR one_cust_part IN (SELECT row_num
                              FROM TABLE(CAST(L_CART_LINE_DTL AS
                                              V_BULK_CART_PO_ARRAY))
                             WHERE inventory_item_id =
                                   bulk_cust_part.inventory_item_id
                               AND cust_account_id =
                                   bulk_cust_part.cust_account_id) LOOP
        SELECT COUNT(1)
          INTO v_count
          FROM TABLE(CAST(P_PART_APPLICABLE AS V_PART_APPLICABLE)) prt_apl,
               fnd_lookup_values supp_code
         WHERE prt_apl.cust_id = bulk_cust_part.cust_account_id
           AND prt_apl.inventory_item_id = bulk_cust_part.inventory_item_id
           AND prt_apl.supplier_code = supp_code.meaning
           AND supp_code.lookup_type = 'GEAE_MYGE_SUPPLIER_ORGS'
           AND supp_code.description = j_OU_ID; --P_OU_ID;
        IF v_count > 0 THEN
          FOR part_appl IN (SELECT prt_apl.supplier_code,
                                   prt_apl.price_list_id,
                                   NVL(prt_apl.upq, 1) upq
                              FROM TABLE(CAST(P_PART_APPLICABLE AS
                                              V_PART_APPLICABLE)) prt_apl,
                                   fnd_lookup_values supp_code
                             WHERE prt_apl.cust_id =
                                   bulk_cust_part.cust_account_id
                               AND prt_apl.inventory_item_id =
                                   bulk_cust_part.inventory_item_id
                               AND prt_apl.supplier_code = supp_code.meaning
                               AND supp_code.lookup_type =
                                   'GEAE_MYGE_SUPPLIER_ORGS'
                               AND supp_code.description = j_OU_ID  --P_OU_ID
                             ORDER BY supp_code.attribute3 DESC) LOOP
            v_supplier_code := part_appl.supplier_code;
            v_price_list_id := part_appl.price_list_id;
            v_part_upq      := part_appl.upq;
          END LOOP;
          IF v_upq_override = 'Y' THEN
            L_CART_LINE_DTL(one_cust_part.row_num) := V_BULK_CART_PO_BO(P_CART_LINE_DTL      (one_cust_part.row_num)
                                                                        .PO_NUMBER,
                                                                        P_CART_LINE_DTL      (one_cust_part.row_num)
                                                                        .LINE_NUMBER,
                                                                        P_CART_LINE_DTL      (one_cust_part.row_num)
                                                                        .PART_NUMBER,
                                                                        P_CART_LINE_DTL      (one_cust_part.row_num)
                                                                        .QUANTITY,
                                                                        P_CART_LINE_DTL      (one_cust_part.row_num)
                                                                        .REQUESTED_DATE,
                                                                        P_CART_LINE_DTL      (one_cust_part.row_num)
                                                                        .PRIORITY,
                                                                        P_CART_LINE_DTL      (one_cust_part.row_num)
                                                                        .CUSTOMER_CODE,
                                                                        one_cust_part.row_num,
                                                                        L_CART_LINE_DTL      (one_cust_part.row_num)
                                                                        .CUST_ACCOUNT_ID,
                                                                        L_CART_LINE_DTL      (one_cust_part.row_num)
                                                                        .INVENTORY_ITEM_ID,
                                                                        v_supplier_code,
                                                                        v_price_list_id,
                                                                        NULL,
                                                                        NULL,
                                                                        L_CART_LINE_DTL      (one_cust_part.row_num)
                                                                        .STS_MSG,
                                                                        P_CART_LINE_DTL      (one_cust_part.row_num)
                                                                        .MYGEA_ESN,
                                                                        P_CART_LINE_DTL(one_cust_part.row_num)
                                                          .WORKSTP_DATE,  --US161328
                                                          P_CART_LINE_DTL(one_cust_part.row_num)
                                                          .WORKSTP_QTY);  --US161328
          ELSE
            L_CART_LINE_DTL(one_cust_part.row_num) := V_BULK_CART_PO_BO(P_CART_LINE_DTL(one_cust_part.row_num)
                                                                        .PO_NUMBER,
                                                                        P_CART_LINE_DTL(one_cust_part.row_num)
                                                                        .LINE_NUMBER,
                                                                        P_CART_LINE_DTL(one_cust_part.row_num)
                                                                        .PART_NUMBER,
                                                                        CEIL(P_CART_LINE_DTL(one_cust_part.row_num)
                                                                             .QUANTITY /
                                                                              v_part_upq) *
                                                                        v_part_upq,
                                                                        P_CART_LINE_DTL(one_cust_part.row_num)
                                                                        .REQUESTED_DATE,
                                                                        P_CART_LINE_DTL(one_cust_part.row_num)
                                                                        .PRIORITY,
                                                                        P_CART_LINE_DTL(one_cust_part.row_num)
                                                                        .CUSTOMER_CODE,
                                                                        one_cust_part.row_num,
                                                                        L_CART_LINE_DTL(one_cust_part.row_num)
                                                                        .CUST_ACCOUNT_ID,
                                                                        L_CART_LINE_DTL(one_cust_part.row_num)
                                                                        .INVENTORY_ITEM_ID,
                                                                        v_supplier_code,
                                                                        v_price_list_id,
                                                                        NULL,
                                                                        NULL,
                                                                        L_CART_LINE_DTL(one_cust_part.row_num)
                                                                        .STS_MSG,
                                                                        P_CART_LINE_DTL(one_cust_part.row_num)
                                                                        .MYGEA_ESN,
                                                                        P_CART_LINE_DTL(one_cust_part.row_num)
                                                          .WORKSTP_DATE,  --US161328
                                                          P_CART_LINE_DTL(one_cust_part.row_num)
                                                          .WORKSTP_QTY);  --US161328
          END IF;
        ELSE
          L_CART_LINE_DTL(one_cust_part.row_num) := V_BULK_CART_PO_BO(P_CART_LINE_DTL      (one_cust_part.row_num)
                                                                      .PO_NUMBER,
                                                                      P_CART_LINE_DTL      (one_cust_part.row_num)
                                                                      .LINE_NUMBER,
                                                                      P_CART_LINE_DTL      (one_cust_part.row_num)
                                                                      .PART_NUMBER,
                                                                      P_CART_LINE_DTL      (one_cust_part.row_num)
                                                                      .QUANTITY,
                                                                      P_CART_LINE_DTL      (one_cust_part.row_num)
                                                                      .REQUESTED_DATE,
                                                                      P_CART_LINE_DTL      (one_cust_part.row_num)
                                                                      .PRIORITY,
                                                                      P_CART_LINE_DTL      (one_cust_part.row_num)
                                                                      .CUSTOMER_CODE,
                                                                      one_cust_part.row_num,
                                                                      L_CART_LINE_DTL      (one_cust_part.row_num)
                                                                      .CUST_ACCOUNT_ID,
                                                                      L_CART_LINE_DTL      (one_cust_part.row_num)
                                                                      .INVENTORY_ITEM_ID,
                                                                      NULL,
                                                                      NULL,
                                                                      NULL,
                                                                      NULL,
                                                                      L_CART_LINE_DTL      (one_cust_part.row_num)
                                                                      .STS_MSG ||
                                                                       'Customer Code not allowed',
                                                                      P_CART_LINE_DTL      (one_cust_part.row_num)
                                                                      .MYGEA_ESN,
                                                                      P_CART_LINE_DTL(one_cust_part.row_num)
                                                          .WORKSTP_DATE,  --US161328
                                                          P_CART_LINE_DTL(one_cust_part.row_num)
                                                          .WORKSTP_QTY);  --US161328
        END IF;
      END LOOP;
    ELSE
      FOR one_cust_part IN (SELECT row_num
                              FROM TABLE(CAST(L_CART_LINE_DTL AS
                                              V_BULK_CART_PO_ARRAY))
                             WHERE inventory_item_id =
                                   bulk_cust_part.inventory_item_id
                               AND cust_account_id =
                                   bulk_cust_part.cust_account_id) LOOP
        L_CART_LINE_DTL(one_cust_part.row_num) := V_BULK_CART_PO_BO(P_CART_LINE_DTL      (one_cust_part.row_num)
                                                                    .PO_NUMBER,
                                                                    P_CART_LINE_DTL      (one_cust_part.row_num)
                                                                    .LINE_NUMBER,
                                                                    P_CART_LINE_DTL      (one_cust_part.row_num)
                                                                    .PART_NUMBER,
                                                                    P_CART_LINE_DTL      (one_cust_part.row_num)
                                                                    .QUANTITY,
                                                                    P_CART_LINE_DTL      (one_cust_part.row_num)
                                                                    .REQUESTED_DATE,
                                                                    P_CART_LINE_DTL      (one_cust_part.row_num)
                                                                    .PRIORITY,
                                                                    P_CART_LINE_DTL      (one_cust_part.row_num)
                                                                    .CUSTOMER_CODE,
                                                                    one_cust_part.row_num,
                                                                    L_CART_LINE_DTL      (one_cust_part.row_num)
                                                                    .CUST_ACCOUNT_ID,
                                                                    L_CART_LINE_DTL      (one_cust_part.row_num)
                                                                    .INVENTORY_ITEM_ID,
                                                                    NULL,
                                                                    NULL,
                                                                    NULL,
                                                                    NULL,
                                                                    L_CART_LINE_DTL      (one_cust_part.row_num)
                                                                    .STS_MSG ||
                                                                     P_MESSAGE,
                                                                    P_CART_LINE_DTL      (one_cust_part.row_num)
                                                                    .MYGEA_ESN,
                                                                    P_CART_LINE_DTL(one_cust_part.row_num)
                                                          .WORKSTP_DATE,  --US161328
                                                          P_CART_LINE_DTL(one_cust_part.row_num)
                                                          .WORKSTP_QTY);  --US161328
      END LOOP;
    END IF;
  END LOOP;
  v_bulk_count := 0;
  FOR i IN (SELECT po_number, min(row_num) as row_num
              FROM TABLE(CAST(P_CART_LINE_DTL AS V_BULK_CART_PO_ARRAY)) group by po_number order by row_num ASC) LOOP
    v_bulk_count := v_bulk_count + 1;
    V_PO_NUMBERS.EXTEND(1);
    V_PO_NUMBERS(v_bulk_count) := i.po_number;
    DBMS_OUTPUT.PUT_LINE('PO# -----> '||V_PO_NUMBERS(v_bulk_count));
  END LOOP;
  FOR i IN 1 .. V_PO_NUMBERS.COUNT LOOP
    new_count       := 1;
    v_bulk_po_array := V_BULK_CART_PO_ARRAY();
    DBMS_OUTPUT.PUT_LINE('PO# -----> '||V_PO_NUMBERS(i));
    FOR j IN 1 .. L_CART_LINE_DTL.COUNT LOOP
      IF L_CART_LINE_DTL(j).PO_NUMBER = V_PO_NUMBERS(i) THEN
        v_bulk_po_array.extend(1);
        v_bulk_po_array(new_count) := V_BULK_CART_PO_BO(V_PO_NUMBERS(i),
                                                        L_CART_LINE_DTL(j)
                                                        .LINE_NUMBER,
                                                        L_CART_LINE_DTL(j)
                                                        .PART_NUMBER,
                                                        L_CART_LINE_DTL(j)
                                                        .QUANTITY,
                                                        L_CART_LINE_DTL(j)
                                                        .REQUESTED_DATE,
                                                        L_CART_LINE_DTL(j)
                                                        .PRIORITY,
                                                        L_CART_LINE_DTL(j)
                                                        .CUSTOMER_CODE,
                                                        j,
                                                        L_CART_LINE_DTL(j)
                                                        .CUST_ACCOUNT_ID,
                                                        L_CART_LINE_DTL(j)
                                                        .INVENTORY_ITEM_ID,
                                                        L_CART_LINE_DTL(j)
                                                        .SUPPLIER_CODE,
                                                        L_CART_LINE_DTL(j)
                                                        .PRICE_LIST_ID,
                                                        NULL,
                                                        NULL,
                                                        L_CART_LINE_DTL(j)
                                                        .STS_MSG,
                                                        L_CART_LINE_DTL(j)
                                                        .MYGEA_ESN,
                                                        L_CART_LINE_DTL(j).WORKSTP_DATE,  --US161328
                                                          L_CART_LINE_DTL(j).WORKSTP_QTY);  --US161328
        new_count := new_count + 1;
      END IF;
    END LOOP;
    l_cart_created := false;
    FOR k IN 1 .. v_bulk_po_array.COUNT LOOP
      IF v_bulk_po_array(k).STS_MSG IS NULL THEN
        IF l_cart_created = false THEN
         -- NULL;
          GEAE_MYGE_CART_PKG.CREATE_CART(P_SSO,
                                         P_ROLE,
                                         P_IACO_CODE,
                                         j_OU_ID, --P_OU_ID,
                                         v_bulk_po_array(k)
                                         .inventory_item_id,
                                         v_bulk_po_array(k).cust_account_id,
                                         v_bulk_po_array(k).supplier_code,
                                         v_bulk_po_array(k).quantity,
                                         v_bulk_po_array(k).price_list_id,
                                         p_MSG           => p_MSG);
          l_cart_created := true;
        ELSE
          P_CUST_ID_PRT(1) := v_bulk_po_array(k).cust_account_id;
          v_loc_msg := ' adding part to cart ';
          SELECT  max(quote_header_id) into l_max_quote_header_id
          FROM    aso_quote_headers_all aqh JOIN fnd_user fnd
                    ON aqh.created_by=fnd.user_id
          WHERE   fnd.user_name= p_SSO
                  AND aqh.CUST_ACCOUNT_ID= v_bulk_po_array(k).cust_account_id
                  AND aqh.attribute1=v_bulk_po_array(k).supplier_code
                  AND aqh.org_id=j_OU_ID --P_OU_ID
                  AND aqh.QUOTE_STATUS_ID in (10000,10010)--status validation
                  AND aqh.QUOTE_EXPIRATION_DATE >SYSDATE --expiry date validation
                  order by aqh.creation_date desc;
          GEAE_MYGE_CART_PKG.ADD_CART_LINE(p_SSO               => P_SSO,
                                           p_ROLE              => P_ROLE,
                                           p_IACO_CODE         => P_IACO_CODE,
                                           p_CUST_ID           => P_CUST_ID_PRT,
                                           p_OU_ID             => j_OU_ID, --P_OU_ID,
                                           p_INVENTORY_ITEM_ID => v_bulk_po_array(k)
                                                                  .inventory_item_id,
                                           p_SLCT_CUST_ID      => v_bulk_po_array(k)
                                                                  .cust_account_id,
                                           p_SUPPLIER_CODE     => v_bulk_po_array(k)
                                                                  .supplier_code,
                                           p_QUANTITY          => v_bulk_po_array(k)
                                                                  .quantity,
                                           p_PRICELIST_ID      => v_bulk_po_array(k)
                                                                  .price_list_id,
                                           p_quoteHeaderId     => l_max_quote_header_id,
                                           p_MSG               => p_MSG);
        END IF;
       j := v_bulk_po_array(k).row_num;
       IF p_MSG IS NOT NULL THEN
            L_CART_LINE_DTL(j) := V_BULK_CART_PO_BO(L_CART_LINE_DTL(j)
                                                    .PO_NUMBER,
                                                    L_CART_LINE_DTL(j)
                                                    .LINE_NUMBER,
                                                    L_CART_LINE_DTL(j)
                                                    .PART_NUMBER,
                                                    L_CART_LINE_DTL(j).QUANTITY,
                                                    L_CART_LINE_DTL(j)
                                                    .REQUESTED_DATE,
                                                    L_CART_LINE_DTL(j).PRIORITY,
                                                    L_CART_LINE_DTL(j)
                                                    .CUSTOMER_CODE,
                                                    j,
                                                    L_CART_LINE_DTL(j)
                                                    .CUST_ACCOUNT_ID,
                                                    L_CART_LINE_DTL(j)
                                                    .INVENTORY_ITEM_ID,
                                                    L_CART_LINE_DTL(j)
                                                    .SUPPLIER_CODE,
                                                    L_CART_LINE_DTL(j)
                                                    .PRICE_LIST_ID,
                                                    NULL,
                                                    NULL,
                                                    L_CART_LINE_DTL(j)
                                                    .STS_MSG || p_MSG || '|',
                                                    L_CART_LINE_DTL(j)
                                                    .MYGEA_ESN,
                                                    L_CART_LINE_DTL(j).WORKSTP_DATE,  --US161328
                                                          L_CART_LINE_DTL(j).WORKSTP_QTY);  --US161328
          ELSE
            v_loc_msg := ' fetching quote header AND line id after succssfully adding ';
            SELECT max(quote_header_id)
              INTO v_quote_header_id
              FROM aso_quote_headers_all aqh
              JOIN fnd_user fnd
                ON aqh.created_by = fnd.user_id
             WHERE fnd.user_name = p_SSO
               AND aqh.CUST_ACCOUNT_ID = L_CART_LINE_DTL(j).cust_account_id
               AND aqh.attribute1 = L_CART_LINE_DTL(j).supplier_code
               AND aqh.org_id = j_OU_ID ---p_OU_ID
               AND aqh.QUOTE_STATUS_ID in (10000, 10010)
               AND aqh.QUOTE_EXPIRATION_DATE > SYSDATE
             order by aqh.creation_date desc;
            --dbms_output.put_line('QUOTE HEADER ID ==> '||v_quote_header_id);
            SELECT MAX(quote_line_id)
              INTO v_quote_line_id
              FROM aso_quote_lines
             WHERE quote_header_id = v_quote_header_id;
            L_CART_LINE_DTL(j) := V_BULK_CART_PO_BO(L_CART_LINE_DTL  (j)
                                                    .PO_NUMBER,
                                                    L_CART_LINE_DTL  (j)
                                                    .LINE_NUMBER,
                                                    L_CART_LINE_DTL  (j)
                                                    .PART_NUMBER,
                                                    L_CART_LINE_DTL  (j)
                                                    .QUANTITY,
                                                    L_CART_LINE_DTL  (j)
                                                    .REQUESTED_DATE,
                                                    L_CART_LINE_DTL  (j)
                                                    .PRIORITY,
                                                    L_CART_LINE_DTL  (j)
                                                    .CUSTOMER_CODE,
                                                    j,
                                                    L_CART_LINE_DTL  (j)
                                                    .CUST_ACCOUNT_ID,
                                                    L_CART_LINE_DTL  (j)
                                                    .INVENTORY_ITEM_ID,
                                                    L_CART_LINE_DTL  (j)
                                                    .SUPPLIER_CODE,
                                                    L_CART_LINE_DTL  (j)
                                                    .PRICE_LIST_ID,
                                                    v_quote_header_id,
                                                    v_quote_line_id,
                                                    L_CART_LINE_DTL  (j)
                                                    .STS_MSG,
                                                    L_CART_LINE_DTL  (j)
                                                    .MYGEA_ESN,
                                                    L_CART_LINE_DTL(j).WORKSTP_DATE,  --US161328
                                                          L_CART_LINE_DTL(j).WORKSTP_QTY);  --US161328
          END IF;
      END IF;
    END LOOP;
  END LOOP;
  v_hd_count := 0;
  v_ln_count := 0;
  FOR i IN (SELECT DISTINCT quote_header_id, po_number
              FROM TABLE(CAST(L_CART_LINE_DTL AS V_BULK_CART_PO_ARRAY))
             WHERE quote_header_id IS NOT NULL
               AND quote_line_id IS NOT NULL )  LOOP
    v_hd_count := v_hd_count + 1;
    P_QT_HDR_DTL_ARRAY.EXTEND(1);
    P_QT_HDR_DTL_ARRAY(v_hd_count) := V_QUOTE_HEADER_DTL(i.quote_header_id,
                                                         i.po_number,
                                                         NULL,
                                                         NULL,
                                                         NULL,
                                                         NULL);
    FOR j IN (SELECT *
                FROM TABLE(CAST(L_CART_LINE_DTL AS V_BULK_CART_PO_ARRAY))
               WHERE quote_header_id = i.quote_header_id) LOOP
      v_ln_count := v_ln_count + 1;
      P_QT_LINE_DTL_ARRAY.EXTEND(1);
      P_QT_LINE_DTL_ARRAY(v_ln_count) := V_QUOTE_LINE_DTL(i.quote_header_id,
                                                          j.quote_line_id,
                                                          j.line_number,
                                                          j.quantity,
                                                          j.priority,
                                                          j.requested_date,
                                                          j.MYGEA_ESN,
                                                          j.WORKSTP_DATE,  --US161834/US166305
                                                          j.WORKSTP_QTY); --US161834/US166305
    END LOOP;
  END LOOP;
  GEAE_MYGE_CART_PKG.SAVE_CART(P_SSO             => P_SSO,
                               P_ROLE            => P_ROLE,
                               P_IACO_CODE       => P_IACO_CODE,
                               P_CUST_ID         => P_CUST_ID,
                               P_OU_ID           => j_OU_ID,  --P_OU_ID,
                               P_CART_HDR_DTL    => P_QT_HDR_DTL_ARRAY,
                               P_CART_LINE_DTL   => P_QT_LINE_DTL_ARRAY,
                               P_QT_HDR_STS_DTL  => P_QT_HDR_STS_SV,
                               P_QT_LINE_STS_DTL => P_QT_LINE_STS_SV,
                               P_MSG             => p_MSG);
    IF p_MSG IS NULL THEN
    FOR i IN 1 .. P_CART_LINE_DTL.COUNT LOOP
      IF L_CART_LINE_DTL(i).quote_header_id IS NOT NULL AND L_CART_LINE_DTL(i)
         .quote_line_id IS NOT NULL THEN
         --dbms_output.put_line('checking quoteheader AND line '||L_CART_LINE_DTL(i).quote_header_id||'-->'||L_CART_LINE_DTL(i).quote_line_id);
         v_loc_msg := ' getting line AND header errors ';
        BEGIN
        SELECT SUBSTR(line_sv.sts_msg || hdr_sv.sts_msg, 1, 500)
          INTO v_conc_sts_msg
          FROM TABLE(CAST(P_QT_HDR_STS_SV AS V_QT_HDR_STS_DTL_ARRAY)) hdr_sv,
               TABLE(CAST(P_QT_LINE_STS_SV AS V_QT_LINE_STS_DTL_ARRAY)) line_sv
         WHERE hdr_sv.quote_header_id = line_sv.quote_header_id
           AND hdr_sv.quote_header_id = L_CART_LINE_DTL(i).quote_header_id
           AND line_sv.quote_line_id = L_CART_LINE_DTL(i).quote_line_id
           AND rownum=1;
           EXCEPTION
             WHEN OTHERS THEN
               --DBMS_OUTPUT.PUT_LINE('SQLCODE-->SQLERRM'||SQLCODE||'-->'||SQLERRM);
               NULL;
           END;
           --dbms_output.put_line('v_conc_sts_msg '||v_conc_sts_msg);
      ELSE
        v_conc_sts_msg := L_CART_LINE_DTL(i).sts_msg;
      END IF;
    --Removed ESn Validation since service team is taking care of it  Suguna 20-May-2018
               l_esn_flag := 'Y';
               l_esn_msg  := NULL;
      IF v_conc_sts_msg IS NOT NULL THEN
        v_line_success := 'N';
      ELSE
        v_line_success := 'Y';
      END IF;
      P_BLK_CRT_LN_STS_DTL(i) := V_BULK_CART_PO_STS_BO(L_CART_LINE_DTL(i)
                                                         .PO_NUMBER,
                                                         L_CART_LINE_DTL(i)
                                                         .line_number,
                                                         L_CART_LINE_DTL(i)
                                                         .part_number,
                                                         L_CART_LINE_DTL(i)
                                                         .quantity,
                                                         v_line_success,
                                                         v_conc_sts_msg,
                                                         l_esn_flag,
                                                         l_esn_msg);
    END LOOP;
  ELSE
    p_MSG := 'Error in Save: ' || p_MSG;
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    p_MSG := 'Oracle Error while ' || v_loc_msg || SQLERRM;
END BULK_CART_ADD_PO;

--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
 --Added by Ratheesh for US313415 - Order Request date Logic -myGEAviation To fetch the 
 -- value from Profile instead of hardcoding to '5'.
 --FUNCTION to retrieve the request date lead time for SDND Customers.
 --@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@2
 FUNCTION WP_get_SDND_reqdate_leadtime(p_customer_number IN VARCHAR2, p_portal_name IN VARCHAR2)
  RETURN NUMBER
IS
  l_req_date_lead_time NUMBER:= 0 ;
  l_push_sdnd          NUMBER:= 0 ;
  l_req_date_lead_time_bf_12PM NUMBER:= 0;
  l_Order_Source       VARCHAR2(100) := NULL; 
  l_ord_source_cnt     NUMBER:= 0 ;
BEGIN

IF (p_portal_name='CWC') THEN
   l_Order_Source :='myGEAviation';
ELSE
   l_Order_Source:= NULL;
END IF;

--Get the Count based on order source from the Lookup - GEAE_REQUEST_DATE_SOURCES
l_ord_source_cnt:=0 ;
	SELECT  COUNT(1)
	INTO l_ord_source_cnt
	FROM apps.fnd_lookup_values
	WHERE lookup_type = 'GEAE_REQUEST_DATE_SOURCES'	
	AND meaning       = NVL(l_Order_Source, 'XYZ')
	AND enabled_flag  = 'Y'      
	AND NVL(TRUNC(end_date_active),TRUNC(sysdate))>= TRUNC(sysdate) ;

-- Get count based on customer's SDND flag.
l_push_sdnd:= 0;
  SELECT COUNT(*)
  INTO l_push_sdnd
  FROM apps.hz_cust_accounts hca
  WHERE SUBSTR(NVL(attribute5, 'Y'), 1, 1) = 'Y'
  AND account_number    = p_customer_number;
  
  --Query to fetch Request Date lead time value from Profile.
l_req_date_lead_time:= 0;
  BEGIN
    SELECT to_number (NVL(fpov.profile_option_value,0))
    INTO l_req_date_lead_time
    FROM apps.fnd_profile_options fpo,
      apps.fnd_profile_option_values fpov
    WHERE fpo.profile_option_id = fpov.profile_option_id
    AND fpo.profile_option_name ='GEAE_REQUEST_DATE_LEAD_TIME'
    --AND fpo.application_id      = 20208
	AND fpo.application_id = ( SELECT application_id FROM apps.fnd_application_tl WHERE application_name = 'GEAE Custom ONT')
    AND level_value             = 660 -- Application Level -  Order Management
      ;
  EXCEPTION
  WHEN OTHERS THEN
    l_req_date_lead_time := 0;
  END;
  
  l_req_date_lead_time_bf_12PM := l_req_date_lead_time-1;
  
 --If the customer is enabled with SDND flag AND the order source is defined in the Lookup then return the new lead time value.
  IF (l_push_sdnd>0) AND (l_ord_source_cnt>0)THEN
    
	   -- Verify if the order is palced after 12.30 PM EST then return Lead time Value without substracting 1 day.
		IF  TO_CHAR(SYSDATE, 'hh24miss') > '123000' THEN
            RETURN l_req_date_lead_time;
			  
		ELSE  -- Return Lead time Value -1 .
			RETURN l_req_date_lead_time_bf_12PM ; 
		END IF;
  ELSE
    RETURN 5;
  END IF;
    
EXCEPTION
WHEN OTHERS THEN
    dbms_output.put_line('Error Occurred in WP_get_SDND_reqdate_leadtime Function:- ' || sqlerrm);
END WP_get_SDND_reqdate_leadtime; 

END GEAE_MYGE_CART_PKG;