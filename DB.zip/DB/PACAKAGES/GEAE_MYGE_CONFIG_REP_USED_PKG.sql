


create or replace PACKAGE BODY GEAE_MYGE_CONFIG_REP_USED_PKG
AS

/*  ***************************************************************************
    * Application:      Order Management
    * Process Name:     AMPS Items configuration history
    * Program Name:     GEAE_MYGE_CONFIG_REP_USED_PKG.pkb
    * Version #:        1.0
    * Title:            Items configaration history for Repairs and Used Materials
    * Utility:          SQL*Plus
    * Created By:
    * Creation   Date:  20-April-2017
    * Description: Installation Script for AMPS .The script returns Items configaration history.
	*****************************************************************************
 */
 
 
--get_item_config_hist_REP_USED
--eis_conservative_flag_REP_USED
--get_ipl_data_REP_USED
--eis_downgrd_recursive_REP_USED
--get_ship_codes_REP_USED
--update_remarks_REP_USED
--eis_assign_data_REP_USED
--get_avl_to_reserve_REP_USED
--get_rel_type_REP_USED
--get_upq_price_REP_USED
--get_org_id_REP_USED
--insert_alt_part_REP_USED
--eis_upgrade_recursive_REP_USED




PROCEDURE get_item_config_hist_REP_USED (p_sso                VARCHAR2,
										 p_org_Id             VARCHAR2,
										 v_item               VARCHAR2,
										 p_part_hist_info     OUT PART_HISTORY_inFO_ARRAY,
										 p_message            OUT VARCHAR
										 )
 IS
 v_inventory_item_id       mtl_system_items_b.inventory_item_id%TYPE ;
 v_dummy_part_item_id      mtl_system_items_b.inventory_item_id%TYPE ;
 --v_item                  mtl_system_items_b.SEGMENT1%TYPE ;
 p_item_id				   mtl_system_items_b.inventory_item_id%TYPE ;
 g_val_org_id              mtl_system_items_b.organization_id%TYPE;
 v_user_Id                 NUMBER := NULL;
 v_resp_Id                 NUMBER := NULL;
 v_resp_appl_id            NUMBER := NULL;
 v_ipl_exists              CHAR := 'N';
 v_sb_dg_ret               NUMBER := 1;
 v_sb_ug_ret               NUMBER := 1;
 v_truncate                VARCHAR2(100);
 p_mesg                    VARCHAR2(1000);
 v_warehouse_id            NUMBER;
 v_count                   NUMBER(10);
 v_icount                  NUMBER(10):=1;
 part_hist_cnt1            INTEGER;
 part_cnt1                 INTEGER;
 part_cnt8                 INTEGER;
 part_cnt9                 INTEGER;
 part_cnt10                INTEGER;
 part_cnt11                INTEGER;
 part_cnt16                 INTEGER;
 v_list_header_id           NUMBER;
 v_dg_prefs                 NUMBER;  /* To get the Downgrade Preferences */
 v_ug_prefs                 NUMBER;  /* To get the Upgrade Preferences */
 v_alt_prefs                VARCHAR2(10) ;

CURSOR get_engine_model_cur2 (v_org_id           NUMBER,
         		      v_val_org_id       NUMBER,
         		      v_inventory_item_id NUMBER
      			      )
      IS
        SELECT                    msib.segment1 engine_model,
				  bs.bill_sequence_id,
				  bs.assembly_item_id,
				  bc.attribute5  ship_code,
				  b.attribute1   eis_data_stream,
				  b.attribute2   inv_ship_lookup,
				  b.attribute3   business_entity,
                                  bs.attribute10 Engine_family,  -- Added for MYJIRATEST-4033
                                  bs.attribute11 product_line,    -- Added for MYJIRATEST-4033
                                  ood.organization_id warehouse_id
	 FROM	                        bom_components_b bc,
					bom_structures_b bs,
					mtl_system_items_b msib,
					mtl_system_items_b msib1,
					mtl_parameters mtp,
					org_organization_definitions  ood,
					fnd_flex_values_tl t,
					fnd_flex_values b,
					fnd_flex_value_sets s,
                                        fnd_lookup_values fv
	WHERE 	1=1
	  AND 	bc.bill_sequence_id = bs.bill_sequence_id
          AND 	bc.component_item_id = v_inventory_item_id
	  AND 	nvl(bc.DISABLE_DATE,sysdate) >= sysdate
	  AND 	msib.inventory_item_id = bs.assembly_item_id
	  AND 	msib.ITEM_TYPE = 'AEM'
          AND 	bs.organization_id = mtp.organization_id
          AND   bs.attribute12 = DECODE(b.attribute3,'IAD','AES',b.attribute3)
	  AND 	msib.organization_id = mtp.organization_id
	  AND   msib1.inventory_item_id = v_inventory_item_id--bc.component_item_id
	  AND   msib1.organization_id  = ood.organization_id
	  AND   b.flex_value_id       = t.flex_value_id
	  AND	b.flex_value          = ood.organization_code
	  AND	t.language            = userenv('LANG')
	  AND	b.flex_value_set_id   = s.flex_value_set_id
	  AND	s.flex_value_set_name = 'GEAE_EIS_WAREHOUSE_CODE'
	  AND	b.enabled_flag        = 'Y'
	  AND	TRUNC(sysdate) BETWEEN TRUNC(NVL(b.start_date_active,sysdate))
	        		   AND TRUNC(NVL(b.END_date_active,sysdate))
	  AND   bs.assembly_item_id = bs.assembly_item_id
	  AND   bs.attribute10 = bs.attribute10
	  AND   bs.attribute11 = bs.attribute11
	  AND   mtp.organization_id =v_val_org_id
          AND   fv.lookup_type='GEAE_MYGE_SUPPLIER_ORGS'
          AND   fv.description =to_char(v_org_id)
          AND   fv.meaning = bs.attribute8
          AND   fv.attribute1=ood.organization_code
         GROUP BY                      msib.segment1 ,
					bs.bill_sequence_id,
					bs.assembly_item_id,
					bc.attribute5,
					b.attribute1,
					b.attribute2,
					b.attribute3,
                                        bs.attribute10,
                                        bs.attribute11,
                                        ood.organization_id;


 BEGIN
         p_part_hist_info         := PART_HISTORY_inFO_ARRAY();
         p_part_inf1              := PART_HISTORY_inFO_ARRAY();


   BEGIN

   ----- AMPS inITIALIZATION-------------------
  BEGIN
    SELECT user_Id
    INTO   v_user_Id
    FROM   fnd_user
    WHERE  1 = 1
    AND    user_Name = p_sso;
   EXCEPTION
    WHEN OTHERS THEN
    v_user_Id := NULL;
   END;
--
  IF V_User_Id IS NULL THEN
     BEGIN
        SELECT usr.user_id
          INTO V_User_Id
          FROM fnd_user usr, fnd_lookup_values dflt
         WHERE dflt.lookup_type = 'GEAE_MYGE_DEFAULT_LOGIN'
           AND dflt.enabled_flag = 'Y'
           AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(dflt.start_date_active,SYSDATE)) AND TRUNC(NVL(dflt.end_date_active,SYSDATE))
           AND dflt.lookup_code = p_org_Id
           AND dflt.description = usr.user_name;
     EXCEPTION
        WHEN OTHERS THEN
           V_User_Id := Null;
     END;
  END IF;
--
   BEGIN
    SELECT  responsibility_Id
           ,application_Id
     INTO   v_resp_Id
           ,v_resp_Appl_Id
     FROM   fnd_Responsibility_Tl  Frt
           ,fnd_Lookup_Values Flv
           ,hr_Operating_Units Hru
     WHERE 1 = 1
       AND frt.language = 'US'
       AND frt.responsibility_name = flv.description
       AND flv.meaning = hru.name
       AND flv.lookup_type = 'GEAE_MYGE_PRICE_RESPONSIBILITY'
       AND Hru.Organization_Id = TO_number(p_org_Id);
   EXCEPTION
        WHEN OTHERS THEN
            v_resp_Id := NULL;
            v_resp_Appl_Id := NULL;
   END;

--  APPS inTIALIZE
 FND_GLOBAL.APPS_inITIALIZE(USER_ID => v_user_Id, RESP_ID => v_resp_Id, RESP_APPL_ID => v_resp_appl_id);
 g_val_org_id := Oe_Sys_Parameters.value('MASTER_ORGANIZATION_ID',Fnd_Profile.value('ORG_ID'));

     SELECT MSIB.inventory_item_id
     INTO  p_item_id
     FROM mtl_system_items_b MSIB
     WHERE MSIB.SEGMENT1 =  v_item
     AND   MSIB.organization_id = g_val_org_id;
     EXCEPTION
     WHEN NO_DATA_FOUND THEN
          p_item_id:= NULL;
     SELECT LOOKUP_CODE
            || ':'
            || DESCRIPTION
          INTO p_message
      FROM fnd_lookup_values
      WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
      AND LOOKUP_CODE = '8033';
      GOTO END_CODE;
     END;


              BEGIN
               SELECT  tl.LIST_HEADER_ID
               INTO    v_list_header_id
               FROM    fnd_lookup_values fl ,
                       qp_list_headers_tl tl
               WHERE   lookup_type='GEAE_MYGE_ITEM_CONFG_DFLT_ORG'
               AND     fl.description=tl.name
               AND     fl.meaning=p_org_Id;
             EXCEPTION
              WHEN OTHERS THEN
                SELECT LOOKUP_CODE
                     || ':'
                     || DESCRIPTION
                  INTO p_message
                FROM fnd_lookup_values
                WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
                AND LOOKUP_CODE = '8015';
              GOTO END_CODE;
          END;


 FOR get_engine_model_rec IN get_engine_model_cur2(  p_org_Id,
																								     g_val_org_id,
																										 p_item_id
                                                    )
 LOOP

		IF 		g_subs_profile_value = 'N'
		THEN

	                                  	g_conservative_flag := eis_conservative_flag_REP_USED(v_item ,
										 																															 get_engine_model_rec.engine_model,
								                                           	 											 get_engine_model_rec.business_entity,
								                                           	 											 get_engine_model_rec.eis_data_stream);
		END IF; --MYJIRATEST-3511


				                               v_ipl_exists		:= get_ipl_data_REP_USED(v_item,get_engine_model_rec.engine_model,get_engine_model_rec.business_entity);

      IF v_ipl_exists = 0 /* If IPL data not exists, upgrade and downgrade is applicable */
			THEN
  		                    -- Processing Downgrades and its Alternates
      	v_sb_dg_ret := eis_downgrd_recursive_REP_USED (v_item,
                                           			p_item_id,
		                                           	g_val_org_id,
		                                           	NULL, --v_cust_id,
		                                           	NULL,
		                                           	NULL,
		                                           	get_engine_model_rec.engine_model,
		                                           	get_engine_model_rec.business_entity,
		                                           	get_engine_model_rec.eis_data_stream,
		                                           	get_engine_model_rec.inv_ship_lookup,
		                                            p_org_Id	 ,
                                                g_conservative_flag,
                                                v_list_header_id,
                                                NULL, --v_cust_code             ,
                                                get_engine_model_rec.warehouse_id,                                                 NULL, --v_dg_prefs,
                                                NULL, --v_ug_prefs,
                                                NULL, --v_alt_prefs,
                                                get_engine_model_rec.Engine_family,
                                                get_engine_model_rec.product_line,
                                                p_part_inf1
		                                          );


    part_hist_cnt1 := p_part_hist_info.COUNT;
    part_cnt1      := p_part_inf1.count;
    p_part_hist_info.EXTEND(part_cnt1);

    FOR i in 1 .. part_cnt1 LOOP
    p_part_hist_info(part_hist_cnt1 + i) := p_part_inf1(i);
    END LOOP;

                                 -- Processing Dummy Alternates FOR Ordered part
                               insert_alt_part_REP_USED(g_val_org_id,
																								 NULL, --v_cust_id,
																								 NULL,
																								 NULL,
																								 v_item,
																							   v_item,
																								 v_item,
																								 get_engine_model_rec.engine_model,
																								 TO_DATE('01-JAN-1962'),
																								'DUMMY ALT',
																								 NULL, -- Level
																								 get_engine_model_rec.business_entity,
																								 get_engine_model_rec.eis_data_stream,
																								 get_engine_model_rec.inv_ship_lookup,
																							  	p_org_Id,
                                                  g_conservative_flag,
                                                  v_list_header_id,
                                                  NULL, --v_cust_code               ,
                                                  g_val_org_id,
                                                  v_dg_prefs,
                                                  v_ug_prefs,
                                                  v_alt_prefs,
                                                  get_engine_model_rec.Engine_family,
                                                  get_engine_model_rec.product_line,
                                                  p_part_inf8
																								 );

    part_hist_cnt1 := p_part_hist_info.COUNT;
    part_cnt8      := p_part_inf8.COUNT;
    p_part_hist_info.EXTEND(part_cnt8);

    FOR i in 1 .. part_cnt8 LOOP
    p_part_hist_info(part_hist_cnt1 + i) := p_part_inf8(i);
    END LOOP;
                                -- Processing Upgrades and its Alternates FOR Ordered part
        	v_sb_ug_ret := eis_upgrade_recursive_REP_USED (v_item,
		                                            p_item_id,
		                                            g_val_org_id,
		                                            NULL, --v_cust_id,
		                                            NULL,
		                                            NULL,
		                                            get_engine_model_rec.engine_model,
		                                            get_engine_model_rec.business_entity,
		                                           	get_engine_model_rec.eis_data_stream,
		                                           	get_engine_model_rec.inv_ship_lookup,
		                                           	p_org_Id
                                                ,g_conservative_flag,
                                                v_list_header_id,
                                                NULL, --v_cust_code
                                                get_engine_model_rec.warehouse_id,
                                                v_dg_prefs,
                                                v_ug_prefs,
                                                v_alt_prefs,
                                                get_engine_model_rec.Engine_family,
                                                get_engine_model_rec.product_line,
                                                p_part_inf9
		                                             );
    part_hist_cnt1 := p_part_hist_info.COUNT;
    part_cnt9      := p_part_inf9.COUNT;
    p_part_hist_info.EXTEND(part_cnt9);

    FOR i in 1 .. part_cnt9 LOOP
    p_part_hist_info(part_hist_cnt1 + i) := p_part_inf9(i);
    END LOOP;

    ELSE -- Only Upgrades

                                             -- Processing Dummy Alternates FOR Ordered part
                             	insert_alt_part_REP_USED (g_val_org_id,
													                       NULL, --v_cust_id
													                       NULL,
													                       NULL,
													                       v_item,
													                       v_item,
													                       v_item,
													                       get_engine_model_rec.engine_model,
													                       TO_DATE('01-JAN-1962'),
													                       'DUMMY ALT',
													                       NULL,-- 0, Level
													                       get_engine_model_rec.business_entity,
													                       get_engine_model_rec.eis_data_stream,
													                       get_engine_model_rec.inv_ship_lookup,
																						     p_org_Id,
                                                 g_conservative_flag,
                                                 v_list_header_id,
                                                 NULL, --v_cust_code
                                                 g_val_org_id,
                                                 v_dg_prefs,
                                                 v_ug_prefs,
                                                 v_alt_prefs,
                                                 get_engine_model_rec.Engine_family,
                                                 get_engine_model_rec.product_line,
                                                 p_part_inf10
													                      );

    part_hist_cnt1 := p_part_hist_info.COUNT;
    part_cnt10     := p_part_inf10.COUNT;
    p_part_hist_info.EXTEND(part_cnt10);

    FOR i in 1 .. part_cnt10 LOOP
    p_part_hist_info(part_hist_cnt1 + i) := p_part_inf10(i);
    END LOOP;


                                        -- Processing Upgrades and its Alternates FOR Ordered part
			 		v_sb_ug_ret := eis_upgrade_recursive_REP_USED (v_item,
		                                            P_ITEM_ID,
		                                            g_val_org_id,
		                                            NULL, --v_cust_id
		                                            NULL,
		                                            NULL,
		                                            get_engine_model_rec.engine_model,
		                                            get_engine_model_rec.business_entity,
		                                           	get_engine_model_rec.eis_data_stream,
		                                           	get_engine_model_rec.inv_ship_lookup,
		                                            p_org_Id,
                                                g_conservative_flag,
                                                v_list_header_id,
                                                NULL, --v_cust_code
                                                get_engine_model_rec.warehouse_id,
                                                v_dg_prefs,
                                                v_ug_prefs,
                                                v_alt_prefs,
                                                get_engine_model_rec.Engine_family,
                                                get_engine_model_rec.product_line,
                                                p_part_inf11
		                                           );
    part_hist_cnt1 := p_part_hist_info.COUNT;
    part_cnt11     := p_part_inf11.COUNT;
    p_part_hist_info.EXTEND(part_cnt11);

    FOR i in 1 .. part_cnt11 LOOP
    p_part_hist_info(part_hist_cnt1 + i) := p_part_inf11(i);
    END LOOP;

END if;

END LOOP;

IF p_part_hist_info.count <> 0 then
FOR i in p_part_hist_info.first..p_part_hist_info.last
LOOP


  fnd_file.put_line(fnd_file.log, 'O/p' || p_part_hist_info(i).inVENTORY_ITEM_ID ||'..'||  p_part_hist_info(i).PART_number ||'..'||  p_part_hist_info(i).unit_PRICE||'..'|| p_part_hist_info(i).AVAILABILITY ||'..'||  p_part_hist_info(i).UPQ ||'..'||  p_part_hist_info(i).serviceBulletin ||'..'|| p_part_hist_info(i).altPart ||'..'||  p_part_hist_info(i).ALT_TYPE ||'..'||  p_part_hist_info(i).EngineModel||'..'||p_part_hist_info(i).CUST_CODE||'..'||p_part_hist_info(i).SBDATE );
 END LOOP;
 END IF;
 dbms_output.put_line('END of Execution NUMBER of records fetched..'||p_part_hist_info.count);


IF p_part_hist_info.count = 0 then

 SELECT LOOKUP_CODE
            || ':'
            || DESCRIPTION
          INTO p_message
      FROM fnd_lookup_values
      WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
      AND LOOKUP_CODE = '8023';

--p_message:='8023:Configuration History is not available for Given Combination Entries';
END IF;

<<END_CODE>>
NULL;
END;

FUNCTION eis_conservative_flag_REP_USED(p_item_number       in   VARCHAR2,
			                      	 p_engine_model      in   VARCHAR2,
			                      	 p_business_entity   in   VARCHAR2,
			                       	 p_eis_data_stream   in   VARCHAR2)
RETURN VARCHAR2
IS

  v_conservative_flag VARCHAR2(1);
	v_ipl_exists CHAR := 'N';
 BEGIN

 	v_ipl_exists					:= get_ipl_data_REP_USED(p_item_number,p_engine_model,p_business_entity);

 IF v_ipl_exists = 0  /* If IPL data not exists, upgrade and downgrade is applicable */
 THEN

 SELECT 'Y'
   INTO  v_conservative_flag
   FROM dual
  WHERE 1=1
  AND ( EXISTS  (  SELECT  NULL
     		           FROM   geae_mtl_ebom_sb_data
		               WHERE   1 = 1
		               AND old_part_number IS NOT NULL
		               AND new_part_number IS NOT NULL
	                 AND bus_enty_cd     = p_business_entity
		               AND src_cd          = p_eis_data_stream
                   AND engine_model    = p_engine_model
                   AND new_part_number = p_item_number
        -- AND sb_intrchngblty_cd = '2'
	/*	START WITH new_part_number = p_item_number AND engine_model = p_engine_model
		CONNECT BY new_part_number = PRIOR old_part_number AND PRIOR sb_intrchngblty_cd = '2'*/
                )
           OR  EXISTS
                (SELECT	 NULL
		             FROM	geae_mtl_ebom_sb_data
	               WHERE 1 = 1
	               AND old_part_number IS NOT NULL
	               AND new_part_number IS NOT NULL
	               AND engine_model    = p_engine_model
	               AND bus_enty_cd     = p_business_entity
	               AND src_cd          = p_eis_data_stream
                 AND old_part_number = p_item_number
              --ANd sb_intrchngblty_cd in ('1','2')
	     /*START WITH old_part_number = p_item_number
	     CONNECT BY old_part_number = PRIOR new_part_number AND PRIOR sb_intrchngblty_cd in ('1','2')*/
                  )
	     OR EXISTS
             (  SELECT	NULL
                FROM	geae_mtl_ebom_alt_data
                WHERE	1=1
                 AND   bus_enty_cd  = p_business_entity
							   AND  part_number   = p_item_number
							   AND  engine_model  = p_engine_model));

 ELSE  	/* Upgrades only */
 		SELECT 'Y'
    INTO  v_conservative_flag
    FROM dual
    WHERE 1=1
    AND ( EXISTS
                (SELECT	 NULL
		             FROM	geae_mtl_ebom_sb_data
	               WHERE 1 = 1
	               AND old_part_number IS NOT NULL
	               AND new_part_number IS NOT NULL
	               AND engine_model    = p_engine_model
	               AND bus_enty_cd     = p_business_entity
	               AND src_cd          = p_eis_data_stream
                 AND old_part_number = p_item_number
             -- AND sb_intrchngblty_cd in ('1','2')
	     /*START WITH old_part_number = p_item_number
	     CONNECT BY old_part_number = PRIOR new_part_number AND PRIOR sb_intrchngblty_cd in ('1','2')*/
       )
	     OR EXISTS
             (SELECT	NULL
                FROM	geae_mtl_ebom_alt_data
               WHERE	1=1
                 AND   bus_enty_cd = p_business_entity
							   AND  part_number =  p_item_number
							   AND  engine_model = p_engine_model));

 END IF;

        RETURN  v_conservative_flag;
  EXCEPTION
	WHEN NO_DATA_FOUND THEN
	      RETURN 'N';
  END ;

FUNCTION get_ipl_data_REP_USED(p_item_number VARCHAR2, p_engine_model VARCHAR2,p_business_entity in VARCHAR2) RETURN NUMBER IS
   v_ipl_count   NUMBER := 1;
BEGIN
        SELECT count (*)
        INTO v_ipl_count
        FROM geae_mtl_ebom_ipl_data
        WHERE part_number = p_item_number
         AND bus_enty_cd = p_business_entity
         AND engine_model = p_engine_model;

      RETURN v_ipl_count;

END get_ipl_data_REP_USED;


FUNCTION eis_downgrd_recursive_REP_USED(p_item_number       in   VARCHAR2,
				p_ordered_item_id   in   NUMBER,
				p_organization_id   in   NUMBER,
				p_cust_account_id   in   NUMBER,
				p_ship_to_org_id    in   NUMBER,
				p_order_line_id     in   NUMBER,
				p_engine_model      in   VARCHAR2,
				p_business_entity	  in   VARCHAR2,
      	p_eis_data_stream	  in   VARCHAR2,
      	p_inv_ship_lookup   in   VARCHAR2,
      	p_org_id		  			in   NUMBER,
        p_conservative_flag in  VARCHAR2,
        p_list_header_id    in  NUMBER,
        p_cust_code         in VARCHAR2,
        p_warehouse_id      in NUMBER,
        p_dg_prefs         in   NUMBER,
				p_ug_prefs        in   NUMBER,
				p_alt_prefs        in   VARCHAR2,
        p_Engine_family    IN   VARCHAR2,
        p_product_line     IN   VARCHAR2,
        p_part_hist_info2  OUT PART_HISTORY_inFO_ARRAY
				)


RETURN NUMBER
IS
-- Return FOR eis_downgrade_recursive *\

	v_insert_eis_return       NUMBER;
	--\* To Populate the Control_ship_applicability Flag *\
	v_control_ship_app        VARCHAR2 (1);
--	\* Return FOR the Comtroll Shippability *\
	v_control_shippable_ret   NUMBER;
--	\* To populate Old_item_id FOR the old_part_number(SEGMENT1) *\
	v_old_item_id             NUMBER;
--	\* To populate New_item_id FOR the new_part_number(SEGMENT1) *\
	v_new_item_id             NUMBER;
--	\* To populate Old Item Ship Code *\
	v_old_item_ship_code      VARCHAR2 (150);
--	\* To populate New Item Ship Code *\
	v_new_item_ship_code      VARCHAR2 (150);
--	\* To populate the SB NUMBER *\
	v_sb_snum                 VARCHAR2 (20);
--	\* To populate the SB Material Disposition code*\
	v_sb_matl_disp_cd         VARCHAR2 (1);
--	\* To populate the SB I/C code*\
	v_sb_intrchngblty_cd      VARCHAR2 (1);
  v_remarks       					VARCHAR2(100);
  v_error_code       				VARCHAR2(100);
  v_assign_data       			NUMBER;
  v_organization_id 				NUMBER;

  part_hist_cnt2             integer;
  part_cnt2                  integer;
  part_hist_cnt4             integer;
  part_cnt4                  integer;
 v_check  number :=0;
 --	\* Cursor to get all the downgrades FOR the ordered_part and Engine model *\

CURSOR sb_data_cur (v_item_number VARCHAR2, v_engine_model VARCHAR2)
	IS
	      SELECT	level,
	             	old_part_number,
	            	new_part_number,
	            	engine_model,bus_enty_cd,
	            	MAX (sb_issue_date) sb_dg_date
	       FROM	  geae_mtl_ebom_sb_data
	       WHERE 1 = 1
	       AND    old_part_number IS NOT NULL
	       AND    new_part_number IS NOT NULL
	       AND    bus_enty_cd = p_business_entity
	       AND    src_cd = p_eis_data_stream
           	    START WITH new_part_number = v_item_number AND engine_model = v_engine_model  AND  bus_enty_cd = p_business_entity AND    src_cd = p_eis_data_stream
	              CONNECT BY NOCYCLE new_part_number = PRIOR old_part_number AND PRIOR sb_intrchngblty_cd = '2' AND engine_model = v_engine_model AND  bus_enty_cd = p_business_entity AND    src_cd = p_eis_data_stream
	       GROUP BY level,
	          	  old_part_number,
		            new_part_number,
	            	 engine_model,bus_enty_cd
         	ORDER BY sb_dg_date DESC;
BEGIN
      p_part_hist_info2         := PART_HISTORY_inFO_ARRAY();
         v_check :=0;
      	BEGIN
        SELECT	 count(1) INTO v_check
		     FROM	geae_mtl_ebom_sb_data
	       WHERE 1 = 1
	       AND    old_part_number IS NOT NULL
	       AND    new_part_number IS NOT NULL
	       AND    bus_enty_cd = p_business_entity
	       AND    src_cd = p_eis_data_stream
         AND    engine_model = p_engine_model
         AND    new_part_number = p_item_number;
         --AND    sb_intrchngblty_cd = '2';
         EXCEPTION
         WHEN OTHERS THEN
         v_check :=0;
         dbms_output.put_line(SQLERRM||p_engine_model);
         END;
      --dbms_output.put_line('DownGrade Engin model..'||'..'||p_engine_model||'..Part..'||p_item_number||'..'||p_business_entity||'..'||p_eis_data_stream||'..'||v_check);

  IF v_check > 0 THEN


 	FOR sb_data_rec in sb_data_cur (p_item_number, p_engine_model)
	LOOP
       v_organization_id 				:= NULL;
       v_old_item_id     				:= NULL;
       v_new_item_id						:= NULL;
       v_sb_snum								:= NULL;
       v_sb_matl_disp_cd				:= NULL;
       v_sb_intrchngblty_cd			:= NULL;
       v_control_shippable_ret	:= NULL;
       v_control_ship_app				:= NULL;
       v_new_item_ship_code			:= NULL;
       v_old_item_ship_code			:= NULL;
       v_assign_data						:= NULL;


		--\* Get the SB NUMBER and SB Material Disposition code FOR the cursor record *\

		BEGIN
			    SELECT	service_bulletin_snum,
				          sb_matl_disp_cd,
			          	sb_intrchngblty_cd
			     INTO	  v_sb_snum,
			          	v_sb_matl_disp_cd,
			           	v_sb_intrchngblty_cd
			     FROM   geae_mtl_ebom_sb_data
			     WHERE   1 = 1
			      AND    old_part_number IS NOT NULL
	          AND     new_part_number IS NOT NULL
			      AND     bus_enty_cd = p_business_entity
	          AND     src_cd = p_eis_data_stream
			      AND     old_part_number = sb_data_rec.old_part_number
			      AND     new_part_number = sb_data_rec.new_part_number
			      AND     engine_model = sb_data_rec.engine_model
			      AND     TRUNC (sb_issue_date) = TRUNC(sb_data_rec.sb_dg_date)
			      AND     ROWNUM=1;
	 EXCEPTION
		        WHEN NO_DATA_FOUND
		        THEN
			                 v_sb_snum := NULL;
			              v_sb_matl_disp_cd := NULL;
	  END;

		--\* Get the inventory_item_ids FOR the old_part_number and the new_part_number *\
		BEGIN
			SELECT	msi1.inventory_item_id,
				      msi2.inventory_item_id
			  INTO	v_old_item_id,
			       	v_new_item_id
			 FROM	  mtl_system_items_b msi1,
			     	   mtl_system_items_b msi2
			 WHERE   msi1.segment1 = sb_data_rec.old_part_number
			  AND	   msi1.organization_id = p_organization_id
			  AND	   msi2.segment1 = sb_data_rec.new_part_number
			  AND	   msi2.organization_id = p_organization_id;
		EXCEPTION
		WHEN NO_DATA_FOUND
		THEN
			NULL;
		END;

    v_organization_id := p_warehouse_id;

    v_control_ship_app := 'Y';

   IF (NVL(v_control_ship_app,'N')= 'Y') AND (NVL(v_sb_intrchngblty_cd,0) = '2') THEN

  v_old_item_ship_code := get_ship_codes_REP_USED (v_old_item_id,
						        sb_data_rec.engine_model,
										NULL,
										p_business_entity,
                    p_organization_id,
                    p_org_id
						       );
	v_new_item_ship_code := get_ship_codes_REP_USED (v_new_item_id,
							sb_data_rec.engine_model,
							NULL,
							p_business_entity,
              p_organization_id,
              p_org_id
							);


       IF v_old_item_ship_code='C' THEN
        EXIT;
       END IF;


  	v_remarks:= update_remarks_REP_USED (p_org_id	 						=> 	p_org_id ,
              			            p_ordered_item_id			=>	p_ordered_item_id,
              			            p_engine_model				=>  p_engine_model,
              			            p_item_number				  =>  p_item_number,
                                p_eis_data_stream		  =>  p_eis_data_stream,
			 									 				p_cust_account_id			=> 	NULL,
			 									 				p_business_entity			=>	p_business_entity,
			 									 			--	p_price_list_id				=> :query_find.price_list_id,
			 									 				p_inv_ship_lookup			=>	p_inv_ship_lookup,
			 									 				p_control_ship_app		=>	v_control_ship_app,
			 									 				p_substitution_type  	=> 	'DOWNGRADE',
			 									 				p_old_item_id					=>	v_old_item_id,
			 									 				p_new_item_id					=>	v_new_item_id,
			 									 				p_old_item_ship_code  =>  v_old_item_ship_code,
			 									 				p_new_item_ship_code  =>  v_new_item_ship_code,
			 									 				p_ic_code 						=>	v_sb_intrchngblty_cd,
			 									 				p_eis_sequence				=>  -1* sb_data_rec.level,
                                p_conservative_flag   =>  g_conservative_flag,
                                p_organization_id     =>  p_organization_id,
                                p_dg_prefs           =>   p_dg_prefs,
			                         	p_ug_prefs            =>   p_ug_prefs,
			                         	p_alt_prefs           =>   p_alt_prefs,
			 									 				p_error_code					=>	v_error_code);


       IF (NVL(v_error_code,'INCLUDE') <> 'EXCLUDE') THEN

        	EIS_ASSIGN_DATA_REP_USED(p_engine_model 			=>	sb_data_rec.engine_model,
												p_sb_snum 						=>	v_sb_snum,
												p_sb_dg_date 					=> 	sb_data_rec.sb_dg_date,
												p_sub_type 						=>	'DOWNGRADE',--'D'||-1 * sb_data_rec.level,
												p_old_item_id 				=> 	v_old_item_id,
												p_old_part_number 		=>	sb_data_rec.old_part_number,
												p_old_item_ship_code 	=>	v_old_item_ship_code,
												p_new_item_id 				=>	v_new_item_id,
												p_new_part_number 		=>	sb_data_rec.new_part_number,
												p_new_item_ship_code 	=>	v_new_item_ship_code,
												p_ic_code 						=>	v_sb_intrchngblty_cd,
												p_ordered_item_id 		=>	p_ordered_item_id,
                        p_order_part_number 	=>  p_item_number,
												p_substitution_type 	=>	'DOWNGRADE',
												p_org_id							=>	p_org_id,
												p_organization_id			=>  p_organization_id,
												p_error_code					=>	v_error_code,
												p_remarks							=>  v_remarks ,
                        p_business_entity     =>  p_business_entity
                       ,p_cust_account_id     =>  NULL,
                        p_list_header_id      =>  p_list_header_id  ,
                        p_cust_code           =>  p_cust_code,
                        p_Engine_family       =>  p_Engine_family,
                        p_product_line        =>  p_product_line,
                        p_altlevel            =>  'D'||-1 * sb_data_rec.level,
                        p_part_hist_info4     =>  p_part_inf4
												);


  part_hist_cnt4 := p_part_hist_info2.count;
  part_cnt4 := p_part_inf4.count;
  p_part_hist_info2.EXTEND(part_cnt4);

  FOR i in 1 .. part_cnt4 loop
     p_part_hist_info2(part_hist_cnt4 + i) := p_part_inf4(i);
  END LOOP;

  IF v_sb_intrchngblty_cd = '2'
		THEN

			insert_alt_part_REP_USED(v_organization_id,
					p_cust_account_id,
					p_ship_to_org_id,
					p_order_line_id,
					p_item_number,
					sb_data_rec.old_part_number,
					sb_data_rec.new_part_number,
					p_engine_model,
					sb_data_rec.sb_dg_date,
					'DOWNGRADE ALT',
					'D'||-1 * sb_data_rec.level, -- g_eis_seq
					p_business_entity,
					p_eis_data_stream,
					p_inv_ship_lookup,
					p_org_id,
         -- p_ordered_item_id,
          p_conservative_flag ,
          p_list_header_id,
          p_cust_code           ,
          p_organization_id,
          p_dg_prefs          ,
			    p_ug_prefs       ,
			   	p_alt_prefs     ,
          p_Engine_family ,
          p_product_line ,
          p_part_inf2
					  );

  part_hist_cnt2 := p_part_hist_info2.count;
  part_cnt2 := p_part_inf2.count;
  p_part_hist_info2.EXTEND(part_cnt2);

  FOR i in 1 .. part_cnt2 loop
      p_part_hist_info2(part_hist_cnt2 + i) := p_part_inf2(i);
  END LOOP;

		END IF;
    END IF; -- Remarks If codition END
    --dbms_output.put_line('DownGrade Engin model Record status..'||'..'||p_engine_model||'..'||v_error_code);
    END IF; -- Control shippable and intrchngblty_cd check end if

 	END LOOP;
	-- FIRST_RECORD;
  END IF;
	RETURN 0;
EXCEPTION
WHEN OTHERS
THEN
 -- message(sqlerrm);
	RETURN 1;
END eis_downgrd_recursive_REP_USED;


-----------------------------------------------


FUNCTION get_ship_codes_REP_USED ( p_inventory_item_id in NUMBER,
													p_engine_model in VARCHAR2,
													p_bill_sequence_id in NUMBER DEFAULT NULL,
													p_business_entity	in VARCHAR2,
                          P_organization_id in NUMBER,
                          p_org_id							in  NUMBER)
RETURN VARCHAR2
IS
	v_ship_code   bom_components_b.attribute5%TYPE:= NULL;
BEGIN
	IF (p_bill_sequence_id IS NOT NULL AND p_inventory_item_id IS NOT NULL)
		THEN
		SELECT	bc.attribute5
			INTO	v_ship_code
			FROM	bom_components_b bc
		 WHERE	bc.bill_sequence_id = p_bill_sequence_id
			 AND	nvl(bc.disable_date,sysdate) >= sysdate
			 AND	bc.component_item_id = p_inventory_item_id;
	ELSE
		SELECT	max(bc.attribute5)
		  INTO	v_ship_code
		  FROM	bom_components_b bc,
						bom_structures_b bs,
						mtl_system_items_b msib
		 WHERE	bc.bill_sequence_id = bs.bill_sequence_id
		   AND	bc.component_item_id = p_inventory_item_id
		   AND	msib.inventory_item_id = bs.assembly_item_id
		   AND	msib.organization_id = bs.organization_id
		   AND  msib.segment1 = p_engine_model
		   AND  bs.attribute12 = DECODE(p_business_entity,'IAD','AES',p_business_entity)
		   AND	msib.organization_id = P_organization_id--Oe_Sys_Parameters.value('MASTER_ORGANIZATION_ID',Fnd_Profile.value(p_org_Id))
		   AND	msib.item_type = 'AEM';
	END IF;

	RETURN v_ship_code;

EXCEPTION
WHEN OTHERS
THEN
	RETURN v_ship_code;
END get_ship_codes_REP_USED;


FUNCTION update_remarks_REP_USED (p_org_id							in 	NUMBER,
                         p_ordered_item_id		in 	NUMBER,
                         p_engine_model				in  VARCHAR2,
                         p_item_number				in  VARCHAR2,
                         p_eis_data_stream		in  VARCHAR2,
			 									 p_cust_account_id		in 	NUMBER,
			 									 p_business_entity		in 	VARCHAR2,
			 							--		 p_price_list_id			in 	NUMBER,
			 									 p_inv_ship_lookup		in 	VARCHAR2,
			 									 p_control_ship_app		in 	VARCHAR2,
			 									 p_substitution_type	in 	VARCHAR2,
			 									 p_old_item_id				in 	NUMBER,
			 									 p_new_item_id				in 	NUMBER,
			 									 p_old_item_ship_code in  VARCHAR2,
			 									 p_new_item_ship_code in  VARCHAR2,
			 									 p_ic_code 						in 	VARCHAR2,
			 									 p_eis_sequence				in  NUMBER,
                         p_conservative_flag  in  VARCHAR2,
                         p_organization_id    in NUMBER,
                         p_dg_prefs         in   NUMBER,
			                   p_ug_prefs        in   NUMBER,
				                 p_alt_prefs        in   VARCHAR2,
			 									 p_error_code 				OUT  VARCHAR2)
  RETURN VARCHAR2
IS

  v_remarks								geae_mtl_related_items.remarks%TYPE:=NULL;
  --v_conservative_flag   	VARCHAR2(1) := 'N';
  v_conservative_flag_du 	VARCHAR2(1) := NULL;
  v_valid_ship_code 			VARCHAR2(10);
  v_subs_type							NUMBER;
  v_otr_process_dffs			hz_cust_accounts.attribute1%TYPE;
 --p_error_code						geae_mtl_related_items.error_code%TYPE := NULL  ;
  v_upq_ordered_item			QP_LIST_LinES_V.ATTRIBUTE3%TYPE ;
  v_upq_old_item					QP_LIST_LinES_V.ATTRIBUTE3%TYPE ;
  v_upq_new_item					QP_LIST_LinES_V.ATTRIBUTE3%TYPE ;
  v_pricing_date					OE_ORDER_LinES.PRICinG_DATE%TYPE ;
  v_price_list_id					OE_ORDER_LinES.PRICE_LIST_ID%TYPE ;
  v_ship_code							bom_inventory_components.attribute5%TYPE := NULL;
  v_upq_validate					CHAR;
  v_price_out     				NUMBER;
  v_customer_prefs 				VARCHAR2(10);
  v_rel_type_code      	 	NUMBER;
  v_global_org_id       	NUMBER;
  v_organization_id_tmp 	NUMBER;
  v_chk_cust_ref       		NUMBER;
  v_price_ord_item   			NUMBER;
  v_price_old_item   			NUMBER;
  v_price_new_item   			NUMBER;
  v_site_use_id           NUMBER;

BEGIN  -- Main 1



	v_global_org_id 		:= 	geae_mtl_util_pkg.get_global_org_id;
  v_rel_type_code 		:= 	get_rel_type_REP_USED ('SUBSTITUTE');

/* v_customer_prefs		:=	customer_prefs (p_cust_account_id		=> 	p_cust_account_id,
                  												p_substitution_type	=> 	p_substitution_type,
			  																	p_eis_sequence			=>	p_eis_sequence,
                                          p_dg_prefs          =>  p_dg_prefs,
                                          p_ug_prefs          =>  p_ug_prefs,
                                          p_alt_prefs          =>  p_alt_prefs
                                        );*/
 -- COMMENTED for MYJIRATEST-4033



	BEGIN  -- Main 2
				v_remarks 						:= NULL;
				p_error_code 					:= NULL ;
        v_organization_id_tmp := -1;

   	IF NVL(p_control_ship_app,'N') ='N'
		THEN
					v_remarks := 'CONTROL SHIP EXCLUDE';
					p_error_code := 'EXCLUDE';
		END IF;

/*		IF (NVL(p_control_ship_app,'N') ='Y' AND NVL(v_customer_prefs,'N') ='N')
    THEN
          v_remarks := 'CUSTOMER PREFERENCES EXCLUDE';
          p_error_code := 'EXCLUDE';  -- COMMENTED for MYJIRATEST-4033
    END IF;*/

         -- Conservative Flag

				 IF (NVL(p_control_ship_app,'N') ='Y' AND
                   -- NVL(v_customer_prefs,'N') ='Y' AND   -- COMMENTED for MYJIRATEST-4033
                                    NVL(P_conservative_flag,'N') ='N' AND
                                          g_subs_profile_value <> 'Y')
         THEN
                   v_remarks := 'PN/CUST/MOD COMBO NOT 100% EQUIVALENT' ;
                   p_error_code := 'EXCLUDE';

         END IF;

	  		IF (p_substitution_type = 'DOWNGRADE' AND  p_ic_code <> '2')
				THEN
							v_remarks := 'DOWNGRADE TRAIL STOPPER';
							p_error_code := 'EXCLUDE';
    		END IF;


IF (NVL(p_error_code,'INCLUDE') <> 'EXCLUDE')THEN

    BEGIN
    SELECT	MAX(bic.attribute5)
		INTO	v_ship_code
		FROM	mtl_system_items_b msib,
					bom_inventory_components bic,
					bom_bill_of_materials bom ,
          fnd_lookup_values fv
	WHERE		1=1
		AND   msib.segment1=   p_engine_model
		AND		msib.organization_id	= bom.organization_id
		AND		msib.organization_id	=p_organization_id-- Oe_Sys_Parameters.value('MASTER_ORGANIZATION_ID',Fnd_Profile.value(p_org_Id))
		AND		bom.organization_id	= msib.organization_id
		AND		bom.assembly_item_id	= msib.inventory_item_id
		AND		bic.bill_sequence_id	= bom.bill_sequence_id
		AND		bom.attribute12		= DECODE(p_business_entity,'IAD','AES',p_business_entity)
		AND		bic.attribute5 NOT in(select 	lookup_code
																	FROM 	FND_LOOKUP_VALUES
                                	WHERE LOOKUP_TYPE= p_inv_ship_lookup)
	 	AND		bic.component_item_id	= p_ordered_item_id
    AND   fv.lookup_type='GEAE_MYGE_SUPPLIER_ORGS'
    AND   fv.description =to_char(p_org_id)
    AND   fv.meaning = bom.attribute8  ;
    EXCEPTION
    WHEN  OTHERS THEN
    v_ship_code:= NULL;
    END;
END IF;

				/* Updating Remarks FOR Downgrades and Upgrades FOR GEAE_MTL_REL_ITEMS_PKG*/
				-- Remarks FOR GEAE_MTL_REL_ITEMS_PKG
				-- Remarks FOR Downgrade


				IF    p_substitution_type in ('DOWNGRADE','DOWNGRADE ALT','DUMMY ALT')
					AND p_control_ship_app='Y'
				--	AND v_customer_prefs = 'Y'
				 	AND NVL(p_ic_code,'2')='2'
				 	AND p_old_item_id != p_ordered_item_id
				 	AND nvl(p_error_code,'~') <> 'EXCLUDE'

				THEN

												IF v_remarks IS NULL
												THEN
														v_remarks := 'NOT INTERFACED TO EIS TABLE';
												END IF;
				          -- Validation FOR Conservative Flag FOR upgrades
												IF 			g_subs_profile_value = 'N'
												THEN
															  v_conservative_flag_du := P_conservative_flag;
			                  ELSE

			                          v_conservative_flag_du := 'Y';
			                  END IF; -- END of  Validation FOR Conservative Flag FOR upgrades
										BEGIN
													SELECT 'N'
								  					INTO  v_valid_ship_code
								  					FROM  fnd_lookup_values
								 					 WHERE  lookup_type=p_inv_ship_lookup
								   				   AND lookup_code=p_old_item_ship_code;

												EXCEPTION
														WHEN OTHERS THEN
														v_valid_ship_code:='Y';
										 END;


							IF  v_valid_ship_code='Y'  AND
								  p_old_item_ship_code IS NOT NULL
              THEN
                   		FOR rec_dg_code in (SELECT lookup_code
				              									FROM FND_LOOKUP_VALUES
                                       WHERE LOOKUP_TYPE=p_inv_ship_lookup
                                         AND v_remarks ='NOT INTERFACED TO EIS TABLE') LOOP

			     						IF  p_old_item_ship_code NOT in (rec_dg_code.lookup_code)

			     						THEN
			     								v_remarks := 'INTERFACED';
			     						END IF;
			     		   END LOOP;
              ELSE
										   	IF p_old_item_ship_code IS NULL AND v_remarks ='NOT INTERFACED TO EIS TABLE'
										   	THEN
													v_remarks 		:= 'NO SHIP CODE NOT INTERFACED';
													p_error_code 	:= 'EXCLUDE';
												END IF;


																FOR rec_dg_code in (SELECT lookup_code
					 	      																	  FROM FND_LOOKUP_VALUES
						     																		 WHERE LOOKUP_TYPE=p_inv_ship_lookup
						     																		   AND v_remarks ='NOT INTERFACED TO EIS TABLE') LOOP

																		IF  p_old_item_ship_code  in (rec_dg_code.lookup_code)
																		THEN
																				BEGIN
																							SELECT  DESCRIPTION
						  																	INTO  v_remarks
						  																	FROM  fnd_lookup_values
						 															 		 WHERE  lookup_type =p_inv_ship_lookup
						   															 		 AND  LOOKUP_CODE =p_old_item_ship_code;
							                                  p_error_code 	:= 'EXCLUDE';
																					EXCEPTION
		   																		 		WHEN OTHERS THEN
		   																		 		v_remarks:=NULL;
		   																	END;

																	   END IF;

																END LOOP;
                END IF;

			  END IF; -- END IF FOR downgrades

		    -- Remarks FOR GEAE_MTL_REL_ITEMS_PKG
				-- Remarks FOR Upgrades

				 		IF      p_substitution_type IN('UPGRADE','UPGRADE ALT')
								   AND p_control_ship_app = 'Y'
							--	AND v_customer_prefs = 'Y'
								AND p_new_item_id !=p_ordered_item_id
								AND nvl(p_error_code,'~') <> 'EXCLUDE'
 						THEN  -- IF FOR Upgrades

 											IF v_remarks IS NULL
												THEN
														v_remarks := 'NOT INTERFACED TO EIS TABLE';
											END IF;

 							   -- Validation FOR Conservative Flag FOR upgrades
 							   		IF 		 g_subs_profile_value = 'N'
										THEN
												  	v_conservative_flag_du := P_conservative_flag;
                  	ELSE

                            v_conservative_flag_du := 'Y';
                  	END IF;
                  -- END  Validation FOR Conservative Flag FOR upgrades

 							    SELECT  DECODE(inSTR(p_substitution_type, 'ALT'), 0,0,2)
 							      INTO  v_subs_type
 							      FROM  DUAL;

 									IF ((p_ic_code ='1') OR (p_ic_code ='2') OR (v_subs_type=0 OR v_subs_type =2) )
	 								THEN  -- if p_ic_code
	 										BEGIN
            								SELECT 'N'
				  										INTO  v_valid_ship_code
				  										FROM  fnd_lookup_values
				 										 WHERE  lookup_type=p_inv_ship_lookup
				   										 AND lookup_code=p_new_item_ship_code ;

														EXCEPTION
														WHEN OTHERS THEN
														v_valid_ship_code:='Y';
											END;
													IF  v_valid_ship_code='Y' AND p_new_item_ship_code IS NOT NULL  --if new_item_ship_code
                   				THEN
									 		FOR rec_ug_code in (SELECT lookup_code
						      																		FROM FND_LOOKUP_VALUES
                                                     WHERE LOOKUP_TYPE=p_inv_ship_lookup
                                                       AND v_remarks ='NOT INTERFACED TO EIS TABLE') LOOP

																			IF  p_new_item_ship_code NOT in (rec_ug_code.lookup_code) AND (p_ic_code in ('1','2') OR p_ic_code IS NULL)

																			THEN

																					v_remarks := 'INTERFACED';
																					p_error_code 	:= 'INCLUDE';

																			END IF;

																END LOOP;

                         ELSE
                               	IF p_old_item_ship_code IS NULL  AND v_remarks ='NOT INTERFACED TO EIS TABLE'
										   					THEN

																		v_remarks := 'NO SHIP CODE NOT INTERFACED';
																		p_error_code 	:= 'EXCLUDE';
																END IF;


																			FOR rec_ug_code in (SELECT lookup_code
			         		      																		FROM FND_LOOKUP_VALUES
						     																					 WHERE LOOKUP_TYPE=P_inv_ship_lookup
						     																					   AND v_remarks ='NOT INTERFACED TO EIS TABLE') LOOP

																					IF  p_new_item_ship_code  in (rec_ug_code.lookup_code)

																					THEN

																							BEGIN
																										SELECT DESCRIPTION
						  																				INTO v_remarks
						  																				FROM fnd_lookup_values
						 																		 		 WHERE lookup_type =p_inv_ship_lookup
						   																		 		 AND LOOKUP_CODE =p_new_item_ship_code;
						   																		 		 p_error_code 	:= 'EXCLUDE';
						   																		 	EXCEPTION
						   																		 		WHEN OTHERS THEN
						   																		 		v_remarks:=NULL;
						   																END;

																					END IF;

				 															END LOOP;

								 					END IF;  -- END if new_item_ship_code
								 	ELSE
													v_remarks:='IC CODE VALUE IS GREATER THAN 2';
								 	END IF;   -- END if p_ic_code

						END IF;


						RETURN v_remarks;

        END;  -- Main 2

EXCEPTION
   WHEN OTHERS
   THEN
      RETURN v_remarks;
END update_remarks_REP_USED; -- Main 1

PROCEDURE  eis_assign_data_REP_USED (p_engine_model 				in 	VARCHAR2,
													p_sb_snum 						in 	VARCHAR2,
													p_sb_dg_date 					in 	DATE,
													p_sub_type 						in 	VARCHAR2,
													p_old_item_id  				in 	NUMBER,
													p_old_part_number 		in 	VARCHAR2,
													p_old_item_ship_code 	in 	VARCHAR2,
													p_new_item_id 				in 	NUMBER,
													p_new_part_number 		in 	VARCHAR2,
													p_new_item_ship_code 	in 	VARCHAR2,
													p_ic_code 						in 	VARCHAR2,
													p_ordered_item_id 		in 	NUMBER,
                          p_order_part_number 		in 	VARCHAR2,
													p_substitution_type 	in 	VARCHAR2,
													p_org_id							in  NUMBER,
													p_organization_id			in  NUMBER,
													p_error_code					in  VARCHAR2,
													p_remarks							in  VARCHAR2
                         ,p_business_entity    in  VARCHAR2,
                          p_cust_account_id     in  NUMBER,
                          p_list_header_id    in  NUMBER,
                          p_cust_code              in VARCHAR2,
                          p_Engine_family    IN   VARCHAR2,
                          p_product_line     IN   VARCHAR2,
                          p_altlevel         IN   VARCHAR2,
                          p_part_hist_info4  OUT PART_HISTORY_inFO_ARRAY
											)
as


v_price_out VARCHAR2(15) ;
v_upq       VARCHAR2(15) ;
v_price_check  VARCHAR2(2);
v_org_id    NUMBER  := NULL;
v_count  NUMBER :=0;
v_snum   VARCHAR2(2) ;
v_snum_len NUMBER :=0;
v_serb_first VARCHAR2(30);
v_serb_last VARCHAR2(30);
V_AVL_QTY   NUMBER :=0;
v_alternate_part VARCHAR2(30);
v_original_part  VARCHAR2(30);
v_price_list_name qp_list_headers_tl.name%TYPE;
v_list_header_id  qp_list_headers_tl.list_header_id%TYPE;
v_list_dummy_id  qp_list_headers_tl.list_header_id%TYPE;
v_alternate_item_id  	NUMBER;
v_ser_bul_num varchar2(100);
v_sb_intercd  VARCHAR2(20);
v_project     VARCHAR2(40);
v_GEK         VARCHAR2(40);
v_Techpubs    VARCHAR2(40);

	BEGIN
    p_part_hist_info4         := PART_HISTORY_inFO_ARRAY();

    v_price_check  := NULL;
/*  IF p_sb_snum IS NOT NULL THEN
  v_ser_bul_numdate:= p_sb_snum||','||TO_CHAR(p_sb_dg_date,'DD/MM/YY');
  END IF;*/  -- Commented for  MYJIRATEST-4033

IF p_sb_snum IS NOT NULL THEN
     BEGIN
      SELECT 'A'
      INTO v_snum
      FROM DUAL
      WHERE  REGEXP_LIKE(p_sb_snum, ' ');
     EXCEPTION
      WHEN OTHERS THEN
      v_snum := NULL;
     END;
IF v_snum  IS NOT NULL THEN
    v_ser_bul_num:= p_sb_snum;
ELSE
 BEGIN
  v_snum_len := LENGTh(p_sb_snum);
  SELECT SUBSTR(p_sb_snum,1,v_snum_len-3) INTO v_serb_first FROM DUAL ;
  SELECT substr(p_sb_snum,v_snum_len-2) INTO  v_serb_last  FROM DUAL ;
  SELECT DECODE(SUBSTR(p_sb_snum,v_snum_len-2,1),'R', v_serb_first||' '||v_serb_last,p_sb_snum) INTO v_ser_bul_num FROM  DUAL;
 -- SELECT DECODE(SUBSTR(p_sb_snum,v_snum_len-2,1),'R', v_ser_bul_num:=SUBSTR(p_sb_snum,1,v_snum_len-3)||' '||substr(p_sb_snum,v_snum_len-2),v_ser_bul_num:=p_sb_snum) from dual;
  EXCEPTION
  WHEN OTHERS THEN
    v_ser_bul_num := p_sb_snum;
  END;
 END IF;

END IF;

 BEGIN
 SELECT meaning
 INTO  v_sb_intercd
 FROM fnd_lookup_values A
 WHERE lookup_type='GEAE_MYGE_ITM_CNFG_SB_INTERCD'
 AND   A.LOOKUP_CODE=p_ic_code;
  EXCEPTION
  WHEN OTHERS THEN
    v_sb_intercd := NULL;
  END;

  BEGIN
 SELECT meaning
 INTO  v_project
 FROM fnd_lookup_values b
 WHERE lookup_type='GEAE_MYGE_ITM_CNFG_PRODUCT'
 AND   b.LOOKUP_CODE=p_engine_model
 AND   b.description=p_product_line;
 EXCEPTION
  WHEN OTHERS THEN
    v_project := null;
  END;


  BEGIN
  SELECT description,  tag
  INTO   v_GEK , v_Techpubs
  FROM fnd_lookup_values
  WHERE lookup_type = 'GEAE_MYGE_GEK_MAPPING'
  AND   attribute1 = p_Engine_family
  AND   attribute2 = p_product_line
  AND   lookup_code = p_engine_model;
   EXCEPTION
  WHEN OTHERS THEN
  v_GEK := null;
  v_Techpubs := null;
  END;

   If p_substitution_type = 'DOWNGRADE' OR p_substitution_type = 'DOWNGRADE ALT' OR p_substitution_type = 'DUMMY ALT'
   Then

				v_alternate_part    := p_old_part_number;
        v_alternate_item_id := p_old_item_id;
        v_original_part     := p_new_part_number;


     BEGIN
                  SELECT SUM(nvl(GET_AVL_TO_RESERVE_REP_USED(GET_ORG_ID_REP_USED(flv.tag),p_old_item_id),0)) INTO V_AVL_QTY
		               FROM 	FND_LOOKUP_VALUES flv, hr_operating_units hou
                   WHERE  flv.LOOKUP_TYPE='GEAE_MYGE_PART_APPLICABLE_ORGS'-- 'GEAE_MYAVATION_ITEM_CONFIG_ORG'
                     AND  flv.description = hou.name
                     AND  hou.organization_id = p_org_id;




		 EXCEPTION
    WHEN OTHERS THEN
                     V_AVL_QTY:= NULL;
    END;


				 v_upq := GET_UPQ_PRICE_REP_USED(p_old_item_id,SYSDATE,p_list_header_id,v_price_out);

      -- DBMS_output.put_line('Business..'||p_business_entity||'..p_org_id..'||p_org_id||'..Item Id..'||p_old_item_id||'..ORder Item.'||p_old_part_number||'..V_Price..'||v_price_out ||'Price list id..'||p_list_header_id);


	       SELECT decode(sign(v_upq),-1,NULL,v_upq)
				 INTO v_upq
				 FROM DUAL;


  ELSIF p_substitution_type = 'UPGRADE' OR  p_substitution_type = 'UPGRADE ALT'
      THEN

    	v_alternate_part    := p_new_part_number;
      v_alternate_item_id := p_new_item_id;
      v_original_part     := p_old_part_number;


    BEGIN
                  SELECT SUM(nvl(GET_AVL_TO_RESERVE_REP_USED(GET_ORG_ID_REP_USED(flv.tag),p_new_item_id),0)) INTO V_AVL_QTY
		               FROM 	FND_LOOKUP_VALUES flv, hr_operating_units hou
                   WHERE  flv.LOOKUP_TYPE='GEAE_MYGE_PART_APPLICABLE_ORGS'-- 'GEAE_MYAVATION_ITEM_CONFIG_ORG'
                     AND  flv.description = hou.name
                     AND  hou.organization_id = p_org_id;

		 EXCEPTION
    WHEN OTHERS THEN
                     V_AVL_QTY:= NULL;

    END;

				v_upq :=GET_UPQ_PRICE_REP_USED(p_new_item_id,SYSDATE,p_list_header_id,v_price_out);

        --  DBMS_output.put_line('Upgrade Business..'||p_business_entity||'..p_org_id..'||p_org_id||'..Item Id..'||p_new_item_id||'..ORder Item.'||p_new_part_number||'..V_Price..'||v_price_out ||'Price list id..'||v_list_header_id);


				SELECT decode(sign(v_upq),-1,NULL,v_upq)
				INTO v_upq
				FROM DUAL;

  END If;

 p_part_hist_info4.EXTEND();
 p_part_hist_info4(p_part_hist_info4.last):=PART_HISTORY_inFO(v_alternate_item_id, p_order_part_number, v_price_out, V_AVL_QTY, v_upq ,v_ser_bul_num,v_alternate_part,p_sub_type,p_engine_model,p_cust_code,TO_CHAR(p_sb_dg_date,'DD/MM/YY'),v_sb_intercd,p_product_line,p_Engine_family,v_project,p_altlevel,v_original_part,v_GEK,v_Techpubs);
 v_alternate_part :=NULL;
 v_list_header_id :=NULL;
 v_upq := NULL;
 v_price_out := NULL;
 V_AVL_QTY := NULL;
 v_project := NULL;
 v_sb_intercd := NULL;
 v_ser_bul_num := NULL;
 v_serb_first  := NULL;
 v_serb_last  := NULL;
 v_GEK := null;
 v_Techpubs := null;
EXCEPTION
when others then
dbms_output.put_line( 'Error..'||SQLERRM);
END eis_assign_data_REP_USED;

FUNCTION get_avl_to_reserve_REP_USED(p_organization_id NUMBER,
				       							p_inventory_item_id NUMBER)
RETURN NUMBER IS
   l_qty_on_hand           NUMBER;
   l_qty_reserved          NUMBER;
   l_avail_to_reserve      NUMBER := 0;
   v_org_code              VARCHAR2(100);
BEGIN

SELECT ORGANIZATION_CODE INTO V_ORG_CODE
FROM MTL_PARAMETERS
WHERE ORGANIZATION_ID= p_organization_id;
--  MYJIRATEST-3172  If condition added for SDC qty
--IF v_org_code ='SDC' THEN  /*Commented by Capgemini Team for AMPS Customization*/
IF v_org_code IN ('SDC','CPL') THEN /*Added CPL by Capgemini Team for AMPS Customization*/
SELECT NVL(sum(transaction_quantity),0)
  INTO	l_qty_on_hand
  FROM	geae_inv_mtl_onhands_v
 WHERE	inventory_item_id = p_inventory_item_id
   AND	organization_id   = p_organization_id;

   ELSE

SELECT	NVL(sum(DECODE(subinventory_code,'FG',transaction_quantity,'MS-FG',transaction_quantity,'STAGE',transaction_quantity,0)),0)
  INTO	l_qty_on_hand
  FROM	geae_inv_mtl_onhands_v
 WHERE	inventory_item_id = p_inventory_item_id
   AND	organization_id   = p_organization_id;
END IF;

SELECT	NVL(sum(mr.reservation_quantity),0)
  INTO	l_qty_reserved
  FROM	mtl_reservations mr
 WHERE	mr.inventory_item_id = p_inventory_item_id
   AND	mr.organization_id = p_organization_id;

		l_avail_to_reserve := l_qty_on_hand - l_qty_reserved;
    V_ORG_CODE := NULL;
	RETURN(l_avail_to_reserve);
EXCEPTION
   WHEN OTHERS
   THEN
      RETURN(l_avail_to_reserve);
END;


FUNCTION get_rel_type_REP_USED ( p_relationship_type      in   VARCHAR2
   )
      RETURN NUMBER  IS
   v_rel_code NUMBER;
BEGIN
      SELECT  lookup_code
            INTO  v_rel_code
        FROM  mfg_lookups
       WHERE  lookup_type = 'MTL_RELATIONSHIP_TYPES'
         AND  enabled_flag = 'Y'
         AND  UPPER(MEANinG) = p_relationship_type;
      return v_rel_code;
EXCEPTION
   WHEN OTHERS
   THEN
     -- fnd_file.put_line(fnd_file.log,'ERROR ' ||SQLERRM);
   return NULL;

END;

FUNCTION get_upq_price_REP_USED (p_ordered_item_id 	in 	NUMBER
                        ,p_pricing_date 		in 	DATE
                        ,p_price_list_id 		in 	NUMBER
                        ,p_list_price 			OUT VARCHAR2)
    RETURN VARCHAR2
    IS
    v_upq VARCHAR2(240) ;
    v_list_price NUMBER := NULL;
    BEGIN
          BEGIN
          SELECT ATTRIBUTE3 UPQ,round(to_number(OPERAND),2)
          INTO   v_upq,v_list_price
          FROM   qp_list_lines_v
          WHERE
          ARITHMETIC_OPERATOR='UNIT_PRICE'
          AND PRODUCT_ATTRIBUTE_CONTEXT='ITEM'
          AND PRODUCT_ATTRIBUTE='PRICING_ATTRIBUTE1'
          AND PRODUCT_ATTR_VALUE=To_Char(p_ordered_item_id)
          AND (
               TRUNC ( p_pricing_date ) BETWEEN TRUNC ( NVL ( START_DATE_ACTIVE, p_pricing_date - 1 ) ) AND TRUNC ( NVL ( END_DATE_ACTIVE, p_pricing_date + 1 ) )
              )
          AND LIST_HEADER_ID=p_price_list_id ;
          EXCEPTION
          WHEN No_Data_Found
          THEN
             --  v_upq := '0'; -- Commented for MYJIRATEST-4465
                 v_upq := NULL;
          WHEN OTHERS
          THEN
           -- v_upq := '0'; -- Commented for MYJIRATEST-4465
              v_upq := NULL;
          END ;
          p_list_price := v_list_price;
    RETURN v_upq ;
   END  GET_UPQ_PRICE_REP_USED  ;

FUNCTION get_org_id_REP_USED(P_ORG_CODE in VARCHAR2) RETURN NUMBER IS
v_organization_id NUMBER := NULL;
BEGIN
    SELECT ORGANIZATION_ID
      INTO v_organization_id
      FROM mtl_parameters
     WHERE ORGANIZATION_CODE = P_ORG_CODE;
      RETURN v_organization_id;
EXCEPTION
	WHEN NO_DATA_FOUND THEN
	 RETURN v_organization_id;
END;


PROCEDURE insert_alt_part_REP_USED(p_organization_id       NUMBER,
												  p_cust_account_id       NUMBER,
												  p_ship_to_org_id        NUMBER,
												  p_order_line_id         NUMBER,
												  p_ordered_part_number   VARCHAR2,
												  p_old_part_number       VARCHAR2,
												  p_new_part_number       VARCHAR2,
												  p_engine_model          VARCHAR2,
												  p_sb_date               DATE,
												  p_substitution_type     VARCHAR2,
												  g_eis_seq               VARCHAR2,
												  p_business_entity				VARCHAR2,
												  p_eis_data_stream				VARCHAR2,
												  p_inv_ship_lookup   in   VARCHAR2,
												  p_org_id								NUMBER ,
                        --  p_ordered_item_id       NUMBER,
                          p_conservative_flag in  VARCHAR2,
                          p_list_header_id    in  NUMBER,
                           p_cust_code              VARCHAR2,
                           p_wharehouse_id       NUMBER,
                          p_dg_prefs         in   NUMBER,
		                     	p_ug_prefs        in   NUMBER,
			                   	p_alt_prefs        in   VARCHAR2,
                          p_Engine_family    IN   VARCHAR2,
                          p_product_line     IN   VARCHAR2,
                          p_part_hist_info3  OUT PART_HISTORY_inFO_ARRAY
											  )
IS

--	\* Return from the insert_eis function *\
	v_insert_eis_return    NUMBER;
	v_ordered_item_id      NUMBER;
	v_part_number          VARCHAR2(40);
	v_item_id              NUMBER;
	v_item_ship_code       VARCHAR2(150);
	v_old_item_number      VARCHAR2(40);
	v_old_item_id          NUMBER;
	v_new_item_number      VARCHAR2(40);
	v_new_item_id          NUMBER;
	v_old_item_ship_code   VARCHAR2(150);
	v_new_item_ship_code   VARCHAR2(150);
	v_control_ship_app     VARCHAR2(1);
	v_sub_type							VARCHAR2(30);
	v_control_shippable_ret NUMBER;
  v_remarks               VARCHAR2(100);
  v_error_code       	VARCHAR2(100);
  v_assign_data       NUMBER;
  	-- iCounter2                   integer:=1;
  part_hist_cnt5             integer;
  part_cnt5                  integer;

--	\* Cursor to get the alternates FOR the Downgrades and Upgrades from the SB alt part table *\

CURSOR get_alt_part_cur(p_part_number  VARCHAR2,
			p_engine_model VARCHAR2,p_business_enty_cd VARCHAR2)
IS
SELECT	part_number,
				alt_part_number
  FROM	geae_mtl_ebom_alt_data
 WHERE	1=1
   AND  bus_enty_cd = p_business_entity
   AND  part_number = p_part_number
   AND  engine_model = p_engine_model
   order by geae_mtl_ebom_alt_data_seq_id;

BEGIN

 p_part_hist_info3         := PART_HISTORY_inFO_ARRAY();
--	\* IF substitution_type is Downgrade Alt or Dummy Alt, then get the alternates FOR the old_part by passing it to the cursor *\
--	\* in this case, the alternate will be FOR the old_part which is the Downgrade *\


	IF p_substitution_type = 'DOWNGRADE ALT' OR p_substitution_type = 'DUMMY ALT'
	THEN
		v_part_number := p_old_part_number;
	END IF;

	--\* IF substitution_type is Upgrade Alt, then get the alternates FOR the new_part by passing it to the cursor *\
--	\* in this case, the alternate will be FOR the new_part which is the Upgrade *\

	IF p_substitution_type = 'UPGRADE ALT'
	THEN
		v_part_number := p_new_part_number;
	END IF;

	FOR get_alt_part_rec in get_alt_part_cur(v_part_number,
						 															 p_engine_model,
						 															 p_business_entity)
	LOOP

				v_old_item_number 			:= NULL;
				v_new_item_number				:= NULL;
				v_ordered_item_id 			:= NULL;
				v_old_item_id						:= NULL;
				v_new_item_id						:= NULL;
				v_old_item_ship_code		:= NULL;
				v_new_item_ship_code  	:= NULL;
				v_control_shippable_ret	:= NULL;
				v_control_ship_app			:= NULL;
				v_sub_type							:= NULL;


	--	\* IF substitution_type is Downgrade Alt or Dummy Alt, then populate the old_item_number and New_item_number from the cursor record *\

		IF p_substitution_type = 'DOWNGRADE ALT' OR p_substitution_type = 'DUMMY ALT'
		THEN
			v_old_item_number := get_alt_part_rec.alt_part_number;
			v_new_item_number := p_new_part_number;
		END IF;

		IF p_substitution_type = 'UPGRADE ALT'
		THEN
			v_old_item_number := p_old_part_number;
			v_new_item_number := get_alt_part_rec.alt_part_number;
		END IF;
	--	\* Get the inventory_item_ids *\
    IF p_substitution_type = 'DOWNGRADE ALT' OR p_substitution_type = 'UPGRADE ALT' THEN

    BEGIN
			SELECT	msi1.inventory_item_id,
							msi2.inventory_item_id,
							msi3.inventory_item_id
			  INTO	v_ordered_item_id,
							v_old_item_id,
							v_new_item_id
			  FROM	mtl_system_items_b msi1,
							mtl_system_items_b msi2,
							mtl_system_items_b msi3
			 WHERE	1 = 1
			   AND	msi1.segment1 = p_ordered_part_number
			   AND	msi1.organization_id = p_wharehouse_id
			   AND	msi2.segment1 = v_old_item_number
			   AND	msi2.organization_id =p_wharehouse_id
			   AND	msi3.segment1 = v_new_item_number
			   AND	msi3.organization_id = p_wharehouse_id;
		EXCEPTION
		WHEN NO_DATA_FOUND
		THEN
			NULL;
		END;
    ELSE
		BEGIN
			SELECT	msi1.inventory_item_id,
							msi2.inventory_item_id,
							msi3.inventory_item_id
			  INTO	v_ordered_item_id,
							v_old_item_id,
							v_new_item_id
			  FROM	mtl_system_items_b msi1,
							mtl_system_items_b msi2,
							mtl_system_items_b msi3
			 WHERE	1 = 1
			   AND	msi1.segment1 = p_ordered_part_number
			   AND	msi1.organization_id = p_organization_id
			   AND	msi2.segment1 = v_old_item_number
			   AND	msi2.organization_id =p_organization_id
			   AND	msi3.segment1 = v_new_item_number
			   AND	msi3.organization_id = p_organization_id;
		EXCEPTION
		WHEN NO_DATA_FOUND
		THEN
			NULL;
		END;
    END IF;

	v_control_ship_app := 'Y';

     IF (NVL(v_control_ship_app,'N')= 'Y')THEN

	--\* Get the ship codes FOR the Alternates *\
	/*	v_old_item_ship_code := get_ship_codes (v_old_item_id,
																						p_engine_model,
																						NULL,
																						p_business_entity,
                                            p_wharehouse_id,
                                            p_org_id
																						);

		v_new_item_ship_code := get_ship_codes (v_new_item_id,
																						p_engine_model,
																						NULL,
																						p_business_entity,
                                            p_wharehouse_id,
                                            p_org_id
																						);*/  -- Performance

 -- Old item ship to code is not used in update remarks function for UPGRADE and UPGRADE ALT process, so Above logic is implemented in below condition

 	 IF p_substitution_type = 'DOWNGRADE ALT' OR p_substitution_type = 'DUMMY ALT'
		THEN

    v_old_item_ship_code := get_ship_codes_REP_USED (v_old_item_id,
																						p_engine_model,
																						NULL,
																						p_business_entity,
                                            p_wharehouse_id,  -- Performance
                                            p_org_id
																						);

		v_new_item_ship_code := get_ship_codes_REP_USED (v_new_item_id,
																						p_engine_model,
																						NULL,
																						p_business_entity,
                                            p_wharehouse_id,
                                            p_org_id     -- Performance
																						);

	          IF v_old_item_ship_code= 'C' THEN
            EXIT;
            END IF;
   ELSE

   	v_new_item_ship_code := get_ship_codes_REP_USED (v_new_item_id,
																						p_engine_model,
																						NULL,
																						p_business_entity,
                                            p_wharehouse_id,
                                            p_org_id   -- Performance
																						);

             IF v_new_item_ship_code= 'C' THEN
                    EXIT;
             END IF;

		END IF;

	        	If p_substitution_type = 'UPGRADE ALT'
	        	Then
	        				v_sub_type := 'UPGRADE ALT';
	        	Elsif
	        				p_substitution_type = 'DOWNGRADE ALT'
	        	Then
	        				v_sub_type := 'DOWNGRADE ALT';
	        	Else
	        				v_sub_type := 'ALTERNATE';
	        	END If;


              v_remarks:= update_remarks_REP_USED (p_org_id	 						=> 	p_org_id ,
              			            p_ordered_item_id			=>	v_ordered_item_id,
              			            p_engine_model				=>	p_engine_model,
              			            p_item_number				  =>  v_part_number,
                                p_eis_data_stream		  =>  p_eis_data_stream,
			 									 				p_cust_account_id			=> 	NULL,
			 									 				p_business_entity			=>	p_business_entity,
			 									 		--		p_price_list_id				=> :query_find.price_list_id,
			 									 				p_inv_ship_lookup			=>	p_inv_ship_lookup,
			 									 				p_control_ship_app		=>	v_control_ship_app,
			 									 				p_substitution_type  	=> 	p_substitution_type,
			 									 				p_old_item_id					=>	v_old_item_id,
			 									 				p_new_item_id					=>	v_new_item_id,
			 									 				p_old_item_ship_code  =>  v_old_item_ship_code,
			 									 				p_new_item_ship_code  =>  v_new_item_ship_code,
			 									 				p_ic_code 						=>	NULL,
			 									 				p_eis_sequence				=>  0,
                                p_conservative_flag   =>  p_conservative_flag,
                                p_organization_id      =>   p_wharehouse_id,
                               p_dg_prefs           =>   p_dg_prefs,
			                         	p_ug_prefs            =>   p_ug_prefs,
			                         	p_alt_prefs           =>   p_alt_prefs,
			 									 				p_error_code					=>  v_error_code);


           IF (NVL(v_error_code,'INCLUDE') <> 'EXCLUDE') THEN

		 				EIS_ASSIGN_DATA_REP_USED(p_engine_model 						=>	p_engine_model,
														p_sb_snum 								=>	NULL,
														p_sb_dg_date	 						=> 	NULL,
														p_sub_type 								=> 	v_sub_type ,
														p_old_item_id 						=> 	v_old_item_id,
														p_old_part_number 				=>	v_old_item_number,
														p_old_item_ship_code 			=>	v_old_item_ship_code,
														p_new_item_id 						=>	v_new_item_id,
														p_new_part_number 				=>	v_new_item_number,
														p_new_item_ship_code 			=>	v_new_item_ship_code,
														p_ic_code 								=>	NULL,
														p_ordered_item_id 				=>	v_ordered_item_id,
                            p_order_part_number				=>	p_ordered_part_number,
														p_substitution_type 			=> 	p_substitution_type,
														p_org_id									=>  p_org_id,
														p_organization_id					=>  p_organization_id,
														p_error_code							=>	v_error_code,
														p_remarks									=>	v_remarks ,
                            p_business_entity         => p_business_entity,
                            p_cust_account_id         => NULL
                           ,p_list_header_id         => p_list_header_id
                           ,p_cust_code              => p_cust_code,
                            p_Engine_family          =>  p_Engine_family,
                            p_product_line           =>  p_product_line,
                            p_altlevel               =>  g_eis_seq,
                            p_part_hist_info4        => p_part_inf5
														);



  part_hist_cnt5 := p_part_hist_info3.count;
  part_cnt5 := p_part_inf5.count;
  p_part_hist_info3.EXTEND(part_cnt5);

  FOR i in 1 .. part_cnt5 loop
     p_part_hist_info3(part_hist_cnt5 + i) := p_part_inf5(i);
  END LOOP;
       END IF;   -- Remarks endif
       END IF;   --Contorl shippable endif--

	END LOOP;
  -- FIRST_RECORD;
EXCEPTION
WHEN OTHERS
THEN
	NULL;
END insert_alt_part_REP_USED;



FUNCTION eis_upgrade_recursive_REP_USED (
p_item_number       in   VARCHAR2,
p_ordered_item_id   in   NUMBER,
p_organization_id   in   NUMBER,
p_cust_account_id   in   NUMBER,
p_ship_to_org_id    in   NUMBER,
p_order_line_id     in   NUMBER,
p_engine_model      in   VARCHAR2,
p_business_entity   in   VARCHAR2,
p_eis_data_stream   in   VARCHAR2,
p_inv_ship_lookup   in   VARCHAR2,
p_org_id		  			in   NUMBER ,
p_conservative_flag in  VARCHAR2,
p_list_header_id    in  NUMBER,
p_cust_code               in VARCHAR2,
p_warehouse_id      in  NUMBER,
p_dg_prefs         in   NUMBER,
p_ug_prefs        in   NUMBER,
p_alt_prefs        in   VARCHAR2,
p_Engine_family    IN   VARCHAR2,
p_product_line     IN   VARCHAR2,
p_part_hist_info5  OUT PART_HISTORY_inFO_ARRAY
)
RETURN NUMBER
IS
	/* Return FOR eis_upgrade_recursive */
	v_insert_eis_return       NUMBER;
	v_control_ship_app        VARCHAR2 (1);
	/* To Populate the Control_ship_applicability Flag */
	v_control_shippable_ret   NUMBER;
	/* To populate Old_item_id FOR the old_part_number(SEGMENT1) */
	v_old_item_id             NUMBER;
	/* To populate New_item_id FOR the new_part_number(SEGMENT1) */
	v_new_item_id             NUMBER;
	/* To populate Old Item Ship Code */
	v_old_item_ship_code      VARCHAR2 (150) ;
	/* To populate New Item Ship Code */
	v_new_item_ship_code      VARCHAR2 (150);
	/* To populate the SB NUMBER */
	v_sb_snum                 VARCHAR2 (20);
	/* To populate the SB Material Disposition code*/
	v_sb_matl_disp_cd         VARCHAR2 (1);
	v_sb_intrchngblty_cd      VARCHAR2 (1);
  v_remarks                 VARCHAR2(100);
  v_error_code       				VARCHAR2(100);
  v_assign_data       			NUMBER;
  v_organization_id  				NUMBER;
  part_hist_cnt6             integer;
  part_cnt6                  integer;
  part_hist_cnt7             integer;
  part_cnt7                  integer;
  v_check  NUMBER :=0;
	/* Cursor to get all the Upgrades FOR the ordered_part and Engine model */
CURSOR sb_data_cur (v_item_number VARCHAR2, v_engine_model VARCHAR2)
IS
	SELECT 	level,
					old_part_number,
					new_part_number,
					engine_model,bus_enty_cd,
					MAX (sb_issue_date) sb_ug_date
	  FROM	geae_mtl_ebom_sb_data
	 WHERE 1 = 1
	   AND old_part_number IS NOT NULL
	   AND new_part_number IS NOT NULL
	   AND engine_model = v_engine_model
	   AND bus_enty_cd = p_business_entity
	   AND src_cd = p_eis_data_stream
	START WITH old_part_number = v_item_number  AND engine_model = v_engine_model  AND bus_enty_cd = p_business_entity AND src_cd = p_eis_data_stream
	CONNECT BY NOCYCLE old_part_number = PRIOR new_part_number AND PRIOR sb_intrchngblty_cd in ('1','2') AND engine_model = v_engine_model  AND bus_enty_cd = p_business_entity AND src_cd = p_eis_data_stream
	GROUP BY level,
		 old_part_number,
		 new_part_number,
		 engine_model,bus_enty_cd
	ORDER BY sb_ug_date ASC;
  --MYJIRATEST-3299 Added nocycle in above query
BEGIN
 p_part_hist_info5         := PART_HISTORY_inFO_ARRAY();
 v_check :=0;
 BEGIN
           SELECT	 count(1) INTO v_check
		        FROM	geae_mtl_ebom_sb_data
	          WHERE 1 = 1
	            AND old_part_number IS NOT NULL
	            AND new_part_number IS NOT NULL
	            AND engine_model = p_engine_model
	            AND bus_enty_cd =  p_business_entity
	            AND src_cd =       p_eis_data_stream
              AND old_part_number = p_item_number;
             -- AND sb_intrchngblty_cd in ('1','2');

           EXCEPTION
           WHEN OTHERS THEN
           dbms_output.put_line(SQLERRM||p_engine_model);
           v_check := 0;
         END;

  IF v_check >0  THEN

	FOR sb_data_rec in sb_data_cur (p_item_number, p_engine_model)
	LOOP
       v_organization_id 				:= NULL;
       v_old_item_id     				:= NULL;
       v_new_item_id						:= NULL;
       v_sb_snum								:= NULL;
       v_sb_matl_disp_cd				:= NULL;
       v_sb_intrchngblty_cd			:= NULL;
       v_control_shippable_ret	:= NULL;
       v_control_ship_app				:= NULL;
       v_new_item_ship_code			:= NULL;
       v_old_item_ship_code			:= NULL;
       v_assign_data						:= NULL;
--dbms_output.put_line('Upgrade Engin model..'||'..'||p_engine_model||'..Part..'||p_item_number||'..'||p_business_entity||'..'||p_eis_data_stream||'..'||v_check);


		/* Get the SB NUMBER and SB Material Disposition code FOR the cursor record */
		BEGIN
		SELECT	service_bulletin_snum,
			sb_matl_disp_cd,
			sb_intrchngblty_cd
		  INTO	v_sb_snum,
			v_sb_matl_disp_cd,
			v_sb_intrchngblty_cd
		  FROM	geae_mtl_ebom_sb_data
		 WHERE 1 = 1
		   AND old_part_number IS NOT NULL
	     AND new_part_number IS NOT NULL
		   AND bus_enty_cd = p_business_entity
	     AND src_cd = p_eis_data_stream
		   AND old_part_number = sb_data_rec.old_part_number
		   AND new_part_number = sb_data_rec.new_part_number
		   AND engine_model = sb_data_rec.engine_model
		   AND TRUNC (sb_issue_date) = TRUNC(sb_data_rec.sb_ug_date)
		   AND ROWNUM=1;
		EXCEPTION
		WHEN NO_DATA_FOUND
		THEN
			v_sb_snum := NULL;
			v_sb_matl_disp_cd := NULL;
		WHEN TOO_MANY_ROWS
		THEN
			NULL;
		END;

		/* Get the inventory_item_ids FOR the old_part_number and the new_part_number */
		BEGIN
			SELECT	msi1.inventory_item_id,
				msi2.inventory_item_id
			  INTO	v_old_item_id,
				v_new_item_id
			  FROM	mtl_system_items_b msi1,
				mtl_system_items_b msi2
			 WHERE	msi1.segment1 = sb_data_rec.old_part_number
			   AND	msi1.organization_id = p_organization_id
			   AND	msi2.segment1 = sb_data_rec.new_part_number
			   AND	msi2.organization_id = p_organization_id;
		EXCEPTION
		WHEN NO_DATA_FOUND
		THEN
			NULL;
		END;


		V_organization_id:= p_warehouse_id;

     	v_control_ship_app := 'Y';

IF (NVL(v_control_ship_app,'N')= 'Y') THEN
		/* Get the ship codes FOR the old_part and the new_part */

	/*	v_old_item_ship_code := get_ship_codes (v_old_item_id,
							sb_data_rec.engine_model,
							NULL,
							p_business_entity,
              p_organization_id,
              p_org_id
							);*/   -- Performance

		v_new_item_ship_code := get_ship_codes_REP_USED (v_new_item_id,
							sb_data_rec.engine_model,
							NULL,
							p_business_entity,
               p_organization_id,
              p_org_id
							);

		/* Populate the eis_sequence using the level from the cursor */
		-- g_eis_seq := sb_data_rec.level;
		-- Arun global variable needs to be addressed


		/* Call function to insert the Upgrade record INTO the Custom Table */
		IF v_sb_intrchngblty_cd in ('1','2')
		THEN

     v_remarks:= update_remarks_REP_USED (p_org_id	 						=> 	p_org_id ,
              			            p_ordered_item_id			=>	p_ordered_item_id,
              			            p_engine_model				=>  p_engine_model,
              			            p_item_number				  =>  p_item_number,
                                p_eis_data_stream		  =>  p_eis_data_stream,
			 									 				p_cust_account_id			=> 	NULL,
			 									 				p_business_entity			=>	p_business_entity,
			 									 		--		p_price_list_id				=> :query_find.price_list_id,
			 									 				p_inv_ship_lookup			=>	p_inv_ship_lookup,
			 									 				p_control_ship_app		=>	v_control_ship_app,
			 									 				p_substitution_type  	=> 	'UPGRADE',
			 									 				p_old_item_id					=>	v_old_item_id,
			 									 				p_new_item_id					=>	v_new_item_id,
			 									 				p_old_item_ship_code  =>  v_old_item_ship_code,
			 									 				p_new_item_ship_code  =>  v_new_item_ship_code,
			 									 				p_ic_code 						=>	v_sb_intrchngblty_cd,
			 									 				p_eis_sequence				=>  1* sb_data_rec.level,
                                p_conservative_flag   => p_conservative_flag,
                                p_organization_id     => p_organization_id,
                               p_dg_prefs           =>   p_dg_prefs,
			                        	p_ug_prefs            =>   p_ug_prefs,
			                        	p_alt_prefs           =>   p_alt_prefs,
			 									 				p_error_code					=>  v_error_code);

		      IF (NVL(v_error_code,'INCLUDE') <> 'EXCLUDE') THEN

								EIS_ASSIGN_DATA_REP_USED(p_engine_model 				=>	sb_data_rec.engine_model,
														p_sb_snum 						=>	v_sb_snum,
														p_sb_dg_date 					=> 	sb_data_rec.sb_ug_date,
														p_sub_type 						=> 'UPGRADE',--	'U'|| 1 * sb_data_rec.level,
														p_old_item_id 				=> 	v_old_item_id,
														p_old_part_number 		=>	sb_data_rec.old_part_number,
														p_old_item_ship_code 	=>	v_old_item_ship_code,
														p_new_item_id 				=>	v_new_item_id,
														p_new_part_number 		=>	sb_data_rec.new_part_number,
														p_new_item_ship_code 	=>	v_new_item_ship_code,
														p_ic_code 						=>	v_sb_intrchngblty_cd,
														p_ordered_item_id 		=>	p_ordered_item_id,
                            p_order_part_number   => p_item_number,
														p_substitution_type 	=>	'UPGRADE',
														p_org_id							=>	p_org_id,
														p_organization_id			=>	p_organization_id,
														p_error_code					=>	v_error_code,
														p_remarks							=>	v_remarks,
                            p_business_entity     => p_business_entity,
                            p_cust_account_id     => NULL,
                             p_list_header_id   => p_list_header_id  ,
                             p_cust_code         => p_cust_code,
                             p_Engine_family      =>  p_Engine_family,
                             p_product_line      =>  p_product_line,
                             p_altlevel          =>  'U'|| 1 * sb_data_rec.level,
                             p_part_hist_info4       => p_part_inf6
												);

  part_hist_cnt6 := p_part_hist_info5.count;
  part_cnt6 := p_part_inf6.count;
  p_part_hist_info5.EXTEND(part_cnt6);

  FOR i in 1 .. part_cnt6 loop
    p_part_hist_info5(part_hist_cnt6 + i) := p_part_inf6(i);
  END LOOP;


		/* Call PROCEDURE to insert Alternate part FOR the Upgrade */
		IF v_sb_intrchngblty_cd in ('1','2')
		THEN

 			insert_alt_part_REP_USED(v_organization_id,
					p_cust_account_id,
					p_ship_to_org_id,
					p_order_line_id,
					p_item_number,
					sb_data_rec.old_part_number,
					sb_data_rec.new_part_number,
					p_engine_model,
					sb_data_rec.sb_ug_date,
					'UPGRADE ALT',
				  'U'|| 1 * sb_data_rec.level, --g_eis_seq
					p_business_entity,
					p_eis_data_stream,
					p_inv_ship_lookup,
					p_org_id,
          p_conservative_flag,
           p_list_header_id ,
           p_cust_code    ,
           p_organization_id,
          p_dg_prefs          ,
			    p_ug_prefs       ,
			  	p_alt_prefs     ,
          p_Engine_family ,
          p_product_line  ,
          p_part_inf7);

  part_hist_cnt7 := p_part_hist_info5.count;
  part_cnt7 := p_part_inf7.count;
  p_part_hist_info5.EXTEND(part_cnt7);

  FOR i in 1 .. part_cnt7 loop
     p_part_hist_info5(part_hist_cnt7 + i) := p_part_inf7(i);
  END LOOP;

		END IF;
    END IF;-- END of Remarks IF condition
   END IF;
   END IF; --Control shippable check end

	END LOOP;
  END IF;
	RETURN 0;
EXCEPTION
WHEN OTHERS
THEN
	RETURN 1;
END eis_upgrade_recursive_REP_USED;

END ;