

GEAE_MYGE_LOGIN



--check_login
--request_login
  
  
  
create or replace PACKAGE BODY GEAE_MYGE_LOGIN is

--------Change Log-------------------------------------
/*
Date          Changed By         Description
07-NOV-2014   Ravi Saxena        MYJIRATEST-3512 Modified user access process
17-NOV-2014   Ravi Saxena        MYJIRATEST-3512 Modified user access process - changes in check login
12-FEB-2015   Ravi Saxena        MYJIRATEST-5943 Global user (GEAE) Impersonation
20-Apr-2015   Ankita Shetty      MYJIRATEST-7031 Modified GTA error and Denied party access logic in Check_login
29-APR-2015   Ankita Shetty      MYJIRATEST-7592 Added role assignment for Storefront users login in Request login
03-JUN-2015   Ankita Shetty      MYJIRATEST-8648 Changed check_login to display correct error for invaid icao_code
20-Oct-2016   Amita Bhoyar       Added New Procedure USER_CREATION_RESP_ASSIGNMENT
22-Jun-2018   Manisha            Passport changes; Manisha replaced the out variable p_status with p_ou_id which will return the ou_id seaprated by '~'
                                 if all the login validations is passed.

*/


  PROCEDURE Check_login(p_Operating_unit_id IN VARCHAR2,
                        p_icao_code         IN VARCHAR2,
                        p_user_id           IN VARCHAR2,
                        --p_status            OUT VARCHAR2,  --Manisha K.;US166563; Passport Changes; Commented p_status paramter and introduced P_OU_ID parameter
                        p_ou_id             OUT VARCHAR2,  --Manisha K.;US166563;Passport Changes;Changed the Output to return the OU_ID in output instead of status
                        p_message           OUT VARCHAR2)

   IS

    v_user_name           VARCHAR2(20);
    v_responsiblity_count number;
    v_global_enq_count    number;
    v_check               varchar2(1);
    v_loop_success        varchar2(10);
    v_loop_count          NUMBER;
    v_count               varchar2(1);
    v_attr_value          varchar2(1);
    v_rowcount            varchar2(10);
    v_internal_icao_code  varchar2(1);
    v_denied_count        number;
    v_gta_count           number;
    n_cust_id             number;
    l_GTA_check           number;
    l_Denied_check        number;
    l number:=0;
    v_status              VARCHAR2(5):= ' '; --22-Jun-2018;US166563; Manisha Added the variable to replace the existing out variable p_status.
    v_ou_id               VARCHAR2(240) := ' '; --22-Jun-2018;US166563; Manisha added the variable to store the ou_id separated by comma.
    l_ou_id               VARCHAR2(240); --US166563;Manisha introduced the variable to store OU_ID value
    n_ou_id               VARCHAR2(240); --US166563;Manisha introduced the variable to store OU_ID value


  BEGIN

    --Commented below for MYJIRATEST-3512 by Ravi S 17-NOV-2014
    /*BEGIN
      SELECT user_name
        INTO v_user_name
        FROM fnd_user
       WHERE user_name = p_user_id
         AND TRUNC(SYSDATE) BETWEEN TRUNC(START_DATE) AND
             NVL(END_DATE, SYSDATE + 1);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        v_status := 'NO';
        --p_message := 'Invalid User';
        SELECT LOOKUP_CODE || ': ' || DESCRIPTION
          INTO p_message
          FROM fnd_lookup_values
         WHERE lookup_type = 'GEAE_MYGE_ERROR_CODES'
           AND UPPER(LOOKUP_CODE) = UPPER('8004');

      WHEN OTHERS THEN
        v_status := 'NO';
    END;*/

    v_user_name := p_user_id; --MYJIRATEST-3512 by Ravi S 17-NOV-2014 NB08RTT
    IF v_user_name is NOT NULL THEN
      v_status := 'YES';
    ELSE
      v_status := 'NO';
      SELECT 'OU ID: '|| p_Operating_unit_id || '; ' || LOOKUP_CODE || ':' || DESCRIPTION
        INTO p_message
        FROM fnd_lookup_values
       WHERE lookup_type = 'GEAE_MYGE_ERROR_CODES'
         AND UPPER(LOOKUP_CODE) = UPPER('8004');
    END IF;

    ---validations
    --- check responsibility
    IF v_status = 'YES' THEN
      --
      IF p_icao_code IS NULL THEN
         v_status := 'NO';
         SELECT 'OU ID: '|| p_Operating_unit_id || '; ' || LOOKUP_CODE || ':' || DESCRIPTION
           INTO p_message
           FROM fnd_lookup_values
          WHERE lookup_type = 'GEAE_MYGE_ERROR_CODES'
            AND UPPER(LOOKUP_CODE) = UPPER('8058');
      END IF;
      begin
        select 'Y'
          into v_internal_icao_code
          from fnd_lookup_values
         where 1 = 1
           and upper(lookup_code) = upper(p_icao_code)
           and lookup_type = 'GEAE_INTERNAL_ICAO_CODES';
      exception
        when no_data_found then
          v_internal_icao_code := 'N';
        when too_many_rows then
          v_internal_icao_code := 'N';
      end;
      --
      --Commented below for MYJIRATEST-3512 by Ravi S 17-NOV-2014
      /*BEGIN
        SELECT count(1)
          INTO v_responsiblity_count
          FROM fnd_user                    fu,
               fnd_user_resp_groups_direct furgd,
               fnd_responsibility_vl       frv
         WHERE fu.user_id = furgd.user_id
           AND furgd.responsibility_id = frv.responsibility_id
           AND fu.user_name = p_user_id --
           AND TRUNC(SYSDATE) BETWEEN TRUNC(furgd.START_DATE) AND
               NVL(furgd.END_DATE, SYSDATE)
           AND frv.responsibility_name in
               ('myGEAviation Global Enquiry', 'myGEAviation Buyer',
                'myGEAviation Customer Enquiry');

        If v_responsiblity_count > 0 THEN
          v_status := 'YES';
          if v_internal_icao_code = 'Y' then
            SELECT count(1)
              INTO v_global_enq_count
              FROM fnd_user                    fu,
                   fnd_user_resp_groups_direct furgd,
                   fnd_responsibility_vl       frv
             WHERE fu.user_id = furgd.user_id
               AND furgd.responsibility_id = frv.responsibility_id
               AND fu.user_name = p_user_id --
               AND TRUNC(SYSDATE) BETWEEN TRUNC(furgd.START_DATE) AND
                   NVL(furgd.END_DATE, SYSDATE)
               AND frv.responsibility_name in
                   ('myGEAviation Global Enquiry');
            ------
            if v_global_enq_count = 0 then
              v_status := 'NO';
              --p_message := 'GE internal user does not have Global Enquiry responsibility';
              SELECT LOOKUP_CODE || ': ' || DESCRIPTION
                INTO p_message
                FROM fnd_lookup_values
               where lookup_type = 'GEAE_MYGE_ERROR_CODES'
                 AND UPPER(LOOKUP_CODE) = UPPER('8006');
            end if;
            -----
          END IF;
        ELSE
          v_status := 'NO';
          --p_message := 'User doesnot have access';
          SELECT LOOKUP_CODE || ': ' || DESCRIPTION
            INTO p_message
            FROM fnd_lookup_values
           WHERE lookup_type = 'GEAE_MYGE_ERROR_CODES'
             AND UPPER(LOOKUP_CODE) = UPPER('8005');
        END IF;

      END;*/
    END IF; ----v_status = 'YES'
    --
    -- If User and Responsibility validation passes successfully we need to check for
    -- ICAO code setup, WEB_ENABLED, Active Sites, Denied Party Check, and GTA
    --
    IF v_status = 'YES' AND v_internal_icao_code <> 'Y' 
	THEN
      --
      --Check conditions to check for WEB ENABLED, ICAO Code, Customer Accounts, Active Sites, and GTA
      --
      --

/*********************************************************
  US166563;Below code Added By Manisha K.;Passport Requirement:
  Two OU_ID will be passed separated by ~ symbol for input p_Operating_unit_id.
  The output will return both OU_ID , the user_id is having access for both.
  **************************************************/

       v_ou_id:=Replace(p_Operating_unit_id,'~',',');

    FOR j IN
     (SELECT trim(regexp_substr(v_ou_id, '[^,]+', 1, LEVEL)) ou_id
    FROM dual
      CONNECT BY LEVEL <= regexp_count(v_ou_id, ',')+1
    )
   LOOP

      begin
        v_loop_success := NULL;
        v_loop_count   := 0;
        l_GTA_check:=0;
        l_Denied_check:=0;
        l_ou_id := j.ou_id;   -- Assigning the OU_ID value

        --Get count of cust_ids for user -- MYJIRATEST-7031 Ankita.S 20-APR-2015
        SELECT COUNT(hca.cust_account_id) 
		into n_cust_id
                    FROM HZ_CUST_ACCOUNTS hca, HZ_PARTIES HP
                   WHERE 1 = 1
                     AND EXISTS
                   (SELECT 1
                            from HZ_CUST_ACCT_SITES_ALL HCASA,
                                 HZ_CUST_SITE_USES_ALL  hcsu
                          -- WHERE hcasa.org_id = p_Operating_unit_id
                             WHERE hcasa.org_id = to_number(j.ou_id)  --US166563;Added By Manisha;US166563; Passing one OU_ID at a time through loop
                             and NVL(HCASA.STATUS, 'I') = 'A'
                             and HCSU.SITE_USE_CODE = 'SHIP_TO'
                             AND hcsu.cust_acct_site_id =
                                 hcasa.cust_acct_site_id
                             AND hcasa.cust_account_id = hca.cust_account_id
					)
                     AND NVL(hp.status, 'I') = 'A'
                     AND hca.party_id = hp.party_id
                     AND NVL(hca.status, 'I') = 'A'
                     AND NVL(hca.attribute11, 'WORLD') = p_icao_code
                     AND NVL(hca.ATTRIBUTE13, 'WORLD') = 'Y';



        FOR i in (SELECT hca.cust_account_id,
                         hca.ACCOUNT_NUMBER,
                         hP.PARTY_NAME
                     FROM HZ_CUST_ACCOUNTS hca, HZ_PARTIES HP
                     WHERE 1 = 1
                     AND EXISTS
                   (SELECT 1
                            from HZ_CUST_ACCT_SITES_ALL HCASA,
                                 HZ_CUST_SITE_USES_ALL  hcsu
                           --WHERE hcasa.org_id = p_Operating_unit_id
                             WHERE hcasa.org_id = to_number(j.ou_id)  --US166563;Added By Manisha; Passing one OU_ID at a time through loop
                             and NVL(HCASA.STATUS, 'I') = 'A'
                             and HCSU.SITE_USE_CODE = 'SHIP_TO'
                             AND hcsu.cust_acct_site_id =
                                 hcasa.cust_acct_site_id
                             AND hcasa.cust_account_id = hca.cust_account_id)
							 AND NVL(hp.status, 'I') = 'A'
							 AND hca.party_id = hp.party_id
							 AND NVL(hca.status, 'I') = 'A'
							 AND NVL(hca.attribute11, 'WORLD') = p_icao_code
							 AND NVL(hca.ATTRIBUTE13, 'WORLD') = 'Y'
					) 
		loop
          v_check        := 'N';
          v_loop_count   := v_loop_count + 1;
          v_denied_count := 0;
          v_gta_count    := 0;

          begin
            select COUNT(1)
              into v_count
              from oe_hold_sources_all ohs,
                   oe_hold_definitions ohd,
                   FND_LOOKUP_VALUES   FLV
             where 1 = 1
               and ohs.hold_entity_id = i.cust_account_id
               and nvl(ohs.hold_entity_code, 'XX') = 'C'
               and nvl(ohs.released_flag, 'X') = 'N'
               --and ohs.org_id = p_Operating_unit_id
               and ohs.org_id = to_number(j.ou_id)  --US166563;Added By Manisha; Passing one OU_ID at a time through loop
               AND ohs.hold_id = ohd.hold_id
               and UPPER(ohd.name) = UPPER(flv.lookup_code)
               and flv.lookup_type = 'GEAE_MYGE_MTLS_DENIED_PARTY';

            if v_count > 0 
			then
              -- MYJIRATEST-7031 Ankita.S 20-APR-2015
                l_Denied_check := l_Denied_check+1;
				
                If l_Denied_check < n_cust_id 
				Then
                  goto end_loop;
                Else
                  v_check        := 'N';
                  v_denied_count := v_denied_count + 1;

                  --p_message := 'Customer is Denied Party' ;
                  SELECT 'OU ID: '|| j.ou_id || '; ' || LOOKUP_CODE || ': ' || DESCRIPTION
                    INTO p_message
                    FROM fnd_lookup_values
                   where lookup_type = 'GEAE_MYGE_ERROR_CODES'
                     AND UPPER(LOOKUP_CODE) = UPPER('8001');
                  v_status := 'NO';
                  l_ou_id := ' ';   --US166563;Manisha K;  the variable will store space in case of error
                End if;
				
            else
              v_check := 'Y';
            end if;
			
          end;

          if v_check = 'Y' 
		  then


            ----------------------------

            BEGIN
              --Check Customer is GTA enabled or not
              SELECT NVL(geae_om_util_pkg.get_segmented_dff_value('OTR Processing Attributes',
                                                                  'GTA Validation Required',
                                                                  attribute3),
                         'N')
                INTO v_attr_value
                from hz_cust_accounts
               WHERE cust_account_id = i.cust_account_id; --cust_account_id = v_cust_id;
               EXCEPTION
              WHEN NO_DATA_FOUND 
			  THEN
                v_attr_value := 'N';
              WHEN OTHERS THEN
                v_attr_value := 'N';
				
            END; --Check Customer is GTA enabled or not


            IF v_attr_value = 'Y' then

              BEGIN

                select count(*)
                  INTO v_rowcount
                  FROM geae_ont_cust_gta_info gta, geae_ont_gta_model gtm
                 WHERE gtm.geae_ont_cust_gta_info_seq_id =
                       gta.geae_ont_cust_gta_info_seq_id
                   AND TRUNC(gta.start_date) <= TRUNC(SYSDATE)
                   AND NVL(TRUNC(gta.end_date), SYSDATE + 1) >=
                       TRUNC(SYSDATE)
                   and gta.customer_id = i.cust_account_id
                  -- and gta.org_id = p_operating_unit_id;
                   and gta.org_id = to_number(j.ou_id);   --US166563;Added By Manisha; Passing one OU_ID at a time through loop

                if v_rowcount > 0 then
                  v_check := 'Y';
                else -- MYJIRATEST-7031 Ankita.S 20-APR-2015

                  l_GTA_check:=l_GTA_check+1;

                  If l_GTA_check < n_cust_id Then
                    goto End_loop;
                  Else
                  v_check := 'N';
                  -- p_message := 'InValid GTA' ;
                  SELECT 'OU ID: '|| j.ou_id || '; ' || LOOKUP_CODE || ': ' || DESCRIPTION
                    INTO p_message
                    FROM fnd_lookup_values
                   where lookup_type = 'GEAE_MYGE_ERROR_CODES'
                     AND UPPER(LOOKUP_CODE) = UPPER('8002');
                  v_status    := 'NO';
                  v_gta_count := v_gta_count + 1;
                   l_ou_id := ' ';    --US166563;Manisha K;  the variable will store space in case of error
                  End if;-- MYJIRATEST-7031 Ankita.S 20-APR-2015
                END IF;

              END;

            End if;

            ------------------
          END IF;

            if v_check = 'Y' and nvl(v_loop_success, 'N') <> 'Y' then
              v_loop_success := 'Y';
            END IF;
          --
          <<End_loop>>
          Null;
        end loop;

          --
          if v_loop_count = 0 
		  then
            v_loop_success := 'Y';
            v_status       := 'NO';
            l_ou_id := ' ';     --US166563;Manisha K;  the variable will store space in case of error
            --p_message := 'No Customer Record for the ICAO Code' ;
            SELECT 'OU ID: '|| j.ou_id || '; ' || LOOKUP_CODE || ': ' || DESCRIPTION
              INTO p_message
              FROM fnd_lookup_values
             where lookup_type = 'GEAE_MYGE_ERROR_CODES'
               AND UPPER(LOOKUP_CODE) = UPPER('8003');
              GOTO end_proc; --Changed by Ankita.S for MYJIRATEST-8648 on 03/06/2015
          END IF;


        IF l_Denied_check=n_cust_id THEN
              v_status := 'NO';
               l_ou_id := ' ';   --US166563;Added By Manisha   the variable will store space in case of error
              SELECT 'OU ID: '||j.ou_id || '; ' || LOOKUP_CODE || ': ' || DESCRIPTION
                  INTO p_message
                  FROM fnd_lookup_values
                 where lookup_type = 'GEAE_MYGE_ERROR_CODES'
                   AND UPPER(LOOKUP_CODE) = UPPER('8001');
        ELSIF l_GTA_check = n_cust_id THEN
            v_status := 'NO';
             l_ou_id := ' ';    --US166563;Manisha K;  the variable will store space in case of error
            SELECT 'OU ID: '|| j.ou_id || '; ' || LOOKUP_CODE || ': ' || DESCRIPTION
                INTO p_message
                FROM fnd_lookup_values
               where lookup_type = 'GEAE_MYGE_ERROR_CODES'
                 AND UPPER(LOOKUP_CODE) = UPPER('8002');
        ELSIF
           l_GTA_check+l_Denied_check=n_cust_id Then
            v_status := 'NO';
             l_ou_id := ' ';   --US166563;Added By Manisha
            SELECT 'OU ID: '||j.ou_id || '; ' || LOOKUP_CODE || ': ' || DESCRIPTION
                INTO p_message
                FROM fnd_lookup_values
               where lookup_type = 'GEAE_MYGE_ERROR_CODES'
                 AND UPPER(LOOKUP_CODE) = UPPER('8007');
        ELSE
            NULL;
        END IF;
        --

        --
        /*if v_loop_success <> 'Y' then
          v_status := 'NO';
          if v_denied_count > 0 and v_gta_count > 0 then
            --p_message := 'Invalid GTA and Denied Party' ;
            SELECT LOOKUP_CODE || ': ' || DESCRIPTION
              INTO p_message
              FROM fnd_lookup_values
             where lookup_type = 'GEAE_MYGE_ERROR_CODES'
               AND UPPER(LOOKUP_CODE) = UPPER('8007');
          END IF;
        END IF;*/
     END;

      n_ou_id := n_ou_id ||'~'||l_ou_id;
      <<end_proc>> --US166563; Manisha K. added end_proc to exit the current iteration and move to next OU_ID
      NULL;
      END LOOP;  --End of j.ou_id LOOP
     --US166563; Manisha K. added the below to assign the n_ou_id to output variable p_ou_id
      n_ou_id:= trim(both ' ' from n_ou_id);
      n_ou_id:= trim(both '~' from n_ou_id);
      p_ou_id := n_ou_id ;

      --US166563; Manisha K. Below code added to update p_message to null if any of the OU_ID is having access
      IF p_ou_id is not null THEN
      p_message := NULL;
      END IF;

    ELSIF v_status = 'YES' AND v_internal_icao_code = 'Y' THEN
    p_ou_id := p_Operating_unit_id;
    END IF;

    -- END;
-- <<end_proc>> --Changed by Ankita.S for MYJIRATEST-8648 on 03/06/2015   --US166563; Manisha K.Commented and place inside the OU_ID loop to continue with next OU_ID
 NULL;
  END Check_login;
	
	
	
	
  
  
  
  
  
  PROCEDURE request_login
	(					p_Operating_unit_id  IN VARCHAR2, 		--CFM,GEAE
                          p_icao_code          IN VARCHAR2,		
                          p_user_name          IN VARCHAR2,		--SSO
                          p_impersonation_flag IN VARCHAR2,
                          P_roles              OUT VARCHAR2,
                          p_cust_ARRAY         out v_cust_array,
                          P_MESSAGE            OUT VARCHAR2
	) is
	
    v_global_enquiry     NUMBER;
    v_Buyer              NUMBER;
    v_cust_enquiry       number;
    v_internal_icao_code  varchar2(1);
    v_excp_buyer_icao_code varchar2(1);

   l_custARRAY v_cust_array := v_cust_array() ;
   -- TYPE l_custARRAY IS VARRAY(250) OF v_Cust_Entry;
    v_index     number := 0;
    v_attr_value       varchar2(1);
    v_rowcount         number;
    v_check char(1);
    v_ou_id         VARCHAR2(240) := ' '; --22-Jun-2018; US166563;Manisha added the variable to store the ou_id separated by comma.
    v_ou_id1        VARCHAr2(240) := ' ';
    v_ou_id2        VARCHAr2(240) := ' ';

  Begin
  
    P_MESSAGE := NULL;
    p_cust_ARRAY := v_cust_array();
    --l_custARRAY  := V_custARRAY();
    BEGIN

      SELECT count(1)
        INTO v_global_enquiry
        FROM fnd_user                    fu,
             fnd_user_resp_groups_direct furgd,
             fnd_responsibility_vl       frv
       WHERE fu.user_id = furgd.user_id
         and furgd.responsibility_id = frv.responsibility_id
         AND fu.user_name = p_user_name --
         AND TRUNC(SYSDATE) BETWEEN TRUNC(furgd.START_DATE) 
		 AND NVL(furgd.END_DATE, SYSDATE)
         AND frv.responsibility_name in ('myGEAviation Global Enquiry');

      SELECT count(1)
        INTO v_Buyer
        FROM fnd_user                    fu,
             fnd_user_resp_groups_direct furgd,
             fnd_responsibility_vl       frv
       WHERE fu.user_id = furgd.user_id
         AND furgd.responsibility_id = frv.responsibility_id
         AND fu.user_name = p_user_name --
         AND TRUNC(SYSDATE) BETWEEN TRUNC(furgd.START_DATE) 
		 AND NVL(furgd.END_DATE, SYSDATE)
         AND frv.responsibility_name in ('myGEAviation Buyer');

      SELECT count(1)
        INTO v_Cust_enquiry
        FROM fnd_user                    fu,
             fnd_user_resp_groups_direct furgd,
             fnd_responsibility_vl       frv
       WHERE fu.user_id = furgd.user_id
         AND furgd.responsibility_id = frv.responsibility_id
         AND fu.user_name = p_user_name --
         AND TRUNC(SYSDATE) BETWEEN TRUNC(furgd.START_DATE) 
		 AND NVL(furgd.END_DATE, SYSDATE)
         AND frv.responsibility_name in ('myGEAviation Customer Enquiry');
      --
      --
      IF p_icao_code IS NULL 
	  THEN
         SELECT LOOKUP_CODE || ':' || DESCRIPTION
           INTO p_message
           FROM fnd_lookup_values
          WHERE lookup_type = 'GEAE_MYGE_ERROR_CODES'
            AND UPPER(LOOKUP_CODE) = UPPER('8058');
			
         SELECT v_Cust_Entry(NUll, NULL, NULL) bulk collect 
		 into l_custARRAY 
		 from dual;
		 
         goto end_proc;
		 
      END IF;
	  
	  
	  
      begin
        select 'Y'
          into v_internal_icao_code
          from fnd_lookup_values
         where 1 = 1
           and upper(lookup_code) = upper(p_icao_code)
           and lookup_type = 'GEAE_INTERNAL_ICAO_CODES';
      exception
        when no_data_found then
          v_internal_icao_code := 'N';
        when too_many_rows then
          v_internal_icao_code := 'N';
      END;
  
  
  
      --Check if the user is an storefront user/Exception user
        --MYJIRATEST-7592  by Ankita.S on 29-APR-2015
       begin
        select 'Y'
          into v_excp_buyer_icao_code
          from fnd_lookup_values
         where 1 = 1
           and upper(lookup_code) = upper(p_icao_code)
           and lookup_type = 'GEAE_MYGE_EXCP_BUYER_ICAO_CODE';
      exception
        when no_data_found then
          v_excp_buyer_icao_code := 'N';
        when too_many_rows then
          v_excp_buyer_icao_code := 'N';
      END;


      --
      --MYJIRATEST-5943 Ravi S 12-FEB-2015
		IF v_internal_icao_code = 'Y' 
		THEN
	  
			IF p_impersonation_flag = 'YES' 
			THEN
				SELECT LOOKUP_CODE || ':' || DESCRIPTION
				INTO p_message
				FROM fnd_lookup_values
				WHERE lookup_type = 'GEAE_MYGE_ERROR_CODES'
				AND UPPER(LOOKUP_CODE) = UPPER('8060');
			   
				SELECT v_Cust_Entry(NUll, NULL, NULL) bulk collect 
				into l_custARRAY 
				from dual;
				goto end_proc;
			
			ELSE
				p_roles := 'Global Enquiry';
				
			END IF;
		 
		ELSIF v_excp_buyer_icao_code = 'Y' 
		THEN --MYJIRATEST-7592  by Ankita.S on 29-APR-2015
			IF v_Buyer > 0 
			THEN
               p_roles := 'Buyer';
            ELSE
               p_roles := 'Cust Enquiry';
            END IF;
			
			
		ELSE
			IF p_impersonation_flag = 'YES' 
			THEN
				p_roles := 'Cust Enquiry';
			ELSE
				IF v_Buyer > 0 
				THEN
				   p_roles := 'Buyer';
				ELSE
				   p_roles := 'Cust Enquiry';
				END IF;
			
			END IF;
		 
		END IF;

      --Commented below logic as part of MYJIRATEST-5943 Ravi S 12-FEB-2015
      /*IF v_internal_icao_code = 'Y' OR p_impersonation_flag = 'YES' THEN
        --
        IF V_GLOBAL_ENQUIRY > 0 THEN
          P_roles := 'Global Enquiry';
        ELSE
          p_roles := NULL;
        END IF;
        --
      ELSE
        ---ELSE of v_internal_icao_code = 'Y'
        --
        IF v_Cust_enquiry >= 0 and v_Buyer > 0 then
          p_roles := 'Buyer';
        ELSIF v_Cust_enquiry > 0 and v_Buyer = 0 THEN
          p_roles := 'Cust Enquiry';
        ELSIF v_Cust_enquiry >= 0 and v_Buyer > 0 and v_global_enquiry > 0 THEN
          p_roles := 'Buyer';
        ELSIF v_Cust_enquiry > 0 and v_global_enquiry > 0 THEN
          p_roles := 'Cust Enquiry';
        ELSE
          p_roles := NULL;
        END IF;
      END IF; ---END IF for v_internal_icao_code = 'Y'
      --Ravi S MYJIRATEST-3512 Modified user access process
      IF p_roles IS NULL THEN
         IF v_internal_icao_code = 'Y' THEN
            P_roles := 'Global Enquiry';
         ELSE
            P_roles := 'Cust Enquiry';
         END IF;
      END IF;*/
    END;
	
    --
    if p_roles is NULL 
	THEN
      --p_message := 'Role could not be determined';
		SELECT LOOKUP_CODE || ': ' || DESCRIPTION
        INTO p_message
        FROM fnd_lookup_values
		where lookup_type = 'GEAE_MYGE_ERROR_CODES'
        AND UPPER(LOOKUP_CODE) = UPPER('8008');

       SELECT v_Cust_Entry(NUll, NULL, NULL) bulk collect 
	   into l_custARRAY 
	   from dual;
	   
    END IF;
    --
    -- Cursor for Customer Codes
    --
    /*********************************************************
  US166563;Below code Added By Manisha K.;Passport Requirement:
  Two OU_ID will be passed separated by ~ symbol for input p_Operating_unit_id.
  Modified the code to find the cust_id havin access to either one of them OU_ID or both
  **************************************************/

V_OU_ID := Replace(p_Operating_unit_id,'~',',');
    FOR j IN
     (SELECT trim(regexp_substr(v_ou_id, '[^,]+', 1, LEVEL)) ou_id
    FROM dual
      CONNECT BY LEVEL <= regexp_count(v_ou_id, ',')+1
    )
   LOOP


    IF p_roles ='Buyer' OR p_roles ='Cust Enquiry' 
	THEN --v_internal_icao_code <> 'Y' AND p_roles IS NOT NULL THEN
	
		BEGIN
	  
			SELECT v_Cust_Entry(hca.cust_account_id, --custId,
							hca.account_number , --custCode,
							hp.party_name
							)  --custName)	
							bulk collect
			into l_custARRAY
			FROM HZ_CUST_ACCOUNTS hca, HZ_PARTIES HP
			WHERE 1 = 1
			AND not exists
			(
				select 'Y'
                  from oe_hold_sources_all ohs,
                       oe_hold_definitions ohd,
                       fnd_lookup_values   flv
                 where 1 = 1
                   and ohs.hold_entity_id = hca.cust_account_id
                   and nvl(ohs.hold_entity_code, 'XX') = 'C'
                   and nvl(ohs.released_flag, 'X') = 'N'
                --   and ohs.org_id = p_Operating_unit_id
                 --  and (ohs.org_id =  v_ou_id1  OR ohs.org_id =v_ou_id2) --US166563; Manisha commented above line and added this to fetch cust id for both the values of ou_id
                 and ohs.org_id = j.ou_id
                   AND ohs.hold_id = ohd.hold_id
                   and upper(ohd.name) = upper(flv.lookup_code)
                   and flv.lookup_type = 'GEAE_MYGE_MTLS_DENIED_PARTY'
			)
			AND EXISTS
			(
				SELECT 1
                  from HZ_CUST_ACCT_SITES_ALL HCASA,
                       HZ_CUST_SITE_USES_ALL  hcsu
                -- WHERE hcasa.org_id = p_Operating_unit_id
                 --  WHERE ( hcasa.org_id = v_ou_id1 or hcasa.org_id = v_ou_id2) --US166563; Manisha commented above line and added this to fetch cust id for both the values of ou_id
                 WHERE hcasa.org_id = j.OU_ID
                   and NVL(HCASA.STATUS, 'I') = 'A'
                   and HCSU.SITE_USE_CODE = 'SHIP_TO'
                   AND hcsu.cust_acct_site_id = hcasa.cust_acct_site_id
                   AND hcasa.cust_account_id = hca.cust_account_id
			)
			AND NVL(hp.status, 'I') = 'A'
			AND hca.party_id = hp.party_id
			AND NVL(hca.status, 'I') = 'A'
			AND NVL(hca.attribute11, 'WORLD') = p_icao_code
			AND NVL(hca.ATTRIBUTE13, 'WORLD') = 'Y'			;

			exception
				when no_data_found 
				then
					SELECT v_Cust_Entry(NUll, NULL, NULL) bulk collect 
					into l_custARRAY 
					from dual	;
			--l_custARRAY := v_custARRAY(-1, NULL, NULL);
		  
		END;
	  
	  

		if l_custARRAY.count > 0 and l_custARRAY(1).cust_id is not null 
		then
		
			for var in 1 .. l_custARRAY.count 
			loop

				begin
		  
					SELECT NVL(geae_om_util_pkg.get_segmented_dff_value('OTR Processing Attributes','GTA Validation Required',attribute3),'N')
					INTO v_attr_value
					from hz_cust_accounts
					WHERE cust_account_id = l_custARRAY(var).cust_id; --cust_account_id = v_cust_id;
					
					EXCEPTION
						WHEN NO_DATA_FOUND THEN
							v_attr_value := 'N';
						WHEN OTHERS THEN
							v_attr_value := 'N';
				END; --Check Customer is GTA enabled or not

				IF v_attr_value = 'Y' 
				then
					select count(*)
					INTO v_rowcount
					FROM geae_ont_cust_gta_info gta, geae_ont_gta_model gtm
					WHERE gtm.geae_ont_cust_gta_info_seq_id = gta.geae_ont_cust_gta_info_seq_id
					AND TRUNC(gta.start_date) <= TRUNC(SYSDATE)
					AND NVL(TRUNC(gta.end_date), SYSDATE + 1) >= TRUNC(SYSDATE)
					and gta.customer_id = l_custARRAY(var).cust_id
					--   and gta.org_id = p_operating_unit_id;
					--   and (gta.org_id  = v_ou_id1 OR gta.org_id  = v_ou_id2); --US166563; Manisha commented above line and added this to fetch both the values of
					and gta.org_id = j.OU_ID		;

					if v_rowcount > 0 
					then
						v_check := 'Y';
						v_index := v_index + 1;
						p_cust_ARRAY.extend();
						p_cust_ARRAY(v_index) := l_custARRAY(var);
					end if;
			
					else
						v_check := 'Y';
						v_index := v_index + 1;
						p_cust_array.extend();
						p_cust_ARRAY(v_index) := l_custARRAY(var);
				
				end if;
		  
			end loop;
		
        else
			SELECT LOOKUP_CODE || ': ' || DESCRIPTION
            INTO p_message
            FROM fnd_lookup_values
			where lookup_type = 'GEAE_MYGE_ERROR_CODES'
            and upper(lookup_code) = upper('8009');
			 
            SELECT v_Cust_Entry(NUll, NULL, NULL) bulk collect 
			into p_cust_ARRAY 
			from dual;
			
		end if;
		
    end if;

    END LOOP; --j.ou_id loop ends
    <<end_proc>>
    NULL;
	
	
  END request_login;
  
  
  
  
  
 PROCEDURE request_login_repairs(p_Operating_unit_id  IN VARCHAR2,
                          p_icao_code          IN VARCHAR2,
                          p_user_name          IN VARCHAR2,
                          p_impersonation_flag IN VARCHAR2,
                          P_roles              OUT VARCHAR2,
                          p_cust_ARRAY         out v_cust_array,
                          P_MESSAGE            OUT VARCHAR2) is

   v_internal_icao_code  varchar2(1);
   l_custARRAY v_cust_array :=v_cust_array() ;
   l_custARRAY_cnt NUMBER:=0;
   -- TYPE l_custARRAY IS VARRAY(250) OF v_Cust_Entry;
  Begin
    P_MESSAGE := NULL;
    p_cust_ARRAY :=v_cust_array();
    --l_custARRAY  := V_custARRAY();
     IF p_icao_code IS NULL THEN
         SELECT LOOKUP_CODE || ':' || DESCRIPTION
           INTO p_message
           FROM fnd_lookup_values
          WHERE lookup_type = 'GEAE_MYGE_ERROR_CODES'
            AND UPPER(LOOKUP_CODE) = UPPER('8058');
         SELECT v_Cust_Entry(NUll, NULL, NULL) bulk collect into l_custARRAY from dual;
         goto end_proc;
      END IF;
      begin
        select 'Y'
          into v_internal_icao_code
          from fnd_lookup_values
         where 1 = 1
           and upper(lookup_code) = upper(p_icao_code)
           and lookup_type = 'GEAE_INTERNAL_ICAO_CODES';
      exception
        when no_data_found then
          v_internal_icao_code := 'N';
        when too_many_rows then
          v_internal_icao_code := 'N';
      END;

       --
      --MYJIRATEST-5943 Ravi S 12-FEB-2015
      IF v_internal_icao_code = 'Y' THEN
         IF p_impersonation_flag = 'YES' THEN
            SELECT LOOKUP_CODE || ':' || DESCRIPTION
              INTO p_message
              FROM fnd_lookup_values
             WHERE lookup_type = 'GEAE_MYGE_ERROR_CODES'
               AND UPPER(LOOKUP_CODE) = UPPER('8060');
            SELECT v_Cust_Entry(NUll, NULL, NULL) bulk collect into l_custARRAY from dual;
            goto end_proc;
         END IF;
      END IF;
   -- Getting customer details
      if p_icao_code = 'GEAE'  then --OR p_icao_code = 'MMGE'

      SELECT v_Cust_Entry(cust_account_id, --custId,
               account_number , --custCode,
               party_name)  --custName)
           bulk collect
          into l_custARRAY
          FROM        (select distinct act1.cust_account_id, --custId,
               act1.account_number , --custCode,
               par.party_name
               FROM           apps.hz_parties par
                                ,apps.hz_cust_accounts act
                                ,apps.hz_cust_acct_sites_all sit
                                ,apps.hz_cust_site_uses_all use
                                ,apps.hz_party_sites prt
                                ,apps.hz_locations loc
                                ,apps.fnd_territories_vl trr
                                ,apps.oe_transaction_types_tl ott
                                ,apps.mtl_parameters mpa
                                ,apps.qp_list_headers_tl qlh
                                ,apps.fnd_user usc
                                ,apps.fnd_user usu
                                ,apps.fnd_lookup_values flv
                                ,apps.hz_cust_acct_relate_all rel
                                ,apps.hz_cust_accounts act1
                                ,apps.hz_cust_site_uses_all su1
                                ,apps.hz_cust_acct_sites_all hca1
                                ,apps.hz_cust_site_uses_all su_bill1
                                ,apps.hz_cust_account_roles acct_role1
                                ,apps.hz_parties party1
                                ,apps.hz_relationships rel1
                                ,apps.ar_lookups l_cat
                                ,apps.jtf_rs_salesreps sr
                WHERE                par.party_id                          = act.party_id
                   AND    act.cust_account_id        = sit.cust_account_id(+)
                   AND    sit.party_site_id          = prt.party_site_id(+)
                   AND    prt.location_id            = loc.location_id(+)
                   AND    loc.country                = trr.territory_code(+)
                   AND    sit.cust_acct_site_id      = use.cust_acct_site_id(+)
                   AND  use.site_use_code          <> 'BILL_TO'
                   AND  NVL (use.LOCATION, '-1')   <> '-1'
                   AND  use.order_type_id          = ott.transaction_type_id(+)
                   AND    ott.LANGUAGE(+)            = USERENV ('LANG')
                   AND    use.warehouse_id           = mpa.organization_id(+)
                   AND    use.price_list_id          = qlh.list_header_id(+)
                   AND    qlh.LANGUAGE(+)            = USERENV ('LANG')
                   AND    act.status(+)              = 'A'
                   AND    use.status(+)                        = 'A'
                   AND  use.primary_salesrep_id    = sr.salesrep_id (+)
                   AND    flv.LOOKUP_TYPE            = 'GEAE_FALLOUT_REPORT'
                   AND    flv.enabled_flag           = 'Y'
                   AND    sit.org_id                 = flv.description(+)
                   AND    act.cust_account_id        = rel.related_cust_account_id(+)
                   AND    rel.cust_account_id        = act1.cust_account_id(+)
                   AND    su1.bill_to_site_use_id    = su_bill1.site_use_id(+)
                   AND    su1.contact_id             = acct_role1.cust_account_role_id(+)
                   AND    acct_role1.party_id        = rel1.party_id(+)
                   AND    rel1.subject_table_name(+) = 'HZ_PARTIES'
                   AND    rel1.object_table_name(+)  = 'HZ_PARTIES'
                   AND    rel1.directional_flag(+)   = 'F'
                   AND    acct_role1.role_type(+)    = 'CONTACT'
                   AND    rel1.subject_id            = party1.party_id(+)
                   AND    hca1.cust_acct_site_id     = su1.cust_acct_site_id
                   AND    hca1.cust_account_id       = sit.cust_account_id
                   AND    su1.cust_acct_site_id      = use.cust_acct_site_id
                   AND    act.created_by             = usc.user_id
                   AND    act.last_updated_by        = usu.user_id
                   AND    sit.customer_category_code = l_cat.lookup_code(+)
                   AND    l_cat.lookup_type(+)       = 'ADDRESS_CATEGORY'
                  -- AND (sit.org_id = NVL (60377, sit.org_id) OR flv.tag      =DECODE(60377,0,'COMMERCIAL'))
                   AND act.attribute11 ='G');

                   else

       SELECT v_Cust_Entry(cust_account_id, --custId,
               account_number , --custCode,
               party_name)  --custName)
           bulk collect
          into l_custARRAY
          FROM        (select distinct act1.cust_account_id, --custId,
               act1.account_number , --custCode,
               par.party_name
               FROM           apps.hz_parties par
                                ,apps.hz_cust_accounts ACT1
                  WHERE   par.party_id   = act1.party_id
                  AND ACT1.attribute11 =p_icao_code);
                  end if;
       --
         IF SQL%rowcount > 0 THEN
           FOR i IN 1 .. l_custARRAY.count
           LOOP
             l_custARRAY_cnt := l_custARRAY_cnt + 1;
             p_cust_ARRAY.EXTEND();
             p_cust_ARRAY(l_custARRAY_cnt) := l_custARRAY(i);
           END LOOP;
         ELSE

          SELECT v_Cust_Entry(NUll, NULL, NULL) bulk collect into l_custARRAY from dual;
          --l_custARRAY := v_custARRAY(-1, NULL, NULL);
         END IF;

    <<end_proc>>
    NULL;
  END request_login_repairs;
  ---------------------------------------------------------------------------------
  --Added New Procedure: USER_CREATION_RESP_ASSIGNMENT
  --To create User and Responsibility Assignment
  --------------------------------------------------------------------------------
  PROCEDURE USER_CREATION_RESP_ASSIGNMENT(P_USER_NAME   IN  VARCHAR2,
                                          P_FIRST_NAME  IN  VARCHAR2,
                                          P_LAST_NAME   IN  VARCHAR2,
                                          P_EMAIL_ADDRESS IN VARCHAR2,
                                          P_RESP_KEY    IN  VARCHAR2,
                                          P_APP_NAME    IN  VARCHAR2,
                                          ERRBUF        OUT VARCHAR2,
                                          RETCODE       OUT NUMBER)
  IS

  L_SESSION_ID INTEGER := USERENV('SESSIONID');
  L_PERSON_ID  NUMBER;

  L_USER_NAME  VARCHAR2(50);
  L_FIRST_NAME VARCHAR2(50);
  L_LAST_NAME VARCHAR2(50);
  L_EMAIL_ADDRESS VARCHAR2(50);
  L_RESP_KEY VARCHAR2(50);
  L_APP_NAME VARCHAR2(50);

  L_DESCRIPTION VARCHAR2(300);

  L_COMMIT_COUNT NUMBER := 10;
  L_REC_COUNT    NUMBER := 0;

  FUNCTION CHECK_USER_NAME(P_USER_NAME IN VARCHAR2) RETURN BOOLEAN IS
    CURSOR C_CHECK IS
      SELECT 'X' FROM APPS.FND_USER WHERE USER_NAME = P_USER_NAME;
    P_CHECK C_CHECK%ROWTYPE;
  BEGIN
    OPEN C_CHECK;
    FETCH C_CHECK
      INTO P_CHECK;
    IF C_CHECK%FOUND THEN
      /*YES, IT EXISTS*/
      CLOSE C_CHECK;
      RETURN TRUE;
    END IF;
    CLOSE C_CHECK;
    RETURN FALSE;
  END CHECK_USER_NAME;
  BEGIN

    ERRBUF := NULL;
    RETCODE := 0;

    L_USER_NAME := P_USER_NAME;
    L_FIRST_NAME := P_FIRST_NAME;
    L_LAST_NAME := P_LAST_NAME;
    L_EMAIL_ADDRESS := P_EMAIL_ADDRESS;
    L_RESP_KEY := P_RESP_KEY;
    L_APP_NAME := P_APP_NAME;

    L_DESCRIPTION := L_FIRST_NAME || ' ' || L_LAST_NAME;


    BEGIN
      BEGIN
        SELECT PERSON_ID
          INTO L_PERSON_ID
          FROM APPS.PER_PEOPLE_F
         WHERE EMPLOYEE_NUMBER = L_USER_NAME
           AND SYSDATE BETWEEN NVL(EFFECTIVE_START_DATE, SYSDATE - 2) AND
               NVL(EFFECTIVE_END_DATE, SYSDATE + 2);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          L_PERSON_ID := NULL;
      END;
      BEGIN
        IF NOT (CHECK_USER_NAME(P_USER_NAME => L_USER_NAME)) THEN
          APPS.FND_USER_PKG.CREATEUSER(X_USER_NAME => L_USER_NAME,
                                       X_OWNER     => NULL,
                                       --X_UNENCRYPTED_PASSWORD => 'WELCOME',
                                       X_SESSION_NUMBER => L_SESSION_ID,
                                       X_START_DATE     => SYSDATE,
                                       X_END_DATE       => NULL,
                                       X_DESCRIPTION    => L_DESCRIPTION,
                                       X_EMAIL_ADDRESS  => L_EMAIL_ADDRESS,
                                       X_EMPLOYEE_ID    => L_PERSON_ID);

          DBMS_OUTPUT.PUT_LINE ('SSO: '||L_USER_NAME||' CREATED SUCCESSFULLY');
        ELSE

          DBMS_OUTPUT.PUT_LINE ('SSO: '||L_USER_NAME||' ALREADY EXISTS');
        END IF;
      END;

      BEGIN
        APPS.FND_USER_PKG.ADDRESP(USERNAME       => L_USER_NAME,
                                  RESP_APP       => L_APP_NAME,
                                  RESP_KEY       => L_RESP_KEY,
                                  SECURITY_GROUP => 'STANDARD',
                                  DESCRIPTION    => NULL,
                                  START_DATE     => SYSDATE,
                                  END_DATE       => NULL);

      EXCEPTION
        WHEN OTHERS THEN
        ERRBUF := SUBSTR(SQLERRM, 1, 100);
        RETCODE := SQLCODE;
          DBMS_OUTPUT.PUT_LINE('UNABLE TO ASSIGN RESPONSIBILITY: ' ||
                               L_RESP_KEY || ' TO SSO: ' || L_USER_NAME ||
                               ' DUE TO ' || SQLCODE || ' ' ||
                               SUBSTR(SQLERRM, 1, 100));
      END;
      L_REC_COUNT := L_REC_COUNT + 1;
    EXCEPTION
      WHEN OTHERS THEN
      ERRBUF := SUBSTR(SQLERRM, 1, 100);
      RETCODE := SQLCODE;
        DBMS_OUTPUT.PUT_LINE('UNABLE TO CREATE SSO: ' || L_USER_NAME ||
                             ' DUE TO ' || SQLCODE || ' ' ||
                             SUBSTR(SQLERRM, 1, 100));
    END;

    IF L_REC_COUNT >= L_COMMIT_COUNT THEN
      COMMIT;
      L_REC_COUNT := 1;
    END IF;

    IF L_REC_COUNT > 0 THEN
      COMMIT;

    END IF;

  EXCEPTION
    WHEN OTHERS THEN
    ERRBUF := SUBSTR(SQLERRM, 1, 100);
    RETCODE := SQLCODE;
      DBMS_OUTPUT.PUT_LINE('UNIDENTIFIED EXCEPTION AT SSO: ' || L_USER_NAME ||
                           ' DUE TO ' || SQLCODE || ' ' ||
                           SUBSTR(SQLERRM, 1, 100));
      ROLLBACK;
  END USER_CREATION_RESP_ASSIGNMENT;


end GEAE_MYGE_LOGIN;

create or replace PACKAGE BODY GEAE_MYGE_LOGIN is

--------Change Log-------------------------------------
/*
Date          Changed By         Description
07-NOV-2014   Ravi Saxena        MYJIRATEST-3512 Modified user access process
17-NOV-2014   Ravi Saxena        MYJIRATEST-3512 Modified user access process - changes in check login
12-FEB-2015   Ravi Saxena        MYJIRATEST-5943 Global user (GEAE) Impersonation
20-Apr-2015   Ankita Shetty      MYJIRATEST-7031 Modified GTA error and Denied party access logic in Check_login
29-APR-2015   Ankita Shetty      MYJIRATEST-7592 Added role assignment for Storefront users login in Request login
03-JUN-2015   Ankita Shetty      MYJIRATEST-8648 Changed check_login to display correct error for invaid icao_code
20-Oct-2016   Amita Bhoyar       Added New Procedure USER_CREATION_RESP_ASSIGNMENT
22-Jun-2018   Manisha            Passport changes; Manisha replaced the out variable p_status with p_ou_id which will return the ou_id seaprated by '~'
                                 if all the login validations is passed.

*/




  PROCEDURE Check_login
			(		p_Operating_unit_id IN VARCHAR2,
                    p_icao_code         IN VARCHAR2,
                    p_user_id           IN VARCHAR2,
                    --p_status            OUT VARCHAR2,  --Manisha K.;US166563; Passport Changes; Commented p_status paramter and introduced P_OU_ID parameter
                    p_ou_id             OUT VARCHAR2,  --Manisha K.;US166563;Passport Changes;Changed the Output to return the OU_ID in output instead of status
                    p_message           OUT VARCHAR2
			)

   IS

    v_user_name           VARCHAR2(20);
	v_status              VARCHAR2(5):= ' '; --22-Jun-2018;US166563; Manisha Added the variable to replace the existing out variable p_status.
	v_internal_icao_code  varchar2(1);
    v_responsiblity_count number;
    v_global_enq_count    number;
    v_check               varchar2(1);
    v_loop_success        varchar2(10);
    v_loop_count          NUMBER;
    v_count               varchar2(1);
    v_attr_value          varchar2(1);
    v_rowcount            varchar2(10);
    
    v_denied_count        number;
    v_gta_count           number;
    n_cust_id             number;
    l_GTA_check           number;
    l_Denied_check        number;
    l number:=0;
    v_ou_id               VARCHAR2(240) := ' '; --22-Jun-2018;US166563; Manisha added the variable to store the ou_id separated by comma.
    l_ou_id               VARCHAR2(240); --US166563;Manisha introduced the variable to store OU_ID value
    n_ou_id               VARCHAR2(240); --US166563;Manisha introduced the variable to store OU_ID value


	BEGIN

		--Commented below for MYJIRATEST-3512 by Ravi S 17-NOV-2014
		
			/*BEGIN
			  SELECT user_name
				INTO v_user_name
				FROM fnd_user
			   WHERE user_name = p_user_id
				 AND TRUNC(SYSDATE) BETWEEN TRUNC(START_DATE) AND
					 NVL(END_DATE, SYSDATE + 1);
			EXCEPTION
			  WHEN NO_DATA_FOUND THEN
				v_status := 'NO';
				--p_message := 'Invalid User';
				SELECT LOOKUP_CODE || ': ' || DESCRIPTION
				  INTO p_message
				  FROM fnd_lookup_values
				 WHERE lookup_type = 'GEAE_MYGE_ERROR_CODES'
				   AND UPPER(LOOKUP_CODE) = UPPER('8004');

			  WHEN OTHERS THEN
				v_status := 'NO';
			END;*/

		v_user_name := p_user_id; --MYJIRATEST-3512 by Ravi S 17-NOV-2014
		
		
		IF v_user_name is NOT NULL 
		THEN
			v_status := 'YES';
		ELSE
			v_status := 'NO';
			
			SELECT 'OU ID: '|| p_Operating_unit_id || '; ' || LOOKUP_CODE || ':' || DESCRIPTION
			INTO 	p_message
			FROM 	fnd_lookup_values
			WHERE 	lookup_type = 'GEAE_MYGE_ERROR_CODES'
			AND 	UPPER(LOOKUP_CODE) = UPPER('8004')			;
			
		END IF;

		
		
		-----------------------------------------------------------VALIDATIONS----------------------------------------------------------------------
		
		
		
		
		-----------------------------------------------------CHECK RESPONSIBILITY--------------------------------------------------------------
		
		
		IF v_status = 'YES' 
		THEN
		
			IF p_icao_code IS NULL 
			THEN
			
				v_status := 'NO';
				
				SELECT 	'OU ID: '|| p_Operating_unit_id || '; ' || LOOKUP_CODE || ':' || DESCRIPTION
				INTO 	p_message
				FROM 	fnd_lookup_values
				WHERE 	lookup_type = 'GEAE_MYGE_ERROR_CODES'
				AND 	UPPER(LOOKUP_CODE) = UPPER('8058')		;
				
			END IF;
		
		
			BEGIN
			
				SELECT 	'Y'
				INTO 	v_internal_icao_code
				FROM 	fnd_lookup_values
				WHERE 	1 = 1
				AND 	upper(lookup_code) = upper(p_icao_code)
				AND 	lookup_type = 'GEAE_INTERNAL_ICAO_CODES';
				
				EXCEPTION
					WHEN NO_DATA_FOUND 
					THEN
						v_internal_icao_code := 'N';
					WHEN TOO_MANY_ROWS 
					THEN
						v_internal_icao_code := 'N';
			END;

		
		
		
		------------------Commented below for MYJIRATEST-3512 by Ravi S 17-NOV-2014
		
			/*BEGIN
			SELECT count(1)
			  INTO v_responsiblity_count
			  FROM fnd_user                    fu,
				   fnd_user_resp_groups_direct furgd,
				   fnd_responsibility_vl       frv
			 WHERE fu.user_id = furgd.user_id
			   AND furgd.responsibility_id = frv.responsibility_id
			   AND fu.user_name = p_user_id --
			   AND TRUNC(SYSDATE) BETWEEN TRUNC(furgd.START_DATE) AND
				   NVL(furgd.END_DATE, SYSDATE)
			   AND frv.responsibility_name in
				   ('myGEAviation Global Enquiry', 'myGEAviation Buyer',
					'myGEAviation Customer Enquiry');

			If v_responsiblity_count > 0 THEN
			  v_status := 'YES';
			  if v_internal_icao_code = 'Y' then
				SELECT count(1)
				  INTO v_global_enq_count
				  FROM fnd_user                    fu,
					   fnd_user_resp_groups_direct furgd,
					   fnd_responsibility_vl       frv
				 WHERE fu.user_id = furgd.user_id
				   AND furgd.responsibility_id = frv.responsibility_id
				   AND fu.user_name = p_user_id --
				   AND TRUNC(SYSDATE) BETWEEN TRUNC(furgd.START_DATE) AND
					   NVL(furgd.END_DATE, SYSDATE)
				   AND frv.responsibility_name in
					   ('myGEAviation Global Enquiry');
				------
				if v_global_enq_count = 0 then
				  v_status := 'NO';
				  --p_message := 'GE internal user does not have Global Enquiry responsibility';
				  SELECT LOOKUP_CODE || ': ' || DESCRIPTION
					INTO p_message
					FROM fnd_lookup_values
				   where lookup_type = 'GEAE_MYGE_ERROR_CODES'
					 AND UPPER(LOOKUP_CODE) = UPPER('8006');
				end if;
				-----
			  END IF;
			ELSE
			  v_status := 'NO';
			  --p_message := 'User doesnot have access';
			  SELECT LOOKUP_CODE || ': ' || DESCRIPTION
				INTO p_message
				FROM fnd_lookup_values
			   WHERE lookup_type = 'GEAE_MYGE_ERROR_CODES'
				 AND UPPER(LOOKUP_CODE) = UPPER('8005');
			END IF;

			END;*/
    
	
		END IF; ----v_status = 'YES'
    
	
	
	
		--------------IF USER AND RESPONSIBILITY VALIDATION PASSES SUCCESSFULLY WE NEED TO CHECK FOR------------------------------------
		--------------ICAO CODE SETUP, WEB_ENABLED, ACTIVE SITES, DENIED PARTY CHECK, AND GTA------------------------------------
    
		IF v_status = 'YES' AND v_internal_icao_code <> 'Y' 
		THEN
  
			---------------------Check conditions to check for WEB ENABLED, ICAO Code, Customer Accounts, Active Sites, and GTA
     

			/*********************************************************
			US166563;Below code Added By Manisha K.;Passport Requirement:
			Two OU_ID will be passed separated by ~ symbol for input p_Operating_unit_id.
			The output will return both OU_ID , the user_id is having access for both.
			**************************************************/
			

			v_ou_id	:=	Replace(p_Operating_unit_id,'~',',');

			FOR j IN
			(	
				SELECT 	trim(regexp_substr(v_ou_id, '[^,]+', 1, LEVEL)) ou_id
				FROM 	dual
				CONNECT BY LEVEL <= regexp_count(v_ou_id, ',')+1
			)
			LOOP

				BEGIN
				
					v_loop_success 	:= NULL;
					v_loop_count   	:= 0;
					l_GTA_check		:= 0;
					l_Denied_check	:= 0;
					l_ou_id 		:= j.ou_id;   -- Assigning the OU_ID value

					
					------------Get count of cust_ids for user -- MYJIRATEST-7031 Ankita.S 20-APR-2015
					
					
					SELECT 	COUNT(hca.cust_account_id) 
					INTO 	n_cust_id
                    FROM 	HZ_CUST_ACCOUNTS hca, HZ_PARTIES HP
					WHERE 	1 = 1
                    AND 	EXISTS
							(
								SELECT 	1
								FROM 	HZ_CUST_ACCT_SITES_ALL HCASA,
										HZ_CUST_SITE_USES_ALL  hcsu
								-- WHERE hcasa.org_id = p_Operating_unit_id
								WHERE 	hcasa.org_id = to_number(j.ou_id)  --US166563;Added By Manisha;US166563; Passing one OU_ID at a time through loop
								and 	NVL(HCASA.STATUS, 'I') = 'A'
								and 	HCSU.SITE_USE_CODE = 'SHIP_TO'
								AND 	hcsu.cust_acct_site_id =
										hcasa.cust_acct_site_id
								AND 	hcasa.cust_account_id = hca.cust_account_id
							)
                    AND	 	NVL(hp.status, 'I') = 'A'
                    AND 	hca.party_id = hp.party_id
                    AND 	NVL(hca.status, 'I') = 'A'
                    AND 	NVL(hca.attribute11, 'WORLD') = p_icao_code
                    AND 	NVL(hca.ATTRIBUTE13, 'WORLD') = 'Y'			;



					FOR i IN 
					(
						SELECT 	hca.cust_account_id,
								hca.ACCOUNT_NUMBER,
								hP.PARTY_NAME
						FROM 	HZ_CUST_ACCOUNTS hca, 
								HZ_PARTIES HP
						WHERE 	1 = 1
						AND 	EXISTS
								(
									SELECT 	1
									FROM 	HZ_CUST_ACCT_SITES_ALL HCASA,
											HZ_CUST_SITE_USES_ALL  hcsu
									--WHERE hcasa.org_id = p_Operating_unit_id
									WHERE 	hcasa.org_id = to_number(j.ou_id)  --US166563;Added By Manisha; Passing one OU_ID at a time through loop
									and 	NVL(HCASA.STATUS, 'I') = 'A'
									and 	HCSU.SITE_USE_CODE = 'SHIP_TO'
									AND 	hcsu.cust_acct_site_id =	hcasa.cust_acct_site_id
									AND hcasa.cust_account_id = hca.cust_account_id
								)
						AND 	NVL(hp.status, 'I') = 'A'
						AND 	hca.party_id = hp.party_id
						AND 	NVL(hca.status, 'I') = 'A'
						AND 	NVL(hca.attribute11, 'WORLD') = p_icao_code
						AND 	NVL(hca.ATTRIBUTE13, 'WORLD') = 'Y'
					) 
					LOOP
					
						v_check        := 'N';
						v_loop_count   := v_loop_count + 1;
						v_denied_count := 0;
						v_gta_count    := 0;

						BEGIN
			
							SELECT COUNT(1)
							INTO 	v_count
							FROM 	oe_hold_sources_all ohs,
									oe_hold_definitions ohd,
									FND_LOOKUP_VALUES   FLV
							WHERE 	1 = 1
							AND 	ohs.hold_entity_id = i.cust_account_id
							AND 	nvl(ohs.hold_entity_code, 'XX') = 'C'
							AND 	nvl(ohs.released_flag, 'X') = 'N'
							--and ohs.org_id = p_Operating_unit_id
							AND 	ohs.org_id = to_number(j.ou_id)  --US166563;Added By Manisha; Passing one OU_ID at a time through loop
							AND 	ohs.hold_id = ohd.hold_id
							AND 	UPPER(ohd.name) = UPPER(flv.lookup_code)
							AND 	flv.lookup_type = 'GEAE_MYGE_MTLS_DENIED_PARTY'				;

							IF v_count > 0 
							THEN
								-- MYJIRATEST-7031 Ankita.S 20-APR-2015
								l_Denied_check := l_Denied_check+1	;
					
								IF l_Denied_check < n_cust_id 
								THEN
									GOTO end_loop;
								ELSE
									v_check        := 'N';
									v_denied_count := v_denied_count + 1;

									--p_message := 'Customer is Denied Party' ;
									SELECT 	'OU ID: '|| j.ou_id || '; ' || LOOKUP_CODE || ': ' || DESCRIPTION
									INTO 	p_message
									FROM 	fnd_lookup_values
									WHERE 	lookup_type = 'GEAE_MYGE_ERROR_CODES'
									AND 	UPPER(LOOKUP_CODE) = UPPER('8001')		;
						
									v_status := 'NO'	;
									l_ou_id := ' '		;   --US166563;Manisha K;  the variable will store space in case of error
								
								END IF	;
					
							ELSE

								v_check := 'Y';
					
					
							END IF;
				
				
						END;
	
			
			
						IF v_check = 'Y' 
						THEN

							BEGIN
				
								-------------------------CHECK CUSTOMER IS GTA ENABLED OR NOT-----------------------------------
								
								SELECT 	NVL(geae_om_util_pkg.get_segmented_dff_value('OTR Processing Attributes','GTA Validation Required',attribute3),'N')
								INTO 	v_attr_value
								FROM 	hz_cust_accounts
								WHERE 	cust_account_id = i.cust_account_id; --cust_account_id = v_cust_id;
								
								EXCEPTION
									WHEN NO_DATA_FOUND 
									THEN
										v_attr_value := 'N';
									WHEN OTHERS 
									THEN
										v_attr_value := 'N';
							
							END; -------------------------CHECK CUSTOMER IS GTA ENABLED OR NOT-----------------------------------


							IF v_attr_value = 'Y' 
							THEN

								BEGIN

									SELECT 	count(*)
									INTO 	v_rowcount
									FROM 	geae_ont_cust_gta_info gta, 
											geae_ont_gta_model gtm
									WHERE 	gtm.geae_ont_cust_gta_info_seq_id =	gta.geae_ont_cust_gta_info_seq_id
									AND 	TRUNC(gta.start_date) <= TRUNC(SYSDATE)
									AND 	NVL(TRUNC(gta.end_date), SYSDATE + 1) 	>=	TRUNC(SYSDATE)
									AND 	gta.customer_id = i.cust_account_id
									-- and gta.org_id = p_operating_unit_id;
									AND 	gta.org_id = to_number(j.ou_id)			;   --US166563;Added By Manisha; Passing one OU_ID at a time through loop

									IF v_rowcount > 0 
									THEN
										v_check := 'Y';
									ELSE -- MYJIRATEST-7031 Ankita.S 20-APR-2015

										l_GTA_check	:=	l_GTA_check+1	;

										IF l_GTA_check < n_cust_id 
										THEN
											GOTO End_loop;
										ELSE
											v_check := 'N';
											-- p_message := 'InValid GTA' ;
											SELECT 'OU ID: '|| j.ou_id || '; ' || LOOKUP_CODE || ': ' || DESCRIPTION
											INTO 	p_message
											FROM 	fnd_lookup_values
											WHERE 	lookup_type = 'GEAE_MYGE_ERROR_CODES'
											AND 	UPPER(LOOKUP_CODE) = UPPER('8002')		;
									
											v_status    := 'NO'				;
											v_gta_count := v_gta_count + 1	;
											l_ou_id 	:= ' '				;    --US166563;Manisha K;  the variable will store space in case of error
								
										END IF;-- MYJIRATEST-7031 Ankita.S 20-APR-2015
							
									END IF;

								END;

							END IF;

    
						END IF;

			
			
			
						IF v_check = 'Y' AND nvl(v_loop_success, 'N') <> 'Y' 
						THEN
							v_loop_success := 'Y';
						END IF;
          
						<<End_loop>>
					
						Null;
					
					END LOOP;


					IF v_loop_count = 0 
					THEN
					
						v_loop_success := 'Y';
						v_status       := 'NO';
						l_ou_id := ' ';     --US166563;Manisha K;  the variable will store space in case of error
						--p_message := 'No Customer Record for the ICAO Code' ;
						
						SELECT 'OU ID: '|| j.ou_id || '; ' || LOOKUP_CODE || ': ' || DESCRIPTION
						INTO p_message
						FROM fnd_lookup_values
						where lookup_type = 'GEAE_MYGE_ERROR_CODES'
						AND UPPER(LOOKUP_CODE) = UPPER('8003');
						GOTO end_proc; --Changed by Ankita.S for MYJIRATEST-8648 on 03/06/2015
								
					END IF;


					IF l_Denied_check=n_cust_id 
					THEN
						v_status := 'NO';
						l_ou_id := ' ';   --US166563;Added By Manisha   the variable will store space in case of error
						
						SELECT 'OU ID: '||j.ou_id || '; ' || LOOKUP_CODE || ': ' || DESCRIPTION
						INTO p_message
						FROM fnd_lookup_values
						where lookup_type = 'GEAE_MYGE_ERROR_CODES'
						AND UPPER(LOOKUP_CODE) = UPPER('8001');
        
					ELSIF l_GTA_check = n_cust_id 
					THEN
						v_status := 'NO';
						l_ou_id := ' ';    --US166563;Manisha K;  the variable will store space in case of error
						
						SELECT 'OU ID: '|| j.ou_id || '; ' || LOOKUP_CODE || ': ' || DESCRIPTION
						INTO p_message
						FROM fnd_lookup_values
						where lookup_type = 'GEAE_MYGE_ERROR_CODES'
						AND UPPER(LOOKUP_CODE) = UPPER('8002')	;
					
					ELSIF	l_GTA_check	+	l_Denied_check	=	n_cust_id 
					Then
						v_status := 'NO';
						l_ou_id := ' ';   --US166563;Added By Manisha
						
						SELECT 'OU ID: '||j.ou_id || '; ' || LOOKUP_CODE || ': ' || DESCRIPTION
						INTO p_message
						FROM fnd_lookup_values
						where lookup_type = 'GEAE_MYGE_ERROR_CODES'
						AND UPPER(LOOKUP_CODE) = UPPER('8007');
					
					ELSE
						NULL;
					
					END IF;


					/*if v_loop_success <> 'Y' then
					  v_status := 'NO';
					  if v_denied_count > 0 and v_gta_count > 0 then
						--p_message := 'Invalid GTA and Denied Party' ;
						SELECT LOOKUP_CODE || ': ' || DESCRIPTION
						  INTO p_message
						  FROM fnd_lookup_values
						 where lookup_type = 'GEAE_MYGE_ERROR_CODES'
						   AND UPPER(LOOKUP_CODE) = UPPER('8007');
					  END IF;
					END IF;*/
				
				END;

				n_ou_id := n_ou_id ||'~'||l_ou_id;
				<<end_proc>> --US166563; Manisha K. added end_proc to exit the current iteration and move to next OU_ID
				
				NULL;
				
			END LOOP;  --End of j.ou_id LOOP
			 
			 
			--US166563; Manisha K. added the below to assign the n_ou_id to output variable p_ou_id
			n_ou_id:= trim(both ' ' from n_ou_id);
			n_ou_id:= trim(both '~' from n_ou_id);
			p_ou_id := n_ou_id ;

			--US166563; Manisha K. Below code added to update p_message to null if any of the OU_ID is having access
			
			IF p_ou_id is not null 
			THEN
				p_message := NULL;
			END IF;

			ELSIF v_status = 'YES' AND v_internal_icao_code = 'Y' 
			THEN
				p_ou_id := p_Operating_unit_id;
			END IF;

    
			-- <<end_proc>> --Changed by Ankita.S for MYJIRATEST-8648 on 03/06/2015   --US166563; Manisha K.Commented and place inside the OU_ID loop to continue with next OU_ID
			NULL;
  
  
	END Check_login;

  
  
  
  
  
  
  
  
  
  
  
  
  PROCEDURE request_login(p_Operating_unit_id  IN VARCHAR2,
                          p_icao_code          IN VARCHAR2,
                          p_user_name          IN VARCHAR2,
                          p_impersonation_flag IN VARCHAR2,
                          P_roles              OUT VARCHAR2,
                          p_cust_ARRAY         out v_cust_array,
                          P_MESSAGE            OUT VARCHAR2) is
    v_global_enquiry     NUMBER;
    v_Buyer              NUMBER;
    v_cust_enquiry       number;
    v_internal_icao_code  varchar2(1);
    v_excp_buyer_icao_code varchar2(1);

   l_custARRAY v_cust_array :=v_cust_array() ;
   -- TYPE l_custARRAY IS VARRAY(250) OF v_Cust_Entry;
    v_index     number := 0;
    v_attr_value       varchar2(1);
    v_rowcount         number;
    v_check char(1);
    v_ou_id         VARCHAR2(240) := ' '; --22-Jun-2018; US166563;Manisha added the variable to store the ou_id separated by comma.
    v_ou_id1        VARCHAr2(240) := ' ';
    v_ou_id2        VARCHAr2(240) := ' ';

  Begin
    P_MESSAGE := NULL;
    p_cust_ARRAY :=v_cust_array();
    --l_custARRAY  := V_custARRAY();
    BEGIN

      SELECT count(1)
        INTO v_global_enquiry
        FROM fnd_user                    fu,
             fnd_user_resp_groups_direct furgd,
             fnd_responsibility_vl       frv
       WHERE fu.user_id = furgd.user_id
         and furgd.responsibility_id = frv.responsibility_id
         AND fu.user_name = p_user_name --
         AND TRUNC(SYSDATE) BETWEEN TRUNC(furgd.START_DATE) AND
             NVL(furgd.END_DATE, SYSDATE)
         AND frv.responsibility_name in ('myGEAviation Global Enquiry');

      SELECT count(1)
        INTO v_Buyer
        FROM fnd_user                    fu,
             fnd_user_resp_groups_direct furgd,
             fnd_responsibility_vl       frv
       WHERE fu.user_id = furgd.user_id
         AND furgd.responsibility_id = frv.responsibility_id
         AND fu.user_name = p_user_name --
         AND TRUNC(SYSDATE) BETWEEN TRUNC(furgd.START_DATE) AND
             NVL(furgd.END_DATE, SYSDATE)
         AND frv.responsibility_name in ('myGEAviation Buyer');

      SELECT count(1)
        INTO v_Cust_enquiry
        FROM fnd_user                    fu,
             fnd_user_resp_groups_direct furgd,
             fnd_responsibility_vl       frv
       WHERE fu.user_id = furgd.user_id
         AND furgd.responsibility_id = frv.responsibility_id
         AND fu.user_name = p_user_name --
         AND TRUNC(SYSDATE) BETWEEN TRUNC(furgd.START_DATE) AND
             NVL(furgd.END_DATE, SYSDATE)
         AND frv.responsibility_name in ('myGEAviation Customer Enquiry');
      --
      --
      IF p_icao_code IS NULL THEN
         SELECT LOOKUP_CODE || ':' || DESCRIPTION
           INTO p_message
           FROM fnd_lookup_values
          WHERE lookup_type = 'GEAE_MYGE_ERROR_CODES'
            AND UPPER(LOOKUP_CODE) = UPPER('8058');
         SELECT v_Cust_Entry(NUll, NULL, NULL) bulk collect into l_custARRAY from dual;
         goto end_proc;
      END IF;
      begin
        select 'Y'
          into v_internal_icao_code
          from fnd_lookup_values
         where 1 = 1
           and upper(lookup_code) = upper(p_icao_code)
           and lookup_type = 'GEAE_INTERNAL_ICAO_CODES';
      exception
        when no_data_found then
          v_internal_icao_code := 'N';
        when too_many_rows then
          v_internal_icao_code := 'N';
      END;

      --Check if the user is an storefront user/Exception user
        --MYJIRATEST-7592  by Ankita.S on 29-APR-2015
        begin
        select 'Y'
          into v_excp_buyer_icao_code
          from fnd_lookup_values
         where 1 = 1
           and upper(lookup_code) = upper(p_icao_code)
           and lookup_type = 'GEAE_MYGE_EXCP_BUYER_ICAO_CODE';
      exception
        when no_data_found then
          v_excp_buyer_icao_code := 'N';
        when too_many_rows then
          v_excp_buyer_icao_code := 'N';
      END;


      --
      --MYJIRATEST-5943 Ravi S 12-FEB-2015
      IF v_internal_icao_code = 'Y' THEN
         IF p_impersonation_flag = 'YES' THEN
            SELECT LOOKUP_CODE || ':' || DESCRIPTION
              INTO p_message
              FROM fnd_lookup_values
             WHERE lookup_type = 'GEAE_MYGE_ERROR_CODES'
               AND UPPER(LOOKUP_CODE) = UPPER('8060');
            SELECT v_Cust_Entry(NUll, NULL, NULL) bulk collect into l_custARRAY from dual;
            goto end_proc;
         ELSE
            p_roles := 'Global Enquiry';
         END IF;
      ELSIF v_excp_buyer_icao_code='Y' THEN --MYJIRATEST-7592  by Ankita.S on 29-APR-2015
          IF v_Buyer > 0 THEN
               p_roles := 'Buyer';
            ELSE
               p_roles := 'Cust Enquiry';
            END IF;
      ELSE
         IF p_impersonation_flag = 'YES' THEN
            p_roles := 'Cust Enquiry';
         ELSE
            IF v_Buyer > 0 THEN
               p_roles := 'Buyer';
            ELSE
               p_roles := 'Cust Enquiry';
            END IF;
         END IF;
      END IF;

      --Commented below logic as part of MYJIRATEST-5943 Ravi S 12-FEB-2015
      /*IF v_internal_icao_code = 'Y' OR p_impersonation_flag = 'YES' THEN
        --
        IF V_GLOBAL_ENQUIRY > 0 THEN
          P_roles := 'Global Enquiry';
        ELSE
          p_roles := NULL;
        END IF;
        --
      ELSE
        ---ELSE of v_internal_icao_code = 'Y'
        --
        IF v_Cust_enquiry >= 0 and v_Buyer > 0 then
          p_roles := 'Buyer';
        ELSIF v_Cust_enquiry > 0 and v_Buyer = 0 THEN
          p_roles := 'Cust Enquiry';
        ELSIF v_Cust_enquiry >= 0 and v_Buyer > 0 and v_global_enquiry > 0 THEN
          p_roles := 'Buyer';
        ELSIF v_Cust_enquiry > 0 and v_global_enquiry > 0 THEN
          p_roles := 'Cust Enquiry';
        ELSE
          p_roles := NULL;
        END IF;
      END IF; ---END IF for v_internal_icao_code = 'Y'
      --Ravi S MYJIRATEST-3512 Modified user access process
      IF p_roles IS NULL THEN
         IF v_internal_icao_code = 'Y' THEN
            P_roles := 'Global Enquiry';
         ELSE
            P_roles := 'Cust Enquiry';
         END IF;
      END IF;*/
    END;
    --
    if p_roles is NULL THEN
      --p_message := 'Role could not be determined';
      SELECT LOOKUP_CODE || ': ' || DESCRIPTION
        INTO p_message
        FROM fnd_lookup_values
       where lookup_type = 'GEAE_MYGE_ERROR_CODES'
         AND UPPER(LOOKUP_CODE) = UPPER('8008');

       SELECT v_Cust_Entry(NUll, NULL, NULL) bulk collect into l_custARRAY from dual;
    END IF;
    --
    -- Cursor for Customer Codes
    --
    /*********************************************************
  US166563;Below code Added By Manisha K.;Passport Requirement:
  Two OU_ID will be passed separated by ~ symbol for input p_Operating_unit_id.
  Modified the code to find the cust_id havin access to either one of them OU_ID or both
  **************************************************/

V_OU_ID := Replace(p_Operating_unit_id,'~',',');
    FOR j IN
     (SELECT trim(regexp_substr(v_ou_id, '[^,]+', 1, LEVEL)) ou_id
    FROM dual
      CONNECT BY LEVEL <= regexp_count(v_ou_id, ',')+1
    )
   LOOP


    IF p_roles ='Buyer' OR p_roles ='Cust Enquiry' THEN --v_internal_icao_code <> 'Y' AND p_roles IS NOT NULL THEN
      BEGIN
        SELECT v_Cust_Entry(hca.cust_account_id, --custId,
               hca.account_number , --custCode,
               hp.party_name)  --custName)
           bulk collect
          into l_custARRAY
          FROM HZ_CUST_ACCOUNTS hca, HZ_PARTIES HP
         WHERE 1 = 1
           AND not exists
         (select 'Y'
                  from oe_hold_sources_all ohs,
                       oe_hold_definitions ohd,
                       fnd_lookup_values   flv
                 where 1 = 1
                   and ohs.hold_entity_id = hca.cust_account_id
                   and nvl(ohs.hold_entity_code, 'XX') = 'C'
                   and nvl(ohs.released_flag, 'X') = 'N'
                --   and ohs.org_id = p_Operating_unit_id
                 --  and (ohs.org_id =  v_ou_id1  OR ohs.org_id =v_ou_id2) --US166563; Manisha commented above line and added this to fetch cust id for both the values of ou_id
                 and ohs.org_id = j.ou_id
                   AND ohs.hold_id = ohd.hold_id
                   and upper(ohd.name) = upper(flv.lookup_code)
                   and flv.lookup_type = 'GEAE_MYGE_MTLS_DENIED_PARTY')
           AND EXISTS
         (SELECT 1
                  from HZ_CUST_ACCT_SITES_ALL HCASA,
                       HZ_CUST_SITE_USES_ALL  hcsu
                -- WHERE hcasa.org_id = p_Operating_unit_id
                 --  WHERE ( hcasa.org_id = v_ou_id1 or hcasa.org_id = v_ou_id2) --US166563; Manisha commented above line and added this to fetch cust id for both the values of ou_id
                 WHERE hcasa.org_id = j.OU_ID
                   and NVL(HCASA.STATUS, 'I') = 'A'
                   and HCSU.SITE_USE_CODE = 'SHIP_TO'
                   AND hcsu.cust_acct_site_id = hcasa.cust_acct_site_id
                   AND hcasa.cust_account_id = hca.cust_account_id)
           AND NVL(hp.status, 'I') = 'A'
           AND hca.party_id = hp.party_id
           AND NVL(hca.status, 'I') = 'A'
           AND NVL(hca.attribute11, 'WORLD') = p_icao_code
           AND NVL(hca.ATTRIBUTE13, 'WORLD') = 'Y';

      exception
        when no_data_found then
          SELECT v_Cust_Entry(NUll, NULL, NULL) bulk collect into l_custARRAY from dual;
          --l_custARRAY := v_custARRAY(-1, NULL, NULL);
      end;

      if l_custARRAY.count > 0 and l_custARRAY(1).cust_id is not null then
        for var in 1 .. l_custARRAY.count loop

          begin
            SELECT NVL(geae_om_util_pkg.get_segmented_dff_value('OTR Processing Attributes',
                                                                'GTA Validation Required',
                                                                attribute3),
                       'N')
              INTO v_attr_value
              from hz_cust_accounts
             WHERE cust_account_id = l_custARRAY(var).cust_id; --cust_account_id = v_cust_id;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              v_attr_value := 'N';
            WHEN OTHERS THEN
              v_attr_value := 'N';
          END; --Check Customer is GTA enabled or not

          IF v_attr_value = 'Y' then
            select count(*)
              INTO v_rowcount
              FROM geae_ont_cust_gta_info gta, geae_ont_gta_model gtm
             WHERE gtm.geae_ont_cust_gta_info_seq_id =
                   gta.geae_ont_cust_gta_info_seq_id
               AND TRUNC(gta.start_date) <= TRUNC(SYSDATE)
               AND NVL(TRUNC(gta.end_date), SYSDATE + 1) >= TRUNC(SYSDATE)
               and gta.customer_id = l_custARRAY(var).cust_id
             --   and gta.org_id = p_operating_unit_id;
            --   and (gta.org_id  = v_ou_id1 OR gta.org_id  = v_ou_id2); --US166563; Manisha commented above line and added this to fetch both the values of
            and gta.org_id =j.OU_ID;

            if v_rowcount > 0 then

              v_check := 'Y';
              v_index := v_index + 1;
            p_cust_ARRAY.extend();
           p_cust_ARRAY(v_index) := l_custARRAY(var);
            end if;
          else

            v_check := 'Y';
              v_index := v_index + 1;
          p_cust_array.extend();
           p_cust_ARRAY(v_index) := l_custARRAY(var);
          end if;
        end loop;
        else
           SELECT LOOKUP_CODE || ': ' || DESCRIPTION
            INTO p_message
            FROM fnd_lookup_values
           where lookup_type = 'GEAE_MYGE_ERROR_CODES'
             and upper(lookup_code) = upper('8009');
            SELECT v_Cust_Entry(NUll, NULL, NULL) bulk collect into p_cust_ARRAY from dual;
      end if;
    end if;

    END LOOP; --j.ou_id loop ends
    <<end_proc>>
    NULL;
  END request_login;
 PROCEDURE request_login_repairs(p_Operating_unit_id  IN VARCHAR2,
                          p_icao_code          IN VARCHAR2,
                          p_user_name          IN VARCHAR2,
                          p_impersonation_flag IN VARCHAR2,
                          P_roles              OUT VARCHAR2,
                          p_cust_ARRAY         out v_cust_array,
                          P_MESSAGE            OUT VARCHAR2) is

   v_internal_icao_code  varchar2(1);
   l_custARRAY v_cust_array :=v_cust_array() ;
   l_custARRAY_cnt NUMBER:=0;
   -- TYPE l_custARRAY IS VARRAY(250) OF v_Cust_Entry;
  Begin
    P_MESSAGE := NULL;
    p_cust_ARRAY :=v_cust_array();
    --l_custARRAY  := V_custARRAY();
     IF p_icao_code IS NULL THEN
         SELECT LOOKUP_CODE || ':' || DESCRIPTION
           INTO p_message
           FROM fnd_lookup_values
          WHERE lookup_type = 'GEAE_MYGE_ERROR_CODES'
            AND UPPER(LOOKUP_CODE) = UPPER('8058');
         SELECT v_Cust_Entry(NUll, NULL, NULL) bulk collect into l_custARRAY from dual;
         goto end_proc;
      END IF;
      begin
        select 'Y'
          into v_internal_icao_code
          from fnd_lookup_values
         where 1 = 1
           and upper(lookup_code) = upper(p_icao_code)
           and lookup_type = 'GEAE_INTERNAL_ICAO_CODES';
      exception
        when no_data_found then
          v_internal_icao_code := 'N';
        when too_many_rows then
          v_internal_icao_code := 'N';
      END;

       --
      --MYJIRATEST-5943 Ravi S 12-FEB-2015
      IF v_internal_icao_code = 'Y' THEN
         IF p_impersonation_flag = 'YES' THEN
            SELECT LOOKUP_CODE || ':' || DESCRIPTION
              INTO p_message
              FROM fnd_lookup_values
             WHERE lookup_type = 'GEAE_MYGE_ERROR_CODES'
               AND UPPER(LOOKUP_CODE) = UPPER('8060');
            SELECT v_Cust_Entry(NUll, NULL, NULL) bulk collect into l_custARRAY from dual;
            goto end_proc;
         END IF;
      END IF;
   -- Getting customer details
      if p_icao_code = 'GEAE'  then --OR p_icao_code = 'MMGE'

      SELECT v_Cust_Entry(cust_account_id, --custId,
               account_number , --custCode,
               party_name)  --custName)
           bulk collect
          into l_custARRAY
          FROM        (select distinct act1.cust_account_id, --custId,
               act1.account_number , --custCode,
               par.party_name
               FROM           apps.hz_parties par
                                ,apps.hz_cust_accounts act
                                ,apps.hz_cust_acct_sites_all sit
                                ,apps.hz_cust_site_uses_all use
                                ,apps.hz_party_sites prt
                                ,apps.hz_locations loc
                                ,apps.fnd_territories_vl trr
                                ,apps.oe_transaction_types_tl ott
                                ,apps.mtl_parameters mpa
                                ,apps.qp_list_headers_tl qlh
                                ,apps.fnd_user usc
                                ,apps.fnd_user usu
                                ,apps.fnd_lookup_values flv
                                ,apps.hz_cust_acct_relate_all rel
                                ,apps.hz_cust_accounts act1
                                ,apps.hz_cust_site_uses_all su1
                                ,apps.hz_cust_acct_sites_all hca1
                                ,apps.hz_cust_site_uses_all su_bill1
                                ,apps.hz_cust_account_roles acct_role1
                                ,apps.hz_parties party1
                                ,apps.hz_relationships rel1
                                ,apps.ar_lookups l_cat
                                ,apps.jtf_rs_salesreps sr
                WHERE                par.party_id                          = act.party_id
                   AND    act.cust_account_id        = sit.cust_account_id(+)
                   AND    sit.party_site_id          = prt.party_site_id(+)
                   AND    prt.location_id            = loc.location_id(+)
                   AND    loc.country                = trr.territory_code(+)
                   AND    sit.cust_acct_site_id      = use.cust_acct_site_id(+)
                   AND  use.site_use_code          <> 'BILL_TO'
                   AND  NVL (use.LOCATION, '-1')   <> '-1'
                   AND  use.order_type_id          = ott.transaction_type_id(+)
                   AND    ott.LANGUAGE(+)            = USERENV ('LANG')
                   AND    use.warehouse_id           = mpa.organization_id(+)
                   AND    use.price_list_id          = qlh.list_header_id(+)
                   AND    qlh.LANGUAGE(+)            = USERENV ('LANG')
                   AND    act.status(+)              = 'A'
                   AND    use.status(+)                        = 'A'
                   AND  use.primary_salesrep_id    = sr.salesrep_id (+)
                   AND    flv.LOOKUP_TYPE            = 'GEAE_FALLOUT_REPORT'
                   AND    flv.enabled_flag           = 'Y'
                   AND    sit.org_id                 = flv.description(+)
                   AND    act.cust_account_id        = rel.related_cust_account_id(+)
                   AND    rel.cust_account_id        = act1.cust_account_id(+)
                   AND    su1.bill_to_site_use_id    = su_bill1.site_use_id(+)
                   AND    su1.contact_id             = acct_role1.cust_account_role_id(+)
                   AND    acct_role1.party_id        = rel1.party_id(+)
                   AND    rel1.subject_table_name(+) = 'HZ_PARTIES'
                   AND    rel1.object_table_name(+)  = 'HZ_PARTIES'
                   AND    rel1.directional_flag(+)   = 'F'
                   AND    acct_role1.role_type(+)    = 'CONTACT'
                   AND    rel1.subject_id            = party1.party_id(+)
                   AND    hca1.cust_acct_site_id     = su1.cust_acct_site_id
                   AND    hca1.cust_account_id       = sit.cust_account_id
                   AND    su1.cust_acct_site_id      = use.cust_acct_site_id
                   AND    act.created_by             = usc.user_id
                   AND    act.last_updated_by        = usu.user_id
                   AND    sit.customer_category_code = l_cat.lookup_code(+)
                   AND    l_cat.lookup_type(+)       = 'ADDRESS_CATEGORY'
                  -- AND (sit.org_id = NVL (60377, sit.org_id) OR flv.tag      =DECODE(60377,0,'COMMERCIAL'))
                   AND act.attribute11 ='G');

                   else

       SELECT v_Cust_Entry(cust_account_id, --custId,
               account_number , --custCode,
               party_name)  --custName)
           bulk collect
          into l_custARRAY
          FROM        (select distinct act1.cust_account_id, --custId,
               act1.account_number , --custCode,
               par.party_name
               FROM           apps.hz_parties par
                                ,apps.hz_cust_accounts ACT1
                  WHERE   par.party_id   = act1.party_id
                  AND ACT1.attribute11 =p_icao_code);
                  end if;
       --
         IF SQL%rowcount > 0 THEN
           FOR i IN 1 .. l_custARRAY.count
           LOOP
             l_custARRAY_cnt := l_custARRAY_cnt + 1;
             p_cust_ARRAY.EXTEND();
             p_cust_ARRAY(l_custARRAY_cnt) := l_custARRAY(i);
           END LOOP;
         ELSE

          SELECT v_Cust_Entry(NUll, NULL, NULL) bulk collect into l_custARRAY from dual;
          --l_custARRAY := v_custARRAY(-1, NULL, NULL);
         END IF;

    <<end_proc>>
    NULL;
  END request_login_repairs;
  ---------------------------------------------------------------------------------
  --Added New Procedure: USER_CREATION_RESP_ASSIGNMENT
  --To create User and Responsibility Assignment
  --------------------------------------------------------------------------------
  PROCEDURE USER_CREATION_RESP_ASSIGNMENT(P_USER_NAME   IN  VARCHAR2,
                                          P_FIRST_NAME  IN  VARCHAR2,
                                          P_LAST_NAME   IN  VARCHAR2,
                                          P_EMAIL_ADDRESS IN VARCHAR2,
                                          P_RESP_KEY    IN  VARCHAR2,
                                          P_APP_NAME    IN  VARCHAR2,
                                          ERRBUF        OUT VARCHAR2,
                                          RETCODE       OUT NUMBER)
  IS

  L_SESSION_ID INTEGER := USERENV('SESSIONID');
  L_PERSON_ID  NUMBER;

  L_USER_NAME  VARCHAR2(50);
  L_FIRST_NAME VARCHAR2(50);
  L_LAST_NAME VARCHAR2(50);
  L_EMAIL_ADDRESS VARCHAR2(50);
  L_RESP_KEY VARCHAR2(50);
  L_APP_NAME VARCHAR2(50);

  L_DESCRIPTION VARCHAR2(300);

  L_COMMIT_COUNT NUMBER := 10;
  L_REC_COUNT    NUMBER := 0;

  FUNCTION CHECK_USER_NAME(P_USER_NAME IN VARCHAR2) RETURN BOOLEAN IS
    CURSOR C_CHECK IS
      SELECT 'X' FROM APPS.FND_USER WHERE USER_NAME = P_USER_NAME;
    P_CHECK C_CHECK%ROWTYPE;
  BEGIN
    OPEN C_CHECK;
    FETCH C_CHECK
      INTO P_CHECK;
    IF C_CHECK%FOUND THEN
      /*YES, IT EXISTS*/
      CLOSE C_CHECK;
      RETURN TRUE;
    END IF;
    CLOSE C_CHECK;
    RETURN FALSE;
  END CHECK_USER_NAME;
  BEGIN

    ERRBUF := NULL;
    RETCODE := 0;

    L_USER_NAME := P_USER_NAME;
    L_FIRST_NAME := P_FIRST_NAME;
    L_LAST_NAME := P_LAST_NAME;
    L_EMAIL_ADDRESS := P_EMAIL_ADDRESS;
    L_RESP_KEY := P_RESP_KEY;
    L_APP_NAME := P_APP_NAME;

    L_DESCRIPTION := L_FIRST_NAME || ' ' || L_LAST_NAME;


    BEGIN
      BEGIN
        SELECT PERSON_ID
          INTO L_PERSON_ID
          FROM APPS.PER_PEOPLE_F
         WHERE EMPLOYEE_NUMBER = L_USER_NAME
           AND SYSDATE BETWEEN NVL(EFFECTIVE_START_DATE, SYSDATE - 2) AND
               NVL(EFFECTIVE_END_DATE, SYSDATE + 2);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          L_PERSON_ID := NULL;
      END;
      BEGIN
        IF NOT (CHECK_USER_NAME(P_USER_NAME => L_USER_NAME)) THEN
          APPS.FND_USER_PKG.CREATEUSER(X_USER_NAME => L_USER_NAME,
                                       X_OWNER     => NULL,
                                       --X_UNENCRYPTED_PASSWORD => 'WELCOME',
                                       X_SESSION_NUMBER => L_SESSION_ID,
                                       X_START_DATE     => SYSDATE,
                                       X_END_DATE       => NULL,
                                       X_DESCRIPTION    => L_DESCRIPTION,
                                       X_EMAIL_ADDRESS  => L_EMAIL_ADDRESS,
                                       X_EMPLOYEE_ID    => L_PERSON_ID);

          DBMS_OUTPUT.PUT_LINE ('SSO: '||L_USER_NAME||' CREATED SUCCESSFULLY');
        ELSE

          DBMS_OUTPUT.PUT_LINE ('SSO: '||L_USER_NAME||' ALREADY EXISTS');
        END IF;
      END;

      BEGIN
        APPS.FND_USER_PKG.ADDRESP(USERNAME       => L_USER_NAME,
                                  RESP_APP       => L_APP_NAME,
                                  RESP_KEY       => L_RESP_KEY,
                                  SECURITY_GROUP => 'STANDARD',
                                  DESCRIPTION    => NULL,
                                  START_DATE     => SYSDATE,
                                  END_DATE       => NULL);

      EXCEPTION
        WHEN OTHERS THEN
        ERRBUF := SUBSTR(SQLERRM, 1, 100);
        RETCODE := SQLCODE;
          DBMS_OUTPUT.PUT_LINE('UNABLE TO ASSIGN RESPONSIBILITY: ' ||
                               L_RESP_KEY || ' TO SSO: ' || L_USER_NAME ||
                               ' DUE TO ' || SQLCODE || ' ' ||
                               SUBSTR(SQLERRM, 1, 100));
      END;
      L_REC_COUNT := L_REC_COUNT + 1;
    EXCEPTION
      WHEN OTHERS THEN
      ERRBUF := SUBSTR(SQLERRM, 1, 100);
      RETCODE := SQLCODE;
        DBMS_OUTPUT.PUT_LINE('UNABLE TO CREATE SSO: ' || L_USER_NAME ||
                             ' DUE TO ' || SQLCODE || ' ' ||
                             SUBSTR(SQLERRM, 1, 100));
    END;

    IF L_REC_COUNT >= L_COMMIT_COUNT THEN
      COMMIT;
      L_REC_COUNT := 1;
    END IF;

    IF L_REC_COUNT > 0 THEN
      COMMIT;

    END IF;

  EXCEPTION
    WHEN OTHERS THEN
    ERRBUF := SUBSTR(SQLERRM, 1, 100);
    RETCODE := SQLCODE;
      DBMS_OUTPUT.PUT_LINE('UNIDENTIFIED EXCEPTION AT SSO: ' || L_USER_NAME ||
                           ' DUE TO ' || SQLCODE || ' ' ||
                           SUBSTR(SQLERRM, 1, 100));
      ROLLBACK;
  END USER_CREATION_RESP_ASSIGNMENT;


end GEAE_MYGE_LOGIN;
