

GEAE_MYGE_PO_EXPT_NEWSPARE_PKG


create or replace PACKAGE BODY GEAE_MYGE_PO_EXPT_NEWSPARE_PKG
AS
/***********************************************************************************
Procedure Name: NEW_SPARES_EXPT_PO_DTLS_PRC
Purpose: Procedure is used to fetch 70000 records for the given Customer Code(if applicable).
Created by : Prasad
Creation Date : 15-Dec-2016
************************************************************************************/

PROCEDURE NEW_SPARES_EXPT_PO_DTLS_PRC (
   P_ICAO_CODE                      		IN       VARCHAR2,
   P_CUST_CODE                      		IN       CLOB,
   P_REQUESTDATEFROM    			IN       VARCHAR2,
   P_REQUESTDATETO       			IN       VARCHAR2,
   P_ORDERDATEFROM       			IN  	 VARCHAR2,
   P_ORDERDATETO         			IN  	 VARCHAR2,
   P_DELIVERDATEFROM     			IN  	 VARCHAR2,
   P_DELIVERDATETO       			IN  	 VARCHAR2,
   P_SHIPMENTDATEFROM    			IN  	 VARCHAR2,
   P_SHIPMENTDATETO      			IN  	 VARCHAR2,
   P_MS_NUMBER_FILTER				IN 	 VARCHAR2,
   P_MS_NUMBER_INP				IN       VARCHAR2,
   P_ORDER_TYPE_FILTER              		IN       VARCHAR2,
   P_ORDER_TYPE_INP                 		IN       VARCHAR2,
   P_CUSTOMER_NUMBER_FILTER         		IN       VARCHAR2,
   P_CUSTOMER_NUMBER_INP            		IN       VARCHAR2,
   P_PURCHASE_ORDER_FILTER          		IN       VARCHAR2,
   P_PURCHASE_ORDER_INP             		IN       VARCHAR2,
   P_INVOICE_NUMBER_FILTER				IN       VARCHAR2,
   P_INVOICE_NUMBER_INP				IN       VARCHAR2,
   P_LINE_NUMBER_FILTER             		IN       VARCHAR2,
   P_LINE_NUMBER_INP                		IN       VARCHAR2,
   P_LINE_STATUS_FILTER           		IN       VARCHAR2,
   P_LINE_STATUS_INP             		IN       VARCHAR2,
   P_PART_NUMBER_IN_FILTER          		IN       VARCHAR2,
   P_PART_NUMBER_IN_INP             		IN       VARCHAR2,
   P_ORDERED_QUANTITY_FILTER        		IN       VARCHAR2,
   P_ORDERED_QUANTITY_INP           		IN       VARCHAR2,
   P_CANCELLED_QUANTITY_FILTER      		IN       VARCHAR2,
   P_CANCELLED_QUANTITY_INP     		IN       VARCHAR2,
   P_SHIPPED_QUANTITY_FILTER      		IN       VARCHAR2,
   P_SHIPPED_QUANTITY_INP          		IN       VARCHAR2,
   P_INVOICED_QUANTITY_FILTER       		IN       VARCHAR2,
   P_INVOICED_QUANTITY_INP          		IN       VARCHAR2,
   P_ENG_FAMILY_FILTER            		IN       VARCHAR2,
   P_ENG_FAMILY_INP               		IN       VARCHAR2,
   P_ORDERED_DATE_FILTER    			IN       VARCHAR2,
   P_REQUEST_DATE_FILTER            		IN       VARCHAR2,
   P_AWB_NUMBER_FILTER 			    	IN       VARCHAR2,
   P_AWB_NUMBER_INP          			IN       VARCHAR2,
   P_DELIVERY_DATE_FILTER           		IN       VARCHAR2,
   P_SHIPMENT_DATE_FILTER           		IN       VARCHAR2,
   P_SELLING_PRICE_FILTER           		IN       VARCHAR2,
   P_SELLING_PRICE_INP              		IN       VARCHAR2,
   P_LIST_PRICE_FILTER              		IN       VARCHAR2,
   P_LIST_PRICE_INP                 		IN       VARCHAR2,
   P_EXTENDED_PRICE_FILTER          		IN       VARCHAR2,
   P_EXTENDED_PRICE_INP             		IN       VARCHAR2,
   P_PRODUCT_LINE_FILTER          		IN       VARCHAR2,
   P_PRODUCT_LINE_INP             		IN       VARCHAR2,
   P_ORDER_BY_COLUMN					IN 		VARCHAR2,
   P_SORT_TYPE							IN 		VARCHAR2,
   P_VIEW_LIST                      		OUT      V_PO_EXPORT_DETAILS_LIST_ARRAY,
   P_DB_ERROR                           OUT      VARCHAR2,
   P_TOTAL_RECORDS                      OUT      VARCHAR2
)

  AS

  timeStart  TIMESTAMP;
  timeEnd    TIMESTAMP;

   V_Select_Str           Varchar2 (32767) := '';
   p_view_cur             SYS_REFCURSOR;
   R_PO_LIST_E            Exception;
   R_PO_COUNT             Number := 0;
   V_RequestDatefrom      Varchar2 (50)    := '';
   V_RequestDateto        Varchar2 (50)    := '';
   V_OrderDatefrom        Varchar2 (50)    := '';
   V_OrderDateto          Varchar2 (50)    := '';
   V_DeliverDatefrom      Varchar2 (50)    := '';
   V_DeliverDateto        Varchar2 (50)    := '';
   V_ShipmentDatefrom     Varchar2 (50)    := '';
   V_ShipmentDateto       Varchar2 (50)    := '';
   V_Customer_Codes       Varchar2 (4000)  := '';
   V_CUSTOMER_NUMBER      VARCHAR2(50);
   V_CUST_PO_NUMBER       VARCHAR2(100);
   V_INVOICE_NUMBER      VARCHAR2(100);
   V_LINE_NUMBER          VARCHAR2(50);
   V_ORDERED_ITEM         VARCHAR2(200);
   V_LINE_STATUS          VARCHAR2(100);
   V_ORDERED_QUANTITY     VARCHAR2(50);
   V_CANCELLED_QUANTITY   VARCHAR2(50);
   V_SHIPPED_QUANTITY    VARCHAR2(100);
   V_INVOICED_QUANTITY    VARCHAR2(30);
   V_ORDERED_DATE         VARCHAR2(50);
   V_REQUEST_DATE    VARCHAR2(50);
   V_DELIVERY_DATE    VARCHAR2(50);
   V_SHIPMENT_DATE    VARCHAR2(10);
   V_SELLING_PRICE    VARCHAR2(100);
   V_LIST_PRICE      VARCHAR2(50);
   V_EXTENDED_PRICE       VARCHAR2(50);
   V_MS_NUMBER          VARCHAR2(50);
   V_WAYBILL        VARCHAR2(100);
   V_ENG_FAMILY      VARCHAR2(50);
   V_PRODUCT_LINE         VARCHAR2(50);
   V_QUICK_FILTER_FLAG    CHAR := 'N';
   V_orderType      VARCHAR2(100);

  BEGIN

     timeStart:=systimestamp;
   dbms_output.put_line('Time starts..'||timeStart);
  /*************************************************
     CHECKING THE NULL CONDITION FOR ICAO CODE
    *************************************************/
  IF P_ICAO_CODE IS NULL THEN

    P_DB_ERROR:= 'ICAO CODE IS NULL';
    RAISE R_PO_LIST_E;

  END IF;

  IF P_ORDER_TYPE_INP IS NULL THEN

    P_DB_ERROR:= 'ORDERTYPE SHOULD NOT BE A NULL';
    RAISE R_PO_LIST_E;

  END IF;


    /*********************************************************************************************************************************
     Replacing the '~' symbol with ',' for Customer codes,Date From and Date To
    **********************************************************************************************************************************/
    V_Customer_Codes:=' '||''''||Replace(P_CUST_CODE,'~',''',''')||''''||' ';
     V_RequestDatefrom:='TO_DATE(' || '''' ||TO_DATE(P_REQUESTDATEFROM,'YYYY-MM-DD') || '''' || ', ''DD-MON-YY'')';
    V_RequestDateto:='TO_DATE(' || '''' ||TO_DATE(P_REQUESTDATETO,'YYYY-MM-DD') || '''' || ', ''DD-MON-YY'')';
    V_OrderDatefrom:='TO_DATE(' || '''' ||TO_DATE(P_ORDERDATEFROM,'YYYY-MM-DD') || '''' || ', ''DD-MON-YY'')';
    V_OrderDateto:='TO_DATE(' || '''' ||TO_DATE(P_ORDERDATETO,'YYYY-MM-DD') || '''' || ', ''DD-MON-YY'')';
    V_DeliverDatefrom:='TO_DATE(' || '''' ||TO_DATE(P_DELIVERDATEFROM,'YYYY-MM-DD') || '''' || ', ''DD-MON-YY'')';
    V_DeliverDateto:='TO_DATE(' || '''' ||TO_DATE(P_DELIVERDATETO,'YYYY-MM-DD') || '''' || ', ''DD-MON-YY'')';
    V_ShipmentDatefrom:='TO_DATE(' || '''' ||TO_DATE(P_SHIPMENTDATEFROM,'YYYY-MM-DD') || '''' || ', ''DD-MON-YY'')';
    V_ShipmentDateto:='TO_DATE(' || '''' ||TO_DATE(P_SHIPMENTDATETO,'YYYY-MM-DD') || '''' || ', ''DD-MON-YY'')';

               V_Select_Str:='SELECT  CUSTOMER_NUMBER,
                     CUST_PO_NUMBER PURCHASE_ORDER,
           INVOICE_NUMBER,
                     LINE_NUMBER,
                     ORDERED_ITEM PART_NUMBER,
                     LINE_STATUS STATUS,
                     ORDERED_QUANTITY REQUESTED_QUANTITY,
                     CANCELLED_QUANTITY,
                     SHIPPED_QUANTITY,
                     INVOICED_QUANTITY,
                     ORDERED_DATE,
                     REQUEST_DATE,
                     PROMISE_DATE DELIVERY_DATE,
                     ACTUAL_SHIPMENT_DATE SHIPMENT_DATE,
                     UNIT_SELLING_PRICE SELLING_PRICE,
                     UNIT_LIST_PRICE LIST_PRICE,
                     (ORDERED_QUANTITY * UNIT_LIST_PRICE) EXTENDED_PRICE,
                     MS_NUMBER,
                     WAYBILL AWB_NUMBER,
                     ENG_FAM ENGINE_FAMILY,
                     PRODUCT_LINE ENGINE_MODEL,
                     LINE_CATEGORY_CODE
                   FROM APPS.GEAE_MYGE_ORDER_LINE_DETAILS_V
                   WHERE';

        /*******************************************************
          Checking the condition for customer codes
         *************************************************/

    IF P_ORDER_TYPE_FILTER IS NOT NULL AND P_ORDER_TYPE_INP IS NOT NULL AND P_ORDER_TYPE_FILTER='LINE_CATEGORY_CODE' THEN

      V_Select_Str:=V_Select_Str||' upper(LINE_CATEGORY_CODE) LIKE upper('''|| P_ORDER_TYPE_INP ||''') AND ROWNUM <= 70000' ;

    END IF;

        IF P_CUST_CODE IS NOT NULL  AND UPPER(P_ICAO_CODE) NOT IN ('GEAE')  THEN

         V_Select_Str:=V_Select_Str||' AND CUSTOMER_NUMBER IN ('||upper(V_Customer_Codes)||')';

        END IF;

    -- REQUEST DATE

    IF P_REQUESTDATEFROM IS NOT NULL AND P_REQUESTDATETO IS NOT NULL AND P_REQUEST_DATE_FILTER='REQUEST_DATE' THEN

        V_Select_Str:=V_Select_Str||' AND TRUNC(REQUEST_DATE) BETWEEN '|| V_RequestDatefrom ||' AND '||V_RequestDateto ||'';

    ELSIF P_REQUESTDATEFROM IS NOT NULL AND P_REQUESTDATETO IS NULL THEN

        V_Select_Str:=V_Select_Str||' AND upper(REQUEST_DATE) LIKE upper('||V_RequestDatefrom||')' ;
    END IF;


    -- ORDERED DATE

    IF P_ORDERDATEFROM IS NOT NULL AND P_ORDERDATETO IS NOT NULL AND P_ORDERED_DATE_FILTER='ORDERED_DATE'  THEN

        V_Select_Str:=V_Select_Str||' AND TRUNC(ORDERED_DATE) BETWEEN '|| V_OrderDatefrom ||' AND '||V_OrderDateto ||'';

    ELSIF P_ORDERDATEFROM IS NOT NULL AND P_ORDERDATETO IS NULL THEN

        V_Select_Str:=V_Select_Str||' AND upper(ORDERED_DATE) LIKE upper('||V_OrderDatefrom||')' ;

    END IF;


    -- SHIPMENT_DATE


    IF P_SHIPMENTDATEFROM IS NOT NULL AND P_SHIPMENTDATETO IS NOT NULL AND P_SHIPMENT_DATE_FILTER='SHIPMENT_DATE' THEN

      V_Select_Str:=V_Select_Str||' AND TRUNC(ACTUAL_SHIPMENT_DATE) BETWEEN '|| V_ShipmentDatefrom ||' AND '|| V_ShipmentDateto ||'';

    ELSIF P_SHIPMENTDATEFROM IS NOT NULL AND P_SHIPMENTDATETO IS NULL THEN

      V_Select_Str:=V_Select_Str||' AND upper(ACTUAL_SHIPMENT_DATE) LIKE upper('|| V_ShipmentDatefrom ||')' ;

    END IF;


    -- DELIVERY_DATE


    IF P_DELIVERDATEFROM IS NOT NULL AND P_DELIVERDATETO IS NOT NULL AND P_DELIVERY_DATE_FILTER ='DELIVERY_DATE' THEN

      V_Select_Str:=V_Select_Str||' AND TRUNC(PROMISE_DATE) BETWEEN '|| V_DeliverDatefrom ||' AND '|| V_DeliverDateto ||'';

    ELSIF P_DELIVERDATEFROM IS NOT NULL AND P_DELIVERDATETO IS NULL THEN

      V_Select_Str:=V_Select_Str||' AND upper(PROMISE_DATE) LIKE upper('|| V_DeliverDatefrom ||')' ;

    END IF;


   -- CUSTOMER

      IF P_CUSTOMER_NUMBER_FILTER IS NOT NULL AND P_CUSTOMER_NUMBER_INP IS NOT NULL AND P_CUSTOMER_NUMBER_FILTER='CUSTOMER_NUMBER' THEN

        V_Select_Str:=V_Select_Str||' AND upper(customer_number) LIKE upper('''||P_CUSTOMER_NUMBER_INP||''')' ;

      END IF;


    -- PO NUMBER

    IF P_PURCHASE_ORDER_FILTER IS NOT NULL AND P_PURCHASE_ORDER_INP IS NOT NULL AND P_PURCHASE_ORDER_FILTER='CUST_PO_NUMBER' THEN

        V_Select_Str:=V_Select_Str||' AND CUST_PO_NUMBER LIKE '''||P_PURCHASE_ORDER_INP||'''' ;

  END IF;

  -- INVOICE_NUMBER

    IF P_INVOICE_NUMBER_FILTER IS NOT NULL AND P_INVOICE_NUMBER_INP IS NOT NULL AND P_INVOICE_NUMBER_FILTER='INVOICE_NUMBER' THEN

        V_Select_Str:=V_Select_Str||' AND INVOICE_NUMBER LIKE '''||P_INVOICE_NUMBER_INP||'''' ;

  END IF;

    -- PO LINE NUMBER

    IF P_LINE_NUMBER_FILTER IS NOT NULL AND P_LINE_NUMBER_INP IS NOT NULL AND P_LINE_NUMBER_FILTER='LINE_NUMBER' THEN

        V_Select_Str:=V_Select_Str||' AND upper(LINE_NUMBER) LIKE upper('''||P_LINE_NUMBER_INP||''')' ;

    END IF;

    -- STATUS

        IF P_LINE_STATUS_FILTER IS NOT NULL AND P_LINE_STATUS_INP IS NOT NULL AND P_LINE_STATUS_FILTER='LINE_STATUS' THEN

    V_Select_Str:=V_Select_Str||' AND upper(LINE_STATUS) LIKE upper('''||P_LINE_STATUS_INP||''')' ;

      END IF;

    -- PART NUMBER

    IF P_PART_NUMBER_IN_FILTER IS NOT NULL AND P_PART_NUMBER_IN_INP IS NOT NULL AND P_PART_NUMBER_IN_FILTER='ORDERED_ITEM' THEN

            V_Select_Str:=V_Select_Str||' AND upper(ORDERED_ITEM) LIKE upper('''||P_PART_NUMBER_IN_INP||''')' ;

  END IF;


     -- ORDERED QTY


      IF P_ORDERED_QUANTITY_FILTER IS NOT NULL AND P_ORDERED_QUANTITY_INP IS NOT NULL AND P_ORDERED_QUANTITY_FILTER='ORDERED_QUANTITY' THEN

        V_Select_Str:=V_Select_Str||' AND ORDERED_QUANTITY LIKE upper('''||P_ORDERED_QUANTITY_INP||''')' ;

      END IF;

    -- CANCELLED QTY


      IF P_CANCELLED_QUANTITY_FILTER IS NOT NULL AND P_CANCELLED_QUANTITY_INP IS NOT NULL AND P_CANCELLED_QUANTITY_FILTER='CANCELLED_QUANTITY' THEN

        V_Select_Str:=V_Select_Str||' AND CANCELLED_QUANTITY LIKE upper('''||P_CANCELLED_QUANTITY_INP||''')' ;

      END IF;


    -- SHIPPED QTY


      IF P_SHIPPED_QUANTITY_FILTER IS NOT NULL AND P_SHIPPED_QUANTITY_INP IS NOT NULL AND P_SHIPPED_QUANTITY_INP='SHIPPED_QUANTITY' THEN

        V_Select_Str:=V_Select_Str||' AND upper(SHIPPED_QUANTITY) LIKE upper('''||P_SHIPPED_QUANTITY_INP||''')' ;

      END IF;


    -- INVOICED QTY


      IF P_INVOICED_QUANTITY_FILTER IS NOT NULL AND P_INVOICED_QUANTITY_INP IS NOT NULL AND P_INVOICED_QUANTITY_FILTER='INVOICED_QUANTITY' THEN

            V_Select_Str:=V_Select_Str||' AND upper(INVOICED_QUANTITY) LIKE upper('''||P_INVOICED_QUANTITY_INP||''')' ;

      END IF;

    -- ENGINE FAMILY


      IF P_ENG_FAMILY_FILTER IS NOT NULL AND P_ENG_FAMILY_INP IS NOT NULL AND P_ENG_FAMILY_FILTER='ENG_FAMILY' THEN

            V_Select_Str:=V_Select_Str||' AND upper(ENG_FAM) LIKE upper('''||P_ENG_FAMILY_INP||''')' ;

      END IF;


    -- AWB NUMBER


      IF P_AWB_NUMBER_FILTER IS NOT NULL AND P_AWB_NUMBER_INP IS NOT NULL AND P_AWB_NUMBER_FILTER='WAYBILL' THEN

            V_Select_Str:=V_Select_Str||' AND upper(WAYBILL) LIKE upper('''||P_AWB_NUMBER_INP||''')' ;

      END IF;


    -- SELLING PRICE


      IF P_SELLING_PRICE_FILTER IS NOT NULL AND P_SELLING_PRICE_INP IS NOT NULL AND P_SELLING_PRICE_FILTER='SELLING_PRICE' THEN

        V_Select_Str:=V_Select_Str||' AND upper(UNIT_SELLING_PRICE) LIKE upper('''||P_SELLING_PRICE_INP||''')' ;

      END IF;


    -- LIST PRICE


      IF P_LIST_PRICE_FILTER IS NOT NULL AND P_LIST_PRICE_INP IS NOT NULL AND P_LIST_PRICE_FILTER='LIST_PRICE' THEN

            V_Select_Str:=V_Select_Str||' AND upper(UNIT_LIST_PRICE) LIKE upper('''||P_LIST_PRICE_INP||''')' ;

      END IF;


    -- EXTENDED PRICE


      IF P_EXTENDED_PRICE_FILTER IS NOT NULL AND P_EXTENDED_PRICE_INP IS NOT NULL AND P_EXTENDED_PRICE_FILTER='EXTENDED_PRICE' THEN

            V_Select_Str:=V_Select_Str||' AND upper((ORDERED_QUANTITY * UNIT_LIST_PRICE)) LIKE upper('''||P_EXTENDED_PRICE_INP||''')' ;

      END IF;


    -- MS NUMBER



     IF P_MS_NUMBER_FILTER IS NOT NULL AND P_MS_NUMBER_INP IS NOT NULL AND P_MS_NUMBER_FILTER='MS_NUMBER' THEN

            V_Select_Str:=V_Select_Str||' AND upper(MS_NUMBER) LIKE upper('''||P_MS_NUMBER_INP||''')' ;

      END IF;


    -- ENGINE MODEL


      IF P_PRODUCT_LINE_FILTER IS NOT NULL AND P_PRODUCT_LINE_INP IS NOT NULL AND P_PRODUCT_LINE_FILTER='PRODUCT_LINE' THEN

        V_Select_Str:=V_Select_Str||' AND upper(PRODUCT_LINE) LIKE upper('''||P_PRODUCT_LINE_INP||''')' ;

      END IF;

    --Sorting by Column Name

    IF P_ORDER_BY_COLUMN  IS NOT NULL AND  P_SORT_TYPE IS NOT NULL THEN

       V_Select_Str:=V_Select_Str||'ORDER BY UPPER('||P_ORDER_BY_COLUMN||') '||P_SORT_TYPE||'';

     END IF;


/*INSERT INTO VSTORE VALUES(V_Select_Str);
COMMIT;*/

               P_VIEW_LIST:= V_PO_EXPORT_DETAILS_LIST_ARRAY();


             Open p_view_cur For V_Select_Str;

                      Loop

                              /**********************************************
                               Fetching the data from cursor into variable.
                               **********************************************/
                                Fetch p_view_cur INTO V_CUSTOMER_NUMBER
                                     ,V_CUST_PO_NUMBER
                   ,V_INVOICE_NUMBER
                                     ,V_LINE_NUMBER
                                     ,V_ORDERED_ITEM
                                     ,V_LINE_STATUS
                                     ,V_ORDERED_QUANTITY
                                     ,V_CANCELLED_QUANTITY
                                     ,V_SHIPPED_QUANTITY
                                     ,V_INVOICED_QUANTITY
                                     ,V_ORDERED_DATE
             ,V_REQUEST_DATE
             ,V_DELIVERY_DATE
             ,V_SHIPMENT_DATE
             ,V_SELLING_PRICE
             ,V_LIST_PRICE
             ,V_EXTENDED_PRICE
             ,V_MS_NUMBER
             ,V_WAYBILL
             ,V_ENG_FAMILY
                                     ,V_PRODUCT_LINE
             ,V_orderType;


                                Exit When p_view_cur%Notfound;

                                P_VIEW_LIST.Extend ();
        R_PO_COUNT := R_PO_COUNT + 1;

                                P_VIEW_LIST (P_VIEW_LIST.LAST) := V_PO_EXPORT_OBJECT(
                                      V_CUSTOMER_NUMBER
                                     ,V_CUST_PO_NUMBER
                   ,V_INVOICE_NUMBER
                                     ,V_LINE_NUMBER
                                     ,V_ORDERED_ITEM
                                     ,V_LINE_STATUS
                                     ,V_ORDERED_QUANTITY
                                     ,V_CANCELLED_QUANTITY
                                     ,V_SHIPPED_QUANTITY
                                     ,V_INVOICED_QUANTITY
                                     ,V_ORDERED_DATE
             ,V_REQUEST_DATE
             ,V_DELIVERY_DATE
             ,V_SHIPMENT_DATE
             ,V_SELLING_PRICE
             ,V_LIST_PRICE
             ,V_EXTENDED_PRICE
             ,V_MS_NUMBER
             ,V_WAYBILL
             ,V_ENG_FAMILY
                                     ,V_PRODUCT_LINE
            ,V_orderType);

                       End Loop;


                  /**********************************************************
                      checking whether the query is return the result or not.
                   **********************************************************/

                     IF R_PO_COUNT = 0 Then

                            P_DB_ERROR :=  'NOROWS';

                     ELSE

                          P_DB_ERROR := 'SUCCESS';

                          P_TOTAL_RECORDS:= R_PO_COUNT;

                     END IF;

                          dbms_output.put_line('Number of rows:::'||P_View_List.count);
                          timeEnd:=systimestamp;
                          dbms_output.put_line('Time ends...'||timeEnd);
                          dbms_output.put_line('Total Time:::'|| (timeEnd-timeStart));

                     EXCEPTION

                             When R_PO_LIST_E Then

                             P_DB_ERROR := P_DB_ERROR || ': Please Take Necessary Action';

END NEW_SPARES_EXPT_PO_DTLS_PRC;
END GEAE_MYGE_PO_EXPT_NEWSPARE_PKG;