


GEAE_MYGE_ITEM_DTL_PKG


create or replace PACKAGE BODY "GEAE_MYGE_ITEM_DTL_PKG"
AS
  --
--------Change Log-------------------------------------
/*
Date          Changed By         Description
10-SEP-2014   Ravi Saxena        MYJIRATEST-3012 Fix to get translated price list name for display
17-SEP-2014   Ravi Saxena        MYJIRATEST-2956 Add logic to allow ordering based on procurement code if all ship codes are past use
30-OCT-2014   Ravi Saxena        MYJIRATEST-3993 Ensure lookup GEAE_MYGE_PART_APPLICABLE_ORGS is used and tag is used in it for organization_code
04-NOV-2014   Ravi Saxena        MYJIRATEST-3989 Add KIT Indicator to the GET_ITEM_PRICE_AVAIL procedure
06-NOV-2014   Ravi Saxena        MYJIRATEST-3876 Added procedure for KIT Structure
18-NOV-2014   Ravi Saxena        MYJIRATEST-3512 Change in call to CREATE_KIT_CONFIG
27-NOV-2014   Ravi Saxena        MYJIRATEST-4645 Kit structure changes
28-NOV-2014   Ravi Saxena        MYJIRATEST-4654 For Option class availability should come as blank
03-DEC-2014   Ravi Saxena        MYJIRATEST-4757 Have ability to enable or disable Kit structure
21-JAN-2015   Ravi Saxena        MYJIRATEST-5063 Discounts added
21-JAN-2015   Ravi Saxena        MYJIRATEST-5102 Remove hard coding of Aero for discount indicator
21-JAN-2015   Ravi Saxena        MYJIRATEST-5093 Add Critical part indicator
10-FEB-2015   Ravi Saxena        MYJIRATEST-5919 Discount changes
18-FEB-2015   Ravi Saxena        MYJIRATEST-6058 Fix for Common parts
03-MAR-2015   Ravi Saxena        MYJIRATEST-6272 Aero enhancement changes
23-MAR-2015   Abhinav Srivastava MYJIRATEST-7139 Engine family to Product line changes
24-MAR-2015   Abhinav Srivastava MYJIRATEST-7138 Oderable Vs Non Oderable changes
27-APR-2015   Ankita S           MYJIRATEST-5059 Add part to cart using PART_NUM
04-MAY-2015   Ankita Shetty      MYJIRATEST-7192 Change the message format for Manual discounts
04-MAY-2015   Ankita Shetty      MYJIRATEST-7056 Changed logic for populating Allocation Message
02-JUN-2015   Ankita S           MYJIRATEST-8466 on 02-JUN-2015
18-AUG-2015   Neelima Y          MYJIRATEST-8631 on 18-AUG-2015 Honda warehouse onhand visibility change
18-AUG-2015   Neelima Y          MYJIRATEST-9104 on 18-AUG-2015 Bulk Search
12-OCT-2015   Neelima Y          MYJIRATEST-9281 on 12-OCT-2015 Vendor part
28-DEC-2015   Trupti D           MYJIRATEST-12358 on 28-DEC-2015
29-JAN-2016   Trupti D           MYJIRATEST-7273 on 29-JAN-2016
26-FEB-2016   Trupti D           MYJIRATEST-13720 changed the logic for populating price list for GLobal Enquiry role
07-APR-2016   Trupti D           MYJIRATEST-13902 PZN ship code
21-JUN-2016   R Prasad           MYJIRATEST-7252  Enabled the Lumpsum as discount.
10-NOV-2016   R Prasad           US34704 - GTA validation check is added
12-DEC-2016   R Prasad     US46803 -Change ship code C to non shippable in portal
12-DEC-2016   R Prasad           US41783 -User customer code is not populating while adding a part to cart
08-MAR-2017   R Prasad           US52826 -Currently GEAE user can see all the inventory location, we should make the change so that they can only view what  a GE shop user see it. They should only see Erlanger and West chester.
18-APR-2017   R Prasad           US63772 -Remove Expired Discount Lines - myGEA, myCFM, myHonda, Aero
19-JUN-2018   OWMS Team          Changes for US192483 and US192484
28-Nov-2018   Manisha K          US198256- Passport requiement; Modified proc GET_ITEM_PRICE_AVAIL to find the Part details in case of two OU_ID passed as input.
27-Mar-2018   Manisha K          US267084- The on hand quantity is not displayed correctly on Part bulk search screen.
 */
 
 

--GET_ITEM_PRICE_AVAIL


 
PROCEDURE GET_ITEM_PRICE_AVAIL(
    P_SSO       VARCHAR2,
    P_IACO_CODE VARCHAR2,
    P_CUST_ID V_CUST_ID_ARRAY,
    P_ROLE    VARCHAR2,
    P_OU_ID   VARCHAR2,
    P_ITEM_ID NUMBER,
    P_PART_DETAILS OUT V_PART_DETAILS,
    P_PART_AVAIL OUT V_PART_AVAIL,
    P_PART_PRICE OUT V_PART_PRICE,
    P_PART_APPLICABLE OUT V_PART_APPLICABLE,
    P_MESSAGE OUT VARCHAR2,
    P_AVAIL_MESSAGE OUT VARCHAR2,
    P_PRICE_MESSAGE OUT VARCHAR2,
    P_KIT_IND         OUT VARCHAR2,
    P_PART_DISCOUNTS  OUT V_PART_DISCOUNTS,
    P_DISC_MESSAGE    OUT VARCHAR2,
    P_CRITICAL_PART   OUT VARCHAR2,
    P_PART_BOM        OUT V_PART_BOM, --MYJIRATEST-6272 Ravi S 03-MAR-2015
    P_ISODERABLE      OUT VARCHAR2  --MYJIRATEST-7138 24-MAR-2015   Abhinav  Oderable Vs Non Oderable changes
    )
AS
  --
  -- DECLARATION OF COUNTERS
  v_cust_cnt             NUMBER := 0;
  v_part_cnt             NUMBER := 0;
  v_part_avail_cnt       NUMBER := 0;
  v_part_price_cnt       NUMBER := 0;
  V_PART_APPL_CNT        NUMBER := 0;
  v_PART_PRICE_V_add     NUMBER := 0;
  V_PRICE_LIST_ID        NUMBER := 0;
  V_AVIALL_PRICE_LIST_ID NUMBER := 0;
  L_PRICE_LIST_DTL_cnt   NUMBER := 0;
  v_price_list_id_old    NUMBER := 0;
  p_aviall_price         NUMBER := 0;
  V_PART_dtl_cnt         NUMBER := 0;
  v_valdn_org            NUMBER;
  v_item_status          VARCHAR2(1);
  v_aviall_part          VARCHAR2(1);
  v_aviall_price         NUMBER;
  v_prc_id               NUMBER;
  V_ACT_NUM              VARCHAR2(30);
  v_aviall_err_ind       VARCHAR2(1);
  v_cust_account_id      NUMBER;
  V_CUST_ACCOUNT_ID_OLD  NUMBER;
  V_ONHAND_FLAG_NON_ZERO VARCHAR2(1);
  v_generic_messg_cnt    NUMBER;
  V_PRICE_LIST_FLAG      VARCHAR2(1);
  V_CUST_ACCOUNT_NUMBER  VARCHAR2(50);
  V_FSCM_SUPPLIER        VARCHAR2(50);
  v_price_list_api       NUMBER := 0;
  v_ou_name              VARCHAR2(240);
  v_parent_wh_id         NUMBER;
  l_disc_price           NUMBER;
  l_pr_fr_disc           NUMBER;
  l_disc_list_id         NUMBER;
  l_disc_line_id         NUMBER;
  l_disc_end_date        DATE;
  l_disc_consumed        NUMBER;
  l_disc_counter         NUMBER;
  l_bom_counter          NUMBER;  --MYJIRATEST-6272 Ravi S 03-MAR-2015
  V_OU_TAG               VARCHAR2(255) := Null;      -- Neelima Y MYJIRATEST-8631 on 18-AUG-2015
  --
  -- DECLARATIONS OF BULK COLLECT ARRAY
  L_PART_DETAILS V_PART_DETAILS           := V_PART_DETAILS();
  L_PART_AVAIL V_PART_AVAIL               := V_PART_AVAIL();
  L_PART_PRICE_V V_PART_PRICE             := V_PART_PRICE();
  L_PART_PRICE V_PART_PRICE               := V_PART_PRICE();
  L_PART_APPLICABLE V_PART_APPLICABLE     := V_PART_APPLICABLE();
  L_PRICE_LIST_ID V_PRICE_LIST_ID_ARRAY   := V_PRICE_LIST_ID_ARRAY();
  L_PRICE_LIST_DTL V_PRICE_LIST_DTL       := V_PRICE_LIST_DTL();
  P_PRICE_LIST_DTL V_PRICE_LIST_DTL       := V_PRICE_LIST_DTL();
  L_PART_VLDTN V_PART_VLDTN               := V_PART_VLDTN();
  l_PART_PRICE_DUP V_PART_PRICE           := V_PART_PRICE();
  l_PART_APPLICABLE_DUP V_PART_APPLICABLE := V_PART_APPLICABLE();
  T_PART_PRICE_LOOP_DUP V_PART_PRICE           := V_PART_PRICE(); --US198256;Passport requirement; Manisha added the variable to remove the duplicates from P_PART_PRICE array after introducing OU_ID loop.
  T_PART_APPLICABLE_LOOP_DUP V_PART_APPLICABLE := V_PART_APPLICABLE();  --US198256; Passport requirement;Manisha added the variable to remove the duplicates from P_PART_APPLICABLE array after introducing OU_ID loop.
  T_PART_AVAIL_LOOP_DUP V_PART_AVAIL := V_PART_AVAIL();  --US198256; Passport requirement; Manisha added the variable to remove the duplicates from P_PART_AVAIL array after introducing OU_ID loop.
  --
  --Declarations of Variables
  l_List_id_count           NUMBER ;
  l_PART_PRICE_DUP_CNT      NUMBER         := 0;
  v_price_dup_flag          BOOLEAN        := true;
  l_PART_APPLICABLE_DUP_CNT NUMBER         := 0;
  v_part_APP_DUP_FLAG       BOOLEAN        := true;
  P_VALID_FLAG              VARCHAR2(1)    := NULL;
  P_UNIT_PRICE              NUMBER         := NULL;
  P_LIST_LINE_ID            NUMBER         := NULL;
  P_AVIALL_UNIT_PRICE       NUMBER         := NULL;
  P_AVIALL_LIST_LINE_ID     NUMBER         := NULL;
  V_CONTROL_SHIP            NUMBER         := NULL;
  V_CONTROL_SHIPPABLE       VARCHAR2(10)   := NULL;
  V_ORG_ID                  NUMBER         := NULL;
  V_PORTAL                  VARCHAR2(150)  := NULL;
  V_FLAG_GTA_ERROR          VARCHAR2(1)    := NULL;
  V_FLAG_CTRL_SHIP_ERROR    VARCHAR2(1)    := NULL;
  V_AMPS_CODE_ERROR         VARCHAR2(1)    := NULL;
  V_FLAG_AVIALL_ERROR       VARCHAR2(1)    := NULL;
  V_FLAG_VENDOR_ERROR       VARCHAR2(1)    := NULL;
  V_FLAG_ORG_ERROR          VARCHAR2(1)    := NULL;
  V_GENERIC_MSSG            VARCHAR2(5000) := NULL;
  V_GTA_ERR_MSSG            VARCHAR2(5000) := NULL;
  V_CTRL_SHIP_ERR_MSSG      VARCHAR2(5000) := NULL;
  V_AVIALL_ERR_MSSG         VARCHAR2(5000) := NULL;
  V_VENDOR_ERR_MSSG         VARCHAR2(5000) := NULL;
  V_AMPS_CODE_ERR_MSSG      VARCHAR2(5000) := NULL;
  V_ORG_ERR_MSSG            VARCHAR2(5000) := NULL;
  V_PUBLISH                 VARCHAR2(10)   := NULL;
  V_AVAILL_ALL_ERROR        VARCHAR2(1)    := NULL;
  V_AVIALL_SUCESS           VARCHAR2(1)    := NULL;
  v_proc_status             VARCHAR2(1);
  v_proc_code               VARCHAR2(5);
  v_on_hand                 NUMBER;
  v_kit_ind_on              VARCHAR2(1);
  v_prod_line_on              VARCHAR2(1);  --MYJIRATEST-6272 Ravi S 03-MAR-2015 and  MYJIRATEST-7139 Engine family to Product line changes    23-MAR-2015    Abhinav
  v_oderable_on               VARCHAR2(1);  --MYJIRATEST-7138 24-MAR-2015   Oderable Vs Non Oderable changes
  V_ISODERABLE                VARCHAR2(1);  --MYJIRATEST-7138 24-MAR-2015   Oderable Vs Non Oderable changes
  V_ISODERABLE_MESSAGE        VARCHAR2(5000) := NULL;  --MYJIRATEST-7138 24-MAR-2015   Oderable Vs Non Oderable changes
  v_item_source                VARCHAR2(500); -- Added for OWMS Implementation US192483/US192484
  v_er1_source VARCHAR2(500); -- Added for OWMS Implementation US192483/US192484
  v_er2_source VARCHAR2(500); -- Added for OWMS Implementation US192483/US192484
  v_er3_source VARCHAR2(500); -- Added for OWMS Implementation US192483/US192484
  v_item_number                VARCHAR2(30); -- Added for OWMS Implementation US192483/US192484
  v_hnd_flag	  VARCHAR2(5);-- Added for OWMS Implementation US192483/US192484
  --
  v_ou_id                      VARCHAR2(30)   := NULL; --Added By Manisha;12-JUL-18;Passport requirement to save the OU_ID separated by comma
  v_ou_id1                      VARCHAR2(30)   := NULL;
  v_ou_id2                      VARCHAR2(30)   := NULL;
  i_PART_PRICE_DUP_CNT      NUMBER         := 0;  --Manisha 10-Aug; Used to increase the counter for loop(to remove duplicate from P_PART_PRICE array after adding OU_ID loop)
  i_price_dup_flag          BOOLEAN        := true; --Manisha 10-Aug; Flag to check for duplicates in P_PART_PRICE
  i_PART_APPLICABLE_DUP_CNT NUMBER         := 0; --US198256; Manisha 10- Aug; Added variable to increase the counter for loop(to remove duplicate from P_PART_APPLICABLE array after adding OU_ID loop)
  i_part_APP_DUP_FLAG       BOOLEAN        := true; --US198256; Manisha 10-Aug; Flag to check for duplicates in P_PART_APPLICABLE
  i_PART_AVAIL_DUP_CNT NUMBER         := 0; --US198256; Manisha 10- Aug;Added variable to increase the counter for loop(to remove duplicate from P_PART_AVAIL after adding OU_ID loop)
  i_part_AVAIL_DUP_FLAG       BOOLEAN        := true; --US198256; Manisha 10-Aug; Flag to check for duplicates in P_PART_AVAIL
  /*******************************
  --Added the variable to save the intermediate value while passing both OU_ID in loop before displaying in the out parameter
  ******************************************/

  v_message                    VARCHAR2(5000) := NULL;
  v_avail_message              VARCHAR2(5000) := NULL;
  v_price_message              VARCHAR2(5000) := NULL;
  v_disc_message               VARCHAR2(5000) := NULL;
  l_isoderable                 VARCHAR2(5000) := NULL;
  ----------------------------------------

  CURSOR C_DISCOUNTS(P_CUSTOMER_ID NUMBER, P_OU_ID NUMBER, P_ITEM_ID NUMBER, P_PRICE_LIST_ID NUMBER) IS
     SELECT cust_account_id, account_number, list_name, list_description, line_number, line_comments, disc_value, arithmetic_operator,
            qual_end_date, line_end_date, list_end_date, grants_end_date, list_auto_flag, line_auto_flag, basis, limit_level_code, limit,
            product_attribute_context, product_attribute, product_attr_value, list_header_id, list_line_id, qualifier_id, qualifier_context
       FROM (
        SELECT hca.cust_account_id, hca.account_number, qlh.name list_name, qlh.description list_description, qll.list_line_no line_number,
               qll.attribute4 line_comments, qll.operand disc_value, qll.arithmetic_operator, qq.end_date_active qual_end_date,
               qll.end_date_active line_end_date, qlh.end_date_active list_end_date, qg.end_date grants_end_date, qlh.automatic_flag list_auto_flag,
               qll.automatic_flag line_auto_flag, ql.basis, ql.limit_level_code, ql.amount limit, qpa.product_attribute_context, qpa.product_attribute,
               qpa.product_attr_value, qll.list_header_id, qll.list_line_id, qq.qualifier_id, qq.qualifier_context
          FROM hz_cust_accounts hca, qp_grants qg, qp_list_headers qlh, qp_list_lines qll, qp_qualifiers qq, qp_pricing_attributes qpa,
               (SELECT * FROM qp_limits WHERE basis = 'QUANTITY' AND limit_level_code = 'ACROSS_TRANSACTION') ql
         WHERE 1 = 1
           AND ((to_char(hca.cust_account_id) = qq.qualifier_attr_value AND qq.qualifier_context = 'CUSTOMER')
             OR (to_char(P_PRICE_LIST_ID) = qq.qualifier_attr_value AND qq.qualifier_context = 'MODLIST'))
           AND hca.status = 'A'
           AND qq.comparison_operator_code = '='
           AND hca.cust_account_id = P_CUSTOMER_ID
           AND qq.active_flag = 'Y'
           AND qq.list_header_id = qlh.list_header_id
           AND DECODE(qq.list_line_id,-1,qll.list_line_id,qq.list_line_id) = qll.list_line_id
           AND qlh.list_type_code = 'DLT'
           AND qlh.active_flag = 'Y'
           AND qlh.list_header_id = qg.instance_id
           AND qg.grantee_type = 'OU'
           AND qg.instance_type = 'MOD'
           AND qg.grantee_id = P_OU_ID
           AND qll.list_line_type_code = 'DIS'
           AND qlh.list_header_id = qll.list_header_id
           AND qll.pricing_phase_id > 1
           AND qll.qualification_ind IN (0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,32)
           AND qll.list_header_id = qpa.list_header_id(+)
           AND qll.list_line_id = qpa.list_line_id(+)
           AND (qpa.pricing_attribute_context = 'VOLUME' OR qpa.pricing_attribute_context IS NULL)
           AND ql.list_header_id(+) = qll.list_header_id
           AND ql.list_line_id(+) = qll.list_line_id
           --AND qll.arithmetic_operator = '%'             MYJIRATEST-7252 Commented by Prasad on 21-Jun-2016
           AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(qlh.start_date_active,SYSDATE)) AND TRUNC(NVL(qlh.end_date_active,SYSDATE))
           AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(qll.start_date_active,SYSDATE)) AND TRUNC(NVL(qll.end_date_active,SYSDATE))  --MYJIRATEST-7273 Trupti D. 29-JAN-2016 --US63772 18-APR-17
           AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(qq.start_date_active,SYSDATE)) AND TRUNC(NVL(qq.end_date_active,SYSDATE))
           AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(qg.start_date,SYSDATE)) AND TRUNC(NVL(qg.end_date,SYSDATE))
         --AND trunc(NVL(qll.end_date_active, SYSDATE))>=add_months(sysdate,-6)                                              --MYJIRATEST-7273 Trupti D. 29-JAN-2016 --US63772 18-APR-17
           )
      WHERE ((product_attribute = 'PRICING_ATTRIBUTE3' AND product_attr_value = 'ALL')
               OR (product_attribute = 'PRICING_ATTRIBUTE1' AND product_attr_value = P_ITEM_ID)
               OR product_attribute IS NULL) AND (product_attribute_context = 'ITEM' OR product_attribute_context IS NULL);
BEGIN
  ---Start of Procedure GET_ITEM_PRICE_AVAIL
  --
  P_PART_DETAILS    := V_PART_DETAILS();
  P_PART_AVAIL      := V_PART_AVAIL();
  P_PART_PRICE      := V_PART_PRICE();
  P_PART_APPLICABLE := V_PART_APPLICABLE();
  P_PART_DISCOUNTS  := V_PART_DISCOUNTS();
  P_PART_BOM        := V_PART_BOM(); --MYJIRATEST-6272 Ravi S 03-MAR-2015


  /*********************************************
  US198256: Manisha K; Passport requirements 12-July-2018
  As part of Passport Requirement: Two OU_ID will be passed separated by ~ symbol.
  So, the part price will be calculated separately for each OU_ID using loop
  **************************************************/
P_PART_DETAILS.EXTEND();   --US198256; Manisha K; Creating element for the PART_DETAILS array ,outside the OU_ID loop to avoid duplicates.

 v_ou_id:=Replace(P_OU_ID,'~',',');

    FOR j IN
     (SELECT trim(regexp_substr(v_ou_id, '[^,]+', 1, LEVEL)) ou_id
    FROM dual
      CONNECT BY LEVEL <= regexp_count(v_ou_id, ',')+1
    )
   LOOP
---  US198256; Manisha K; Passport Changes End here

  SELECT name
    INTO v_ou_name
    FROM HR_OPERATING_UNITS
   WHERE organization_id = J.OU_ID;
  --MYJIRATEST-5102 Ravi S 21-JAN-2015
  BEGIN
     SELECT mp.organization_id
       INTO v_parent_wh_id
       FROM MTL_PARAMETERS MP,
            FND_LOOKUP_VALUES FLV
      WHERE MP.ORGANIZATION_CODE = FLV.ATTRIBUTE1
        AND FLV.description      = J.OU_ID
        AND FLV.LOOKUP_TYPE      = 'GEAE_MYGE_SUPPLIER_ORGS'
        AND FLV.ATTRIBUTE3       = (SELECT MIN(FLV2.ATTRIBUTE3)
                                      FROM MTL_PARAMETERS MP2,
                                           FND_LOOKUP_VALUES FLV2
                                     WHERE MP2.ORGANIZATION_CODE = FLV2.ATTRIBUTE1
                                       AND FLV2.description      = J.OU_ID
                                       AND FLV2.LOOKUP_TYPE      = 'GEAE_MYGE_SUPPLIER_ORGS');
  EXCEPTION
     WHEN NO_DATA_FOUND THEN
        v_parent_wh_id := NULL;
  END;
  -- MYJIRATEST-4757 Ravi S 03-DEC-2014
  BEGIN
     SELECT description
       INTO v_kit_ind_on
       FROM fnd_lookup_values
      WHERE lookup_type = 'GEAE_MYGE_ENABLE_KIT_STRUCTURE'
        AND lookup_code = J.OU_ID
        AND enabled_flag = 'Y'
        AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(start_date_active,SYSDATE)) AND TRUNC(NVL(end_date_active,SYSDATE));
  EXCEPTION
     WHEN NO_DATA_FOUND THEN
        v_kit_ind_on := 'N';
  END;
  --MYJIRATEST-6272 Ravi S 03-MAR-2015
  BEGIN
     SELECT description
       INTO v_prod_line_on  --  MYJIRATEST-7139 23-MAR-2015    Engine family to Product line changes
       FROM fnd_lookup_values
      WHERE lookup_type = 'GEAE_MYGE_ENABLE_ENGINE_FAMILY'
        AND lookup_code = J.OU_ID
        AND enabled_flag = 'Y'
        AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(start_date_active,SYSDATE)) AND TRUNC(NVL(end_date_active,SYSDATE));
  EXCEPTION
     WHEN NO_DATA_FOUND THEN
        v_prod_line_on := 'N';  --  MYJIRATEST-7139 23-MAR-2015    Engine family to Product line changes
  END;
  --
  -- If Role is Global Enquiry fetch the Item Availiability accross Orgs
  --If role is Global Enquiry fetch the Item Price across all price list for that operating unit pass as parameter

  IF p_ROLE      = 'Global Enquiry' THEN
    V_VALDN_ORG := GEAE_CNV_UTILITY_PACKAGE.GET_ORGANIZATION_ID('CVO');

    -- validate whether part is orderable the organization used is CVO
    BEGIN
      SELECT 'Y'
      INTO v_item_status
      FROM mtl_system_items_b msi
      WHERE msi.organization_id           = v_valdn_org
      AND msi.CUSTOMER_ORDER_FLAG         = 'Y'
      AND msi.CUSTOMER_ORDER_ENABLED_FLAg = 'Y'
      AND msi.inventory_item_id           = P_ITEM_ID;
    EXCEPTION
    WHEN OTHERS THEN
      V_ITEM_STATUS := 'N';
      --
      SELECT LOOKUP_CODE
        || ': '
        || DESCRIPTION
      INTO p_message
      FROM fnd_lookup_values
      WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
      AND UPPER(LOOKUP_CODE) = UPPER('8125');
      --
      /*  IF P_CUST_ID.COUNT > 0 THEN
      FOR VAR IN 1 .. P_CUST_ID.COUNT
      LOOP
      P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
      END LOOP;
      END IF;  */
      --
    END;
    IF V_ITEM_STATUS = 'Y' THEN
      --Getting KIT Flag
      BEGIN
         SELECT 'Y'
           INTO P_KIT_IND
           FROM mtl_system_items_b
          WHERE organization_id = v_valdn_org
            AND inventory_item_id = P_ITEM_ID
            AND bom_item_type = 1;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            P_KIT_IND := 'N';
      END;
      IF v_kit_ind_on <> 'Y' THEN
         P_KIT_IND := 'N'; -- MYJIRATEST-4757 Ravi S 03-DEC-2014
      END IF;
      --MYJIRATEST-5093 Ravi S 21-JAN-2015
      BEGIN
         SELECT 'Y'
           INTO P_CRITICAL_PART
           FROM oe_hold_definitions ohd, oe_hold_sources_all ohsa, fnd_lookup_values flv
          WHERE ohd.hold_id = ohsa.hold_id
            AND ohd.name = flv.description
            AND flv.lookup_type = 'GEAE_MYGE_CRITICAL_PART_HOLDS'
            AND flv.enabled_flag = 'Y'
            AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(flv.start_date_active,SYSDATE)) AND TRUNC(NVL(flv.end_date_active,SYSDATE))
            AND ohsa.hold_entity_code = 'I'
            AND ohsa.released_flag <>'Y'   -- MYJIRATEST-12046  23-NOV-2015
            AND ohsa.hold_entity_id = P_ITEM_ID
            AND rownum = 1;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            P_CRITICAL_PART := 'N';
      END;
      ---------------------------------------
      ---Creating the Price List Array for Price if the role is global enquiry across all Price list in Operating unit passed
      --added this to fix the price list is not diplayed for internal GEAE users US267081 on 28th March 2019
      MO_GLOBAL.SET_POLICY_CONTEXT('S',J.OU_ID);
      --end of the change
      SELECT V_PART_PRICE_LIST_BO(GQIPV.inventory_item_id, GQIPV.PRICE_LIST_NAME, GQIPV.list_price, NVL(GQIPV.CATALOG_UPQ,1), GQIPV.CATALOG_LEAD_TIME) BULK COLLECT
      INTO L_PART_PRICE_V
      FROM GEAE_QP_ITEM_PRICES_V GQIPV
      WHERE 1                     = 1
      AND GQIPV.inventory_item_id = to_char(P_ITEM_ID) -- added by Mohammed Yadul on 16.Oct.2014 for Item data type issue, this issue raised by bala
      --AND NVL(GQIPV.OPERATING_UNIT,TO_NUMBER(P_OU_ID))    = TO_NUMBER(P_OU_ID)
      AND NVL(GQIPV.OPERATING_UNIT,TO_NUMBER(J.OU_ID))=To_Number(Decode((SELECT GLOBAL_FLAG FROM QP_LIST_HEADERS WHERE NAME = GQIPV.PRICE_LIST_NAME AND ACTIVE_FLAG ='Y' AND Nvl(END_DATE_ACTIVE,SYSDATE+1) > SYSDATE )
                                                                  ,'Y'
                                                                     ,GEAE_CSO_FIN_UTL_PKG.GET_CSO_ORG_ID
                                                                     ,J.OU_ID))   ----------MYJIRATEST-13720 Trupti D. 26-FEB-2016
      AND NOT EXISTS
        (SELECT 'X'
        FROM fnd_lookup_values flv
        WHERE flv.enabled_flag = 'Y'
        AND FLV.LOOKUP_TYPE    = 'GEAE_INV_PIS_CATALOG_EXCLUSION'
        AND FLV.DESCRIPTION    = GQIPV.PRICE_LIST_NAME
        );
      --
      IF SQL%ROWCOUNT > 0 THEN
        FOR i IN 1 .. L_PART_PRICE_V.count
        LOOP
          v_PART_PRICE_V_add := v_PART_PRICE_V_add + 1;
          P_PART_PRICE.extend();
          P_PART_PRICE(V_PART_PRICE_V_ADD) := L_PART_PRICE_V(I);
        END LOOP;
      ELSE
        SELECT LOOKUP_CODE
          || ': '
          || DESCRIPTION
        INTO p_message
        FROM fnd_lookup_values
        WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
        AND UPPER(LOOKUP_CODE) = UPPER('8134'); --
        p_message             := NULL;
        --EXIT;
        /* IF P_CUST_ID.COUNT > 0 THEN
        FOR VAR IN 1 .. P_CUST_ID.COUNT
        LOOP
        P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
        END LOOP;
        END IF;  */
      END IF;

      --
      --   Getting the Global Availability across all valid organization across SPR, OSW and SCP
      --
      /*SELECT V_PART_AVAILABILITY_LIST_BO(STG.INVENTORY_ITEM_ID, STG.ORGANIZATION_CODE, NVL(STG.QTY,0) ) BULK collect
      INTO L_PART_AVAIL
      FROM
        (SELECT STG3.INVENTORY_ITEM_ID,
          STG3.ORGANIZATION_CODE,
          NVL(STG3.TOTAL_QTY,0) - NVL(STG3.RESERVE_QTY,0) QTY
        FROM
          (SELECT MSI.INVENTORY_ITEM_ID ,
            MTP.ORGANIZATION_CODE ,
            NVL(SUM(MOQ.TRANSACTION_QUANTITY),0) TOTAL_QTY ,
            stg2.reserve_qty
          FROM MTL_ONHAND_QUANTITIES MOQ,
            MTL_SYSTEM_ITEMS_B msi,
            MTL_PARAMETERS MTP ,
            (SELECT MRS.INVENTORY_ITEM_ID ,
              MRS.ORGANIZATION_ID ,
              SUM(MRS.RESERVATION_QUANTITY) reserve_qty
            FROM MTL_RESERVATIONS MRS
            GROUP BY MRS.INVENTORY_ITEM_ID,
              MRS.ORGANIZATION_ID
            ) stg2
          WHERE 1                        = 1
          AND stg2.INVENTORY_ITEM_ID (+) = MSI.INVENTORY_ITEM_ID
          AND stg2.organization_id (+)   = MSI.ORGANIZATION_ID
          AND MOQ.ORGANIZATION_ID(+)     = MSI.ORGANIZATION_ID
          AND MOQ.INVENTORY_ITEM_ID(+)   = MSI.INVENTORY_ITEM_ID
          AND MTP.organization_code NOT IN
            (SELECT FFV.flex_value
            FROM fnd_flex_values FFV ,
              fnd_flex_value_sets FVS
            WHERE FFV.flex_value_set_id=FVS.flex_value_set_id
            AND FVS.FLEX_VALUE_SET_NAME='GEAE_AMPS_RETIRED_ORGS'
            )
          AND MTP.attribute_category IN ('SPR','OSW','SCP')
          AND MSI.ORGANIZATION_ID     = MTP.ORGANIZATION_ID
          AND MSI.INVENTORY_ITEM_ID   = P_ITEM_ID
          AND MTP.ORGANIZATION_CODE  <> 'HAI'
          GROUP BY MSI.INVENTORY_ITEM_ID ,
            MTP.ORGANIZATION_CODE ,
            STG2.RESERVE_QTY
          ) STG3
        UNION ALL
          SELECT distinct msib.inventory_item_id,
                 gif.org_code ORGANIZATION_CODE,
                 gif.onhand_Qty QTY
            FROM geae_inv_foxtrot_data_stg gif,
                 mtl_system_items_b msib
           WHERE msib.segment1=gif.prt_num
             AND msib.inventory_item_id =P_ITEM_ID
             AND gif.SRC_SYS ='HONDA'
             )stg;*/  --Commeted for Rally#US52826
          -- replicated query for  Rally#US52826  --Started
--Added by OWMS Team : Start
   v_item_source := NULL;
   v_item_number := NULL;
   BEGIN
     SELECT DISTINCT segment1
         INTO v_item_number
         FROM mtl_system_items_b
         WHERE INVENTORY_ITEM_ID   = P_ITEM_ID;
     EXCEPTION
       WHEN OTHERS THEN
                  v_item_number := NULL;
     END;
  --
 	SELECT DECODE(COUNT(1),1,'Y','N')
	INTO v_hnd_flag
	 FROM HR_OPERATING_UNITS HOU,
		  FND_LOOKUP_VALUES FLV
	WHERE  HOU.ORGANIZATION_ID = TO_NUMBER(j.OU_ID) --116797
	  AND HOU.NAME = FLV.DESCRIPTION
	  AND FLV.TAG = 'HAI'
	  AND FLV.LOOKUP_TYPE = 'GEAE_MYGE_PART_APPLICABLE_ORGS';
   --
   IF v_hnd_flag = 'Y' THEN
     v_item_source := 'HAI';
   ELSIF v_hnd_flag = 'N' THEN
	   --
	   v_er1_source := GEAE_INV_GET_SOURCE_CODE ('ER1',v_item_number,'Y');
	   v_er2_source := GEAE_INV_GET_SOURCE_CODE ('ER2',v_item_number,'Y');
	   v_er3_source := GEAE_INV_GET_SOURCE_CODE ('ER3',v_item_number,'Y');
	   --
	   IF v_er1_source = 'CPL' OR v_er2_source = 'CPL' OR v_er3_source = 'CPL' THEN
		v_item_source := 'CPL';
	   ELSE
		 v_item_source := 'ERL';
	   END IF;
   END IF;

--Added by OWMS Team : End

           SELECT V_PART_AVAILABILITY_LIST_BO(tab.INVENTORY_ITEM_ID, tab.ORGANIZATION_CODE, NVL(tab.QTY,0)) BULK collect
      INTO L_PART_AVAIL
      FROM
--Added by OWMS Team : Start
      (SELECT STG.INVENTORY_ITEM_ID,STG.ORGANIZATION_CODE,sum(stg.qty) qty
          FROM (SELECT P_ITEM_ID INVENTORY_ITEM_ID ,
                        'On-Hand Stock' ORGANIZATION_CODE,
                         (a.qty-b.qty) QTY
            FROM (SELECT (geae_wms_total_onhand_erl_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
			geae_wms_total_pick_release(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
			 FROM apps.mtl_system_items_b msib,
			      apps.mtl_parameters mp
			 WHERE 1 = 1
			   and msib.inventory_item_id = P_ITEM_ID
			   and msib.organization_id = mp.organization_id
			   and mp.organization_code = v_item_source
			   AND v_item_source NOT IN ('CPL','HAI')) A,
                 (SELECT (geae_wms_resv_qty_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
			geae_wms_total_resv(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
			 FROM apps.mtl_system_items_b msib,
			      apps.mtl_parameters mp
			 WHERE 1 = 1
			   and msib.inventory_item_id = P_ITEM_ID
			   and msib.organization_id = mp.organization_id
			   and mp.organization_code = v_item_source
			   AND v_item_source NOT IN ('CPL','HAI')) B
           UNION ALL
                SELECT P_ITEM_ID INVENTORY_ITEM_ID ,
                        'On-Hand Stock' ORGANIZATION_CODE,
                        (b.qty-c.qty) QTY
                FROM
                     (SELECT NVL(SUM(MOQ.TRANSACTION_QUANTITY),0) qty
                        FROM GEAE_INV_MTL_ONHANDS_V MOQ
                       WHERE INVENTORY_ITEM_ID = P_ITEM_ID
                         AND SUBINVENTORY_CODE in ('STOCK','STG')
                         AND ORGANIZATION_ID IN (SELECT ORGANIZATION_ID
                                                   FROM MTL_PARAMETERS
                                                  WHERE ORGANIZATION_CODE = V_ITEM_SOURCE)
                          AND v_item_source NOT IN ('ERL','HAI')
                    ) b,
                 (SELECT NVL(SUM(RESERVATION_QUANTITY),0) qty
                             FROM MTL_RESERVATIONS
                     WHERE INVENTORY_ITEM_ID = P_ITEM_ID
                         AND ORGANIZATION_ID IN (SELECT ORGANIZATION_ID
                                                   FROM MTL_PARAMETERS
                                                  WHERE ORGANIZATION_CODE = V_ITEM_SOURCE)
                          AND v_item_source NOT IN ('ERL','HAI')
                   ) C
        UNION ALL
        SELECT DISTINCT MSIB.INVENTORY_ITEM_ID,
                 'On-Hand Stock' ORGANIZATION_CODE,
               GIF.ONHAND_QTY  QTY
          FROM GEAE_INV_FOXTROT_DATA_STG GIF,
               MTL_SYSTEM_ITEMS_B MSIB,
               HR_OPERATING_UNITS HOU,
               MTL_PARAMETERS MTP,
               FND_LOOKUP_VALUES FLV
         WHERE MSIB.SEGMENT1=GIF.PRT_NUM
           AND HOU.ORGANIZATION_ID       = TO_NUMBER(J.OU_ID)
           AND HOU.NAME                   = FLV.DESCRIPTION
           AND MTP.ORGANIZATION_CODE      = FLV.TAG
           AND FLV.LOOKUP_TYPE            = 'GEAE_MYGE_PART_APPLICABLE_ORGS'
           AND GIF.ORG_CODE               = MTP.ORGANIZATION_CODE
           AND MSIB.INVENTORY_ITEM_ID =P_ITEM_ID
	   AND FLV.TAG					 = v_item_Source
	   and  v_item_Source NOT IN ('CPL','ERL')
           AND GIF.SRC_SYS ='HONDA'
          ) STG
       GROUP BY INVENTORY_ITEM_ID, ORGANIZATION_CODE ) TAB		  ;
                -- replicated query for  Rally#US52826  --Ended
      --
      IF SQL%rowcount > 0 THEN
        FOR i IN 1 .. L_PART_AVAIL.count
        LOOP
          V_PART_AVAIL_cnt := V_PART_AVAIL_cnt + 1;
          P_PART_AVAIL.EXTEND();
          P_PART_AVAIL(V_PART_AVAIL_cnt) := L_PART_AVAIL(i);
        END LOOP;
      ELSE
        SELECT LOOKUP_CODE
          || ': '
          || DESCRIPTION
        INTO p_message
        FROM fnd_lookup_values
        WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
        AND UPPER(LOOKUP_CODE) = UPPER('8133');
        --
        -- EXIT;
        --Looping in customer loop to get the cust ids in message for 8133
        /* IF P_CUST_ID.COUNT > 0 THEN
        FOR VAR IN 1 .. P_CUST_ID.COUNT
        LOOP
        P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
        END LOOP;
        END IF;  */
        -- Loop ends for customer id concatenation in messages
      END IF;
      --
      --
      SELECT V_PART_DETAILS_LIST_BO(MSI.INVENTORY_ITEM_ID, MSI.SEGMENT1, DECODE(GEAE_MYGE_CTRL_SHIPBILITY(MSI.INVENTORY_ITEM_ID),'Y',NULL,MSI.DESCRIPTION),
             DECODE(v_parent_wh_id,NULL,NULL,GEAE_INV_AMPS_COMMON_UTILS_PKG.GET_CATEGORY_VALUE(v_parent_wh_id,MSI.INVENTORY_ITEM_ID,'Discount Indicator'))) BULK COLLECT
      INTO L_PART_DETAILS
      FROM mtl_system_items_b msi,
        mtl_parameters mtp
      WHERE 1                   = 1
      AND msi.organization_id   = mtp.organization_id
      AND INVENTORY_ITEM_ID     = P_ITEM_ID
      AND MTP.ORGANIZATION_CODE = 'CVO';
      --
      IF SQL%rowcount > 0 THEN
        FOR I IN 1 .. L_PART_DETAILS.COUNT
        LOOP
         V_PART_dtl_cnt  := 0;  --Manisha K. 27 Jul Initializing the variable so that the array P_PART_DETAILS fetch single record.
          V_PART_dtl_cnt := V_PART_dtl_cnt + 1;
       --   P_PART_DETAILS.EXTEND();  --Manisha 14 Dec Have added this code in the beginning outside the loop, to fetch only one record
          P_PART_DETAILS(V_PART_dtl_cnt) := L_PART_DETAILS(I);
        END LOOP;
      END IF;
      --
      IF SQL%ROWCOUNT = 0 THEN
        --
        SELECT LOOKUP_CODE
          || ': '
          || DESCRIPTION
        INTO p_message
        FROM fnd_lookup_values
        WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
        AND UPPER(LOOKUP_CODE) = UPPER('8125');
        --
        --Looping in customer loop to get the cust ids in message for 8125
        IF P_CUST_ID.COUNT > 0 THEN
          FOR VAR IN 1 .. P_CUST_ID.COUNT
          LOOP
            P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
          END LOOP;
        END IF;
        -- Loop ends for customer id concatenation in messages
      END IF;
      --
      --MYJIRATEST-6272 Ravi S 03-MAR-2015
      IF v_prod_line_on = 'Y' THEN
         l_bom_counter := 0;
         FOR part_bom IN (SELECT --DISTINCT bom.eng_fam engine_family    MYJIRATEST-7139 23-MAR-2015    Commented for Engine family to Product line changes
                                 DISTINCT bom.product_line product_line
                            FROM geae_myge_bom_details_v bom
                           WHERE bom.search_ou_id = J.OU_ID
                             AND bom.inventory_item_id = P_ITEM_ID) LOOP
            P_PART_BOM.EXTEND(1);
            l_bom_counter := l_bom_counter + 1;
            P_PART_BOM(P_PART_BOM.last):= V_PART_BOM_BO(NULL, part_bom.product_line , l_bom_counter);--   MYJIRATEST-7139 23-MAR-2015    Engine family to Product line changes
         END LOOP;
      END IF;
      --
    END IF; --END IF of IF V_ITEM_STATUS = 'Y'
  ELSE     ---ELSE OF  p_ROLE = 'Global Enquiry'
    -- Step-0 -Check part is valid or not
    V_VALDN_ORG := GEAE_CNV_UTILITY_PACKAGE.GET_ORGANIZATION_ID('CVO');
    -- validate whether part is orderable the organization used is CVO
    BEGIN
      --
      SELECT 'Y'
      INTO v_item_status
      FROM mtl_system_items_b msi
      WHERE msi.organization_id           = v_valdn_org
      AND msi.CUSTOMER_ORDER_FLAG         = 'Y'
      AND msi.CUSTOMER_ORDER_ENABLED_FLAg = 'Y'
      AND MSI.INVENTORY_ITEM_ID           = P_ITEM_ID;
      --
    EXCEPTION
    WHEN OTHERS THEN
      v_item_STATUS := 'N';
      SELECT LOOKUP_CODE
        || ': '
        || DESCRIPTION
      INTO p_message
      FROM fnd_lookup_values
      WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
      AND UPPER(LOOKUP_CODE) = UPPER('8125');
      --
      --Looping in customer loop to get the cust ids in message for 8125
      IF P_CUST_ID.COUNT > 0 THEN
        FOR VAR IN 1 .. P_CUST_ID.COUNT
        LOOP
          P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
        END LOOP;
      END IF;
      -- Loop ends for customer id concatenation in messages
    END;
    IF V_ITEM_STATUS = 'Y' THEN
      -- Inside the If condition of Item is Valid and orderable
      --Getting KIT Flag
      BEGIN
         SELECT 'Y'
           INTO P_KIT_IND
           FROM mtl_system_items_b
          WHERE organization_id = v_valdn_org
            AND inventory_item_id = P_ITEM_ID
            AND bom_item_type = 1;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            P_KIT_IND := 'N';
      END;
      IF v_kit_ind_on <> 'Y' THEN
         P_KIT_IND := 'N'; -- MYJIRATEST-4757 Ravi S 03-DEC-2014
      END IF;
      --MYJIRATEST-5093 Ravi S 21-JAN-2015
      BEGIN
         SELECT 'Y'
           INTO P_CRITICAL_PART
           FROM oe_hold_definitions ohd, oe_hold_sources_all ohsa, fnd_lookup_values flv
          WHERE ohd.hold_id = ohsa.hold_id
            AND ohd.name = flv.description
            AND flv.lookup_type = 'GEAE_MYGE_CRITICAL_PART_HOLDS'
            AND flv.enabled_flag = 'Y'
            AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(flv.start_date_active,SYSDATE)) AND TRUNC(NVL(flv.end_date_active,SYSDATE))
            AND ohsa.hold_entity_code = 'I'
            AND ohsa.released_flag <>'Y'   -- MYJIRATEST-12046  23-NOV-2015
            AND ohsa.hold_entity_id = P_ITEM_ID
            AND rownum = 1;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            P_CRITICAL_PART := 'N';
      END;
      -- Populating Below the Item details
      SELECT V_PART_DETAILS_LIST_BO(MSI.INVENTORY_ITEM_ID, MSI.SEGMENT1, DECODE(GEAE_MYGE_CTRL_SHIPBILITY(MSI.INVENTORY_ITEM_ID),'Y',NULL,MSI.DESCRIPTION),
             DECODE(v_parent_wh_id,NULL,NULL,GEAE_INV_AMPS_COMMON_UTILS_PKG.GET_CATEGORY_VALUE(v_parent_wh_id,MSI.INVENTORY_ITEM_ID,'Discount Indicator'))) BULK COLLECT
      INTO L_PART_DETAILS
      FROM mtl_system_items_b msi,
        mtl_parameters mtp
      WHERE 1                   = 1
      AND msi.organization_id   = mtp.organization_id
      AND INVENTORY_ITEM_ID     = P_ITEM_ID
      AND MTP.ORGANIZATION_CODE = 'CVO';
      --
      IF SQL%rowcount > 0 THEN
        FOR I IN 1 .. L_PART_DETAILS.COUNT
        LOOP
         V_PART_dtl_cnt  := 0;  --Manisha K. 27 Jul Initializing the variable so that the array P_PART_DETAILS fetch single record.
          V_PART_dtl_cnt := V_PART_dtl_cnt + 1;
        --  P_PART_DETAILS.EXTEND(); --Manisha 14 Dec Have added this code in the beginning outside the loop, to fetch only one record
          P_PART_DETAILS(V_PART_dtl_cnt) := L_PART_DETAILS(I);
        END LOOP;
      END IF;
      --
      IF SQL%ROWCOUNT = 0 THEN
        --
        SELECT LOOKUP_CODE
          || ': '
          || DESCRIPTION
        INTO p_message
        FROM fnd_lookup_values
        WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
        AND UPPER(LOOKUP_CODE) = UPPER('8125');
        --
        --Looping in customer loop to get the cust ids in message for 8125
        IF P_CUST_ID.COUNT > 0 THEN
          FOR VAR IN 1 .. P_CUST_ID.COUNT
          LOOP
            P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
          END LOOP;
        END IF;
        -- Loop ends for customer id concatenation in messages
      END IF;
      --Step -1 get distinct  price lists and price
      IF P_CUST_ID.COUNT > 0 THEN
        --
        V_FLAG_GTA_ERROR       := 'Y';
        V_FLAG_CTRL_SHIP_ERROR := 'Y';
        V_FLAG_AVIALL_ERROR    := 'Y';
        V_FLAG_VENDOR_ERROR    := 'Y';
        V_FLAG_ORG_ERROR       := 'Y';
        V_AMPS_CODE_ERROR      := 'Y';
        V_GENERIC_MESSG_CNT    := 0;
        V_AVAILL_ALL_ERROR     := NULL;
        FOR var IN 1 .. p_CUST_ID.COUNT
        LOOP
          -- to fetch the customer shipping address
          v_price_list_flag := NULL;
          BEGIN
            --
            SELECT V_PRICE_LIST_DTL_BO(stg.PRICE_LIST_ID, stg.account_number, stg.cust_account_id, stg.ORG_ID) BULK COLLECT
            INTO L_PRICE_LIST_DTL
            FROM
              (SELECT DISTINCT HCSUA.PRICE_LIST_ID price_list_id,
                hca.account_number account_number,
                hca.cust_account_id cust_account_id,
                HCSUA.ORG_ID org_id
              FROM hz_parties hp,
                hz_party_sites hps,
                hz_cust_accounts hca,
                hz_cust_acct_sites_all hcasa,
                hz_cust_site_uses_all hcsua
              WHERE hp.party_id                = hps.party_id(+)
              AND hp.party_id                  = hca.party_id(+)
              AND hcasa.party_site_id(+)       = hps.party_site_id
              AND HCSUA.CUST_ACCT_SITE_ID(+)   = HCASA.CUST_ACCT_SITE_ID
              AND HCSUA.PRICE_LIST_ID         IS NOT NULL
              AND hcsua.site_use_code          = 'SHIP_TO'
              AND hps.location_id              = hps.location_id -- AND hps.location_id = hl.location_id
              AND NVL(hcasa.status, 'I')       = 'A'           ----Added NVL
              AND NVL(HCA.STATUS, 'I')         = 'A'           ----Added NVL
              AND NVL(hcsua.primary_flag, 'X') = 'Y'
              AND NVL(hcsua.STATUS, 'I')       = 'A' ----Added NVL
              AND NVL(hps.STATUS, 'I')         = 'A' ----Added NVL
              AND NVL(hp.STATUS, 'I')          = 'A' ----Added NVL
              AND HCSUA.ORG_ID                 = TO_NUMBER(J.OU_ID) -- Added by Ravi S for MYJIRATEST-2758
              AND HCA.CUST_ACCOUNT_ID          = TO_NUMBER(P_CUST_ID(VAR))
              ) stg
            ORDER BY STG.ACCOUNT_NUMBER;
            --
          EXCEPTION
          WHEN NO_DATA_FOUND THEN
            v_price_list_flag := 'N';
          WHEN OTHERS THEN
            v_price_list_flag := 'N';
          END; ---END OF BEGIN OF SELECT STATMENT FOR BULK COLLECT OF PRICELIST
          --Check if the PRICE LIST IDS are NOT NULL else Price cannot be determined
          IF L_PRICE_LIST_DTL.COUNT > 0 THEN
            --
            FOR i IN 1 .. L_PRICE_LIST_DTL.count
            LOOP
              L_PRICE_LIST_DTL_cnt := L_PRICE_LIST_DTL_cnt + 1;
              P_PRICE_LIST_DTL.EXTEND();
              P_PRICE_LIST_DTL(L_PRICE_LIST_DTL_cnt) := L_PRICE_LIST_DTL(i); --BM Commented
            END LOOP;
          ELSE
            --
            NULL;
            --
          END IF;
        END LOOP; ---END LOOP for Lopp of Custids to determine the Pricelist from Active Ship-tos
        IF L_PRICE_LIST_DTL.COUNT = 0 THEN
          --
          SELECT LOOKUP_CODE
            || ': '
            || DESCRIPTION
          INTO p_message
          FROM fnd_lookup_values
          WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
          AND UPPER(LOOKUP_CODE) = UPPER('8137');
          --
          --Looping in customer loop to get the cust ids in message for 8125
          IF P_CUST_ID.COUNT > 0 THEN
            FOR VAR IN 1 .. P_CUST_ID.COUNT
            LOOP
              P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
            END LOOP;
          END IF;
          -- Loop ends for customer id concatenation in messages
        END IF;
      ELSE
        --else of Customer count
        ---Customer Ids are empty hence error
        --
        SELECT LOOKUP_CODE
          || ': '
          || DESCRIPTION
        INTO p_message
        FROM fnd_lookup_values
        WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
        AND UPPER(LOOKUP_CODE) = UPPER('8136');
        --
        --
        --
      END IF;
      --Step 2 get all the BOM and GTA intersection for all customers, consider shippable and vendor parts
      --Step 3 check the control shippability
      FOR var IN 1 .. p_CUST_ID.COUNT
      LOOP
        --
        --
        BEGIN
          SELECT V_PART_VLDTN_BO(CUSTOMER_NUMBER, SUPPLIER_CODE, SHIP_CODE, PAST_SHP_CD, VENDOR_PART, CUST_ACCOUNT_ID ,COMPONENT_ID ,site_to_use,amps_code) BULK COLLECT
          INTO L_PART_VLDTN
          FROM
              (SELECT stg.customer_number,
                stg.supplier_code,
                stg.ship_code,
                stg.past_shp_cd,
                stg.vendor_part,
                STG.CUST_ACCOUNT_ID,
                STG.COMPONENT_ID ,
                stg.site_to_use ,
                stg.amps_code
              FROM
                (SELECT hca.account_number customer_number,
                  bom.attribute8 supplier_code,
                  SUM(
                  CASE
                    WHEN EXISTS
                      (SELECT com.attribute5
                      FROM fnd_flex_value_sets ffs1,
                        FND_FLEX_VALUES_VL FFV1,
                        fnd_lookup_values FLV2,
                        HR_OPERATING_UNITS HOU1,
                        FND_LOOKUP_VALUES FLV1
                      WHERE 1                       = 1
                      AND NVL(ffv1.attribute1, 'N') = 'Y'
                      AND ffv1.flex_value           = com.attribute5
                      AND FFS1.FLEX_VALUE_SET_ID    = FFV1.FLEX_VALUE_SET_ID
                      AND FFS1.FLEX_VALUE_SET_NAME  = flv2.description
                      AND flv2.lookup_code          = flv1.tag
                      AND flv2.lookup_type          = 'GEAE_ONT_PRDLN_SHPCD_OU_LKP'
                      AND flv1.lookup_code          = hou1.organization_id
                      AND FLV1.LOOKUP_TYPE          = 'GEAE_MYGE_OPERATING_UNITS'
                      AND hou1.organization_id      = to_number(J.OU_ID)
                      )
                    THEN 1
                    ELSE 0
                  END) ship_code,
                  SUM(
                  CASE
                    WHEN EXISTS
                      (SELECT com.attribute5
                      FROM HR_OPERATING_UNITS HOU1,
                        FND_LOOKUP_VALUES FLV1,
                        fnd_lookup_values FLV3
                      WHERE 1                       = 1
                      AND flv1.lookup_code          = hou1.organization_id
                      AND FLV1.LOOKUP_TYPE          = 'GEAE_MYGE_OPERATING_UNITS'
                      AND FLV3.lookup_type          = 'GEAE_MYGE_PAST_SHIP_CODES'
                      AND FLV3.tag                  = com.attribute5
                      AND FLV3.enabled_flag         = 'Y'
                      AND FLV3.description          = hou1.organization_id
                      AND hou1.organization_id      = to_number(J.OU_ID)
                      )
                    THEN 1
                    ELSE 0
                  END) past_shp_cd,
                  SUM(
                  CASE
                    WHEN EXISTS
                      (SELECT com.attribute5
                      FROM fnd_lookup_values
                      WHERE lookup_type = 'GEAE_MYGE_VENDOR_CODE'
                      AND lookup_code   = com.attribute5
                      )
                    THEN 1
                    ELSE 0
                  END) vendor_part,
                  hca.cust_account_id cust_account_id,
                  com.component_item_id component_id ,
                  flv.description site_to_use ,
                  com.attribute5 amps_code
                FROM geae_ont_cust_gta_info goc,
                  geae_ont_gta_applblty_v gom,
                  bom_bill_of_materials bom,
                  bom_components_b com,
                  mtl_system_items msi,
                  mtl_parameters mp,
                  hz_cust_accounts_all hca,
                  fnd_lookup_values flv
                WHERE 1                               = 1
                AND gom.engine_model_id               = bom.assembly_item_id
                AND msi.inventory_item_id             = bom.assembly_item_id
                AND com.bill_sequence_id              = bom.bill_sequence_id
                AND com.component_item_id             = p_item_id
                AND hca.cust_account_id               = TO_NUMBER(P_CUST_ID(VAR))
                AND goc.geae_ont_cust_gta_info_seq_id = gom.geae_ont_cust_gta_info_seq_id
                AND goc.customer_id                   = hca.cust_account_id
                AND trunc(goc.end_date)             > = trunc(sysdate)  -- US34704--added by Prasad on 10-NOV-16
                AND NVL(com.disable_date,SYSDATE+1) >  SYSDATE
                AND flv.lookup_type                   = 'GEAE_MYGE_SUPPLIER_ORGS'
                AND flv.enabled_flag                  = 'Y'
                AND TO_NUMBER(flv.description)        = goc.org_id
                AND goc.org_id                        = to_number(J.OU_ID)  --Manisha K 07-DEC Added the OU_ID condition  to fetch the data for cuurent OU_ID as two U_ID will passed in loop; Passport requirement
                AND msi.enabled_flag                  = 'Y'
                AND msi.organization_id               = mp.organization_id
                AND mp.organization_code              = 'CVO'
                AND bom.attribute8                    = flv.meaning
                GROUP BY hca.account_number,
                  bom.attribute8,
                  cust_account_id,
                  com.component_item_id ,
                  FLV.DESCRIPTION,
                  com.attribute5
                ) STG
            );
          --
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
          NULL;
        WHEN OTHERS THEN
          NULL;
        END; ---END of BEGIN of Select statment for bulk collect of Pricelist
        --Check if the PRICE LIST IDS are NOT NULL else Price cannot be determined
        IF L_PART_VLDTN.COUNT = 0 THEN
          --
          --
          --
          BEGIN
            v_cust_account_number := NULL;
            SELECT ACCOUNT_NUMBER
            INTO v_cust_account_number
            FROM hz_cust_accounts
            WHERE 1             = 1
            AND CUST_ACCOUNT_ID = TO_NUMBER(P_CUST_ID(VAR));
          EXCEPTION
          WHEN OTHERS THEN
            V_CUST_ACCOUNT_NUMBER := P_CUST_ID(VAR);
          END;
          --
          --
          IF p_message IS NULL THEN
            SELECT LOOKUP_CODE
              || ': '
              || DESCRIPTION
            INTO p_message
            FROM fnd_lookup_values
            WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
            AND UPPER(LOOKUP_CODE) = UPPER('8127');
            P_MESSAGE             := P_MESSAGE||'~'||P_CUST_ID(VAR);
          ELSE
            P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
          END IF;
          V_FLAG_GTA_ERROR      := 'N';
          IF V_GTA_ERR_MSSG     IS NULL THEN
            V_GTA_ERR_MSSG      := 'Customer GTA does not allow them to buy the part:'||v_cust_account_number;
          ELSE
            V_GTA_ERR_MSSG      := V_GTA_ERR_MSSG||','||v_cust_account_number;
          END IF;
        END IF;
        --IF all results point to other OU, then put a message and come out.
        FOR I IN 1 .. L_PART_VLDTN.COUNT
        LOOP
        DBMS_OUTPUT.PUT_LINE('IN PART... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
           --
          IF J.OU_ID         <> L_PART_VLDTN(I).SITE_TO_USE THEN
           DBMS_OUTPUT.PUT_LINE('1... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
            V_FLAG_ORG_ERROR := 'N';
            --
            IF V_ORG_ERR_MSSG     IS NULL THEN
              V_ORG_ERR_MSSG      := 'Part is being ordered in the wrong OU.'||L_PART_VLDTN(I).CUSTOMER_NUMBER;
            ELSE
              V_ORG_ERR_MSSG      := V_ORG_ERR_MSSG||','||L_PART_VLDTN(I) .CUSTOMER_NUMBER;
            END IF;
            BEGIN
              --
              SELECT attribute2
              INTO v_portal
              FROM FND_LOOKUP_VALUES FLV
              WHERE 1              = 1
              AND flv.lookup_type  = 'GEAE_MYGE_SUPPLIER_ORGS'
              AND flv.enabled_flag = 'Y'
              AND flv.description  = L_PART_VLDTN(I).site_to_use
              AND flv.meaning  =L_PART_VLDTN(I).SUPPLIER_CODE;
            EXCEPTION
            WHEN OTHERS THEN
              --
              v_portal := NULL;
            END;
            --
            IF p_message IS NULL THEN
              SELECT LOOKUP_CODE
                || ': '
                || DESCRIPTION
              INTO p_message
              FROM fnd_lookup_values
              WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
              AND UPPER(LOOKUP_CODE) = UPPER('8126');
              P_MESSAGE             := P_MESSAGE ||'|'||V_PORTAL;
            --ELSE
              --P_MESSAGE := P_MESSAGE ||'|'||V_PORTAL;
            END IF;
            --EXIT;
            CONTINUE; --MYJIRATEST-6058 Ravi S 18-FEB-2015
          END IF;  --J.OU_ID         <> L_PART_VLDTN(I).SITE_TO_USE
        DBMS_OUTPUT.PUT_LINE('2... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
         --
          --Adding the Aviall validation after GTA
          --
          BEGIN
            --
            v_aviall_err_ind := 'N';
            --
            SELECT 'Y'
            INTO v_aviall_part
            FROM mtl_item_categories_v mic
            WHERE 1                                    = 1
            AND SUBSTR(mic.category_concat_segs, 1, 6) = 'AVIALL'
            AND mic.inventory_item_id                  = p_item_id
            AND mic.category_set_name                  = 'GEAE_AMPS_DISTRIBUTION_DEAL'
            AND ROWNUM                                 < 2;
          EXCEPTION
          WHEN OTHERS THEN
            --
            v_aviall_part := 'N';
          END;
          IF V_AVIALL_PART = 'Y' THEN
         DBMS_OUTPUT.PUT_LINE('3... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
            ---Calling the Price API to check if the Part is Priced
            V_AVIALL_SUCESS               := NULL;
            IF NVL(V_PRICE_LIST_FLAG,'Y') <> 'N' THEN
              P_AVIALL_UNIT_PRICE         := NULL;
              FOR PRICELSTID IN
              (SELECT stg.price_list_id,
                stg.account_number,
                STG.CUST_ACCOUNT_ID
              FROM TABLE(CAST(P_PRICE_LIST_DTL AS v_PRICE_LIST_DTL)) stg
              WHERE STG.ACCOUNT_NUMBER = L_PART_VLDTN(I).CUSTOMER_NUMBER
              )
              LOOP
                V_AVIALL_PRICE_LIST_ID := PRICELSTID.PRICE_LIST_ID;
                GET_PRICE(P_SSO ,J.OU_ID, P_ITEM_ID, V_AVIALL_PRICE_LIST_ID, P_AVIALL_UNIT_PRICE, P_AVIALL_LIST_LINE_ID);
                IF P_AVIALL_UNIT_PRICE IS NOT NULL THEN
                  V_AVIALL_SUCESS      := 'Y';
                  EXIT;
                END IF;
              END LOOP;
            ELSE ---NVL(V_PRICE_LIST_FLAG,'Y') <> 'N' then
              IF p_message IS NULL THEN
                SELECT LOOKUP_CODE
                  || ': '
                  || DESCRIPTION
                INTO p_message
                FROM fnd_lookup_values
                WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
                AND UPPER(LOOKUP_CODE) = UPPER('8132');
                --
                p_message := p_message||'~'||P_CUST_ID(VAR);
                --
              ELSE
                P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
              END IF;
              v_aviall_err_ind     := 'Y';
              V_FLAG_AVIALL_ERROR  := 'N';
              IF V_AVIALL_ERR_MSSG IS NULL THEN
                --
                V_AVIALL_ERR_MSSG   := 'The part is a Aviall part :'||L_PART_VLDTN(I).CUSTOMER_NUMBER;
              ELSE
                V_AVIALL_ERR_MSSG   := V_AVIALL_ERR_MSSG||','||L_PART_VLDTN(I).CUSTOMER_NUMBER;
              END IF;
                 EXIT;
            END IF;--NVL(V_PRICE_LIST_FLAG,'Y') <> 'N' then
            --
            -- Checking if the Aviall part has price

           IF V_AVIALL_SUCESS = 'Y' THEN
              NULL;
            ELSE
              IF p_message IS NULL THEN
                SELECT LOOKUP_CODE
                  || ': '
                  || DESCRIPTION
                INTO p_message
                FROM fnd_lookup_values
                WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
                AND UPPER(LOOKUP_CODE) = UPPER('8132');
                --
                p_message := p_message||'~'||P_CUST_ID(VAR);
                --
              ELSE
                P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
              END IF;
              --
              v_aviall_err_ind     := 'Y';
              V_FLAG_AVIALL_ERROR  := 'N';
              IF V_AVIALL_ERR_MSSG IS NULL THEN
                --
                V_AVIALL_ERR_MSSG   := 'The part is a Aviall part :'||L_PART_VLDTN(I).CUSTOMER_NUMBER;
              ELSE
                V_AVIALL_ERR_MSSG   := V_AVIALL_ERR_MSSG||','||L_PART_VLDTN(I).CUSTOMER_NUMBER;
              END IF;
              --
               EXIT;
            END IF;--if V_AVIALL_SUCESS = 'Y'
          END IF;----if V_AVIALL_PART = 'Y' then
          --Aviall Validation ends
        DBMS_OUTPUT.PUT_LINE('4... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
          IF  L_PART_VLDTN(I).AMPS_CODE = 'C' THEN      --US46803-Change ship code C to non shippable in portal
             V_FSCM_SUPPLIER := NULL;
                BEGIN
                  SELECT MIC.CATEGORY_CONCAT_SEGS
                  INTO v_FSCM_supplier
                  FROM MTL_ITEM_CATEGORIES_V MIC,
                    FND_LOOKUP_VALUES FLV,
                    mtl_parameters mp,
                    hr_operating_units hou
                  WHERE 1                   = 1
                  AND MIC.INVENTORY_ITEM_ID = P_ITEM_ID
                  AND MIC.CATEGORY_SET_NAME = 'FSCM supplier'
                  AND mic.organization_id   = mp.organization_id
                  AND flv.lookup_type = 'GEAE_MYGE_PART_APPLICABLE_ORGS'
                  AND mp.organization_code  = flv.tag  --MYJIRATEST-3993 Ravi S 30-OCT-2014
                  AND FLV.DESCRIPTION       = HOU.NAME
                  AND HOU.ORGANIZATION_ID   = TO_NUMBER(J.OU_ID)
                  AND ROWNUM                < 2;
                EXCEPTION
                WHEN OTHERS THEN
                  V_FSCM_SUPPLIER := NULL;
                END;
             IF p_message IS NULL THEN
               dbms_output.put_line('p_message::::'||p_message);
               SELECT LOOKUP_CODE
                 || ': '
                 || DESCRIPTION
               INTO p_message
               FROM fnd_lookup_values
               WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
               AND UPPER(LOOKUP_CODE) = UPPER('8204');
                     --
               P_MESSAGE := P_MESSAGE||'|'||V_FSCM_SUPPLIER||'~'||P_CUST_ID(VAR);
             END IF;
             --
            CONTINUE; --US41783-User customer code is not populating while adding a part to cart
              EXIT;
            END IF;
      DBMS_OUTPUT.PUT_LINE('5... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
       IF  L_PART_VLDTN(I).AMPS_CODE IN('P','Z','N') THEN      --MYJIRATEST-9281 Neelima Y 12-OCT-2015 ---MYJIRATEST-13902 Trupti D. 07-APR-2016
       DBMS_OUTPUT.PUT_LINE('12... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
            V_FSCM_SUPPLIER := NULL;
                BEGIN
                  SELECT MIC.CATEGORY_CONCAT_SEGS
                  INTO v_FSCM_supplier
                  FROM MTL_ITEM_CATEGORIES_V MIC,
                    FND_LOOKUP_VALUES FLV,
                    mtl_parameters mp,
                    hr_operating_units hou
                  WHERE 1                   = 1
                  AND MIC.INVENTORY_ITEM_ID = P_ITEM_ID
                  AND MIC.CATEGORY_SET_NAME = 'FSCM supplier'
                  AND mic.organization_id   = mp.organization_id
                  AND flv.lookup_type = 'GEAE_MYGE_PART_APPLICABLE_ORGS'
                  AND mp.organization_code  = flv.tag  --MYJIRATEST-3993 Ravi S 30-OCT-2014
                  AND FLV.DESCRIPTION       = HOU.NAME
                  AND HOU.ORGANIZATION_ID   = TO_NUMBER(J.OU_ID)
                  AND ROWNUM                < 2;
                EXCEPTION
                WHEN OTHERS THEN
                  V_FSCM_SUPPLIER := NULL;
                END;
             IF p_message IS NULL THEN
               SELECT LOOKUP_CODE
                 || ': '
                 || DESCRIPTION
               INTO p_message
               FROM fnd_lookup_values
               WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
               AND UPPER(LOOKUP_CODE) = UPPER('8203');
                     --
               P_MESSAGE := P_MESSAGE||'|'||V_FSCM_SUPPLIER||'~'||P_CUST_ID(VAR);
             END IF;
             --
             V_AMPS_CODE_ERROR  := 'N';
             IF V_AMPS_CODE_ERR_MSSG IS NULL THEN
               V_AMPS_CODE_ERR_MSSG  := 'Dear Customers, if you need to place an order or know the availability/price of this part, contact CAM:'||L_PART_VLDTN(I) .CUSTOMER_NUMBER;
             ELSE
               V_AMPS_CODE_ERR_MSSG := V_AMPS_CODE_ERR_MSSG||','||L_PART_VLDTN(I) .CUSTOMER_NUMBER;
             END IF;
            CONTINUE;
              EXIT;
        ELSE
          IF L_PART_VLDTN(I).SHIP_CODE > 0 THEN
          DBMS_OUTPUT.PUT_LINE('13... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
            --
            --If all ship codes are past use, validate procurement code and on hand

           IF L_PART_VLDTN(I).SHIP_CODE = L_PART_VLDTN(I).PAST_SHP_CD THEN

DBMS_OUTPUT.PUT_LINE('14... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
  --            v_proc_status
               BEGIN
                  SELECT mcb.segment1
                    INTO v_proc_code
                    FROM mtl_item_categories mic, mtl_category_sets mcs, mtl_categories_b mcb, mtl_parameters mp, fnd_lookup_values supp
                   WHERE mic.category_set_id = mcs.category_set_id
                     AND mic.category_id = mcb.category_id
                     AND mic.organization_id = mp.organization_id
                     AND mcs.category_set_name = 'Procurement Code'
                     AND supp.lookup_type = 'GEAE_MYGE_SUPPLIER_ORGS'
                     AND supp.description = J.OU_ID
                     AND mp.organization_code = supp.attribute1
                     AND supp.meaning = L_PART_VLDTN(I).SUPPLIER_CODE
                     AND mic.inventory_item_id = L_PART_VLDTN(I).COMPONENT_ID;
               EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                     v_proc_code := 'NA';
               END;
               IF v_proc_code IS NULL THEN
                  v_proc_code := 'NA';
               END IF;
               IF v_proc_code IN ('X','Y','NA') THEN
                  v_proc_status := 'Y';
               ELSE
                  BEGIN
                   --Added by OWMS Team : Start
                           v_item_source := NULL;
                           v_item_number := NULL;
                           BEGIN
                             SELECT DISTINCT segment1
                                 INTO v_item_number
                                 FROM mtl_system_items_b
                                 WHERE INVENTORY_ITEM_ID   = P_ITEM_ID;
                             EXCEPTION
                               WHEN OTHERS THEN
                                          v_item_number := NULL;
                             END;
                               --
                              SELECT DECODE(COUNT(1),1,'Y','N')
                              INTO v_hnd_flag
                               FROM HR_OPERATING_UNITS HOU,
                                  FND_LOOKUP_VALUES FLV
                              WHERE  HOU.ORGANIZATION_ID = TO_NUMBER(j.OU_ID) --116797
                                AND HOU.NAME = FLV.DESCRIPTION
                                AND FLV.TAG = 'HAI'
                                AND FLV.LOOKUP_TYPE = 'GEAE_MYGE_PART_APPLICABLE_ORGS';
                               --
                               IF v_hnd_flag = 'Y' THEN
					   v_item_source := 'HAI';
                               ELSIF v_hnd_flag = 'N' THEN
					   --
					   v_er1_source := GEAE_INV_GET_SOURCE_CODE ('ER1',v_item_number,'Y');
					   v_er2_source := GEAE_INV_GET_SOURCE_CODE ('ER2',v_item_number,'Y');
					   v_er3_source := GEAE_INV_GET_SOURCE_CODE ('ER3',v_item_number,'Y');
					   --
					   IF v_er1_source = 'CPL' OR v_er2_source = 'CPL' OR v_er3_source = 'CPL' THEN
						v_item_source := 'CPL';
					   ELSE
						 v_item_source := 'ERL';
					   END IF;
					   --
                               END IF;
                               --
                            SELECT NVL(SUM(QTY),0)
                                INTO v_on_hand
                                FROM (SELECT (A.QTY - B.QTY)  QTY
				    FROM (SELECT (geae_wms_total_onhand_erl_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
						geae_wms_total_pick_release(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
						 FROM apps.mtl_system_items_b msib,
						      apps.mtl_parameters mp
						 WHERE 1 = 1
						   and msib.inventory_item_id = L_PART_VLDTN(I).COMPONENT_ID
						   and msib.organization_id = mp.organization_id
						   and mp.organization_code = v_item_source
						   AND v_item_source NOT IN ('CPL','HAI')) A,
					 (SELECT (geae_wms_resv_qty_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
						geae_wms_total_resv(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
						 FROM apps.mtl_system_items_b msib,
						      apps.mtl_parameters mp
						 WHERE 1 = 1
						   and msib.inventory_item_id = L_PART_VLDTN(I).COMPONENT_ID
						   and msib.organization_id = mp.organization_id
						   and mp.organization_code = v_item_source
						   AND v_item_source NOT IN ('CPL','HAI')) B
                                      UNION ALL -- Neelima Y MYJIRATEST-8631 on 18-AUG-2015
                                      SELECT SUM(HND.QTY)
                                        FROM (SELECT DISTINCT MSIB.INVENTORY_ITEM_ID, GIF.ONHAND_QTY QTY
                                                FROM GEAE_INV_FOXTROT_DATA_STG GIF,
                                                     MTL_SYSTEM_ITEMS_B        MSIB,
                                                     HR_OPERATING_UNITS        HOU,
                                                     MTL_PARAMETERS            MTP,
                                                     FND_LOOKUP_VALUES         FLV
                                               WHERE MSIB.SEGMENT1 = GIF.PRT_NUM
                                                 AND HOU.ORGANIZATION_ID = TO_NUMBER(J.OU_ID)
                                                 AND HOU.NAME = FLV.DESCRIPTION
                                                 AND MTP.ORGANIZATION_CODE = FLV.TAG
           			                 AND FLV.TAG	= v_item_Source
						 AND v_item_Source NOT IN ('CPL','ERL')
                                                 AND FLV.LOOKUP_TYPE = 'GEAE_MYGE_PART_APPLICABLE_ORGS'
                                                 AND GIF.ORG_CODE = MTP.ORGANIZATION_CODE
                                                 AND MSIB.INVENTORY_ITEM_ID = L_PART_VLDTN(I).COMPONENT_ID
                                                 AND GIF.SRC_SYS = 'HONDA') HND
                                      UNION
                                      SELECT (A.QTY - B.QTY)  QTY
                                        FROM (SELECT NVL(SUM(MOQ.TRANSACTION_QUANTITY), 0) QTY
                                                FROM GEAE_INV_MTL_ONHANDS_V MOQ
                                               WHERE INVENTORY_ITEM_ID = L_PART_VLDTN(I).COMPONENT_ID
                                                 AND SUBINVENTORY_CODE IN ('STOCK','STG')
                                                 AND ORGANIZATION_ID IN
                                                     (SELECT ORGANIZATION_ID
                                                        FROM MTL_PARAMETERS
                                                       WHERE ORGANIZATION_CODE = V_ITEM_SOURCE)
                                                  AND v_item_source NOT IN ('ERL','HAI')    ) A,
                                             (SELECT NVL(SUM(RESERVATION_QUANTITY), 0) QTY
                                                FROM MTL_RESERVATIONS
                                               WHERE INVENTORY_ITEM_ID = L_PART_VLDTN(I).COMPONENT_ID
                                                 AND ORGANIZATION_ID IN
                                                     (SELECT ORGANIZATION_ID
                                                        FROM MTL_PARAMETERS
                                                       WHERE ORGANIZATION_CODE = V_ITEM_SOURCE)
                                                  AND v_item_source NOT IN ('ERL','HAI')    ) B);
--Added by OWMS Team : END
                  EXCEPTION
                     WHEN NO_DATA_FOUND THEN
                        v_on_hand := 0;
                  END;
                  IF v_on_hand > 0 THEN
                     v_proc_status := 'Y';
                  ELSE
                     v_proc_status := 'N';
                  END IF;
              DBMS_OUTPUT.PUT_LINE('17... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
         END IF;
            --Fetch data for proc_yes
            END IF;
            IF (L_PART_VLDTN(I).SHIP_CODE = L_PART_VLDTN(I).PAST_SHP_CD AND v_proc_status = 'Y') OR L_PART_VLDTN(I).SHIP_CODE > L_PART_VLDTN(I).PAST_SHP_CD THEN
            DBMS_OUTPUT.PUT_LINE('15... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
            DBMS_OUTPUT.PUT_LINE('L_PART_VLDTN(I).SHIP_CODE-->'||L_PART_VLDTN(I).SHIP_CODE);
            DBMS_OUTPUT.PUT_LINE('L_PART_VLDTN(I).PAST_SHP_CD-->'||L_PART_VLDTN(I).PAST_SHP_CD);
            DBMS_OUTPUT.PUT_LINE('v_proc_status-->'||v_proc_status);
            DBMS_OUTPUT.PUT_LINE('L_PART_VLDTN(I).PAST_SHP_CD-->'||L_PART_VLDTN(I).PAST_SHP_CD);
               BEGIN
                 SELECT mp.organization_id
                 INTO V_ORG_ID
                 FROM MTL_PARAMETERS MP,
                   FND_LOOKUP_VALUES FLV
                 WHERE 1                  = 1
                 AND MP.ORGANIZATION_CODE = FLV.ATTRIBUTE1
                 AND FLV.meaning          = L_PART_VLDTN(I).SUPPLIER_CODE
                 AND FLV.LOOKUP_TYPE      = 'GEAE_MYGE_SUPPLIER_ORGS';
               EXCEPTION
               WHEN OTHERS THEN
                 v_org_id := 60378;
               END ;
               --
               V_CONTROL_SHIP      := NVL(GEAE_AMPS_OM_CONFIG_VAL.FUN_CONTROL_SHIPPABLE_ITEM(L_PART_VLDTN(I).COMPONENT_ID, L_PART_VLDTN(I).CUST_ACCOUNT_ID, V_ORG_ID, L_PART_VLDTN(I).SITE_TO_USE), 0);
               v_control_shippable := NVL(geae_inv_amps_common_utils_pkg.get_category_value(V_ORG_ID, L_PART_VLDTN(I).component_id, 'Control Shippable'), 'N');
               IF V_CONTROL_SHIP IN (1, 3) THEN
                 --
                 IF V_CONTROL_SHIPPABLE = 'A' THEN
                   --
                   IF p_message IS NULL THEN
                     SELECT LOOKUP_CODE
                       || ': '
                       || DESCRIPTION
                     INTO p_message
                     FROM fnd_lookup_values
                     WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
                     AND UPPER(LOOKUP_CODE) = UPPER('8135');
                     --
                     P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
                   ELSE
                     P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
                   END IF;
                   --
                   V_FLAG_CTRL_SHIP_ERROR  := 'N';
                   IF V_CTRL_SHIP_ERR_MSSG IS NULL THEN
                     V_CTRL_SHIP_ERR_MSSG  := 'Part is approval required but customer doesnot have Approval :'||L_PART_VLDTN(I) .CUSTOMER_NUMBER;
                   ELSE
                     V_CTRL_SHIP_ERR_MSSG := V_CTRL_SHIP_ERR_MSSG||','||L_PART_VLDTN(I) .CUSTOMER_NUMBER;
                   END IF;
                     EXIT;
                 ELSE
                   --
                   IF p_message IS NULL THEN
                     SELECT LOOKUP_CODE
                       || ': '
                       || DESCRIPTION
                     INTO p_message
                     FROM fnd_lookup_values
                     WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
                     AND UPPER(LOOKUP_CODE) = UPPER('8129');
                     --
                     P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
                   ELSE
                     P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
                   END IF;
                   --
                   V_FLAG_CTRL_SHIP_ERROR  := 'N';
                   IF V_CTRL_SHIP_ERR_MSSG IS NULL THEN
                     V_CTRL_SHIP_ERR_MSSG  := 'Part is a license control and customer is not set up to buy it:'||L_PART_VLDTN(I) .CUSTOMER_NUMBER;
                   ELSE
                     V_CTRL_SHIP_ERR_MSSG := V_CTRL_SHIP_ERR_MSSG||','||L_PART_VLDTN(I) .CUSTOMER_NUMBER;
                   END IF;
                     EXIT;
                 END IF;  --end of V_CONTROL_SHIPPABLE = 'A'
               END IF;  -- end of V_CONTROL_SHIP IN (1, 3)
         DBMS_OUTPUT.PUT_LINE('16... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
         ELSIF L_PART_VLDTN(I).SHIP_CODE = L_PART_VLDTN(I).PAST_SHP_CD AND v_proc_status = 'N' THEN
         DBMS_OUTPUT.PUT_LINE('19... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
              IF P_message IS NULL THEN
                  SELECT LOOKUP_CODE
                         || ': '
                         || DESCRIPTION
                    INTO p_message
                    FROM fnd_lookup_values
                   WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
                     AND UPPER(LOOKUP_CODE) = UPPER('8179');
                   --
                  P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
               ELSE
                  P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
               END IF;
               --
              continue;
                  EXIT;
            END IF;  --  IF (L_PART_VLDTN(I).SHIP_CODE = L_PART_VLDTN(I).PAST_SHP_CD AND v_proc_status = 'Y')
          ELSIF L_PART_VLDTN(I).VENDOR_PART > 0 THEN
            --   Adding logic to get the FSCM supplier from Item Category
           DBMS_OUTPUT.PUT_LINE('20... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
           V_FSCM_SUPPLIER := NULL;
            BEGIN
              SELECT MIC.CATEGORY_CONCAT_SEGS
              INTO v_FSCM_supplier
              FROM MTL_ITEM_CATEGORIES_V MIC,
                FND_LOOKUP_VALUES FLV,
                mtl_parameters mp,
                hr_operating_units hou
              WHERE 1                   = 1
              AND MIC.INVENTORY_ITEM_ID = P_ITEM_ID
              AND MIC.CATEGORY_SET_NAME = 'FSCM supplier'
              AND mic.organization_id   = mp.organization_id
              AND flv.lookup_type = 'GEAE_MYGE_PART_APPLICABLE_ORGS'
              AND mp.organization_code  = flv.tag  --MYJIRATEST-3993 Ravi S 30-OCT-2014
              AND FLV.DESCRIPTION       = HOU.NAME
              AND HOU.ORGANIZATION_ID   = TO_NUMBER(J.OU_ID)
              AND ROWNUM                < 2;
            EXCEPTION
            WHEN OTHERS THEN
              V_FSCM_SUPPLIER := NULL;
            END;
            --   Adding logic to get the FSCM supplier from Item Category
            IF P_MESSAGE IS NULL THEN
              SELECT LOOKUP_CODE
                || ': '
                || DESCRIPTION
              INTO p_message
              FROM fnd_lookup_values
              WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
              AND UPPER(LOOKUP_CODE) = UPPER('8131');
              --
              P_MESSAGE := P_MESSAGE||'|'||V_FSCM_SUPPLIER;
           -- ELSE
           --   P_MESSAGE := P_MESSAGE||'|'||V_FSCM_SUPPLIER;
            END IF;
            V_FLAG_VENDOR_ERROR   := 'N';
            IF V_VENDOR_ERR_MSSG  IS NULL THEN
              V_VENDOR_ERR_MSSG   := 'Vendor part and GE does not have permission to sell this part to the customer:'||L_PART_VLDTN(I).CUSTOMER_NUMBER;
            ELSE
              V_VENDOR_ERR_MSSG   := V_VENDOR_ERR_MSSG||','||L_PART_VLDTN(I) .CUSTOMER_NUMBER;
            END IF;
              EXIT;
            --
          DBMS_OUTPUT.PUT_LINE('18... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
          ELSE
            IF P_message IS NULL THEN
              SELECT LOOKUP_CODE
                || ': '
                || DESCRIPTION
              INTO p_message
              FROM fnd_lookup_values
              WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
              AND UPPER(LOOKUP_CODE) = UPPER('8125');
              --
              P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
            ELSE
              P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
            END IF;
            --
          --  EXIT; --JIRA 12358 TRUPTI D. 28-12-2015
DBMS_OUTPUT.PUT_LINE('22... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
          END IF;
          DBMS_OUTPUT.PUT_LINE('21... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
        END IF;  -- end if for ampcode =P Z N
        DBMS_OUTPUT.PUT_LINE('6... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
          -- line is control shippable then get the pricelist
          --
          --Adding if to check if the customer has the price list attached if not then populate the Applicability array and price will be NULL;
          IF NVL(v_price_list_flag,'Y') <> 'N' THEN
            DBMS_OUTPUT.PUT_LINE('7... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
            FOR PRICELSTID IN
            (SELECT stg.price_list_id,
              stg.account_number,
              STG.CUST_ACCOUNT_ID
            FROM TABLE(CAST(P_PRICE_LIST_DTL AS v_PRICE_LIST_DTL)) stg
            WHERE STG.ACCOUNT_NUMBER = L_PART_VLDTN(I) .CUSTOMER_NUMBER
            )
            LOOP
            DBMS_OUTPUT.PUT_LINE('8... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
              --
              P_UNIT_PRICE    := NULL;
              V_PRICE_LIST_ID := PRICELSTID.PRICE_LIST_ID;
              v_cust_account_id := PRICELSTID.cust_account_id;
              V_PUBLISH         := NULL;
              v_price_list_api  := NULL;
              --Calling the procedure GET_PRICE which internally calls  QP_PREQ_PUB.PRICE_REQUEST
              IF V_PRICE_LIST_ID <> NVL(V_PRICE_LIST_ID_OLD, 0) OR V_CUST_ACCOUNT_ID <> NVL(V_CUST_ACCOUNT_ID_OLD, 0) THEN
              DBMS_OUTPUT.PUT_LINE('9... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
                v_price_list_id_old   := v_price_list_id;
                V_Cust_Account_Id_Old := V_Cust_Account_Id;
                GET_PRICE(P_SSO,J.OU_ID, P_ITEM_ID, V_PRICE_LIST_ID, P_UNIT_PRICE, P_LIST_LINE_ID);
                IF P_UNIT_PRICE     IS NOT NULL THEN
                  IF P_LIST_LINE_ID IS NOT NULL THEN
                    BEGIN
                      SELECT NVL(ATTRIBUTE13,'Y')
                             ,list_header_id
                      INTO V_PUBLISH
                           ,v_price_list_api
                      FROM QP_LIST_LINES
                      WHERE 1          = 1
                      AND LIST_LINE_ID = P_LIST_LINE_ID;
                    EXCEPTION
                    WHEN OTHERS THEN
                      V_PUBLISH := 'N';
                      v_price_list_api := NULL;
                    END;
                    IF V_PUBLISH = 'Y' THEN
                      SELECT V_PART_PRICE_LIST_BO(GQIPV.inventory_item_id, GET_PRICE_LIST_NAME(V_PRICE_LIST_ID), P_UNIT_PRICE, NVL(GQIPV.CATALOG_UPQ,1), GQIPV.CATALOG_LEAD_TIME) BULK COLLECT
                      INTO L_PART_PRICE_V
                      FROM GEAE_QP_ITEM_PRICES_V GQIPV,
                        QP_LIST_HEADERS_TL QLH
                      WHERE 1                     = 1
                      AND GQIPV.inventory_item_id = to_char(P_ITEM_ID)
                      AND GQIPV.PRICE_LIST_NAME   = QLH.NAME
                      AND QLH.LIST_HEADER_ID      = v_price_list_api; --L_PRICE_LIST_ID(PRICELSTID);
                      --
                      IF SQL%rowcount > 0 THEN
                        FOR i IN 1 .. L_PART_PRICE_V.count
                        LOOP
                          v_PART_PRICE_V_add := v_PART_PRICE_V_add + 1;
                          l_PART_PRICE_DUP.extend();
                          l_PART_PRICE_DUP(v_PART_PRICE_V_add) := L_PART_PRICE_V(i); --BM Commented
                        END LOOP;
                      ELSE
                        IF p_message IS NULL THEN
                          SELECT LOOKUP_CODE
                            || ': '
                            || DESCRIPTION
                          INTO p_message
                          FROM fnd_lookup_values
                          WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
                          AND UPPER(LOOKUP_CODE) = UPPER('8134');
                          --
                          P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
                        ELSE
                          P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
                        END IF;
                        --
                        EXIT;
                      END IF;
                      --Adding condition to check for No data for QLH.LIST_HEADER_ID
                      SELECT   COUNT(*) INTO l_List_id_count
                           FROM     GEAE_QP_ITEM_PRICES_V GQIPV,
                                    QP_LIST_HEADERS_TL QLH
                           WHERE 1                     = 1
                            AND GQIPV.inventory_item_id = to_char(P_ITEM_ID)
                            AND GQIPV.PRICE_LIST_NAME   = QLH.NAME
                            AND QLH.LIST_HEADER_ID      = v_price_list_api;
                         IF (l_List_id_count)>0 THEN
                         DBMS_OUTPUT.PUT_LINE('10... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
                          --Ravi S: Price list id is passed even if part does not exist in price list MYJIRATEST-2629
                          SELECT V_PART_APPLICABLE_LIST_BO(GQIPV.inventory_item_id,PRICELSTID.account_number, L_PART_VLDTN(I).supplier_code, PRICELSTID.cust_account_id, NVL(GQIPV.CATALOG_UPQ,1), v_price_list_id) BULK COLLECT
                          INTO L_PART_APPLICABLE
                          FROM GEAE_QP_ITEM_PRICES_V GQIPV,
                            QP_LIST_HEADERS_TL QLH
                          WHERE 1                     = 1
                          AND GQIPV.inventory_item_id = P_ITEM_ID
                          AND GQIPV.PRICE_LIST_NAME   = QLH.NAME
                          AND QLH.LIST_HEADER_ID      = v_price_list_api; --L_PRICE_LIST_ID(PRICELSTID);
                        ELSE -- Ankita S:L_PART_APPLICABLE varray will still be populated
                          SELECT V_PART_APPLICABLE_LIST_BO(P_ITEM_ID,PRICELSTID.account_number, L_PART_VLDTN(I).supplier_code, PRICELSTID.cust_account_id, 1, v_price_list_id) BULK COLLECT
                          INTO L_PART_APPLICABLE
                          FROM GEAE_QP_ITEM_PRICES_V GQIPV
                          WHERE 1                     = 1
                        --  AND GQIPV.inventory_item_id = P_ITEM_ID
                          AND rownum = 1;
                        END IF;
                        DBMS_OUTPUT.PUT_LINE('11... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
                      --
                      IF SQL%rowcount > 0 THEN
                        FOR i IN 1 .. L_PART_APPLICABLE.count
                        LOOP
                          V_PART_APPL_CNT := V_PART_APPL_CNT + 1;
                          l_PART_APPLICABLE_DUP.extend();
                          l_PART_APPLICABLE_DUP(V_PART_APPL_CNT) := L_PART_APPLICABLE(i); --BM Commented
                        END LOOP;
                      ELSE
                        IF p_message IS NULL THEN
                          SELECT LOOKUP_CODE
                            || ': '
                            || DESCRIPTION
                          INTO p_message
                          FROM fnd_lookup_values
                          WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
                          AND UPPER(LOOKUP_CODE) = UPPER('8134'); -----
                          --
                          P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
                        ELSE
                          P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
                        END IF;
                        --
                      END IF;
                      --
                  DBMS_OUTPUT.PUT_LINE('PRICELSTID.account_number3-->'||PRICELSTID.account_number||' '||'L_PART_VLDTN(I) .supplier_code3-->'||L_PART_VLDTN(I) .supplier_code);
                   ELSE --ELSE OF  V_PUBLISH = 'Y' THEN
                      ---Part is priced but publish is N
                      --Populating the Applicability Array such that the Item can be bought
                      ---Populating The Applicability Array even if the Price is nULL as Customer can still buy the parts if the Price is not there Ravi S: However price list id can be passed. MYJIRATEST-2629
                      DBMS_OUTPUT.PUT_LINE('PRICELSTID.account_number-->'||PRICELSTID.account_number||' '||'L_PART_VLDTN(I) .supplier_code-->'||L_PART_VLDTN(I) .supplier_code);
                      SELECT V_PART_APPLICABLE_LIST_BO(msi.inventory_item_id, PRICELSTID.account_number, L_PART_VLDTN(I) .supplier_code, PRICELSTID.cust_account_id, 1, V_PRICE_LIST_ID) BULK COLLECT
                      INTO L_PART_APPLICABLE
                      FROM mtl_system_items_b msi,
                        mtl_parameters mp
                      WHERE 1                   = 1
                      AND msi.inventory_item_id = P_ITEM_ID
                      AND msi.organization_id   = mp.organization_id
                     AND mp.organization_code  = 'CVO';
                     DBMS_OUTPUT.PUT_LINE('PRICELSTID.account_number1-->'||PRICELSTID.account_number||' '||'L_PART_VLDTN(I) .supplier_code1-->'||L_PART_VLDTN(I) .supplier_code);

                      --
                      IF SQL%rowcount > 0 THEN
                        FOR i IN 1 .. L_PART_APPLICABLE.count
                        LOOP
                          V_PART_APPL_CNT := V_PART_APPL_CNT + 1;
                          l_PART_APPLICABLE_DUP.extend();
                         l_PART_APPLICABLE_DUP(V_PART_APPL_CNT) := L_PART_APPLICABLE(i); --BM Commented
                        END LOOP;
                      ELSE
                        IF p_message IS NULL THEN
                          SELECT LOOKUP_CODE
                            || ': '
                            || DESCRIPTION
                          INTO p_message
                          FROM fnd_lookup_values
                          WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
                          AND UPPER(LOOKUP_CODE) = UPPER('8139'); -----
                          --
                          P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
                        ELSE
                          P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
                        END IF;
                        --
                      END IF;
                    END IF; --v_publish is not null and v_publish is 'Y'
                  END IF;   -- P_LIST_LINE_ID is not null
                ELSE        --ELSE OF IF P_UNIT_PRICE IS NOT NULL THEN
                  ---Populating The Applicability Array even if the Price is nULL as Customer can still buy the parts if the Price is not there. Ravi S: However price list id can be passed.  MYJIRATEST-2629
                  DBMS_OUTPUT.PUT_LINE('PRICELSTID.account_number2-->'||PRICELSTID.account_number||' '||'L_PART_VLDTN(I) .supplier_code2-->'||L_PART_VLDTN(I) .supplier_code);
                  SELECT V_PART_APPLICABLE_LIST_BO(msi.inventory_item_id, PRICELSTID.account_number, L_PART_VLDTN(I) .supplier_code, PRICELSTID.cust_account_id, 1, V_PRICE_LIST_ID) BULK COLLECT
                  INTO L_PART_APPLICABLE
                  FROM mtl_system_items_b msi,
                    mtl_parameters mp
                  WHERE 1                   = 1
                  AND msi.inventory_item_id = P_ITEM_ID
                  AND msi.organization_id   = mp.organization_id
                  AND mp.organization_code  = 'CVO';
                  --
                  IF SQL%rowcount > 0 THEN
                    FOR i IN 1 .. L_PART_APPLICABLE.count
                    LOOP
                      V_PART_APPL_CNT := V_PART_APPL_CNT + 1;
                      l_PART_APPLICABLE_DUP.extend();
                      l_PART_APPLICABLE_DUP(V_PART_APPL_CNT) := L_PART_APPLICABLE(i); --BM Commented
                    END LOOP;
                  ELSE
                    IF p_message IS NULL THEN
                      SELECT LOOKUP_CODE
                        || ': '
                        || DESCRIPTION
                      INTO p_message
                      FROM fnd_lookup_values
                      WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
                      AND UPPER(LOOKUP_CODE) = UPPER('8139'); -----
                      --
                      P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
                    ELSE
                      P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
                    END IF;
                    --
                  END IF;
                END IF; -- IF P_UNIT_PRICE IS NOT NULL THEN
             --END IF;
              END IF;  --- IF v_price_list_id <> NVL(v_price_list_id_old, 0) OR
            END LOOP;   --FOR PRICELSTID IN
          ELSE         ---ELSE OF  IF NVL(v_price_list_flag,'Y') <> 'N' THEN
            --Price list could not be detrmined at customer ship to level Populating the Applicability array as customer can still buy the part
          DBMS_OUTPUT.PUT_LINE('L_PART_VLDTN(I).CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
           SELECT V_PART_APPLICABLE_LIST_BO(msi.inventory_item_id, L_PART_VLDTN(I).CUSTOMER_NUMBER, L_PART_VLDTN(I).supplier_code, L_PART_VLDTN(I).CUST_ACCOUNT_ID, 1, NULL) BULK COLLECT
            INTO L_PART_APPLICABLE
            FROM mtl_system_items_b msi,
              mtl_parameters mp
            WHERE 1                   = 1
            AND msi.inventory_item_id = P_ITEM_ID
            AND msi.organization_id   = mp.organization_id
            AND mp.organization_code  = 'CVO';
            --
            IF SQL%rowcount > 0 THEN
              FOR i IN 1 .. L_PART_APPLICABLE.count
              LOOP
                V_PART_APPL_CNT := V_PART_APPL_CNT + 1;
                l_PART_APPLICABLE_DUP.extend();
                l_PART_APPLICABLE_DUP(V_PART_APPL_CNT) := L_PART_APPLICABLE(i); --BM Commented
              END LOOP;
            ELSE
              IF p_message IS NULL THEN
                SELECT LOOKUP_CODE
                  || ': '
                  || DESCRIPTION
                INTO p_message
                FROM fnd_lookup_values
                WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
                AND UPPER(LOOKUP_CODE) = UPPER('8139'); -----
                --
                P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
              ELSE
                P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
              END IF;
              --
            END IF;
            --
          END IF; ---END IF OF  IF NVL(v_price_list_flag,'Y') <> 'N' THEN
DBMS_OUTPUT.PUT_LINE('IN PART... CUSTOMER_NUMBER1-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
DBMS_OUTPUT.PUT_LINE('IN CUST... p_CUST_ID(var)1-->'||p_CUST_ID(var));
        END LOOP;  --FOR I IN 1 .. L_PART_VLDTN.COUNT LOOP
        --
      END LOOP; --FOR var IN 1 .. p_CUST_ID.COUNT LOOP
      ---
      --Populating the Onhand VArray outside Customer Loop.
      --
--Added by OWMS Team : START
         v_item_source := NULL;
         v_item_number := NULL;
         BEGIN
           SELECT DISTINCT segment1
               INTO v_item_number
               FROM mtl_system_items_b
               WHERE INVENTORY_ITEM_ID   = P_ITEM_ID;
           EXCEPTION
             WHEN OTHERS THEN
                        v_item_number := NULL;
           END;
	  --
		SELECT DECODE(COUNT(1),1,'Y','N')
		INTO v_hnd_flag
		 FROM HR_OPERATING_UNITS HOU,
			  FND_LOOKUP_VALUES FLV
		WHERE  HOU.ORGANIZATION_ID = TO_NUMBER(j.OU_ID) --116797
		  AND HOU.NAME = FLV.DESCRIPTION
		  AND FLV.TAG = 'HAI'
		  AND FLV.LOOKUP_TYPE = 'GEAE_MYGE_PART_APPLICABLE_ORGS';
	   --
	   IF v_hnd_flag = 'Y' THEN
	     v_item_source := 'HAI';
	   ELSIF v_hnd_flag = 'N' THEN
	   --
	   v_er1_source := GEAE_INV_GET_SOURCE_CODE ('ER1',v_item_number,'Y');
	   v_er2_source := GEAE_INV_GET_SOURCE_CODE ('ER2',v_item_number,'Y');
	   v_er3_source := GEAE_INV_GET_SOURCE_CODE ('ER3',v_item_number,'Y');
	   --
	   IF v_er1_source = 'CPL' OR v_er2_source = 'CPL' OR v_er3_source = 'CPL' THEN
		v_item_source := 'CPL';
	   ELSE
		 v_item_source := 'ERL';
	   END IF;
	   --
	   END IF;
      SELECT V_PART_AVAILABILITY_LIST_BO(tab.INVENTORY_ITEM_ID, tab.ORGANIZATION_CODE, NVL(tab.QTY,0)) BULK collect
      INTO L_PART_AVAIL
      FROM
      (SELECT STG.INVENTORY_ITEM_ID,STG.ORGANIZATION_CODE,sum(stg.qty) qty
          FROM (SELECT P_ITEM_ID INVENTORY_ITEM_ID ,
                        'On-Hand Stock' ORGANIZATION_CODE,
                         (a.qty-b.qty) QTY
            FROM (SELECT (geae_wms_total_onhand_erl_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
			geae_wms_total_pick_release(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
			 FROM apps.mtl_system_items_b msib,
			      apps.mtl_parameters mp
			 WHERE 1 = 1
			   and msib.inventory_item_id = P_ITEM_ID
			   and msib.organization_id = mp.organization_id
			   and mp.organization_code = v_item_source
			   AND v_item_source NOT IN ('CPL','HAI')) A,
                 (SELECT (geae_wms_resv_qty_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
			geae_wms_total_resv(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
			 FROM apps.mtl_system_items_b msib,
			      apps.mtl_parameters mp
			 WHERE 1 = 1
			   and msib.inventory_item_id = P_ITEM_ID
			   and msib.organization_id = mp.organization_id
			   and mp.organization_code = v_item_source
			   AND v_item_source NOT IN ('CPL','HAI')) B
           UNION ALL
                SELECT P_ITEM_ID INVENTORY_ITEM_ID ,
                        'On-Hand Stock' ORGANIZATION_CODE,
                        (b.qty-c.qty) QTY
                FROM
                     (SELECT NVL(SUM(MOQ.TRANSACTION_QUANTITY),0) qty
                        FROM GEAE_INV_MTL_ONHANDS_V MOQ
                       WHERE INVENTORY_ITEM_ID = P_ITEM_ID
                         AND SUBINVENTORY_CODE IN ('STOCK','STG')
                         AND ORGANIZATION_ID IN (SELECT ORGANIZATION_ID
                                                   FROM MTL_PARAMETERS
                                                  WHERE ORGANIZATION_CODE = V_ITEM_SOURCE)
                          AND v_item_source NOT IN ('ERL','HAI')
                    ) b,
                 (SELECT NVL(SUM(RESERVATION_QUANTITY),0) qty
                             FROM MTL_RESERVATIONS
                     WHERE INVENTORY_ITEM_ID = P_ITEM_ID
                         AND ORGANIZATION_ID IN (SELECT ORGANIZATION_ID
                                                   FROM MTL_PARAMETERS
                                                  WHERE ORGANIZATION_CODE = V_ITEM_SOURCE)
                          AND v_item_source NOT IN ('ERL','HAI')
                   ) C
        UNION ALL
        SELECT DISTINCT MSIB.INVENTORY_ITEM_ID,
                'On-Hand Stock' ORGANIZATION_CODE,
               GIF.ONHAND_QTY  QTY
          FROM GEAE_INV_FOXTROT_DATA_STG GIF,
               MTL_SYSTEM_ITEMS_B MSIB,
               HR_OPERATING_UNITS HOU,
               MTL_PARAMETERS MTP,
               FND_LOOKUP_VALUES FLV
         WHERE MSIB.SEGMENT1=GIF.PRT_NUM
           AND HOU.ORGANIZATION_ID       = TO_NUMBER(J.OU_ID)
           AND HOU.NAME                   = FLV.DESCRIPTION
           AND MTP.ORGANIZATION_CODE      = FLV.TAG
	        AND FLV.TAG					 = v_item_Source
            AND v_item_source NOT IN ('ERL','CPL')
           AND FLV.LOOKUP_TYPE            = 'GEAE_MYGE_PART_APPLICABLE_ORGS'
           AND GIF.ORG_CODE               = MTP.ORGANIZATION_CODE
           AND MSIB.INVENTORY_ITEM_ID =P_ITEM_ID
           AND GIF.SRC_SYS ='HONDA'
          ) STG
--Added by OWMS Team : END
       GROUP BY INVENTORY_ITEM_ID,
          ORGANIZATION_CODE)TAB ;
      -- Onhand Varray Ends

      IF SQL%rowcount > 0 THEN
        FOR i IN 1 .. L_PART_AVAIL.count
        LOOP
          V_PART_AVAIL_cnt := V_PART_AVAIL_cnt + 1;
          P_PART_AVAIL.EXTEND();
          P_PART_AVAIL(V_PART_AVAIL_cnt) := L_PART_AVAIL(i) ; --BM Commented
        END LOOP;
      ELSE
        SELECT LOOKUP_CODE
          || ': '
          || DESCRIPTION
        INTO p_message
        FROM fnd_lookup_values
        WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
        AND UPPER(LOOKUP_CODE) = UPPER('8133');
        --
        --
        --Looping in customer loop to get the cust ids in message for 8133
        IF P_CUST_ID.COUNT > 0 THEN
          FOR VAR IN 1 .. P_CUST_ID.COUNT
          LOOP
            P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
          END LOOP;
        END IF;
        -- Loop ends for customer id concatenation in messages
      END IF;--- End If Part Avaliability list BO
      --End of Onhand Varray Population
      --Making P_MESSAGE NULL if the Array is populated
      IF l_PART_APPLICABLE_DUP.COUNT > 0 THEN
        --
        P_MESSAGE := NULL;
        -- Setting the P_PRICE_MESSAGE
        IF L_PART_PRICE_DUP.COUNT = 0 THEN
          IF p_ROLE              <> 'Cust Enquiry' THEN
            P_PRICE_MESSAGE      := 'Price_Msg:';
            P_PRICE_MESSAGE      := P_PRICE_MESSAGE||'Part is not priced but you can still order part';
          ELSE
            P_PRICE_MESSAGE := 'Price_Msg_01:';
            P_PRICE_MESSAGE := P_PRICE_MESSAGE||'Part is not priced';
          END IF;
          IF P_CUST_ID.COUNT > 0 THEN
            FOR VAR IN 1 .. P_CUST_ID.COUNT
            LOOP
              P_PRICE_MESSAGE := P_PRICE_MESSAGE||'~'||P_CUST_ID(VAR);
            END LOOP;
          END IF;
        ELSE
       --   l_PART_PRICE_DUP_CNT :=0;  Manisha commented on 12 dec to avoid losing the data of P_PART_PRICE array if count initialize again
          ---P_PART_PRICE := l_PART_PRICE_DUP;

          FOR var IN 1 .. l_PART_PRICE_DUP.COUNT
          LOOP

            IF var                  =1  AND P_PART_PRICE.COUNT = 0 THEN --Manisha Added the condition
              l_PART_PRICE_DUP_CNT := l_PART_PRICE_DUP_CNT + 1;
              P_PART_PRICE.extend();
              P_PART_PRICE(l_PART_PRICE_DUP_CNT) := l_PART_PRICE_DUP(var);
            ELSE
              v_price_dup_flag := true;
              FOR dup IN 1 .. P_PART_PRICE.count
              LOOP
                IF l_PART_PRICE_DUP(var).INVENTORY_ITEM_ID = P_PART_PRICE(dup).INVENTORY_ITEM_ID AND l_PART_PRICE_DUP(var).CATALOG = P_PART_PRICE(dup).CATALOG AND l_PART_PRICE_DUP(var).UNIT_PRICE = P_PART_PRICE(dup).UNIT_PRICE AND l_PART_PRICE_DUP(var).UPQ = P_PART_PRICE(dup).UPQ AND l_PART_PRICE_DUP(var).LEAD_TIME = P_PART_PRICE(dup).LEAD_TIME THEN
                  v_price_dup_flag                        := false;
                END IF;
                NULL;
              END LOOP;
              IF v_price_dup_flag THEN
                l_PART_PRICE_DUP_CNT := l_PART_PRICE_DUP_CNT + 1;
                P_PART_PRICE.extend();
                P_PART_PRICE(l_PART_PRICE_DUP_CNT) := l_PART_PRICE_DUP(var);
              END IF;
            END IF;
          END LOOP;
          --Remove Duplicates from P_PART_PRICE  l_PART_PRICE_DUP
        END IF;
        -- Looping in the Onhadn Varray to find if we have onhand
        v_onhand_flag_non_zero := 'N';
        FOR I IN 1 .. P_PART_AVAIL.COUNT
        LOOP
          IF P_PART_AVAIL(I).QUANTITY > 0 THEN
            V_ONHAND_FLAG_NON_ZERO   := 'Y';
               EXIT;
          END IF;
        END LOOP ;
               -- Neelima Y MYJIRATEST-8631 on 18-AUG-2015
       BEGIN
          SELECT tag
            INTO V_OU_TAG
            FROM fnd_lookup_values
           WHERE lookup_type = 'GEAE_MYGE_OPERATING_UNITS'
             AND enabled_flag = 'Y'
             AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(start_date_active, SYSDATE)) AND
                 TRUNC(NVL(end_date_active, SYSDATE))
             AND lookup_code = J.OU_ID;
        Exception
          When Others then
            V_OU_TAG := NULL;
        End; --Fetching Operating Unit Code
        -- Setting the P_AVAIL_MESSAGE
      IF (P_CRITICAL_PART ='Y') AND (V_OU_TAG <>'HND') THEN  -- MYJIRATEST-7056 Ankita.S 04-MAY-2015  --AND Condition added by Neelima Y MYJIRATEST-8631 on 18-AUG-2015
           IF p_ROLE = 'Cust Enquiry' THEN
              P_AVAIL_MESSAGE  := 'Avail_Msg_02:';
              P_AVAIL_MESSAGE:= P_AVAIL_MESSAGE||'Current on hand is already being allocated';
           ELSIF p_ROLE = 'Buyer' THEN
                IF P_CUST_ID.COUNT > 0 THEN
                  FOR VAR IN 1 .. P_CUST_ID.COUNT
                  LOOP
                    P_AVAIL_MESSAGE  := 'Avail_Msg_03:';
                    P_AVAIL_MESSAGE:= P_AVAIL_MESSAGE||'Current on hand is already being allocated, you can still purchase the part'||'~'||P_CUST_ID(VAR);
                  END LOOP;
                END IF;
           ELSE
                  NULL;
           END IF;
      ELSE
            IF V_ONHAND_FLAG_NON_ZERO = 'N' THEN
              IF p_ROLE              <> 'Cust Enquiry' THEN
                P_AVAIL_MESSAGE      := 'Avail_Msg:';
                P_AVAIL_MESSAGE      := P_AVAIL_MESSAGE||'Part does not have on-hand but you can still order part';
              ELSE
                P_AVAIL_MESSAGE := 'Avail_Msg_01:';
                P_AVAIL_MESSAGE := P_AVAIL_MESSAGE||'Part does not have on-hand.';
              END IF;
              IF P_CUST_ID.COUNT > 0 THEN
                FOR VAR IN 1 .. P_CUST_ID.COUNT
                LOOP
                  P_AVAIL_MESSAGE := P_AVAIL_MESSAGE||'~'||P_CUST_ID(VAR);
                END LOOP;
              END IF;
            END IF; --END IF OF V_ONHAND_FLAG_NON_ZERO = 'N' THEN
      END IF;
        --
        -- Loop ends for customer id concatenation in messages
        --Remove duplicates from P_PART_APPLICABLE below
       -- l_PART_APPLICABLE_DUP_CNT :=0;  Manisha commented on 12 dec to avoid reintialize inside the loop
        FOR var IN 1 .. l_PART_APPLICABLE_DUP.COUNT
        LOOP
          IF var                       =1 THEN
            l_PART_APPLICABLE_DUP_CNT := l_PART_APPLICABLE_DUP_CNT + 1;
            P_PART_APPLICABLE.extend();
            P_PART_APPLICABLE(l_PART_APPLICABLE_DUP_CNT) := l_PART_APPLICABLE_DUP(var);
          ELSE
            v_part_APP_DUP_FLAG := true;
            FOR dup IN 1 .. P_PART_APPLICABLE.count
            LOOP
              IF l_PART_APPLICABLE_DUP(var).INVENTORY_ITEM_ID = P_PART_APPLICABLE(dup).INVENTORY_ITEM_ID AND l_PART_APPLICABLE_DUP(var).CUST_CODE = P_PART_APPLICABLE(dup).CUST_CODE AND l_PART_APPLICABLE_DUP(var).SUPPLIER_CODE = P_PART_APPLICABLE(dup).SUPPLIER_CODE AND l_PART_APPLICABLE_DUP(var).CUST_ID = P_PART_APPLICABLE(dup).CUST_ID AND l_PART_APPLICABLE_DUP(var).UPQ = P_PART_APPLICABLE(dup).UPQ AND l_PART_APPLICABLE_DUP(var).PRICE_LIST_ID = P_PART_APPLICABLE(dup).PRICE_LIST_ID THEN
                v_part_APP_DUP_FLAG                          := false;
              END IF;
            END LOOP;
            IF v_part_APP_DUP_FLAG THEN
              l_PART_APPLICABLE_DUP_CNT := l_PART_APPLICABLE_DUP_CNT + 1;
              P_PART_APPLICABLE.extend();
              P_PART_APPLICABLE(l_PART_APPLICABLE_DUP_CNT) := l_PART_APPLICABLE_DUP(var);
            END IF;
          END IF;
        END LOOP;
      END IF; --END IF of P_PART_APPLICABLE.COUNT > 0
      --
      --
      --Looping in customer loop to get the cust ids in message for 8125
      --
      V_GENERIC_MSSG := NULL;
      --
      IF P_PART_APPLICABLE.COUNT = 0 THEN
        --
        P_PART_AVAIL.DELETE;
        V_PART_AVAIL_cnt := 0;  --Manisha 02-Jan Added this to initialize the count if P_PART_AVAIL array is getting deleted
        P_PART_PRICE.DELETE;
        -- If There are more than one 1 message then only return Generic message else return P_MESSAGE
        IF V_GTA_ERR_MSSG     IS NOT NULL THEN
          V_GENERIC_MESSG_CNT := V_GENERIC_MESSG_CNT + 1;
        END IF;
        IF V_ORG_ERR_MSSG     IS NOT NULL THEN
          V_GENERIC_MESSG_CNT := V_GENERIC_MESSG_CNT + 1;
        END IF;
        IF V_CTRL_SHIP_ERR_MSSG    IS NOT NULL THEN
          V_GENERIC_MESSG_CNT := V_GENERIC_MESSG_CNT + 1;
        END IF;
        IF V_AVIALL_ERR_MSSG  IS NOT NULL THEN
          V_GENERIC_MESSG_CNT := V_GENERIC_MESSG_CNT + 1;
        END IF;
        IF V_VENDOR_ERR_MSSG  IS NOT NULL THEN
          V_GENERIC_MESSG_CNT := V_GENERIC_MESSG_CNT + 1;
        END IF;
        IF V_AMPS_CODE_ERR_MSSG IS NOT NULL THEN
          V_GENERIC_MESSG_CNT := V_GENERIC_MESSG_CNT + 1;
        END IF;
        IF V_GENERIC_MESSG_CNT > 1 THEN
          SELECT LOOKUP_CODE
            || ': '
          INTO V_GENERIC_MSSG
          FROM fnd_lookup_values
          WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
          AND UPPER(LOOKUP_CODE) = UPPER('8200');
          V_GENERIC_MSSG        := V_GENERIC_MSSG||V_GTA_ERR_MSSG||'.'||V_ORG_ERR_MSSG||'.'||V_CTRL_SHIP_ERR_MSSG||'.'||V_AVIALL_ERR_MSSG||'.'||V_VENDOR_ERR_MSSG||'.'||V_AMPS_CODE_ERR_MSSG;
          P_MESSAGE             := V_GENERIC_MSSG;
          IF P_CUST_ID.COUNT     > 0 THEN
            FOR VAR IN 1 .. P_CUST_ID.COUNT
            LOOP
              P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
            END LOOP;
          END IF;
        END IF; --END IF Of IF V_GENERIC_MESSG_CNT > 1
      END IF;   --END IF of  P_PART_APPLICABLE.COUNT = 0 THEN
      --
      --MYJIRATEST-6272 Ravi S 03-MAR-2015
      IF v_prod_line_on = 'Y' THEN --   MYJIRATEST-7139 23-MAR-2015    Engine family to Product line changes
         l_bom_counter := 0;
         IF P_CUST_ID.COUNT > 0 AND P_PART_APPLICABLE.COUNT > 0 THEN
            FOR part_bom IN (SELECT DISTINCT prt_apl.cust_code, bom.product_line product_line --   MYJIRATEST-7139 23-MAR-2015    Engine family to Product line changes
                               FROM geae_myge_bom_details_v bom, geae_ont_cust_gta_info gta_hdr, geae_ont_gta_applblty_v gta_line,
                                    TABLE(CAST(P_PART_APPLICABLE AS V_PART_APPLICABLE)) prt_apl
                              WHERE bom.search_ou_id = gta_hdr.org_id
                                AND gta_hdr.geae_ont_cust_gta_info_seq_id = gta_line.geae_ont_cust_gta_info_seq_id
                                AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(gta_hdr.start_date,SYSDATE)) AND TRUNC(NVL(gta_hdr.end_date,SYSDATE))
                                AND bom.eng_mod = gta_line.engine_model
                                AND bom.search_ou_id = J.OU_ID
                                AND bom.inventory_item_id = prt_apl.inventory_item_id
                                AND gta_hdr.customer_id = prt_apl.cust_id) LOOP
               P_PART_BOM.EXTEND(1);
               l_bom_counter := l_bom_counter + 1;
               P_PART_BOM(P_PART_BOM.last):= V_PART_BOM_BO(part_bom.cust_code, part_bom.product_line , l_bom_counter);--   MYJIRATEST-7139 23-MAR-2015    Engine family to Product line changes
            END LOOP;
         END IF;
      END IF;
    ELSE --Else of  IF V_ITEM_STATUS = 'Y' THEN
      --
      SELECT LOOKUP_CODE
        || ': '
        || DESCRIPTION
      INTO p_message
      FROM fnd_lookup_values
      WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
      AND UPPER(LOOKUP_CODE) = UPPER('8125');
      --
      --Looping in customer loop to get the cust ids in message for 8125
      IF P_CUST_ID.COUNT > 0 THEN
        FOR VAR IN 1 .. P_CUST_ID.COUNT
        LOOP
          P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
        END LOOP;
      END IF;
      -- Loop ends for customer id concatenation in messages
    END IF; ---END IF of IF V_ITEM_STATUS = 'Y' THEN
  END IF;   ---END IF of p_ROLE = 'Global Enquiry'
  --Ravi S MYJIRATEST-5063 21-JAN-2015
  l_disc_counter := 0;
  IF P_CUST_ID.COUNT > 0 AND P_PART_APPLICABLE.COUNT > 0 THEN
     FOR i IN 1 .. P_CUST_ID.COUNT LOOP
        l_pr_fr_disc := NULL;
        FOR part_appl IN (SELECT prt_apl.supplier_code, prt_apl.price_list_id, NVL(prt_apl.upq,1) upq
                            FROM TABLE(CAST(P_PART_APPLICABLE AS V_PART_APPLICABLE)) prt_apl,
                                 fnd_lookup_values supp_code
                           WHERE prt_apl.cust_id = P_CUST_ID(i)
                             AND prt_apl.inventory_item_id = P_ITEM_ID
                             AND prt_apl.supplier_code = supp_code.meaning
                             AND supp_code.lookup_type = 'GEAE_MYGE_SUPPLIER_ORGS'
                             AND supp_code.description = J.OU_ID
                           ORDER BY supp_code.attribute3) LOOP
           GET_PRICE(P_SSO,J.OU_ID,P_ITEM_ID,part_appl.price_list_id,l_pr_fr_disc,l_disc_line_id);
           IF l_pr_fr_disc IS NOT NULL THEN
              l_disc_list_id := part_appl.price_list_id;

                EXIT;
           END IF;
           l_disc_list_id := NULL;
        END LOOP;
        FOR r_disc IN C_DISCOUNTS(P_CUST_ID(i),J.OU_ID,P_ITEM_ID,l_disc_list_id) LOOP
           IF r_disc.line_auto_flag = 'Y' THEN
              l_disc_end_date := NULL;
              IF l_disc_end_date > r_disc.qual_end_date OR l_disc_end_date IS NULL THEN
                 l_disc_end_date := r_disc.qual_end_date;
              END IF;
              IF l_disc_end_date > r_disc.line_end_date OR l_disc_end_date IS NULL THEN
                 l_disc_end_date := r_disc.line_end_date;
              END IF;
              IF l_disc_end_date > r_disc.list_end_date OR l_disc_end_date IS NULL THEN
                 l_disc_end_date := r_disc.list_end_date;
              END IF;
              IF l_disc_end_date > r_disc.grants_end_date OR l_disc_end_date IS NULL THEN
                 l_disc_end_date := r_disc.grants_end_date;
              END IF;
              SELECT NVL(SUM(amount),0)
                INTO l_disc_consumed
                FROM qp_limit_transactions
               WHERE list_header_id = r_disc.list_header_id
                 AND list_line_id = r_disc.list_line_id;
              IF r_disc.limit > l_disc_consumed OR r_disc.basis IS NULL THEN
                 l_disc_price := l_pr_fr_disc*(100-r_disc.disc_value)/100;
              ELSE
                 l_disc_price := l_pr_fr_disc;
              END IF;
              P_PART_DISCOUNTS.EXTEND(1);
              l_disc_counter := l_disc_counter + 1;
              P_PART_DISCOUNTS(P_PART_DISCOUNTS.last):= V_PART_DISCOUNTS_BO(r_disc.account_number, r_disc.line_number, r_disc.disc_value, l_disc_price, r_disc.limit, GREATEST(r_disc.limit-l_disc_consumed,0), l_disc_end_date, r_disc.list_name, r_disc.list_description, r_disc.line_number, r_disc.line_comments, r_disc.arithmetic_operator, r_disc.list_header_id, r_disc.list_line_id, l_disc_counter, r_disc.qualifier_id);
          ELSE
              IF P_CUST_ID.COUNT > 0 THEN
                FOR VAR IN 1 .. P_CUST_ID.COUNT
                  LOOP
                    P_DISC_MESSAGE :=GEAE_MYGE_CART_PKG.GET_ERR_MSG(8199)||'~'||P_CUST_ID(VAR);--MYJIRATEST-7192: Ankita.S 04-MAY-2015
                  END LOOP;
              END IF;
           END IF;
        END LOOP;
     END LOOP;
  END IF;
----MYJIRATEST-7138   24-MAR-2015    Oderable Vs Non Oderable changes  starts
 BEGIN
  BEGIN
     SELECT description
--       INTO NVL(v_oderable_on,'N')
      INTO v_oderable_on
       FROM fnd_lookup_values
      WHERE lookup_type = 'GEAE_MYGE_ENABLE_ORDERABLE'
        AND lookup_code = J.OU_ID
        AND enabled_flag = 'Y'
        AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(start_date_active,SYSDATE)) AND TRUNC(NVL(end_date_active,SYSDATE));
  EXCEPTION
     WHEN NO_DATA_FOUND THEN
        v_oderable_on := 'N';
     WHEN OTHERS THEN
        v_oderable_on := 'N';
  END;
  IF v_oderable_on = 'Y' THEN
  --Calls the Procedure for getting Inventory Item status Code
   get_inventory_item_status_code ( lp_inventory_item_id=> P_ITEM_ID ,
                                    P_OU_ID =>J.OU_ID,
                                    lp_inventory_item_status_code => V_ISODERABLE ,
                                    pp_message => V_ISODERABLE_MESSAGE);
   P_ISODERABLE :=V_ISODERABLE;
   IF V_ISODERABLE_MESSAGE  IS NOT NULL THEN
      P_MESSAGE := P_MESSAGE||'.'||V_ISODERABLE_MESSAGE;
   END IF;
  END IF;--v_oderable_on flag
 END;  ----MYJIRATEST-7138   24-MAR-2015    Oderable Vs Non Oderable changes  Ends
--<<END_CODE>>
  NULL;
 END LOOP; --End of Loop J.OU_ID


 /******************************************************
 Manisha K. 10-Aug Added the below code to  remove the duplicates from the loop
 because of OU_ID loop
 *******************************************************/

 FOR i IN 1 .. P_PART_PRICE.COUNT  LOOP

 T_PART_PRICE_LOOP_DUP.extend();
 T_PART_PRICE_LOOP_DUP(T_PART_PRICE_LOOP_DUP.last):= V_PART_PRICE_LIST_BO(P_PART_PRICE(i).INVENTORY_ITEM_ID, P_PART_PRICE(i).CATALOG, P_PART_PRICE(i).UNIT_PRICE, P_PART_PRICE(i).UPQ ,P_PART_PRICE(i).LEAD_TIME);
 END LOOP;

 FOR i IN 1 .. P_PART_APPLICABLE.COUNT  LOOP
 T_PART_APPLICABLE_LOOP_DUP.extend();
 T_PART_APPLICABLE_LOOP_DUP(T_PART_APPLICABLE_LOOP_DUP.LAST):=V_PART_APPLICABLE_LIST_BO(P_PART_APPLICABLE(i).INVENTORY_ITEM_ID,P_PART_APPLICABLE(i).CUST_CODE,P_PART_APPLICABLE(i).SUPPLIER_CODE,P_PART_APPLICABLE(i).CUST_ID,P_PART_APPLICABLE(i).UPQ,P_PART_APPLICABLE(i).PRICE_LIST_ID);
 END LOOP;

 FOR i IN 1 .. P_PART_AVAIL.COUNT  LOOP

 T_PART_AVAIL_LOOP_DUP.extend();
 T_PART_AVAIL_LOOP_DUP(T_PART_AVAIL_LOOP_DUP.last):= V_PART_AVAILABILITY_LIST_BO(P_PART_AVAIL(i).INVENTORY_ITEM_ID, P_PART_AVAIL(i).LOCATION , P_PART_AVAIL(i).QUANTITY);

 END LOOP;

 P_PART_PRICE.DELETE;
 P_PART_APPLICABLE.DELETE;
 P_PART_AVAIL.DELETE;

   i_PART_PRICE_DUP_CNT :=0;
  FOR var IN 1 .. T_PART_PRICE_LOOP_DUP.COUNT     LOOP
      IF var                  =1 THEN
        i_PART_PRICE_DUP_CNT := i_PART_PRICE_DUP_CNT + 1;
        P_PART_PRICE.extend();

        P_PART_PRICE(i_PART_PRICE_DUP_CNT) := T_PART_PRICE_LOOP_DUP(var);

      ELSE

        i_price_dup_flag := true;
        FOR dup IN 1 .. P_PART_PRICE.count
        LOOP
          IF T_PART_PRICE_LOOP_DUP(var).INVENTORY_ITEM_ID = P_PART_PRICE(dup).INVENTORY_ITEM_ID AND T_PART_PRICE_LOOP_DUP(var).CATALOG = P_PART_PRICE(dup).CATALOG AND T_PART_PRICE_LOOP_DUP(var).UNIT_PRICE = P_PART_PRICE(dup).UNIT_PRICE AND T_PART_PRICE_LOOP_DUP(var).UPQ = P_PART_PRICE(dup).UPQ AND T_PART_PRICE_LOOP_DUP(var).LEAD_TIME = P_PART_PRICE(dup).LEAD_TIME THEN
            i_price_dup_flag                        := false;
          END IF;
          NULL;
        END LOOP;
        IF i_price_dup_flag THEN
          i_PART_PRICE_DUP_CNT := i_PART_PRICE_DUP_CNT + 1;
          P_PART_PRICE.extend();
          P_PART_PRICE(i_PART_PRICE_DUP_CNT) := T_PART_PRICE_LOOP_DUP(var);
        END IF;
      END IF;
 END LOOP;

 i_PART_APPLICABLE_DUP_CNT :=0;

 FOR var IN 1 .. T_PART_APPLICABLE_LOOP_DUP.COUNT
        LOOP
          IF var                       =1 THEN
            i_PART_APPLICABLE_DUP_CNT := i_PART_APPLICABLE_DUP_CNT + 1;
            P_PART_APPLICABLE.extend();
            P_PART_APPLICABLE(i_PART_APPLICABLE_DUP_CNT) := T_PART_APPLICABLE_LOOP_DUP(var);
          ELSE
            i_part_APP_DUP_FLAG := true;
            FOR dup IN 1 .. P_PART_APPLICABLE.count
            LOOP
              IF T_PART_APPLICABLE_LOOP_DUP(var).INVENTORY_ITEM_ID = P_PART_APPLICABLE(dup).INVENTORY_ITEM_ID AND T_PART_APPLICABLE_LOOP_DUP(var).CUST_CODE = P_PART_APPLICABLE(dup).CUST_CODE AND T_PART_APPLICABLE_LOOP_DUP(var).SUPPLIER_CODE = P_PART_APPLICABLE(dup).SUPPLIER_CODE AND T_PART_APPLICABLE_LOOP_DUP(var).CUST_ID = P_PART_APPLICABLE(dup).CUST_ID AND T_PART_APPLICABLE_LOOP_DUP(var).UPQ = P_PART_APPLICABLE(dup).UPQ AND T_PART_APPLICABLE_LOOP_DUP(var).PRICE_LIST_ID = P_PART_APPLICABLE(dup).PRICE_LIST_ID THEN
                i_part_APP_DUP_FLAG                          := false;
              END IF;
            END LOOP;
            IF i_part_APP_DUP_FLAG THEN
              i_PART_APPLICABLE_DUP_CNT := i_PART_APPLICABLE_DUP_CNT + 1;
              P_PART_APPLICABLE.extend();
              P_PART_APPLICABLE(i_PART_APPLICABLE_DUP_CNT) := T_PART_APPLICABLE_LOOP_DUP(var);
            END IF;
          END IF;
        END LOOP;
      --remoeve duplicate for p_part_avail
       i_PART_AVAIL_DUP_CNT :=0;

 FOR var IN 1 .. T_PART_AVAIL_LOOP_DUP.COUNT
        LOOP
          IF var                       =1 THEN
            i_PART_AVAIL_DUP_CNT := i_PART_AVAIL_DUP_CNT + 1;
            P_PART_AVAIL.extend();
            P_PART_AVAIL(i_PART_AVAIL_DUP_CNT) := T_PART_AVAIL_LOOP_DUP(var);
          ELSE
            i_part_AVAIL_DUP_FLAG := true;
            FOR dup IN 1 .. P_PART_AVAIL.count
            LOOP
              IF T_PART_AVAIL_LOOP_DUP(var).INVENTORY_ITEM_ID = P_PART_AVAIL(dup).INVENTORY_ITEM_ID AND T_PART_AVAIL_LOOP_DUP(var).QUANTITY = P_PART_AVAIL(dup).QUANTITY AND T_PART_AVAIL_LOOP_DUP(var).LOCATION = P_PART_AVAIL(dup).LOCATION THEN
                i_part_AVAIL_DUP_FLAG                          := false;
              END IF;
            END LOOP;
            IF i_part_AVAIL_DUP_FLAG THEN
              i_PART_AVAIL_DUP_CNT := i_PART_AVAIL_DUP_CNT + 1;
              P_PART_AVAIL.extend();
              P_PART_AVAIL(i_PART_AVAIL_DUP_CNT) := T_PART_AVAIL_LOOP_DUP(var);
            END IF;
          END IF;
        END LOOP;
END GET_ITEM_PRICE_AVAIL;
--MYJIRATEST-7138 Added new procedure for calculating Inventory Item status Code for Oderable Vs Non Oderable Change Starts
PROCEDURE get_inventory_item_status_code(lp_inventory_item_id          IN VARCHAR2,
                                         P_OU_ID                       IN VARCHAR2,
                                         lp_inventory_item_status_code OUT VARCHAR2,
                                         pp_message                    OUT VARCHAR2) IS
  v_procurement_code  mtl_item_categories_v.category_concat_segs%TYPE := NULL;
  v_all_ship_a        bom_components_b.attribute5%type;
  v_all_ship_b        bom_components_b.attribute5%type;
  v_all_ship_c        bom_components_b.attribute5%type;
  v_status_cd         VARCHAR2(255);
  v_future_part       VARCHAR2(255);
  v_prime_ship        VARCHAR2(255);
  v_error_code        VARCHAR2(255) := Null;
  v_ou_tag            VARCHAR2(255) := Null;
  v_onhand_qty        mtl_onhand_quantities.transaction_quantity%type;
  v_operating_unit_id hr_operating_units.organization_id%type;
  v_validation_org_id mtl_parameters.organization_id%type;
  lp_organization_id  mtl_system_items_b.organization_id%type;
  e_exit exception;
  v_cpl_org_id ORG_ORGANIZATION_DEFINITIONS.ORGANIZATION_CODE%type; /*Added by Capgemini OWMS Team for MyGE Changes*/
  v_sdc_org_id ORG_ORGANIZATION_DEFINITIONS.ORGANIZATION_CODE%type; /*Added by Capgemini OWMS Team for MyGE Changes*/
  v_erl_org_id ORG_ORGANIZATION_DEFINITIONS.ORGANIZATION_CODE%type; /*Added by Capgemini OWMS Team for MyGE Changes*/
  v_item_source                VARCHAR2(10); -- Added for OWMS Implementation US192483/US192484
  v_item_number                VARCHAR2(30); -- Added for OWMS Implementation US192483/US192484
  CURSOR ship_codes(p_organization_id NUMBER, p_inventory_item_id NUMBER) IS
    SELECT distinct cmp.attribute5 shippability_code
      FROM bom_structures_b bom, bom_components_b cmp
     WHERE bom.bill_sequence_id = cmp.bill_sequence_id
       AND SYSDATE BETWEEN cmp.effectivity_date AND
           NVL(cmp.disable_date, SYSDATE)
       AND bom.attribute12 = v_ou_tag
       AND bom.organization_id = v_validation_org_id
       AND cmp.component_item_id = lp_inventory_item_id;
BEGIN
  /*Added by Capgemini OWMS Team for MyGE Changes*/
  BEGIN
    SELECT ORGANIZATION_ID
      INTO v_cpl_org_id
      FROM ORG_ORGANIZATION_DEFINITIONS
     WHERE ORGANIZATION_CODE = 'CPL';
  EXCEPTION
    WHEN OTHERS THEN
    v_cpl_org_id:= 0;
  END;
--Added by OWMS Team : START
  BEGIN
    SELECT ORGANIZATION_ID
      INTO v_erl_org_id
      FROM ORG_ORGANIZATION_DEFINITIONS
     WHERE ORGANIZATION_CODE = 'ERL';
  EXCEPTION
    WHEN OTHERS THEN
    v_erl_org_id:= 0;
  END;
--Added by OWMS Team : END
  BEGIN
    SELECT ORGANIZATION_ID
      INTO v_sdc_org_id
      FROM ORG_ORGANIZATION_DEFINITIONS
     WHERE ORGANIZATION_CODE = 'SDC';
  EXCEPTION
    WHEN OTHERS THEN
    v_sdc_org_id:= 0;
  END;
  /*Added by Capgemini OWMS Team for MyGE Changes*/
  BEGIN
    --Fetching Operating Unit Code
    SELECT tag
      INTO v_ou_tag
      FROM fnd_lookup_values
     WHERE lookup_type = 'GEAE_MYGE_OPERATING_UNITS'
       AND enabled_flag = 'Y'
       AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(start_date_active, SYSDATE)) AND
           TRUNC(NVL(end_date_active, SYSDATE))
       AND lookup_code = P_OU_ID;
  Exception
    When Others then
      v_error_code := '8066';
      RAISE e_exit;
  End; --Fetching Operating Unit Code
  BEGIN
    --Fetching Organization ID and Org Code
    SELECT msib.organization_id, ood.operating_unit
      INTO lp_organization_id, v_operating_unit_id
      FROM mtl_system_items_b           msib,
           org_organization_definitions ood,
           fnd_lookup_values            flv
     WHERE msib.organization_id = ood.organization_id
       AND ood.organization_code = flv.attribute1
       AND msib.item_type NOT IN ('OC')
       AND inventory_item_id = lp_inventory_item_id
       AND flv.lookup_type = 'GEAE_MYGE_SUPPLIER_ORGS'
       AND flv.enabled_flag = 'Y'
       AND flv.attribute3 = '1'
       AND TRUNC(SYSDATE) BETWEEN
           TRUNC(NVL(flv.start_date_active, SYSDATE)) AND
           TRUNC(NVL(flv.end_date_active, SYSDATE))
       AND flv.description = P_OU_ID;
    v_validation_org_id := oe_sys_parameters.VALUE('MASTER_ORGANIZATION_ID',
                                                   v_operating_unit_id);
  Exception
    When Others then
      v_error_code := '8066';
      RAISE e_exit;
  End; --Fetching Organization ID and Org Code
  v_all_ship_a  := '-1';
  v_all_ship_b  := '-1';
  v_all_ship_c  := '-1';
  v_future_part := '-1';
  v_status_cd   := 'Ltd-Usage';
  -- r_foxt_data_stg.attribute12 := 'ALL-SHIPPABLE-OTHERS';
  v_onhand_qty       := 0;
  v_procurement_code := NULL;
  FOR sel_model_ship_codes IN ship_codes(to_number(v_validation_org_id),
                                         to_number(lp_inventory_item_id)) loop
--    fnd_file.put_line(fnd_file.log,'Shipability code:' ||sel_model_ship_codes.shippability_code);
    IF sel_model_ship_codes.shippability_code = 'A' -- AND v_all_ship_a <> 'N'  --Commented for Aero AMPS Nov-13 Release Scenario 3
     THEN
      v_all_ship_a  := 'Y';
      v_all_ship_b  := 'N';
      v_all_ship_c  := 'N';
      v_future_part := 'N';
    ELSIF sel_model_ship_codes.shippability_code = 'B' AND
          v_all_ship_b <> 'N' THEN
      v_all_ship_b  := 'Y';
      v_all_ship_a  := 'N';
      v_all_ship_c  := 'N';
      v_future_part := 'N';
    ELSIF sel_model_ship_codes.shippability_code = 'C' AND
          v_all_ship_c <> 'N' THEN
      v_all_ship_c  := 'Y';
      v_all_ship_a  := 'N';
      v_all_ship_b  := 'N';
      v_future_part := 'N';
    ELSIF sel_model_ship_codes.shippability_code IN ('1', '2') AND
          v_future_part <> 'N' --Removed "4" for AeroAMPS Nov-13 release Scenario 1
     THEN
      v_future_part := 'Y';
      v_all_ship_a  := 'N';
      v_all_ship_b  := 'N';
      v_all_ship_c  := 'N';
    ELSIF sel_model_ship_codes.shippability_code IN ('X', 'Y', '3', '4') --Added "4" for AeroAMPS Nov-13 release Scenario 2
     THEN
      v_prime_ship  := 'Y';
      v_all_ship_a  := 'N';
      v_all_ship_b  := 'N';
      v_all_ship_c  := 'N';
      v_future_part := 'N';
    ELSE
      v_all_ship_a  := 'N';
      v_all_ship_b  := 'N';
      v_all_ship_c  := 'N';
      v_future_part := 'N';
    END IF;
  END LOOP;
  --fnd_file.put_line(fnd_file.LOG, 'v_prime_ship:' || v_prime_ship);
  v_procurement_code := geae_inv_amps_common_utils_pkg.get_category_value(p_organization_id   => to_number(lp_organization_id),
                                                                          p_inventory_item_id => to_number(lp_inventory_item_id),
                                                                          p_category_set_name => 'Procurement Code');
  --r_foxt_data_stg.attribute13 := v_procurement_code;
  --fnd_file.put_line(fnd_file.LOG,'v_procurement_code:' || v_procurement_code);
  IF v_prime_ship = 'Y' AND v_procurement_code = 'X' THEN
    v_status_cd := 'Active';
    --  r_foxt_data_stg.attribute12 := 'SHIP-X-Y-3-4-AND-PRIMESHIP';  --Added "4" for AeroAMPS Nov-13 release Scenario 2
    /*Added for AeroAMPS Nov-13 release Scenario 2*/
  ELSIF v_prime_ship = 'Y' AND v_procurement_code = 'V' THEN
    /*Added by Capgemini OWMS Team for MyGE Changes*/
   IF v_cpl_org_id = lp_organization_id OR v_sdc_org_id = lp_organization_id THEN
--Added by OWMS Team : START
  	SELECT NVL((b.qty-c.qty),0) QTY
			   INTO v_onhand_qty
		FROM (SELECT NVL(SUM(MOQ.TRANSACTION_QUANTITY),0) qty
				FROM GEAE_INV_MTL_ONHANDS_V MOQ
			   WHERE INVENTORY_ITEM_ID = to_number(lp_inventory_item_id)
        AND SUBINVENTORY_CODE IN ('STOCK','STG')
				 AND ORGANIZATION_ID = to_number(lp_organization_id)
			) b,
		 (SELECT NVL(SUM(RESERVATION_QUANTITY),0) qty
					 FROM MTL_RESERVATIONS
			 WHERE INVENTORY_ITEM_ID = to_number(lp_inventory_item_id)
				 AND ORGANIZATION_ID = to_number(lp_organization_id)
			) C ;
		---- OWMS team Changes for DE25546 : End
    ELSIF v_erl_org_id = lp_organization_id THEN
          SELECT NVL((A.QTY - B.QTY),0)  QTY
       		   INTO v_onhand_qty
            FROM (SELECT (geae_wms_total_onhand_erl_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
			geae_wms_total_pick_release(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
			 FROM apps.mtl_system_items_b msib,
			      apps.mtl_parameters mp
			 WHERE 1 = 1
			   and msib.inventory_item_id = to_number(lp_inventory_item_id)
			   and msib.organization_id = mp.organization_id
			   and mp.organization_id = to_number(lp_organization_id)) A,
                 (SELECT (geae_wms_resv_qty_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
			geae_wms_total_resv(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
			 FROM apps.mtl_system_items_b msib,
			      apps.mtl_parameters mp
			 WHERE 1 = 1
			   and msib.inventory_item_id = to_number(lp_inventory_item_id)
			   and msib.organization_id = mp.organization_id
			   and mp.organization_id = to_number(lp_organization_id)) B;
--Added by OWMS Team : END
    ELSE
    /*Added by Capgemini OWMS Team for MyGE Changes*/
    SELECT nvl(sum(transaction_quantity), 0)
      INTO v_onhand_qty
      FROM GEAE_INV_MTL_ONHANDS_V moq
     WHERE moq.inventory_item_id = to_number(lp_inventory_item_id)
       AND moq.organization_id = to_number(lp_organization_id);
    /*Added by Capgemini OWMS Team for MyGE Changes*/
    END IF;
    /*Added by Capgemini OWMS Team for MyGE Changes*/
    IF v_onhand_qty = 0 THEN
      v_status_cd := 'Ltd-Usage';
    END IF;
    /*Added for AeroAMPS Nov-13 release*/
  ELSIF v_all_ship_b = 'Y' THEN
    v_status_cd := 'Rework';
    -- r_foxt_data_stg.attribute12 := 'ALL-SHIPPABLE-B';
  ELSIF v_all_ship_c = 'Y' THEN
    v_status_cd := 'Obsolete';
    -- r_foxt_data_stg.attribute12 := 'ALL-SHIPPABLE-C';
  ELSIF v_future_part = 'Y' THEN
    v_status_cd := 'DO-NOT-SEND';
    --  r_foxt_data_stg.attribute12 := 'FUTURE-1-2'; --Removed '4' for Nov-13 Release
  ELSIF v_all_ship_a = 'Y' THEN
    /* SELECT  nvl(max('SDC'),'NON-SDC')
    INTO  v_prt_src_cd
    FROM  mtl_system_items_b msib,
    mtl_parameters mp
                     WHERE  msib.inventory_item_id = to_number(lp_inventory_item_id)
     AND  msib.organization_id = mp.organization_id
     AND  mp.organization_code = g_sdc_org_code;*/
    /*Added by Capgemini OWMS Team for MyGE Changes*/
   IF v_cpl_org_id = lp_organization_id OR v_sdc_org_id = lp_organization_id THEN
--Added by OWMS Team : START
  	SELECT NVL((b.qty-c.qty),0) QTY
			   INTO v_onhand_qty
		FROM (SELECT NVL(SUM(MOQ.TRANSACTION_QUANTITY),0) qty
				FROM GEAE_INV_MTL_ONHANDS_V MOQ
			   WHERE INVENTORY_ITEM_ID = to_number(lp_inventory_item_id)
         AND SUBINVENTORY_CODE IN ('STOCK','STG')
				 AND ORGANIZATION_ID = to_number(lp_organization_id)
			) b,
		 (SELECT NVL(SUM(RESERVATION_QUANTITY),0) qty
					 FROM MTL_RESERVATIONS
			 WHERE INVENTORY_ITEM_ID = to_number(lp_inventory_item_id)
				 AND ORGANIZATION_ID = to_number(lp_organization_id)
			) C ;
    ELSIF v_erl_org_id = lp_organization_id THEN
          SELECT NVL((A.QTY - B.QTY),0)  QTY
       		   INTO v_onhand_qty
            FROM (SELECT (geae_wms_total_onhand_erl_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
			geae_wms_total_pick_release(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
			 FROM apps.mtl_system_items_b msib,
			      apps.mtl_parameters mp
			 WHERE 1 = 1
			   and msib.inventory_item_id = to_number(lp_inventory_item_id)
			   and msib.organization_id = mp.organization_id
			   and mp.organization_id = to_number(lp_organization_id)) A,
                 (SELECT (geae_wms_resv_qty_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
			geae_wms_total_resv(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
			 FROM apps.mtl_system_items_b msib,
			      apps.mtl_parameters mp
			 WHERE 1 = 1
			   and msib.inventory_item_id = to_number(lp_inventory_item_id)
			   and msib.organization_id = mp.organization_id
			   and mp.organization_id = to_number(lp_organization_id)) B;
--Added by OWMS Team : END
	ELSE
    /*Added by Capgemini OWMS Team for MyGE Changes*/
    SELECT nvl(sum(transaction_quantity), 0)
      INTO v_onhand_qty
      FROM GEAE_INV_MTL_ONHANDS_V moq
     WHERE moq.inventory_item_id = to_number(lp_inventory_item_id)
       AND moq.organization_id = to_number(lp_organization_id);
    /*Added by Capgemini OWMS Team for MyGE Changes*/
    END IF;
       /*Added by Capgemini OWMS Team for MyGE Changes*/
    --END IF;
    --  fnd_file.put_line(fnd_file.log,'10  on hand qty before if  -> :'||v_onhand_qty);
    IF v_onhand_qty > 0 THEN
      --   r_foxt_data_stg.attribute12 := 'ALL-SHIPPABLE-A-WITH-ONHAND';
      v_status_cd := 'Active';
      -- fnd_file.put_line(fnd_file.log,'20  SHIPPABLE-A-WITH-ONHAND  -> :'||r_foxt_data_stg.attribute12);
      --   r_foxt_data_stg.attribute12 := 'ALL-SHIPPABLE-A-WITHOUT-ONHAND';
      --fnd_file.put_line(fnd_file.log,'30  SHIPPABLE-A-WITHOUT-ONHAND -> :'||r_foxt_data_stg.attribute12);
    end if;
    /*Added for AeroAMPS Nov-13 release Scenario 4 Anything with Inventory in fndderlanger /with out Inventory in erlanger*/
  END IF;
  IF v_status_cd = 'Ltd-Usage' THEN
   IF v_cpl_org_id = lp_organization_id OR v_sdc_org_id = lp_organization_id THEN
--Added by OWMS Team : START
  	SELECT NVL((b.qty-c.qty),0) QTY
			   INTO v_onhand_qty
		FROM (SELECT NVL(SUM(MOQ.TRANSACTION_QUANTITY),0) qty
				FROM GEAE_INV_MTL_ONHANDS_V MOQ
			   WHERE INVENTORY_ITEM_ID = to_number(lp_inventory_item_id)
         AND SUBINVENTORY_CODE IN ('STOCK','STG')
				 AND ORGANIZATION_ID = to_number(lp_organization_id)
			) b,
		 (SELECT NVL(SUM(RESERVATION_QUANTITY),0) qty
					 FROM MTL_RESERVATIONS
			 WHERE INVENTORY_ITEM_ID = to_number(lp_inventory_item_id)
				 AND ORGANIZATION_ID = to_number(lp_organization_id)
			) C ;
		---- OWMS team Changes for DE25546 : End
    ELSIF v_erl_org_id = lp_organization_id THEN
          SELECT NVL((A.QTY - B.QTY),0)  QTY
       		   INTO v_onhand_qty
            FROM (SELECT (geae_wms_total_onhand_erl_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
			geae_wms_total_pick_release(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
			 FROM apps.mtl_system_items_b msib,
			      apps.mtl_parameters mp
			 WHERE 1 = 1
			   and msib.inventory_item_id = to_number(lp_inventory_item_id)
			   and msib.organization_id = mp.organization_id
			   and mp.organization_id = to_number(lp_organization_id)) A,
                 (SELECT (geae_wms_resv_qty_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
			geae_wms_total_resv(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
			 FROM apps.mtl_system_items_b msib,
			      apps.mtl_parameters mp
			 WHERE 1 = 1
			   and msib.inventory_item_id = to_number(lp_inventory_item_id)
			   and msib.organization_id = mp.organization_id
			   and mp.organization_id = to_number(lp_organization_id)) B;
--Added by OWMS Team : End
    /*Added by Capgemini OWMS Team for MyGE Changes*/
	ELSE
    SELECT nvl(sum(transaction_quantity), 0)
      INTO v_onhand_qty
      FROM GEAE_INV_MTL_ONHANDS_V moq
     WHERE moq.inventory_item_id = to_number(lp_inventory_item_id)
       AND moq.organization_id = to_number(lp_organization_id);
    /*Added by Capgemini OWMS Team for MyGE Changes*/
    END IF;
       /*Added by Capgemini OWMS Team for MyGE Changes*/
    /*Added by Capgemini OWMS Team for MyGE Changes*/
    IF v_onhand_qty > 0 THEN
      v_status_cd := 'Active';
    END IF;
    /*Added for AeroAMPS Nov-13 release Scenario 4 Anything with Inventory in erlanger /with out Inventory in erlanger*/
  END IF;
  IF v_status_cd = 'Active' THEN
    lp_inventory_item_status_code := 'Y';
  ELSIF v_status_cd = 'DO-NOT-SEND' THEN
    lp_inventory_item_status_code := 'D';
  ELSE
    lp_inventory_item_status_code := 'N';
  END IF;
  --  fnd_file.put_line(fnd_file.LOG,'inv_item_status onhand_qty - '||r_foxt_data_stg.onhand_qty );
  --  fnd_file.put_line(fnd_file.log,'attribute12 after item status:'|| r_foxt_data_stg.attribute12);
EXCEPTION
  WHEN e_exit THEN
    SELECT LOOKUP_CODE || ': ' || DESCRIPTION
      INTO pp_message
      FROM fnd_lookup_values
     WHERE LOOKUP_TYPE = 'GEAE_MYGE_ERROR_CODES'
       AND UPPER(LOOKUP_CODE) = v_error_code;
END get_inventory_item_status_code;
--MYJIRATEST-7138 Added new procedure for calculating Inventory Item status Code for Oderable Vs Non Oderable Change Ends
PROCEDURE GET_PRICE(
    P_SSO               VARCHAR2,
    P_OU_ID             VARCHAR2,
    P_INVENTORY_ITEM_ID NUMBER,
    P_PRICE_LIST_ID     NUMBER,
    P_UNIT_PRICE OUT NUMBER,
    P_LIST_LINE_ID OUT NUMBER )
AS
  --
  p_line_tbl QP_PREQ_GRP.LINE_TBL_TYPE;
  p_qual_tbl QP_PREQ_GRP.QUAL_TBL_TYPE;
  p_line_attr_tbl QP_PREQ_GRP.LINE_ATTR_TBL_TYPE;
  p_LINE_DETAIL_tbl QP_PREQ_GRP.LINE_DETAIL_TBL_TYPE;
  p_LINE_DETAIL_qual_tbl QP_PREQ_GRP.LINE_DETAIL_QUAL_TBL_TYPE;
  p_LINE_DETAIL_attr_tbl QP_PREQ_GRP.LINE_DETAIL_ATTR_TBL_TYPE;
  p_related_lines_tbl QP_PREQ_GRP.RELATED_LINES_TBL_TYPE;
  p_control_rec QP_PREQ_GRP.CONTROL_RECORD_TYPE;
  x_line_tbl QP_PREQ_GRP.LINE_TBL_TYPE;
  x_line_qual QP_PREQ_GRP.QUAL_TBL_TYPE;
  x_line_attr_tbl QP_PREQ_GRP.LINE_ATTR_TBL_TYPE;
  x_line_detail_tbl QP_PREQ_GRP.LINE_DETAIL_TBL_TYPE;
  x_line_detail_qual_tbl QP_PREQ_GRP.LINE_DETAIL_QUAL_TBL_TYPE;
  x_line_detail_attr_tbl QP_PREQ_GRP.LINE_DETAIL_ATTR_TBL_TYPE;
  x_related_lines_tbl QP_PREQ_GRP.RELATED_LINES_TBL_TYPE;
  x_return_status      VARCHAR2(240);
  x_return_status_text VARCHAR2(240);
  qual_rec QP_PREQ_GRP.QUAL_REC_TYPE;
  line_attr_rec QP_PREQ_GRP.LINE_ATTR_REC_TYPE;
  line_rec QP_PREQ_GRP.LINE_REC_TYPE;
  detail_rec QP_PREQ_GRP.LINE_DETAIL_REC_TYPE;
  ldet_rec QP_PREQ_GRP.LINE_DETAIL_REC_TYPE;
  rltd_rec QP_PREQ_GRP.RELATED_LINES_REC_TYPE;
  l_pricing_contexts_Tbl QP_Attr_Mapping_PUB.Contexts_Result_Tbl_Type;
  l_qualifier_contexts_Tbl QP_Attr_Mapping_PUB.Contexts_Result_Tbl_Type;
  v_line_tbl_cnt INTEGER;
  I BINARY_INTEGER;
  J BINARY_INTEGER;
  l_version  VARCHAR2(240);
  --L_File_Val Varchar2(60);
  V_User_Id Number := Null;
  V_Resp_Id Number := Null;
  v_RESP_APPL_ID Number := Null;
  v_app_short_name VARCHAR2(10);
BEGIN
  --oe_debug_pub.debug_on;
  --oe_debug_pub.initialize;
  --l_file_val := OE_DEBUG_PUB.Set_Debug_Mode('FILE');
  --OE_DEBUG_PUB.SETDEBUGLEVEL(5);
 -- QP_Attr_Mapping_PUB.Build_Contexts(p_request_type_code => 'ONT', p_pricing_type => 'L', x_price_contexts_result_tbl => l_pricing_contexts_Tbl, x_qual_contexts_result_tbl => l_qualifier_Contexts_Tbl);
  v_line_tbl_cnt := 1;
  ---- Control Record
  p_control_rec.pricing_event            := 'LINE'; -- 'BATCH'; LINE
  p_control_rec.calculate_flag           := 'Y';     --QP_PREQ_GRP.G_SEARCH_N_CALCULATE;
  p_control_rec.simulation_flag          := 'N';
  p_control_rec.rounding_flag            := 'Q';
  p_control_Rec.manual_discount_flag     := 'Y';
  p_control_rec.request_type_code        := 'ONT';
  p_control_rec.TEMP_TABLE_INSERT_FLAG   := 'Y';
  p_control_rec.source_order_amount_flag := 'Y';
  -------------------------
  ---- Line Records ---------
  line_rec.request_type_code := 'ONT';
  --line_rec.line_id := 2125125; -- Order Line Id. This can be any thing for this script
  line_rec.line_Index              := '1';       -- Request Line Index
  line_rec.line_type_code          := 'LINE';    -- LINE or ORDER(Summary Line)
  line_rec.pricing_effective_date  := SYSDATE;   -- Pricing as of what date ?
  line_rec.active_date_first       := SYSDATE;   -- Can be Ordered Date or Ship Date
  line_rec.active_date_second      := SYSDATE;   -- Can be Ordered Date or Ship Date
  line_rec.active_date_first_type  := 'NO TYPE'; -- ORD/SHIP
  line_rec.active_date_second_type := 'NO TYPE'; -- ORD/SHIP
  line_rec.line_quantity           := 1;         -- Ordered Quantity
  line_rec.line_uom_code           := 'EA';      -- Ordered UOM Code
  line_rec.currency_code           := 'USD';     -- Currency Code
  line_rec.price_flag              := 'Y';       -- Price Flag can have 'Y' , 'N'(No pricing) , 'P'(Phase)
  p_line_tbl(1)                    := line_rec;
  ---- Line Attribute Record
  line_attr_rec.LINE_INDEX              := 1;
  line_attr_rec.PRICING_CONTEXT         := 'ITEM'; --
  line_attr_rec.PRICING_ATTRIBUTE       := 'PRICING_ATTRIBUTE3';
  line_attr_rec.PRICING_ATTR_VALUE_FROM := 'ALL';
  line_attr_rec.VALIDATED_FLAG          := 'N';
  p_line_attr_tbl(1)                    := line_attr_rec;
  line_attr_rec.LINE_INDEX              := 1;
  line_attr_rec.PRICING_CONTEXT         := 'ITEM'; --
  line_attr_rec.PRICING_ATTRIBUTE       := 'PRICING_ATTRIBUTE1';
  line_attr_rec.PRICING_ATTR_VALUE_FROM := TO_CHAR(P_INVENTORY_ITEM_ID); -- INVENTORY ITEM ID
  line_attr_rec.VALIDATED_FLAG          := 'N';
  p_line_attr_tbl(2)                    := line_attr_rec;
  ---- Qualifier Attribute Record
  qual_rec.LINE_INDEX                := 1; -- Attributes for the above line. Attributes are attached with the line index
  qual_rec.QUALIFIER_CONTEXT         := 'MODLIST';
  qual_rec.QUALIFIER_ATTRIBUTE       := 'QUALIFIER_ATTRIBUTE4';
  qual_rec.QUALIFIER_ATTR_VALUE_FROM := TO_CHAR(P_PRICE_LIST_ID); -- PRICE LIST ID;
  qual_rec.COMPARISON_OPERATOR_CODE  := '=';
  qual_rec.VALIDATED_FLAG            := 'Y';
  p_qual_tbl(1)                      := qual_rec;
  --
 -- FND_GLOBAL.APPS_INITIALIZE(USER_ID => 43867, RESP_ID => 54274, RESP_APPL_ID => 660);
  --
  Begin
    Select User_Id
      into V_User_Id
     From Fnd_User
    Where 1 = 1
    And  User_Name = P_Sso;
   Exception
     when OTHERS THEN
     V_User_Id := Null;
  End;
  --MYJIRATEST-3512 Ravi S 18-NOV-2014
  IF V_User_Id IS NULL THEN
     BEGIN
        SELECT usr.user_id
          INTO V_User_Id
          FROM fnd_user usr, fnd_lookup_values dflt
         WHERE dflt.lookup_type = 'GEAE_MYGE_DEFAULT_LOGIN'
           AND dflt.enabled_flag = 'Y'
           AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(dflt.start_date_active,SYSDATE)) AND TRUNC(NVL(dflt.end_date_active,SYSDATE))
           AND dflt.lookup_code = P_OU_ID
           AND dflt.description = usr.user_name;
     EXCEPTION
        WHEN OTHERS THEN
           V_User_Id := Null;
     END;
  END IF;
--
--
   Begin
    Select frt.Responsibility_Id
          ,fa.Application_Id
          ,fa.application_short_name
      Into V_Resp_Id
           ,V_Resp_Appl_Id
           ,v_app_short_name
     From Fnd_Responsibility_Tl  Frt
         ,Fnd_Lookup_Values Flv
         ,Hr_Operating_Units Hru
         ,fnd_application fa
      Where 1 = 1
       and frt.language = 'US'
       and frt.responsibility_name = flv.description
       And flv.meaning = hru.name
       And flv.lookup_type = 'GEAE_MYGE_PRICE_RESPONSIBILITY'
       and fa.application_id = frt.application_id
       And Hru.Organization_Id = To_Number(P_Ou_Id);
      Exception
        When Others Then
        V_Resp_Id := Null;
        V_Resp_Appl_Id := NULL;
   END;
--
--  APPS INTIALIZE
 FND_GLOBAL.APPS_INITIALIZE(USER_ID => V_User_Id, RESP_ID => V_Resp_Id, RESP_APPL_ID => V_Resp_Appl_Id);
 MO_GLOBAL.SET_POLICY_CONTEXT('S', P_OU_ID);
 MO_GLOBAL.INIT(v_app_short_name);
--
  QP_PREQ_PUB.PRICE_REQUEST(p_line_tbl, p_qual_tbl, p_line_attr_tbl, p_line_detail_tbl, p_line_detail_qual_tbl, p_line_detail_attr_tbl, p_related_lines_tbl, p_control_rec, x_line_tbl, x_line_qual, x_line_attr_tbl, x_line_detail_tbl, x_line_detail_qual_tbl, x_line_detail_attr_tbl, x_related_lines_tbl, x_return_status, x_return_status_text);
  I    := X_LINE_TBL.first;
  IF I IS NOT NULL THEN
    LOOP
      EXIT
    WHEN I = X_LINE_TBL.LAST;
      I   := x_line_tbl.NEXT(I);
    END LOOP;
  END IF;
  J    := x_line_detail_tbl.FIRST;
  IF J IS NOT NULL THEN
    LOOP
      Exit
    When X_Line_Detail_Tbl(J).List_Line_Type_Code = 'PLL';
    --J = X_Line_Detail_Tbl.Last;
      J   := x_line_detail_tbl.NEXT(J);
    END LOOP;
  end if;
  If I               Is Not Null Then
    P_UNIT_PRICE     := X_LINE_TBL(I).UNIT_PRICE;
    IF J             IS NOT NULL THEN
      P_List_Line_Id := X_Line_Detail_Tbl(J).List_Line_Id;
    ELSE
      P_LIST_LINE_ID := NULL;
      P_UNIT_PRICE   := NULL;
    END IF;
  ELSE
    P_UNIT_PRICE   := NULL;
    P_LIST_LINE_ID := NULL;
  END IF;
End Get_Price;
FUNCTION GET_PRICE_LIST_NAME(P_PRICE_LIST_ID     NUMBER)
     RETURN VARCHAR2
AS
   L_PRICE_LIST_NAME VARCHAR2(240);
BEGIN
   BEGIN
      SELECT DESCRIPTION
        INTO L_PRICE_LIST_NAME
        FROM fnd_lookup_values
       WHERE lookup_type = 'GEAE_MYGE_PRICE_LIST_NAME'
         AND lookup_code = P_PRICE_LIST_ID;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         SELECT NAME
           INTO L_PRICE_LIST_NAME
           FROM qp_list_headers_tl
          WHERE list_header_id = P_PRICE_LIST_ID;
   END;
   RETURN L_PRICE_LIST_NAME;
EXCEPTION
   WHEN OTHERS THEN
      RETURN NULL;
END GET_PRICE_LIST_NAME;
PROCEDURE GET_KIT_STRUCTURE(
    P_SSO       VARCHAR2,
    P_IACO_CODE VARCHAR2,
    P_CUST_ID V_CUST_ID_ARRAY,
    P_ROLE    VARCHAR2,
    P_OU_ID   VARCHAR2,
    P_ITEM_ID NUMBER,
    P_KIT_HDR_DTL OUT V_KIT_HDR_INFO_ARRAY,
    P_KIT_COMP_DTL OUT V_KIT_COMP_INFO_ARRAY,
    P_MSG OUT VARCHAR2
)
AS
   CURSOR C_EXPL(P_ITEM_ID NUMBER) IS
      SELECT msib.segment1 part_number, msib.description part_description, bcb.attribute6 default_value, bet.*
        FROM bom_explosion_temp bet, mtl_system_items_b msib, bom_components_b bcb
       WHERE bet.top_item_id = P_ITEM_ID
         AND bet.component_item_id = msib.inventory_item_id
         AND bet.organization_id = msib.organization_id
         AND bet.component_item_id = bcb.component_item_id(+)
         AND bet.component_sequence_id  = bcb.component_sequence_id(+)
         AND NVL(bcb.disable_date,TRUNC(SYSDATE+1)) >= TRUNC(SYSDATE)
      ORDER BY bet.sort_order;
   l_cfg_hdr_id NUMBER;
   l_part_details V_PART_DETAILS;
   l_part_avail V_PART_AVAIL;
   l_part_price V_PART_PRICE;
   l_part_applicable V_PART_APPLICABLE;
   l_message VARCHAR2(500);
   l_avail_message VARCHAR2(500);
   l_price_message VARCHAR2(500);
   l_kit_ind VARCHAR2(1);
   l_user_id NUMBER;
   l_resp_id NUMBER;
   l_app_id NUMBER;
   l_loc_msg VARCHAR2(100);
   l_config_err VARCHAR2(500);
   l_comp_count NUMBER;
   l_hdr_count NUMBER;
   l_comp_level VARCHAR2(100);
   l_comp_avail NUMBER;
   l_kit_avail NUMBER;
   l_kit_price NUMBER;
   l_unit_price NUMBER;
   l_sum_price NUMBER;
   l_list_line_id NUMBER;
   l_ext_price NUMBER;
   l_kit_message VARCHAR2(500);
   l_kit_pr_er_cd NUMBER;
   l_exploded VARCHAR2(1);
   l_one_indent VARCHAR2(20) := '     ';
   l_indent VARCHAR2(50);
   l_null_avail NUMBER;
   l_price_list_id NUMBER;
   l_config_exists NUMBER;
   e_exit EXCEPTION;
   l_part_discounts V_PART_DISCOUNTS;
   l_discount_message VARCHAR2(100);
   l_critical_part VARCHAR2(10);
   l_part_bom V_PART_BOM; --MYJIRATEST-6272 Ravi S 03-MAR-2015
   l_ISODERABLE VARCHAR2(1);--MYJIRATEST-7138 24-MAR-2015   Abhinav Srivastava Oderable Vs Non Oderable changes
  v_item_source                VARCHAR2(500); -- Added for OWMS Implementation US192483/US192484
  v_er1_source VARCHAR2(500); -- Added for OWMS Implementation US192483/US192484
  v_er2_source VARCHAR2(500); -- Added for OWMS Implementation US192483/US192484
  v_er3_source VARCHAR2(500); -- Added for OWMS Implementation US192483/US192484
  v_item_number                VARCHAR2(30); -- Added for OWMS Implementation US192483/US192484
BEGIN
   l_loc_msg := ' Getting user ID ';
   SELECT USER_ID INTO l_user_id
     FROM FND_USER
    WHERE USER_NAME=P_SSO;
   l_loc_msg := ' Fetching responsibility and application for kit explosion ';
   SELECT RESP.RESPONSIBILITY_ID,RESP.APPLICATION_ID
     INTO l_resp_id,l_app_id
     FROM FND_RESPONSIBILITY_TL RESP,
          FND_LOOKUP_VALUES FLV,
          HR_OPERATING_UNITS HOU
    WHERE HOU.NAME = FLV.MEANING
      AND RESP.RESPONSIBILITY_NAME = FLV.DESCRIPTION
      AND HOU.ORGANIZATION_ID = P_OU_ID
      AND FLV.LOOKUP_TYPE = 'GEAE_MYGE_ORDER_RESPONSIBILITY';
   SELECT COUNT(1)
     INTO l_config_exists
     FROM bom_explosion_temp bet, mtl_system_items_b msib, bom_components_b bcb
    WHERE bet.top_item_id = P_ITEM_ID
      AND bet.component_item_id = msib.inventory_item_id
      AND bet.organization_id = msib.organization_id
      AND bet.component_item_id = bcb.component_item_id(+)
      AND bet.component_sequence_id  = bcb.component_sequence_id(+)
      AND NVL(bcb.disable_date,TRUNC(SYSDATE+1)) >= TRUNC(SYSDATE);
   IF l_config_exists = 0 THEN
      l_loc_msg := ' Calling CREATE_KIT_CONFIG ';
      GEAE_MYGE_CART_PKG.CREATE_KIT_CONFIG(l_user_id,l_app_id,l_resp_id,P_ITEM_ID,1,'N',l_cfg_hdr_id,l_config_err); --MYJIRATEST-3512 Ravi S 18-NOV-2014
      IF l_config_err IS NOT NULL THEN
         P_MSG := 'Error in CREATE_KIT_CONFIG '||l_config_err;
         RAISE e_exit;
      END IF;
   END IF;
   l_loc_msg := ' Initializing Output VARRAYS ';
   l_comp_count := 0;
   l_hdr_count := 0;
   P_KIT_HDR_DTL := V_KIT_HDR_INFO_ARRAY();
   P_KIT_COMP_DTL := V_KIT_COMP_INFO_ARRAY();
   l_exploded := 'N';
   l_loc_msg := ' Calling cursor C_EXPL ';
   FOR r_expl IN C_EXPL(P_ITEM_ID) LOOP
      l_exploded := 'Y';
      IF r_expl.assembly_item_id IS NULL THEN
         l_hdr_count := l_hdr_count + 1;
         P_KIT_HDR_DTL.EXTEND(1);
         l_loc_msg := ' Assignment to P_KIT_HDR_DTL '||l_hdr_count||' ';
         P_KIT_HDR_DTL(l_hdr_count) := V_KIT_HDR_INFO_BO(r_expl.part_number,r_expl.part_description,NULL,NULL,NULL,NULL,r_expl.component_item_id,l_hdr_count);
      ELSE
         l_comp_count := l_comp_count + 1;
         P_KIT_COMP_DTL.EXTEND(1);
         l_loc_msg := ' Assignment to P_KIT_COMP_DTL '||l_comp_count||' ';
         P_KIT_COMP_DTL(l_comp_count) := V_KIT_COMP_INFO_BO(NULL,r_expl.part_number,r_expl.part_description,r_expl.component_quantity,NULL,NULL,NULL,NULL,r_expl.default_value,r_expl.sort_order,r_expl.component_item_id,r_expl.assembly_item_id,r_expl.top_item_id,l_comp_count,r_expl.plan_level,r_expl.bom_item_type);
      END IF;
   END LOOP;
   IF l_exploded = 'N' THEN
      P_MSG := 'The KIT could not be exploded';
      RAISE e_exit;
   END IF;
   l_loc_msg := ' Start logic for COMP_LEVEL ';
   FOR r_level IN (SELECT *
                     FROM TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY))
                    WHERE comp_level IS NULL
                   ORDER BY row_num) LOOP
      IF r_level.assembly_item_id = P_ITEM_ID THEN
         l_loc_msg := ' Assigning COMP_LEVEL for top level ';
         SELECT TO_CHAR(MAX(NVL(TO_NUMBER(comp_level),0))+1)
           INTO l_comp_level
           FROM TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY))
          WHERE assembly_item_id = P_ITEM_ID;
      ELSE
         l_loc_msg := ' Assigning COMP_LEVEL for lower level ';
         SELECT parent.comp_level||'.'||TO_CHAR(MAX(NVL(TO_NUMBER(SUBSTR(child.comp_level,INSTR(child.comp_level,parent.comp_level)+2)),0))+1)
           INTO l_comp_level
           FROM TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY)) parent,
                TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY)) child
          WHERE parent.component_item_id = child.assembly_item_id
            AND child.component_item_id = r_level.component_item_id
         GROUP BY parent.comp_level;
      END IF;
      l_loc_msg := ' Assignment to P_KIT_COMP_DTL '||r_level.row_num||' for comp_level ';
      P_KIT_COMP_DTL(r_level.row_num) := V_KIT_COMP_INFO_BO(l_comp_level,r_level.comp_part_number,r_level.comp_part_desc,r_level.comp_qty,r_level.comp_availability,r_level.comp_unit_price,r_level.comp_ext_price,r_level.customer_code,r_level.default_value,r_level.sort_order,r_level.component_item_id,r_level.assembly_item_id,r_level.top_model_item_id,r_level.row_num,r_level.plan_level,r_level.bom_item_type);
   END LOOP;
   l_loc_msg := ' Start logic for COMP_AVAIL ';
   FOR r_avail IN (SELECT *
                     FROM TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY))
                    WHERE comp_availability IS NULL
                   ORDER BY row_num) LOOP
      IF r_avail.bom_item_type = 2 THEN
         l_comp_avail := NULL; --MYJIRATEST-4654 Ravi S 28-NOV-2014
      ELSE
         l_loc_msg := ' Fetch COMP_AVAIL for '||r_avail.comp_part_number||' ';
--Added by OWMS Team : START
                  BEGIN
                        --
                           v_item_source := NULL;
			   --
			   v_er1_source := GEAE_INV_GET_SOURCE_CODE ('ER1',r_avail.comp_part_number,'Y');
			   v_er2_source := GEAE_INV_GET_SOURCE_CODE ('ER2',r_avail.comp_part_number,'Y');
			   v_er3_source := GEAE_INV_GET_SOURCE_CODE ('ER3',r_avail.comp_part_number,'Y');
			   --
			   IF v_er1_source = 'CPL' OR v_er2_source = 'CPL' OR v_er3_source = 'CPL' THEN
				v_item_source := 'CPL';
			   ELSE
				 v_item_source := 'ERL';
			   END IF;
			   --

                            SELECT NVL(SUM(QTY),0)
                                INTO l_comp_avail
                                FROM (SELECT NVL((A.QTY - B.QTY),0)  QTY
				    FROM (SELECT (geae_wms_total_onhand_erl_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
						geae_wms_total_pick_release(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
						 FROM apps.mtl_system_items_b msib,
						      apps.mtl_parameters mp
						 WHERE 1 = 1
						   and msib.inventory_item_id = r_avail.component_item_id
						   and msib.organization_id = mp.organization_id
						   and mp.organization_code = v_item_source
						   AND v_item_source <> 'CPL') A,
					 (SELECT (geae_wms_resv_qty_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
						geae_wms_total_resv(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
						 FROM apps.mtl_system_items_b msib,
						      apps.mtl_parameters mp
						 WHERE 1 = 1
						   and msib.inventory_item_id = r_avail.component_item_id
						   and msib.organization_id = mp.organization_id
						   and mp.organization_code = v_item_source
						   AND v_item_source <> 'CPL') B
                                      UNION ALL
                                      SELECT (A.QTY - B.QTY)  QTY
                                        FROM (SELECT NVL(SUM(MOQ.TRANSACTION_QUANTITY), 0) QTY
                                                FROM GEAE_INV_MTL_ONHANDS_V MOQ
                                               WHERE INVENTORY_ITEM_ID = r_avail.component_item_id
                                                 AND SUBINVENTORY_CODE IN ('STOCK','STG')
                                                 AND ORGANIZATION_ID IN
                                                     (SELECT ORGANIZATION_ID
                                                        FROM MTL_PARAMETERS
                                                       WHERE ORGANIZATION_CODE = V_ITEM_SOURCE)
                                                  AND v_item_source <> 'ERL'     ) A,
                                             (SELECT NVL(SUM(RESERVATION_QUANTITY), 0) QTY
                                                FROM MTL_RESERVATIONS
                                               WHERE INVENTORY_ITEM_ID = r_avail.component_item_id
                                                 AND ORGANIZATION_ID IN
                                                     (SELECT ORGANIZATION_ID
                                                        FROM MTL_PARAMETERS
                                                       WHERE ORGANIZATION_CODE = V_ITEM_SOURCE)
                                                  AND v_item_source <> 'ERL'     ) B);
                             EXCEPTION
                                WHEN OTHERS THEN
                                               l_comp_avail := 0;
                              END;
--Added by OWMS Team : END
      END IF;
      l_loc_msg := ' Assignment to P_KIT_COMP_DTL '||r_avail.row_num||' for comp_avail ';
      P_KIT_COMP_DTL(r_avail.row_num) := V_KIT_COMP_INFO_BO(r_avail.comp_level,r_avail.comp_part_number,r_avail.comp_part_desc,r_avail.comp_qty,l_comp_avail,r_avail.comp_unit_price,r_avail.comp_ext_price,r_avail.customer_code,r_avail.default_value,r_avail.sort_order,r_avail.component_item_id,r_avail.assembly_item_id,r_avail.top_model_item_id,r_avail.row_num,r_avail.plan_level,r_avail.bom_item_type);
   END LOOP;
   l_loc_msg := ' Logic for KIT_AVAIL ';
   SELECT COUNT(1)
     INTO l_null_avail
     FROM TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY))
    WHERE comp_qty IS NULL;
   IF l_null_avail > 0 THEN
      l_kit_avail := NULL;
   ELSE
      SELECT FLOOR(MIN(NVL(comp_availability,0)/comp_qty))
        INTO l_kit_avail
        FROM TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY))
       WHERE comp_qty IS NOT NULL
         AND bom_item_type <> 2; --MYJIRATEST-4645 Ravi S 27-NOV-2014
   END IF;
   l_loc_msg := ' Assignment to P_KIT_HDR_DTL '||l_hdr_count||' for kit_avail ';
   P_KIT_HDR_DTL(l_hdr_count) := V_KIT_HDR_INFO_BO(P_KIT_HDR_DTL(l_hdr_count).kit_name,P_KIT_HDR_DTL(l_hdr_count).kit_description,l_kit_avail,P_KIT_HDR_DTL(l_hdr_count).kit_message,P_KIT_HDR_DTL(l_hdr_count).customer_code,P_KIT_HDR_DTL(l_hdr_count).kit_price,P_KIT_HDR_DTL(l_hdr_count).kit_item_id,l_hdr_count);
   IF P_ROLE      = 'Global Enquiry' THEN --MYJIRATEST-4645 Ravi S 27-NOV-2014
      l_loc_msg := ' Start logic for Kit Price for Global Enquiry ';
      BEGIN
         SELECT qlht.list_header_id
           INTO l_price_list_id
           FROM qp_list_headers_tl qlht, fnd_lookup_values def_pl
          WHERE def_pl.lookup_code = 'GEAE_MYGE_ITEM_CONFG_DFLT_ORG'
            AND def_pl.enabled_flag = 'Y'
            AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(def_pl.start_date_active,SYSDATE)) AND TRUNC(NVL(def_pl.end_date_active,SYSDATE))
            AND def_pl.meaning = P_OU_ID
            AND def_pl.description = qlht.name;
      EXCEPTION
         WHEN OTHERS THEN
            l_price_list_id := NULL;
      END;
      IF l_price_list_id IS NOT NULL THEN
         l_loc_msg := ' Get KIT price from GET_PRICE proc ';
         GET_PRICE(P_SSO,P_OU_ID,P_ITEM_ID,l_price_list_id,l_kit_price,l_list_line_id);
         l_loc_msg := ' Assignment to P_KIT_HDR_DTL '||l_hdr_count||' for Global Enquiry ';
         P_KIT_HDR_DTL(l_hdr_count) := V_KIT_HDR_INFO_BO(P_KIT_HDR_DTL(l_hdr_count).kit_name,P_KIT_HDR_DTL(l_hdr_count).kit_description,P_KIT_HDR_DTL(l_hdr_count).kit_availability,P_KIT_HDR_DTL(l_hdr_count).kit_message,P_KIT_HDR_DTL(l_hdr_count).customer_code,l_kit_price,P_KIT_HDR_DTL(l_hdr_count).kit_item_id,l_hdr_count);
         l_loc_msg := ' Start logic for COMP_PRICE for Global Enquiry ';
         FOR r_price IN (SELECT *
                           FROM TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY))
                         ORDER BY row_num) LOOP
            l_loc_msg := ' Fetching COMP price for '||r_price.comp_part_number||' ';
            l_unit_price := NULL;
            GET_PRICE(P_SSO,P_OU_ID,r_price.component_item_id,l_price_list_id,l_unit_price,l_list_line_id);
            IF l_unit_price IS NOT NULL THEN
               l_ext_price := l_unit_price*r_price.comp_qty;
            ELSE
               l_ext_price := NULL;
            END IF;
            l_loc_msg := ' Assignment to P_KIT_COMP_DTL '||r_price.row_num||' for Global Enquiry ';
            P_KIT_COMP_DTL(r_price.row_num) := V_KIT_COMP_INFO_BO(r_price.comp_level,r_price.comp_part_number,r_price.comp_part_desc,r_price.comp_qty,r_price.comp_availability,l_unit_price,l_ext_price,r_price.customer_code,r_price.default_value,r_price.sort_order,r_price.component_item_id,r_price.assembly_item_id,r_price.top_model_item_id,r_price.row_num,r_price.plan_level,r_price.bom_item_type);
         END LOOP;
      END IF;
   ELSE
      l_loc_msg := ' Get KIT data from Item Details proc ';
      GET_ITEM_PRICE_AVAIL(P_SSO,P_IACO_CODE,P_CUST_ID,P_ROLE,P_OU_ID,P_ITEM_ID,l_part_details,l_part_avail,l_part_price,l_part_applicable,l_message,l_avail_message,l_price_message,l_kit_ind,l_part_discounts,l_discount_message,l_critical_part,l_part_bom,l_ISODERABLE); --Added l_part_bom MYJIRATEST-6272 Ravi S 03-MAR-2015 and MYJIRATEST-7138 24-MAR-2015   Abhinav Added l_ISODERABLE for Oderable Vs Non Oderable changes
      l_loc_msg := ' Loop for kit part applicable list ';
      FOR r_kit_cc IN 1..l_part_applicable.COUNT LOOP
         l_loc_msg := ' Getting Kit Price ';
         BEGIN
            SELECT unit_price
              INTO l_kit_price
              FROM TABLE(CAST(l_part_price AS V_PART_PRICE))
             WHERE catalog = GET_PRICE_LIST_NAME(l_part_applicable(r_kit_cc).price_list_id)
               AND inventory_item_id = P_ITEM_ID;
         EXCEPTION
            WHEN NO_DATA_FOUND THEN
               l_kit_price := NULL;
         END;
         IF P_KIT_HDR_DTL(l_hdr_count).customer_code IS NOT NULL THEN
            l_hdr_count := l_hdr_count + 1;
            P_KIT_HDR_DTL.EXTEND(1);
            l_loc_msg := ' Assignment to P_KIT_HDR_DTL '||l_hdr_count||' for cust_code '||l_part_applicable(r_kit_cc).cust_code||' ';
            P_KIT_HDR_DTL(l_hdr_count) := V_KIT_HDR_INFO_BO(P_KIT_HDR_DTL(1).kit_name,P_KIT_HDR_DTL(1).kit_description,P_KIT_HDR_DTL(1).kit_availability,P_KIT_HDR_DTL(1).kit_message,l_part_applicable(r_kit_cc).cust_code,l_kit_price,P_KIT_HDR_DTL(1).kit_item_id,l_hdr_count);
         ELSE
            l_loc_msg := ' Assignment to P_KIT_HDR_DTL '||l_hdr_count||' for cust_code '||l_part_applicable(r_kit_cc).cust_code||' ';
            P_KIT_HDR_DTL(l_hdr_count) := V_KIT_HDR_INFO_BO(P_KIT_HDR_DTL(l_hdr_count).kit_name,P_KIT_HDR_DTL(l_hdr_count).kit_description,P_KIT_HDR_DTL(l_hdr_count).kit_availability,P_KIT_HDR_DTL(l_hdr_count).kit_message,l_part_applicable(r_kit_cc).cust_code,l_kit_price,P_KIT_HDR_DTL(l_hdr_count).kit_item_id,l_hdr_count);
         END IF;
         l_loc_msg := ' Start logic for COMP_PRICE ';
         FOR r_price IN (SELECT *
                           FROM TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY))
                         ORDER BY row_num) LOOP
            l_loc_msg := ' Fetching COMP price for '||r_price.comp_part_number||' ';
            l_unit_price := NULL;
            GET_PRICE(P_SSO,P_OU_ID,r_price.component_item_id,l_part_applicable(r_kit_cc).price_list_id,l_unit_price,l_list_line_id);
            IF l_unit_price IS NOT NULL THEN
               l_ext_price := l_unit_price*r_price.comp_qty;
            ELSE
               l_ext_price := NULL;
            END IF;
            IF r_price.customer_code IS NOT NULL THEN
               l_comp_count := l_comp_count + 1;
               P_KIT_COMP_DTL.EXTEND(1);
               l_loc_msg := ' Assignment to P_KIT_COMP_DTL '||l_comp_count||' for cust_code '||l_part_applicable(r_kit_cc).cust_code||' ';
               P_KIT_COMP_DTL(l_comp_count) := V_KIT_COMP_INFO_BO(r_price.comp_level,r_price.comp_part_number,r_price.comp_part_desc,r_price.comp_qty,r_price.comp_availability,l_unit_price,l_ext_price,l_part_applicable(r_kit_cc).cust_code,r_price.default_value,r_price.sort_order,r_price.component_item_id,r_price.assembly_item_id,r_price.top_model_item_id,l_comp_count,r_price.plan_level,r_price.bom_item_type);
            ELSE
               l_loc_msg := ' Assignment to P_KIT_COMP_DTL '||r_price.row_num||' for cust_code '||l_part_applicable(r_kit_cc).cust_code||' ';
               P_KIT_COMP_DTL(r_price.row_num) := V_KIT_COMP_INFO_BO(r_price.comp_level,r_price.comp_part_number,r_price.comp_part_desc,r_price.comp_qty,r_price.comp_availability,l_unit_price,l_ext_price,l_part_applicable(r_kit_cc).cust_code,r_price.default_value,r_price.sort_order,r_price.component_item_id,r_price.assembly_item_id,r_price.top_model_item_id,r_price.row_num,r_price.plan_level,r_price.bom_item_type);
            END IF;
         END LOOP;
      END LOOP;
   END IF;
   l_loc_msg := ' Start logic for Kit price comparison ';
   FOR r_comp_pr IN (SELECT *
                       FROM TABLE(CAST(P_KIT_HDR_DTL AS V_KIT_HDR_INFO_ARRAY))
                     ORDER BY row_num) LOOP
      DBMS_OUTPUT.PUT_LINE('In Kit hdr loop for message');
      IF r_comp_pr.kit_price IS NULL THEN
         l_kit_pr_er_cd := 8041;
      ELSE
         IF r_comp_pr.customer_code IS NOT NULL THEN
            l_loc_msg := ' Getting sum for cust '||r_comp_pr.customer_code||' ';
            SELECT SUM(comp_ext_price)
              INTO l_sum_price
              FROM TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY))
             WHERE customer_code = r_comp_pr.customer_code;
         ELSE --MYJIRATEST-4645 Ravi S 27-NOV-2014
            l_loc_msg := ' Getting sum for null cust ';
            SELECT SUM(comp_ext_price)
              INTO l_sum_price
              FROM TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY))
             WHERE customer_code IS NULL;
         END IF;
         l_loc_msg := ' Setting the kit message when kit price found ';
         IF l_sum_price = r_comp_pr.kit_price THEN
            l_kit_pr_er_cd := NULL;
         ELSE
            l_kit_pr_er_cd := 8042;
         END IF;
      END IF;
      IF l_kit_pr_er_cd IS NOT NULL THEN
         l_kit_message := SUBSTR(GEAE_MYGE_CART_PKG.GET_ERR_MSG(l_kit_pr_er_cd),6);
      ELSE
         l_kit_message := NULL;
      END IF;
      l_loc_msg := ' Assignment to P_KIT_HDR_DTL '||r_comp_pr.row_num||' for kit_message ';
      P_KIT_HDR_DTL(r_comp_pr.row_num) := V_KIT_HDR_INFO_BO(P_KIT_HDR_DTL(r_comp_pr.row_num).kit_name,P_KIT_HDR_DTL(r_comp_pr.row_num).kit_description,P_KIT_HDR_DTL(r_comp_pr.row_num).kit_availability,l_kit_message,P_KIT_HDR_DTL(r_comp_pr.row_num).customer_code,P_KIT_HDR_DTL(r_comp_pr.row_num).kit_price,P_KIT_HDR_DTL(r_comp_pr.row_num).kit_item_id,r_comp_pr.row_num);
   END LOOP;
/*   --MYJIRATEST-4645 Ravi S 27-NOV-2014
   FOR r_indent IN (SELECT comp.*, REGEXP_COUNT(REPLACE(comp.comp_level,'.','#'),'#') point_count
                      FROM TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY)) comp
                      ORDER BY comp.row_num) LOOP
      l_loc_msg := ' Deciding indentation for '||r_indent.comp_part_number||' ';
      l_indent := NULL;
      FOR i IN 1..r_indent.point_count LOOP
         l_indent := l_indent||l_one_indent;
      END LOOP;
      l_loc_msg := ' Doing indentation for '||r_indent.comp_part_number||' by '||r_indent.point_count;
      P_KIT_COMP_DTL(r_indent.row_num) := V_KIT_COMP_INFO_BO(r_indent.comp_level,l_indent||r_indent.comp_part_number,r_indent.comp_part_desc,r_indent.comp_qty,r_indent.comp_availability,r_indent.comp_unit_price,r_indent.comp_ext_price,r_indent.customer_code,r_indent.default_value,r_indent.sort_order,r_indent.component_item_id,r_indent.assembly_item_id,r_indent.top_model_item_id,r_indent.row_num,r_indent.plan_level,r_indent.bom_item_type);
   END LOOP;
   l_loc_msg := ' Start logic for COMP_PRICE ';
   FOR r_price IN (SELECT *
                     FROM TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY))
                    WHERE customer_code IS NULL
                   ORDER BY row_num) LOOP
      l_loc_msg := ' Get COMP data from Item Details proc '||r_price.comp_part_number||' ';
      GET_ITEM_PRICE_AVAIL(P_SSO,P_IACO_CODE,P_CUST_ID,P_ROLE,P_OU_ID,r_price.component_item_id,l_part_details,l_part_avail,l_part_price,l_part_applicable,l_message,l_avail_message,l_price_message,l_kit_ind);
      l_loc_msg := ' Putting Customer code, price in P_KIT_COMP_DTL ';
      FOR r_comp_cc IN 1..l_part_applicable.COUNT LOOP
         IF l_part_applicable(r_comp_cc).price_list_id IS NOT NULL THEN
            l_loc_msg := ' Fetching COMP price for '||r_price.comp_part_number||' ';
            BEGIN
               SELECT unit_price
                 INTO l_unit_price
                 FROM TABLE(CAST(l_part_price AS V_PART_PRICE))
                WHERE catalog = GET_PRICE_LIST_NAME(l_part_applicable(r_comp_cc).price_list_id)
                  AND inventory_item_id = r_price.component_item_id;
            EXCEPTION
               WHEN NO_DATA_FOUND THEN
                  l_unit_price := NULL;
            END;
            IF l_unit_price IS NOT NULL THEN
               l_ext_price := l_unit_price*r_price.comp_qty;
            ELSE
               l_ext_price := NULL;
            END IF;
         ELSE
            l_unit_price := NULL;
            l_ext_price := NULL;
         END IF;
         IF r_price.customer_code IS NOT NULL THEN
            l_comp_count := l_comp_count + 1;
            P_KIT_COMP_DTL.EXTEND(1);
            l_loc_msg := ' Before assignment to P_KIT_COMP_DTL '||l_comp_count||' for cust_code '||l_part_applicable(r_comp_cc).cust_code||' ';
            P_KIT_COMP_DTL(l_comp_count) := V_KIT_COMP_INFO_BO(r_price.comp_level,r_price.comp_part_number,r_price.comp_part_desc,r_price.comp_qty,r_price.comp_availability,l_unit_price,l_ext_price,l_part_applicable(r_comp_cc).cust_code,r_price.default_value,r_price.sort_order,r_price.component_item_id,r_price.assembly_item_id,r_price.top_model_item_id,l_comp_count);
            l_loc_msg := ' After assignment to P_KIT_COMP_DTL '||l_comp_count||' for cust_code '||l_part_applicable(r_comp_cc).cust_code||' ';
         ELSE
            l_loc_msg := ' Before assignment to P_KIT_COMP_DTL '||r_price.row_num||' for cust_code '||l_part_applicable(r_comp_cc).cust_code||' ';
            P_KIT_COMP_DTL(r_price.row_num) := V_KIT_COMP_INFO_BO(r_price.comp_level,r_price.comp_part_number,r_price.comp_part_desc,r_price.comp_qty,r_price.comp_availability,l_unit_price,l_ext_price,l_part_applicable(r_comp_cc).cust_code,r_price.default_value,r_price.sort_order,r_price.component_item_id,r_price.assembly_item_id,r_price.top_model_item_id,r_price.row_num);
            l_loc_msg := ' After assignment to P_KIT_COMP_DTL '||r_price.row_num||' for cust_code '||l_part_applicable(r_comp_cc).cust_code||' ';
         END IF;
      END LOOP;
   END LOOP;
   */
EXCEPTION
   WHEN e_exit THEN
      NULL;
   WHEN OTHERS THEN
      P_MSG := 'Oracle Error while '|| l_loc_msg ||SUBSTR(SQLERRM,1,100);
END GET_KIT_STRUCTURE;
--Ankita S MYJIRATEST-8466 on 02-JUN-2015
PROCEDURE ITEM_DTL_PART_NUM(
    P_SSO       VARCHAR2,
    P_IACO_CODE VARCHAR2,
    P_CUST_ID V_CUST_ID_ARRAY,
    P_ROLE    VARCHAR2,
    P_OU_ID   VARCHAR2,
    P_PART_NUM VARCHAR2,
    P_PART_DETAILS OUT V_PART_DETAILS,
    P_PART_AVAIL OUT V_PART_AVAIL,
    P_PART_PRICE OUT V_PART_PRICE,
    P_PART_APPLICABLE OUT V_PART_APPLICABLE,
    P_MESSAGE OUT VARCHAR2,
    P_AVAIL_MESSAGE OUT VARCHAR2,
    P_PRICE_MESSAGE OUT VARCHAR2,
    P_KIT_IND         OUT VARCHAR2,
    P_PART_DISCOUNTS  OUT V_PART_DISCOUNTS,
    P_DISC_MESSAGE    OUT VARCHAR2,
    P_CRITICAL_PART   OUT VARCHAR2,
    P_PART_BOM        OUT V_PART_BOM, --MYJIRATEST-6272 Ravi S 03-MAR-2015
    P_ISODERABLE      OUT VARCHAR2  --MYJIRATEST-7138 24-MAR-2015   Abhinav  Oderable Vs Non Oderable changes
    )
AS
l_inventory_item_id   NUMBER;
BEGIN
 /*   P_PART_DETAILS    := V_PART_DETAILS();
    P_PART_AVAIL      := V_PART_AVAIL();
    P_PART_PRICE      := V_PART_PRICE();
    P_PART_APPLICABLE := V_PART_APPLICABLE();
    P_PART_DISCOUNTS  := V_PART_DISCOUNTS();
    P_PART_BOM        := V_PART_BOM();*/
   BEGIN
    SELECT INVENTORY_ITEM_ID
      INTO l_inventory_item_id
      FROM mtl_system_items_b
     WHERE SEGMENT1=P_PART_NUM
       AND rownum=1;
   EXCEPTION
     WHEN NO_DATA_FOUND THEN
       SELECT LOOKUP_CODE
       || ': '
       || DESCRIPTION
       INTO p_message
       FROM fnd_lookup_values
       WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
       AND UPPER(LOOKUP_CODE) = UPPER('8033');
     goto end_proc;
   END;
  --Calling GET_ITEM_PRICE_AVAIL
  apps.GEAE_MYGE_ITEM_DTL_PKG.GET_ITEM_PRICE_AVAIL(P_SSO,
                                                   P_IACO_CODE,
                                                   P_CUST_ID,
                                                   P_ROLE,
                                                   P_OU_ID,
                                                   l_inventory_item_id,
                                                   P_PART_DETAILS,
                                                   P_PART_AVAIL,
                                                   P_PART_PRICE,
                                                   P_PART_APPLICABLE,
                                                   P_MESSAGE,
                                                   P_AVAIL_MESSAGE,
                                                   P_PRICE_MESSAGE,
                                                   P_KIT_IND,
                                                   P_PART_DISCOUNTS,
                                                   P_DISC_MESSAGE,
                                                   P_CRITICAL_PART,
                                                   P_PART_BOM,
                                                   P_ISODERABLE);
  <<end_proc>>
  NULL;
END ITEM_DTL_PART_NUM;
--Neelima Y MYJIRATEST-9104 on 18-AUG-2015
PROCEDURE ITEM_DTL_PART_NUM_BULK( P_SSO               VARCHAR2,
                                  P_IACO_CODE         VARCHAR2,
                                  P_CUST_ID           V_CUST_ID_ARRAY,
                                  P_ROLE              VARCHAR2,
                                  P_OU_ID             VARCHAR2,
                                  P_PART_NUM          V_PART_NUM_LIST_ARRAY,
                                  P_BULK_PART_DETAILS OUT V_BULK_PART_DETAILS,
                                  P_MESSAGE           OUT VARCHAR2
                                 )
  AS
  V_INVENTORY_ITEM_ID     NUMBER;
  V_EXIST                 VARCHAR2(1);
  V_MESSAGE               VARCHAR2(2000);
  V_QTY_TOTAL             NUMBER;
  V_INV_ITEM_ID           NUMBER;
  V_PRT_DESC              VARCHAR2(100);
  P_MSG                   VARCHAR2(1000);
  P_AVAIL_MESSAGE         VARCHAR2(1000);
  P_PRICE_MESSAGE         VARCHAR2(1000);
  P_DISC_MESSAGE          VARCHAR2(1000);
  P_CRITICAL_PART         VARCHAR2(1000);
  P_ISODERABLE            VARCHAR2(1000);
  P_KIT_IND               VARCHAR2(1000);
  V_UNIT_PRICE            VARCHAR2(1000);
  V_UPQ                   VARCHAR2(1000);
  V_LEAD_TIME             VARCHAR2(1000);
  V_DISC_PERCENT          NUMBER;
  V_DISC_PRICE            NUMBER;
  P_PART_DETAILS     V_PART_DETAILS    := V_PART_DETAILS();
  P_PART_AVAIL       V_PART_AVAIL      := V_PART_AVAIL();
  P_PART_PRICE       V_PART_PRICE      := V_PART_PRICE();
  P_PART_APPLICABLE  V_PART_APPLICABLE := V_PART_APPLICABLE();
  P_PART_DISCOUNTS   V_PART_DISCOUNTS  := V_PART_DISCOUNTS();
  P_PART_BOM         V_PART_BOM        := V_PART_BOM();
BEGIN
  P_MESSAGE :=NULL;
  P_BULK_PART_DETAILS :=V_BULK_PART_DETAILS();
  IF P_PART_NUM.COUNT =0 THEN
    P_MESSAGE := 'No Part Num. is passed';
    goto end_proc;
  END IF;
   FOR J in 1..P_PART_NUM.COUNT
   LOOP
      V_QTY_TOTAL      := 0;
      V_UNIT_PRICE     := NULL;
      V_UPQ            := NULL;
      V_LEAD_TIME      := NULL;
      V_DISC_PERCENT   := NULL;
      V_INV_ITEM_ID    := NULL;
      V_PRT_DESC       := NULL;
    --  V_DISC_PRICE     := NULL;
     BEGIN
        V_EXIST :='Y';
       SELECT INVENTORY_ITEM_ID
         INTO V_INVENTORY_ITEM_ID
         FROM MTL_SYSTEM_ITEMS_B
        WHERE SEGMENT1=P_PART_NUM(J)
          AND ROWNUM=1;
     EXCEPTION
       WHEN NO_DATA_FOUND THEN
         SELECT LOOKUP_CODE
         || ': '
         || DESCRIPTION
         ||'~'||P_PART_NUM(J)
         INTO V_MESSAGE
         FROM FND_LOOKUP_VALUES
         WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
         AND UPPER(LOOKUP_CODE) = UPPER('8033');
         V_EXIST :='N';
     END;
    IF V_EXIST ='Y' THEN
     --Calling GET_ITEM_PRICE_AVAIL
     apps.GEAE_MYGE_ITEM_DTL_PKG.GET_ITEM_PRICE_AVAIL(P_SSO,
                                                      P_IACO_CODE,
                                                      P_CUST_ID,
                                                      P_ROLE,
                                                      P_OU_ID,
                                                      V_INVENTORY_ITEM_ID,
                                                      P_PART_DETAILS ,
                                                      P_PART_AVAIL ,
                                                      P_PART_PRICE ,
                                                      P_PART_APPLICABLE ,
                                                      P_MSG ,
                                                      P_AVAIL_MESSAGE ,
                                                      P_PRICE_MESSAGE ,
                                                      P_KIT_IND ,
                                                      P_PART_DISCOUNTS ,
                                                      P_DISC_MESSAGE ,
                                                      P_CRITICAL_PART ,
                                                      P_PART_BOM ,
                                                      P_ISODERABLE );
     IF  P_PART_DETAILS.COUNT > 0 THEN
       V_INVENTORY_ITEM_ID := P_PART_DETAILS(1).INVENTORY_ITEM_ID;
       V_PRT_DESC          := P_PART_DETAILS(1).PART_DESCRIPTION;
     END IF;

/**************************************************
US267084: The on hand quantity is not displayed correctly on Part bulk search screen . Because of the recent change
the part_avail count is 1. So modifying the below condition to check the count >0
******************************************************/
  --   IF P_PART_AVAIL.COUNT > 1 THEN
       IF P_PART_AVAIL.COUNT > 0 THEN   ---US267084
       FOR i IN 1 ..P_PART_AVAIL.COUNT
       LOOP
         V_QTY_TOTAL := V_QTY_TOTAL + P_PART_AVAIL(i).QUANTITY ;
       END LOOP;

/*Added the below code, to show quantity = 0 of critical parts for external users */
        IF P_CRITICAL_PART ='Y' and P_ROLE <> 'Global Enquiry' THEN
            V_QTY_TOTAL := 0;
        END IF;

     END IF;
     IF P_PART_PRICE.COUNT > 1 THEN
       P_PART_PRICE.DELETE;
       P_PRICE_MESSAGE := 'Price_Msg_02:';
       P_PRICE_MESSAGE :=P_PRICE_MESSAGE||'Please click on Part No. for complete information';
     ELSIF P_PART_PRICE.COUNT =1 THEN
       V_UNIT_PRICE := P_PART_PRICE(1).UNIT_PRICE;
       V_UPQ        := P_PART_PRICE(1).UPQ;
       V_LEAD_TIME  := P_PART_PRICE(1).LEAD_TIME;
     ELSE
       V_UNIT_PRICE := NULL;
       V_UPQ        := NULL;
       V_LEAD_TIME  := NULL;
     END IF;
     IF P_PART_DISCOUNTS.COUNT > 0 THEN
       IF P_PART_DISCOUNTS.COUNT > 1 THEN
         IF P_CUST_ID.COUNT > 0 THEN
            FOR VAR IN 1 .. P_CUST_ID.COUNT
               LOOP
               P_DISC_MESSAGE := GEAE_MYGE_CART_PKG.GET_ERR_MSG(8202)||'~'||P_CUST_ID(VAR);
             END LOOP;
          END IF;
         P_PART_DISCOUNTS.DELETE;
         V_DISC_PERCENT := NULL;
       --  V_DISC_PRICE   := NULL;
       ELSE
         V_DISC_PERCENT := P_PART_DISCOUNTS(1).DISC_PERCENT;
        -- V_DISC_PRICE   := P_PART_DISCOUNTS(1).DISC_PRICE;
       END IF;
     ELSE
       V_DISC_PERCENT := NULL;
      -- V_DISC_PRICE   := NULL;
     END IF;
     P_BULK_PART_DETAILS.EXTEND();
     P_BULK_PART_DETAILS(J):=   V_BULK_PART_DETAILS_LIST_BO(V_INVENTORY_ITEM_ID ,
                                                            P_PART_NUM(J) ,
                                                            V_PRT_DESC ,
                                                            V_QTY_TOTAL ,
                                                            V_UNIT_PRICE ,
                                                            V_UPQ ,
                                                            V_LEAD_TIME ,
                                                            V_DISC_PERCENT ,
                                                          --  V_DISC_PRICE ,
                                                            P_MSG ,
                                                            P_AVAIL_MESSAGE ,
                                                            P_PRICE_MESSAGE ,
                                                            P_DISC_MESSAGE ,
                                                            P_CRITICAL_PART
                                                           );
     ELSE
       P_BULK_PART_DETAILS.EXTEND();
        P_BULK_PART_DETAILS(J):= V_BULK_PART_DETAILS_LIST_BO('' ,
                                                             P_PART_NUM(J) ,
                                                             '' ,
                                                             '' ,
                                                             '' ,
                                                             '' ,
                                                             '' ,
                                                             '' ,
                                                           --  '' ,
                                                             '' ,
                                                             '' ,
                                                             '' ,
                                                             '' ,
                                                             ''
                                                            );
    END IF;
   END LOOP;
  <<end_proc>>
  NULL;
EXCEPTION
   WHEN OTHERS THEN
      P_MESSAGE := '8000:'||SUBSTR(SQLERRM,1,100);
END ITEM_DTL_PART_NUM_BULK;

END GEAE_MYGE_ITEM_DTL_PKG;


create or replace PACKAGE BODY "GEAE_MYGE_ITEM_DTL_PKG"
AS
  --
--------Change Log-------------------------------------
/*
Date          Changed By         Description
10-SEP-2014   Ravi Saxena        MYJIRATEST-3012 Fix to get translated price list name for display
17-SEP-2014   Ravi Saxena        MYJIRATEST-2956 Add logic to allow ordering based on procurement code if all ship codes are past use
30-OCT-2014   Ravi Saxena        MYJIRATEST-3993 Ensure lookup GEAE_MYGE_PART_APPLICABLE_ORGS is used and tag is used in it for organization_code
04-NOV-2014   Ravi Saxena        MYJIRATEST-3989 Add KIT Indicator to the GET_ITEM_PRICE_AVAIL procedure
06-NOV-2014   Ravi Saxena        MYJIRATEST-3876 Added procedure for KIT Structure
18-NOV-2014   Ravi Saxena        MYJIRATEST-3512 Change in call to CREATE_KIT_CONFIG
27-NOV-2014   Ravi Saxena        MYJIRATEST-4645 Kit structure changes
28-NOV-2014   Ravi Saxena        MYJIRATEST-4654 For Option class availability should come as blank
03-DEC-2014   Ravi Saxena        MYJIRATEST-4757 Have ability to enable or disable Kit structure
21-JAN-2015   Ravi Saxena        MYJIRATEST-5063 Discounts added
21-JAN-2015   Ravi Saxena        MYJIRATEST-5102 Remove hard coding of Aero for discount indicator
21-JAN-2015   Ravi Saxena        MYJIRATEST-5093 Add Critical part indicator
10-FEB-2015   Ravi Saxena        MYJIRATEST-5919 Discount changes
18-FEB-2015   Ravi Saxena        MYJIRATEST-6058 Fix for Common parts
03-MAR-2015   Ravi Saxena        MYJIRATEST-6272 Aero enhancement changes
23-MAR-2015   Abhinav Srivastava MYJIRATEST-7139 Engine family to Product line changes
24-MAR-2015   Abhinav Srivastava MYJIRATEST-7138 Oderable Vs Non Oderable changes
27-APR-2015   Ankita S           MYJIRATEST-5059 Add part to cart using PART_NUM
04-MAY-2015   Ankita Shetty      MYJIRATEST-7192 Change the message format for Manual discounts
04-MAY-2015   Ankita Shetty      MYJIRATEST-7056 Changed logic for populating Allocation Message
02-JUN-2015   Ankita S           MYJIRATEST-8466 on 02-JUN-2015
18-AUG-2015   Neelima Y          MYJIRATEST-8631 on 18-AUG-2015 Honda warehouse onhand visibility change
18-AUG-2015   Neelima Y          MYJIRATEST-9104 on 18-AUG-2015 Bulk Search
12-OCT-2015   Neelima Y          MYJIRATEST-9281 on 12-OCT-2015 Vendor part
28-DEC-2015   Trupti D           MYJIRATEST-12358 on 28-DEC-2015
29-JAN-2016   Trupti D           MYJIRATEST-7273 on 29-JAN-2016
26-FEB-2016   Trupti D           MYJIRATEST-13720 changed the logic for populating price list for GLobal Enquiry role
07-APR-2016   Trupti D           MYJIRATEST-13902 PZN ship code
21-JUN-2016   R Prasad           MYJIRATEST-7252  Enabled the Lumpsum as discount.
10-NOV-2016   R Prasad           US34704 - GTA validation check is added
12-DEC-2016   R Prasad     US46803 -Change ship code C to non shippable in portal
12-DEC-2016   R Prasad           US41783 -User customer code is not populating while adding a part to cart
08-MAR-2017   R Prasad           US52826 -Currently GEAE user can see all the inventory location, we should make the change so that they can only view what  a GE shop user see it. They should only see Erlanger and West chester.
18-APR-2017   R Prasad           US63772 -Remove Expired Discount Lines - myGEA, myCFM, myHonda, Aero
19-JUN-2018   OWMS Team          Changes for US192483 and US192484
28-Nov-2018   Manisha K          US198256- Passport requiement; Modified proc GET_ITEM_PRICE_AVAIL to find the Part details in case of two OU_ID passed as input.
27-Mar-2018   Manisha K          US267084- The on hand quantity is not displayed correctly on Part bulk search screen.
 */
PROCEDURE GET_ITEM_PRICE_AVAIL(
    P_SSO       VARCHAR2,
    P_IACO_CODE VARCHAR2,
    P_CUST_ID V_CUST_ID_ARRAY,
    P_ROLE    VARCHAR2,
    P_OU_ID   VARCHAR2,
    P_ITEM_ID NUMBER,
    P_PART_DETAILS OUT V_PART_DETAILS,
    P_PART_AVAIL OUT V_PART_AVAIL,
    P_PART_PRICE OUT V_PART_PRICE,
    P_PART_APPLICABLE OUT V_PART_APPLICABLE,
    P_MESSAGE OUT VARCHAR2,
    P_AVAIL_MESSAGE OUT VARCHAR2,
    P_PRICE_MESSAGE OUT VARCHAR2,
    P_KIT_IND         OUT VARCHAR2,
    P_PART_DISCOUNTS  OUT V_PART_DISCOUNTS,
    P_DISC_MESSAGE    OUT VARCHAR2,
    P_CRITICAL_PART   OUT VARCHAR2,
    P_PART_BOM        OUT V_PART_BOM, --MYJIRATEST-6272 Ravi S 03-MAR-2015
    P_ISODERABLE      OUT VARCHAR2  --MYJIRATEST-7138 24-MAR-2015   Abhinav  Oderable Vs Non Oderable changes
    )
AS
  --
  -- DECLARATION OF COUNTERS
  v_cust_cnt             NUMBER := 0;
  v_part_cnt             NUMBER := 0;
  v_part_avail_cnt       NUMBER := 0;
  v_part_price_cnt       NUMBER := 0;
  V_PART_APPL_CNT        NUMBER := 0;
  v_PART_PRICE_V_add     NUMBER := 0;
  V_PRICE_LIST_ID        NUMBER := 0;
  V_AVIALL_PRICE_LIST_ID NUMBER := 0;
  L_PRICE_LIST_DTL_cnt   NUMBER := 0;
  v_price_list_id_old    NUMBER := 0;
  p_aviall_price         NUMBER := 0;
  V_PART_dtl_cnt         NUMBER := 0;
  v_valdn_org            NUMBER;
  v_item_status          VARCHAR2(1);
  v_aviall_part          VARCHAR2(1);
  v_aviall_price         NUMBER;
  v_prc_id               NUMBER;
  V_ACT_NUM              VARCHAR2(30);
  v_aviall_err_ind       VARCHAR2(1);
  v_cust_account_id      NUMBER;
  V_CUST_ACCOUNT_ID_OLD  NUMBER;
  V_ONHAND_FLAG_NON_ZERO VARCHAR2(1);
  v_generic_messg_cnt    NUMBER;
  V_PRICE_LIST_FLAG      VARCHAR2(1);
  V_CUST_ACCOUNT_NUMBER  VARCHAR2(50);
  V_FSCM_SUPPLIER        VARCHAR2(50);
  v_price_list_api       NUMBER := 0;
  v_ou_name              VARCHAR2(240);
  v_parent_wh_id         NUMBER;
  l_disc_price           NUMBER;
  l_pr_fr_disc           NUMBER;
  l_disc_list_id         NUMBER;
  l_disc_line_id         NUMBER;
  l_disc_end_date        DATE;
  l_disc_consumed        NUMBER;
  l_disc_counter         NUMBER;
  l_bom_counter          NUMBER;  --MYJIRATEST-6272 Ravi S 03-MAR-2015
  V_OU_TAG               VARCHAR2(255) := Null;      -- Neelima Y MYJIRATEST-8631 on 18-AUG-2015
  --
  -- DECLARATIONS OF BULK COLLECT ARRAY
  L_PART_DETAILS V_PART_DETAILS           := V_PART_DETAILS();
  L_PART_AVAIL V_PART_AVAIL               := V_PART_AVAIL();
  L_PART_PRICE_V V_PART_PRICE             := V_PART_PRICE();
  L_PART_PRICE V_PART_PRICE               := V_PART_PRICE();
  L_PART_APPLICABLE V_PART_APPLICABLE     := V_PART_APPLICABLE();
  L_PRICE_LIST_ID V_PRICE_LIST_ID_ARRAY   := V_PRICE_LIST_ID_ARRAY();
  L_PRICE_LIST_DTL V_PRICE_LIST_DTL       := V_PRICE_LIST_DTL();
  P_PRICE_LIST_DTL V_PRICE_LIST_DTL       := V_PRICE_LIST_DTL();
  L_PART_VLDTN V_PART_VLDTN               := V_PART_VLDTN();
  l_PART_PRICE_DUP V_PART_PRICE           := V_PART_PRICE();
  l_PART_APPLICABLE_DUP V_PART_APPLICABLE := V_PART_APPLICABLE();
  T_PART_PRICE_LOOP_DUP V_PART_PRICE           := V_PART_PRICE(); --US198256;Passport requirement; Manisha added the variable to remove the duplicates from P_PART_PRICE array after introducing OU_ID loop.
  T_PART_APPLICABLE_LOOP_DUP V_PART_APPLICABLE := V_PART_APPLICABLE();  --US198256; Passport requirement;Manisha added the variable to remove the duplicates from P_PART_APPLICABLE array after introducing OU_ID loop.
  T_PART_AVAIL_LOOP_DUP V_PART_AVAIL := V_PART_AVAIL();  --US198256; Passport requirement; Manisha added the variable to remove the duplicates from P_PART_AVAIL array after introducing OU_ID loop.
  --
  --Declarations of Variables
  l_List_id_count           NUMBER ;
  l_PART_PRICE_DUP_CNT      NUMBER         := 0;
  v_price_dup_flag          BOOLEAN        := true;
  l_PART_APPLICABLE_DUP_CNT NUMBER         := 0;
  v_part_APP_DUP_FLAG       BOOLEAN        := true;
  P_VALID_FLAG              VARCHAR2(1)    := NULL;
  P_UNIT_PRICE              NUMBER         := NULL;
  P_LIST_LINE_ID            NUMBER         := NULL;
  P_AVIALL_UNIT_PRICE       NUMBER         := NULL;
  P_AVIALL_LIST_LINE_ID     NUMBER         := NULL;
  V_CONTROL_SHIP            NUMBER         := NULL;
  V_CONTROL_SHIPPABLE       VARCHAR2(10)   := NULL;
  V_ORG_ID                  NUMBER         := NULL;
  V_PORTAL                  VARCHAR2(150)  := NULL;
  V_FLAG_GTA_ERROR          VARCHAR2(1)    := NULL;
  V_FLAG_CTRL_SHIP_ERROR    VARCHAR2(1)    := NULL;
  V_AMPS_CODE_ERROR         VARCHAR2(1)    := NULL;
  V_FLAG_AVIALL_ERROR       VARCHAR2(1)    := NULL;
  V_FLAG_VENDOR_ERROR       VARCHAR2(1)    := NULL;
  V_FLAG_ORG_ERROR          VARCHAR2(1)    := NULL;
  V_GENERIC_MSSG            VARCHAR2(5000) := NULL;
  V_GTA_ERR_MSSG            VARCHAR2(5000) := NULL;
  V_CTRL_SHIP_ERR_MSSG      VARCHAR2(5000) := NULL;
  V_AVIALL_ERR_MSSG         VARCHAR2(5000) := NULL;
  V_VENDOR_ERR_MSSG         VARCHAR2(5000) := NULL;
  V_AMPS_CODE_ERR_MSSG      VARCHAR2(5000) := NULL;
  V_ORG_ERR_MSSG            VARCHAR2(5000) := NULL;
  V_PUBLISH                 VARCHAR2(10)   := NULL;
  V_AVAILL_ALL_ERROR        VARCHAR2(1)    := NULL;
  V_AVIALL_SUCESS           VARCHAR2(1)    := NULL;
  v_proc_status             VARCHAR2(1);
  v_proc_code               VARCHAR2(5);
  v_on_hand                 NUMBER;
  v_kit_ind_on              VARCHAR2(1);
  v_prod_line_on              VARCHAR2(1);  --MYJIRATEST-6272 Ravi S 03-MAR-2015 and  MYJIRATEST-7139 Engine family to Product line changes    23-MAR-2015    Abhinav
  v_oderable_on               VARCHAR2(1);  --MYJIRATEST-7138 24-MAR-2015   Oderable Vs Non Oderable changes
  V_ISODERABLE                VARCHAR2(1);  --MYJIRATEST-7138 24-MAR-2015   Oderable Vs Non Oderable changes
  V_ISODERABLE_MESSAGE        VARCHAR2(5000) := NULL;  --MYJIRATEST-7138 24-MAR-2015   Oderable Vs Non Oderable changes
  v_item_source                VARCHAR2(500); -- Added for OWMS Implementation US192483/US192484
  v_er1_source VARCHAR2(500); -- Added for OWMS Implementation US192483/US192484
  v_er2_source VARCHAR2(500); -- Added for OWMS Implementation US192483/US192484
  v_er3_source VARCHAR2(500); -- Added for OWMS Implementation US192483/US192484
  v_item_number                VARCHAR2(30); -- Added for OWMS Implementation US192483/US192484
  v_hnd_flag	  VARCHAR2(5);-- Added for OWMS Implementation US192483/US192484
  --
  v_ou_id                      VARCHAR2(30)   := NULL; --Added By Manisha;12-JUL-18;Passport requirement to save the OU_ID separated by comma
  v_ou_id1                      VARCHAR2(30)   := NULL;
  v_ou_id2                      VARCHAR2(30)   := NULL;
  i_PART_PRICE_DUP_CNT      NUMBER         := 0;  --Manisha 10-Aug; Used to increase the counter for loop(to remove duplicate from P_PART_PRICE array after adding OU_ID loop)
  i_price_dup_flag          BOOLEAN        := true; --Manisha 10-Aug; Flag to check for duplicates in P_PART_PRICE
  i_PART_APPLICABLE_DUP_CNT NUMBER         := 0; --US198256; Manisha 10- Aug; Added variable to increase the counter for loop(to remove duplicate from P_PART_APPLICABLE array after adding OU_ID loop)
  i_part_APP_DUP_FLAG       BOOLEAN        := true; --US198256; Manisha 10-Aug; Flag to check for duplicates in P_PART_APPLICABLE
  i_PART_AVAIL_DUP_CNT NUMBER         := 0; --US198256; Manisha 10- Aug;Added variable to increase the counter for loop(to remove duplicate from P_PART_AVAIL after adding OU_ID loop)
  i_part_AVAIL_DUP_FLAG       BOOLEAN        := true; --US198256; Manisha 10-Aug; Flag to check for duplicates in P_PART_AVAIL
  /*******************************
  --Added the variable to save the intermediate value while passing both OU_ID in loop before displaying in the out parameter
  ******************************************/

  v_message                    VARCHAR2(5000) := NULL;
  v_avail_message              VARCHAR2(5000) := NULL;
  v_price_message              VARCHAR2(5000) := NULL;
  v_disc_message               VARCHAR2(5000) := NULL;
  l_isoderable                 VARCHAR2(5000) := NULL;
  ----------------------------------------

  CURSOR C_DISCOUNTS(P_CUSTOMER_ID NUMBER, P_OU_ID NUMBER, P_ITEM_ID NUMBER, P_PRICE_LIST_ID NUMBER) IS
     SELECT cust_account_id, account_number, list_name, list_description, line_number, line_comments, disc_value, arithmetic_operator,
            qual_end_date, line_end_date, list_end_date, grants_end_date, list_auto_flag, line_auto_flag, basis, limit_level_code, limit,
            product_attribute_context, product_attribute, product_attr_value, list_header_id, list_line_id, qualifier_id, qualifier_context
       FROM (
        SELECT hca.cust_account_id, hca.account_number, qlh.name list_name, qlh.description list_description, qll.list_line_no line_number,
               qll.attribute4 line_comments, qll.operand disc_value, qll.arithmetic_operator, qq.end_date_active qual_end_date,
               qll.end_date_active line_end_date, qlh.end_date_active list_end_date, qg.end_date grants_end_date, qlh.automatic_flag list_auto_flag,
               qll.automatic_flag line_auto_flag, ql.basis, ql.limit_level_code, ql.amount limit, qpa.product_attribute_context, qpa.product_attribute,
               qpa.product_attr_value, qll.list_header_id, qll.list_line_id, qq.qualifier_id, qq.qualifier_context
          FROM hz_cust_accounts hca, qp_grants qg, qp_list_headers qlh, qp_list_lines qll, qp_qualifiers qq, qp_pricing_attributes qpa,
               (SELECT * FROM qp_limits WHERE basis = 'QUANTITY' AND limit_level_code = 'ACROSS_TRANSACTION') ql
         WHERE 1 = 1
           AND ((to_char(hca.cust_account_id) = qq.qualifier_attr_value AND qq.qualifier_context = 'CUSTOMER')
             OR (to_char(P_PRICE_LIST_ID) = qq.qualifier_attr_value AND qq.qualifier_context = 'MODLIST'))
           AND hca.status = 'A'
           AND qq.comparison_operator_code = '='
           AND hca.cust_account_id = P_CUSTOMER_ID
           AND qq.active_flag = 'Y'
           AND qq.list_header_id = qlh.list_header_id
           AND DECODE(qq.list_line_id,-1,qll.list_line_id,qq.list_line_id) = qll.list_line_id
           AND qlh.list_type_code = 'DLT'
           AND qlh.active_flag = 'Y'
           AND qlh.list_header_id = qg.instance_id
           AND qg.grantee_type = 'OU'
           AND qg.instance_type = 'MOD'
           AND qg.grantee_id = P_OU_ID
           AND qll.list_line_type_code = 'DIS'
           AND qlh.list_header_id = qll.list_header_id
           AND qll.pricing_phase_id > 1
           AND qll.qualification_ind IN (0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,32)
           AND qll.list_header_id = qpa.list_header_id(+)
           AND qll.list_line_id = qpa.list_line_id(+)
           AND (qpa.pricing_attribute_context = 'VOLUME' OR qpa.pricing_attribute_context IS NULL)
           AND ql.list_header_id(+) = qll.list_header_id
           AND ql.list_line_id(+) = qll.list_line_id
           --AND qll.arithmetic_operator = '%'             MYJIRATEST-7252 Commented by Prasad on 21-Jun-2016
           AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(qlh.start_date_active,SYSDATE)) AND TRUNC(NVL(qlh.end_date_active,SYSDATE))
           AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(qll.start_date_active,SYSDATE)) AND TRUNC(NVL(qll.end_date_active,SYSDATE))  --MYJIRATEST-7273 Trupti D. 29-JAN-2016 --US63772 18-APR-17
           AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(qq.start_date_active,SYSDATE)) AND TRUNC(NVL(qq.end_date_active,SYSDATE))
           AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(qg.start_date,SYSDATE)) AND TRUNC(NVL(qg.end_date,SYSDATE))
         --AND trunc(NVL(qll.end_date_active, SYSDATE))>=add_months(sysdate,-6)                                              --MYJIRATEST-7273 Trupti D. 29-JAN-2016 --US63772 18-APR-17
           )
      WHERE ((product_attribute = 'PRICING_ATTRIBUTE3' AND product_attr_value = 'ALL')
               OR (product_attribute = 'PRICING_ATTRIBUTE1' AND product_attr_value = P_ITEM_ID)
               OR product_attribute IS NULL) AND (product_attribute_context = 'ITEM' OR product_attribute_context IS NULL);
BEGIN
  ---Start of Procedure GET_ITEM_PRICE_AVAIL
  --
  P_PART_DETAILS    := V_PART_DETAILS();
  P_PART_AVAIL      := V_PART_AVAIL();
  P_PART_PRICE      := V_PART_PRICE();
  P_PART_APPLICABLE := V_PART_APPLICABLE();
  P_PART_DISCOUNTS  := V_PART_DISCOUNTS();
  P_PART_BOM        := V_PART_BOM(); --MYJIRATEST-6272 Ravi S 03-MAR-2015


  /*********************************************
  US198256: Manisha K; Passport requirements 12-July-2018
  As part of Passport Requirement: Two OU_ID will be passed separated by ~ symbol.
  So, the part price will be calculated separately for each OU_ID using loop
  **************************************************/
P_PART_DETAILS.EXTEND();   --US198256; Manisha K; Creating element for the PART_DETAILS array ,outside the OU_ID loop to avoid duplicates.

 v_ou_id:=Replace(P_OU_ID,'~',',');

    FOR j IN
     (SELECT trim(regexp_substr(v_ou_id, '[^,]+', 1, LEVEL)) ou_id
    FROM dual
      CONNECT BY LEVEL <= regexp_count(v_ou_id, ',')+1
    )
   LOOP
---  US198256; Manisha K; Passport Changes End here

  SELECT name
    INTO v_ou_name
    FROM HR_OPERATING_UNITS
   WHERE organization_id = J.OU_ID;
  --MYJIRATEST-5102 Ravi S 21-JAN-2015
  BEGIN
     SELECT mp.organization_id
       INTO v_parent_wh_id
       FROM MTL_PARAMETERS MP,
            FND_LOOKUP_VALUES FLV
      WHERE MP.ORGANIZATION_CODE = FLV.ATTRIBUTE1
        AND FLV.description      = J.OU_ID
        AND FLV.LOOKUP_TYPE      = 'GEAE_MYGE_SUPPLIER_ORGS'
        AND FLV.ATTRIBUTE3       = (SELECT MIN(FLV2.ATTRIBUTE3)
                                      FROM MTL_PARAMETERS MP2,
                                           FND_LOOKUP_VALUES FLV2
                                     WHERE MP2.ORGANIZATION_CODE = FLV2.ATTRIBUTE1
                                       AND FLV2.description      = J.OU_ID
                                       AND FLV2.LOOKUP_TYPE      = 'GEAE_MYGE_SUPPLIER_ORGS');
  EXCEPTION
     WHEN NO_DATA_FOUND THEN
        v_parent_wh_id := NULL;
  END;
  -- MYJIRATEST-4757 Ravi S 03-DEC-2014
  BEGIN
     SELECT description
       INTO v_kit_ind_on
       FROM fnd_lookup_values
      WHERE lookup_type = 'GEAE_MYGE_ENABLE_KIT_STRUCTURE'
        AND lookup_code = J.OU_ID
        AND enabled_flag = 'Y'
        AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(start_date_active,SYSDATE)) AND TRUNC(NVL(end_date_active,SYSDATE));
  EXCEPTION
     WHEN NO_DATA_FOUND THEN
        v_kit_ind_on := 'N';
  END;
  --MYJIRATEST-6272 Ravi S 03-MAR-2015
  BEGIN
     SELECT description
       INTO v_prod_line_on  --  MYJIRATEST-7139 23-MAR-2015    Engine family to Product line changes
       FROM fnd_lookup_values
      WHERE lookup_type = 'GEAE_MYGE_ENABLE_ENGINE_FAMILY'
        AND lookup_code = J.OU_ID
        AND enabled_flag = 'Y'
        AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(start_date_active,SYSDATE)) AND TRUNC(NVL(end_date_active,SYSDATE));
  EXCEPTION
     WHEN NO_DATA_FOUND THEN
        v_prod_line_on := 'N';  --  MYJIRATEST-7139 23-MAR-2015    Engine family to Product line changes
  END;
  --
  -- If Role is Global Enquiry fetch the Item Availiability accross Orgs
  --If role is Global Enquiry fetch the Item Price across all price list for that operating unit pass as parameter

  IF p_ROLE      = 'Global Enquiry' THEN
    V_VALDN_ORG := GEAE_CNV_UTILITY_PACKAGE.GET_ORGANIZATION_ID('CVO');

    -- validate whether part is orderable the organization used is CVO
    BEGIN
      SELECT 'Y'
      INTO v_item_status
      FROM mtl_system_items_b msi
      WHERE msi.organization_id           = v_valdn_org
      AND msi.CUSTOMER_ORDER_FLAG         = 'Y'
      AND msi.CUSTOMER_ORDER_ENABLED_FLAg = 'Y'
      AND msi.inventory_item_id           = P_ITEM_ID;
    EXCEPTION
    WHEN OTHERS THEN
      V_ITEM_STATUS := 'N';
      --
      SELECT LOOKUP_CODE
        || ': '
        || DESCRIPTION
      INTO p_message
      FROM fnd_lookup_values
      WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
      AND UPPER(LOOKUP_CODE) = UPPER('8125');
      --
      /*  IF P_CUST_ID.COUNT > 0 THEN
      FOR VAR IN 1 .. P_CUST_ID.COUNT
      LOOP
      P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
      END LOOP;
      END IF;  */
      --
    END;
    IF V_ITEM_STATUS = 'Y' THEN
      --Getting KIT Flag
      BEGIN
         SELECT 'Y'
           INTO P_KIT_IND
           FROM mtl_system_items_b
          WHERE organization_id = v_valdn_org
            AND inventory_item_id = P_ITEM_ID
            AND bom_item_type = 1;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            P_KIT_IND := 'N';
      END;
      IF v_kit_ind_on <> 'Y' THEN
         P_KIT_IND := 'N'; -- MYJIRATEST-4757 Ravi S 03-DEC-2014
      END IF;
      --MYJIRATEST-5093 Ravi S 21-JAN-2015
      BEGIN
         SELECT 'Y'
           INTO P_CRITICAL_PART
           FROM oe_hold_definitions ohd, oe_hold_sources_all ohsa, fnd_lookup_values flv
          WHERE ohd.hold_id = ohsa.hold_id
            AND ohd.name = flv.description
            AND flv.lookup_type = 'GEAE_MYGE_CRITICAL_PART_HOLDS'
            AND flv.enabled_flag = 'Y'
            AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(flv.start_date_active,SYSDATE)) AND TRUNC(NVL(flv.end_date_active,SYSDATE))
            AND ohsa.hold_entity_code = 'I'
            AND ohsa.released_flag <>'Y'   -- MYJIRATEST-12046  23-NOV-2015
            AND ohsa.hold_entity_id = P_ITEM_ID
            AND rownum = 1;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            P_CRITICAL_PART := 'N';
      END;
      ---------------------------------------
      ---Creating the Price List Array for Price if the role is global enquiry across all Price list in Operating unit passed
      --added this to fix the price list is not diplayed for internal GEAE users US267081 on 28th March 2019
      MO_GLOBAL.SET_POLICY_CONTEXT('S',J.OU_ID);
      --end of the change
      SELECT V_PART_PRICE_LIST_BO(GQIPV.inventory_item_id, GQIPV.PRICE_LIST_NAME, GQIPV.list_price, NVL(GQIPV.CATALOG_UPQ,1), GQIPV.CATALOG_LEAD_TIME) BULK COLLECT
      INTO L_PART_PRICE_V
      FROM GEAE_QP_ITEM_PRICES_V GQIPV
      WHERE 1                     = 1
      AND GQIPV.inventory_item_id = to_char(P_ITEM_ID) -- added by Mohammed Yadul on 16.Oct.2014 for Item data type issue, this issue raised by bala
      --AND NVL(GQIPV.OPERATING_UNIT,TO_NUMBER(P_OU_ID))    = TO_NUMBER(P_OU_ID)
      AND NVL(GQIPV.OPERATING_UNIT,TO_NUMBER(J.OU_ID))=To_Number(Decode((SELECT GLOBAL_FLAG FROM QP_LIST_HEADERS WHERE NAME = GQIPV.PRICE_LIST_NAME AND ACTIVE_FLAG ='Y' AND Nvl(END_DATE_ACTIVE,SYSDATE+1) > SYSDATE )
                                                                  ,'Y'
                                                                     ,GEAE_CSO_FIN_UTL_PKG.GET_CSO_ORG_ID
                                                                     ,J.OU_ID))   ----------MYJIRATEST-13720 Trupti D. 26-FEB-2016
      AND NOT EXISTS
        (SELECT 'X'
        FROM fnd_lookup_values flv
        WHERE flv.enabled_flag = 'Y'
        AND FLV.LOOKUP_TYPE    = 'GEAE_INV_PIS_CATALOG_EXCLUSION'
        AND FLV.DESCRIPTION    = GQIPV.PRICE_LIST_NAME
        );
      --
      IF SQL%ROWCOUNT > 0 THEN
        FOR i IN 1 .. L_PART_PRICE_V.count
        LOOP
          v_PART_PRICE_V_add := v_PART_PRICE_V_add + 1;
          P_PART_PRICE.extend();
          P_PART_PRICE(V_PART_PRICE_V_ADD) := L_PART_PRICE_V(I);
        END LOOP;
      ELSE
        SELECT LOOKUP_CODE
          || ': '
          || DESCRIPTION
        INTO p_message
        FROM fnd_lookup_values
        WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
        AND UPPER(LOOKUP_CODE) = UPPER('8134'); --
        p_message             := NULL;
        --EXIT;
        /* IF P_CUST_ID.COUNT > 0 THEN
        FOR VAR IN 1 .. P_CUST_ID.COUNT
        LOOP
        P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
        END LOOP;
        END IF;  */
      END IF;

      --
      --   Getting the Global Availability across all valid organization across SPR, OSW and SCP
      --
      /*SELECT V_PART_AVAILABILITY_LIST_BO(STG.INVENTORY_ITEM_ID, STG.ORGANIZATION_CODE, NVL(STG.QTY,0) ) BULK collect
      INTO L_PART_AVAIL
      FROM
        (SELECT STG3.INVENTORY_ITEM_ID,
          STG3.ORGANIZATION_CODE,
          NVL(STG3.TOTAL_QTY,0) - NVL(STG3.RESERVE_QTY,0) QTY
        FROM
          (SELECT MSI.INVENTORY_ITEM_ID ,
            MTP.ORGANIZATION_CODE ,
            NVL(SUM(MOQ.TRANSACTION_QUANTITY),0) TOTAL_QTY ,
            stg2.reserve_qty
          FROM MTL_ONHAND_QUANTITIES MOQ,
            MTL_SYSTEM_ITEMS_B msi,
            MTL_PARAMETERS MTP ,
            (SELECT MRS.INVENTORY_ITEM_ID ,
              MRS.ORGANIZATION_ID ,
              SUM(MRS.RESERVATION_QUANTITY) reserve_qty
            FROM MTL_RESERVATIONS MRS
            GROUP BY MRS.INVENTORY_ITEM_ID,
              MRS.ORGANIZATION_ID
            ) stg2
          WHERE 1                        = 1
          AND stg2.INVENTORY_ITEM_ID (+) = MSI.INVENTORY_ITEM_ID
          AND stg2.organization_id (+)   = MSI.ORGANIZATION_ID
          AND MOQ.ORGANIZATION_ID(+)     = MSI.ORGANIZATION_ID
          AND MOQ.INVENTORY_ITEM_ID(+)   = MSI.INVENTORY_ITEM_ID
          AND MTP.organization_code NOT IN
            (SELECT FFV.flex_value
            FROM fnd_flex_values FFV ,
              fnd_flex_value_sets FVS
            WHERE FFV.flex_value_set_id=FVS.flex_value_set_id
            AND FVS.FLEX_VALUE_SET_NAME='GEAE_AMPS_RETIRED_ORGS'
            )
          AND MTP.attribute_category IN ('SPR','OSW','SCP')
          AND MSI.ORGANIZATION_ID     = MTP.ORGANIZATION_ID
          AND MSI.INVENTORY_ITEM_ID   = P_ITEM_ID
          AND MTP.ORGANIZATION_CODE  <> 'HAI'
          GROUP BY MSI.INVENTORY_ITEM_ID ,
            MTP.ORGANIZATION_CODE ,
            STG2.RESERVE_QTY
          ) STG3
        UNION ALL
          SELECT distinct msib.inventory_item_id,
                 gif.org_code ORGANIZATION_CODE,
                 gif.onhand_Qty QTY
            FROM geae_inv_foxtrot_data_stg gif,
                 mtl_system_items_b msib
           WHERE msib.segment1=gif.prt_num
             AND msib.inventory_item_id =P_ITEM_ID
             AND gif.SRC_SYS ='HONDA'
             )stg;*/  --Commeted for Rally#US52826
          -- replicated query for  Rally#US52826  --Started
--Added by OWMS Team : Start
   v_item_source := NULL;
   v_item_number := NULL;
   BEGIN
     SELECT DISTINCT segment1
         INTO v_item_number
         FROM mtl_system_items_b
         WHERE INVENTORY_ITEM_ID   = P_ITEM_ID;
     EXCEPTION
       WHEN OTHERS THEN
                  v_item_number := NULL;
     END;
  --
 	SELECT DECODE(COUNT(1),1,'Y','N')
	INTO v_hnd_flag
	 FROM HR_OPERATING_UNITS HOU,
		  FND_LOOKUP_VALUES FLV
	WHERE  HOU.ORGANIZATION_ID = TO_NUMBER(j.OU_ID) --116797
	  AND HOU.NAME = FLV.DESCRIPTION
	  AND FLV.TAG = 'HAI'
	  AND FLV.LOOKUP_TYPE = 'GEAE_MYGE_PART_APPLICABLE_ORGS';
   --
   IF v_hnd_flag = 'Y' THEN
     v_item_source := 'HAI';
   ELSIF v_hnd_flag = 'N' THEN
	   --
	   v_er1_source := GEAE_INV_GET_SOURCE_CODE ('ER1',v_item_number,'Y');
	   v_er2_source := GEAE_INV_GET_SOURCE_CODE ('ER2',v_item_number,'Y');
	   v_er3_source := GEAE_INV_GET_SOURCE_CODE ('ER3',v_item_number,'Y');
	   --
	   IF v_er1_source = 'CPL' OR v_er2_source = 'CPL' OR v_er3_source = 'CPL' THEN
		v_item_source := 'CPL';
	   ELSE
		 v_item_source := 'ERL';
	   END IF;
   END IF;

--Added by OWMS Team : End

           SELECT V_PART_AVAILABILITY_LIST_BO(tab.INVENTORY_ITEM_ID, tab.ORGANIZATION_CODE, NVL(tab.QTY,0)) BULK collect
      INTO L_PART_AVAIL
      FROM
--Added by OWMS Team : Start
      (SELECT STG.INVENTORY_ITEM_ID,STG.ORGANIZATION_CODE,sum(stg.qty) qty
          FROM (SELECT P_ITEM_ID INVENTORY_ITEM_ID ,
                        'On-Hand Stock' ORGANIZATION_CODE,
                         (a.qty-b.qty) QTY
            FROM (SELECT (geae_wms_total_onhand_erl_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
			geae_wms_total_pick_release(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
			 FROM apps.mtl_system_items_b msib,
			      apps.mtl_parameters mp
			 WHERE 1 = 1
			   and msib.inventory_item_id = P_ITEM_ID
			   and msib.organization_id = mp.organization_id
			   and mp.organization_code = v_item_source
			   AND v_item_source NOT IN ('CPL','HAI')) A,
                 (SELECT (geae_wms_resv_qty_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
			geae_wms_total_resv(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
			 FROM apps.mtl_system_items_b msib,
			      apps.mtl_parameters mp
			 WHERE 1 = 1
			   and msib.inventory_item_id = P_ITEM_ID
			   and msib.organization_id = mp.organization_id
			   and mp.organization_code = v_item_source
			   AND v_item_source NOT IN ('CPL','HAI')) B
           UNION ALL
                SELECT P_ITEM_ID INVENTORY_ITEM_ID ,
                        'On-Hand Stock' ORGANIZATION_CODE,
                        (b.qty-c.qty) QTY
                FROM
                     (SELECT NVL(SUM(MOQ.TRANSACTION_QUANTITY),0) qty
                        FROM GEAE_INV_MTL_ONHANDS_V MOQ
                       WHERE INVENTORY_ITEM_ID = P_ITEM_ID
                         AND SUBINVENTORY_CODE in ('STOCK','STG')
                         AND ORGANIZATION_ID IN (SELECT ORGANIZATION_ID
                                                   FROM MTL_PARAMETERS
                                                  WHERE ORGANIZATION_CODE = V_ITEM_SOURCE)
                          AND v_item_source NOT IN ('ERL','HAI')
                    ) b,
                 (SELECT NVL(SUM(RESERVATION_QUANTITY),0) qty
                             FROM MTL_RESERVATIONS
                     WHERE INVENTORY_ITEM_ID = P_ITEM_ID
                         AND ORGANIZATION_ID IN (SELECT ORGANIZATION_ID
                                                   FROM MTL_PARAMETERS
                                                  WHERE ORGANIZATION_CODE = V_ITEM_SOURCE)
                          AND v_item_source NOT IN ('ERL','HAI')
                   ) C
        UNION ALL
        SELECT DISTINCT MSIB.INVENTORY_ITEM_ID,
                 'On-Hand Stock' ORGANIZATION_CODE,
               GIF.ONHAND_QTY  QTY
          FROM GEAE_INV_FOXTROT_DATA_STG GIF,
               MTL_SYSTEM_ITEMS_B MSIB,
               HR_OPERATING_UNITS HOU,
               MTL_PARAMETERS MTP,
               FND_LOOKUP_VALUES FLV
         WHERE MSIB.SEGMENT1=GIF.PRT_NUM
           AND HOU.ORGANIZATION_ID       = TO_NUMBER(J.OU_ID)
           AND HOU.NAME                   = FLV.DESCRIPTION
           AND MTP.ORGANIZATION_CODE      = FLV.TAG
           AND FLV.LOOKUP_TYPE            = 'GEAE_MYGE_PART_APPLICABLE_ORGS'
           AND GIF.ORG_CODE               = MTP.ORGANIZATION_CODE
           AND MSIB.INVENTORY_ITEM_ID =P_ITEM_ID
	   AND FLV.TAG					 = v_item_Source
	   and  v_item_Source NOT IN ('CPL','ERL')
           AND GIF.SRC_SYS ='HONDA'
          ) STG
       GROUP BY INVENTORY_ITEM_ID, ORGANIZATION_CODE ) TAB		  ;
                -- replicated query for  Rally#US52826  --Ended
      --
      IF SQL%rowcount > 0 THEN
        FOR i IN 1 .. L_PART_AVAIL.count
        LOOP
          V_PART_AVAIL_cnt := V_PART_AVAIL_cnt + 1;
          P_PART_AVAIL.EXTEND();
          P_PART_AVAIL(V_PART_AVAIL_cnt) := L_PART_AVAIL(i);
        END LOOP;
      ELSE
        SELECT LOOKUP_CODE
          || ': '
          || DESCRIPTION
        INTO p_message
        FROM fnd_lookup_values
        WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
        AND UPPER(LOOKUP_CODE) = UPPER('8133');
        --
        -- EXIT;
        --Looping in customer loop to get the cust ids in message for 8133
        /* IF P_CUST_ID.COUNT > 0 THEN
        FOR VAR IN 1 .. P_CUST_ID.COUNT
        LOOP
        P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
        END LOOP;
        END IF;  */
        -- Loop ends for customer id concatenation in messages
      END IF;
      --
      --
      SELECT V_PART_DETAILS_LIST_BO(MSI.INVENTORY_ITEM_ID, MSI.SEGMENT1, DECODE(GEAE_MYGE_CTRL_SHIPBILITY(MSI.INVENTORY_ITEM_ID),'Y',NULL,MSI.DESCRIPTION),
             DECODE(v_parent_wh_id,NULL,NULL,GEAE_INV_AMPS_COMMON_UTILS_PKG.GET_CATEGORY_VALUE(v_parent_wh_id,MSI.INVENTORY_ITEM_ID,'Discount Indicator'))) BULK COLLECT
      INTO L_PART_DETAILS
      FROM mtl_system_items_b msi,
        mtl_parameters mtp
      WHERE 1                   = 1
      AND msi.organization_id   = mtp.organization_id
      AND INVENTORY_ITEM_ID     = P_ITEM_ID
      AND MTP.ORGANIZATION_CODE = 'CVO';
      --
      IF SQL%rowcount > 0 THEN
        FOR I IN 1 .. L_PART_DETAILS.COUNT
        LOOP
         V_PART_dtl_cnt  := 0;  --Manisha K. 27 Jul Initializing the variable so that the array P_PART_DETAILS fetch single record.
          V_PART_dtl_cnt := V_PART_dtl_cnt + 1;
       --   P_PART_DETAILS.EXTEND();  --Manisha 14 Dec Have added this code in the beginning outside the loop, to fetch only one record
          P_PART_DETAILS(V_PART_dtl_cnt) := L_PART_DETAILS(I);
        END LOOP;
      END IF;
      --
      IF SQL%ROWCOUNT = 0 THEN
        --
        SELECT LOOKUP_CODE
          || ': '
          || DESCRIPTION
        INTO p_message
        FROM fnd_lookup_values
        WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
        AND UPPER(LOOKUP_CODE) = UPPER('8125');
        --
        --Looping in customer loop to get the cust ids in message for 8125
        IF P_CUST_ID.COUNT > 0 THEN
          FOR VAR IN 1 .. P_CUST_ID.COUNT
          LOOP
            P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
          END LOOP;
        END IF;
        -- Loop ends for customer id concatenation in messages
      END IF;
      --
      --MYJIRATEST-6272 Ravi S 03-MAR-2015
      IF v_prod_line_on = 'Y' THEN
         l_bom_counter := 0;
         FOR part_bom IN (SELECT --DISTINCT bom.eng_fam engine_family    MYJIRATEST-7139 23-MAR-2015    Commented for Engine family to Product line changes
                                 DISTINCT bom.product_line product_line
                            FROM geae_myge_bom_details_v bom
                           WHERE bom.search_ou_id = J.OU_ID
                             AND bom.inventory_item_id = P_ITEM_ID) LOOP
            P_PART_BOM.EXTEND(1);
            l_bom_counter := l_bom_counter + 1;
            P_PART_BOM(P_PART_BOM.last):= V_PART_BOM_BO(NULL, part_bom.product_line , l_bom_counter);--   MYJIRATEST-7139 23-MAR-2015    Engine family to Product line changes
         END LOOP;
      END IF;
      --
    END IF; --END IF of IF V_ITEM_STATUS = 'Y'
  ELSE     ---ELSE OF  p_ROLE = 'Global Enquiry'
    -- Step-0 -Check part is valid or not
    V_VALDN_ORG := GEAE_CNV_UTILITY_PACKAGE.GET_ORGANIZATION_ID('CVO');
    -- validate whether part is orderable the organization used is CVO
    BEGIN
      --
      SELECT 'Y'
      INTO v_item_status
      FROM mtl_system_items_b msi
      WHERE msi.organization_id           = v_valdn_org
      AND msi.CUSTOMER_ORDER_FLAG         = 'Y'
      AND msi.CUSTOMER_ORDER_ENABLED_FLAg = 'Y'
      AND MSI.INVENTORY_ITEM_ID           = P_ITEM_ID;
      --
    EXCEPTION
    WHEN OTHERS THEN
      v_item_STATUS := 'N';
      SELECT LOOKUP_CODE
        || ': '
        || DESCRIPTION
      INTO p_message
      FROM fnd_lookup_values
      WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
      AND UPPER(LOOKUP_CODE) = UPPER('8125');
      --
      --Looping in customer loop to get the cust ids in message for 8125
      IF P_CUST_ID.COUNT > 0 THEN
        FOR VAR IN 1 .. P_CUST_ID.COUNT
        LOOP
          P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
        END LOOP;
      END IF;
      -- Loop ends for customer id concatenation in messages
    END;
    IF V_ITEM_STATUS = 'Y' THEN
      -- Inside the If condition of Item is Valid and orderable
      --Getting KIT Flag
      BEGIN
         SELECT 'Y'
           INTO P_KIT_IND
           FROM mtl_system_items_b
          WHERE organization_id = v_valdn_org
            AND inventory_item_id = P_ITEM_ID
            AND bom_item_type = 1;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            P_KIT_IND := 'N';
      END;
      IF v_kit_ind_on <> 'Y' THEN
         P_KIT_IND := 'N'; -- MYJIRATEST-4757 Ravi S 03-DEC-2014
      END IF;
      --MYJIRATEST-5093 Ravi S 21-JAN-2015
      BEGIN
         SELECT 'Y'
           INTO P_CRITICAL_PART
           FROM oe_hold_definitions ohd, oe_hold_sources_all ohsa, fnd_lookup_values flv
          WHERE ohd.hold_id = ohsa.hold_id
            AND ohd.name = flv.description
            AND flv.lookup_type = 'GEAE_MYGE_CRITICAL_PART_HOLDS'
            AND flv.enabled_flag = 'Y'
            AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(flv.start_date_active,SYSDATE)) AND TRUNC(NVL(flv.end_date_active,SYSDATE))
            AND ohsa.hold_entity_code = 'I'
            AND ohsa.released_flag <>'Y'   -- MYJIRATEST-12046  23-NOV-2015
            AND ohsa.hold_entity_id = P_ITEM_ID
            AND rownum = 1;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            P_CRITICAL_PART := 'N';
      END;
      -- Populating Below the Item details
      SELECT V_PART_DETAILS_LIST_BO(MSI.INVENTORY_ITEM_ID, MSI.SEGMENT1, DECODE(GEAE_MYGE_CTRL_SHIPBILITY(MSI.INVENTORY_ITEM_ID),'Y',NULL,MSI.DESCRIPTION),
             DECODE(v_parent_wh_id,NULL,NULL,GEAE_INV_AMPS_COMMON_UTILS_PKG.GET_CATEGORY_VALUE(v_parent_wh_id,MSI.INVENTORY_ITEM_ID,'Discount Indicator'))) BULK COLLECT
      INTO L_PART_DETAILS
      FROM mtl_system_items_b msi,
        mtl_parameters mtp
      WHERE 1                   = 1
      AND msi.organization_id   = mtp.organization_id
      AND INVENTORY_ITEM_ID     = P_ITEM_ID
      AND MTP.ORGANIZATION_CODE = 'CVO';
      --
      IF SQL%rowcount > 0 THEN
        FOR I IN 1 .. L_PART_DETAILS.COUNT
        LOOP
         V_PART_dtl_cnt  := 0;  --Manisha K. 27 Jul Initializing the variable so that the array P_PART_DETAILS fetch single record.
          V_PART_dtl_cnt := V_PART_dtl_cnt + 1;
        --  P_PART_DETAILS.EXTEND(); --Manisha 14 Dec Have added this code in the beginning outside the loop, to fetch only one record
          P_PART_DETAILS(V_PART_dtl_cnt) := L_PART_DETAILS(I);
        END LOOP;
      END IF;
      --
      IF SQL%ROWCOUNT = 0 THEN
        --
        SELECT LOOKUP_CODE
          || ': '
          || DESCRIPTION
        INTO p_message
        FROM fnd_lookup_values
        WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
        AND UPPER(LOOKUP_CODE) = UPPER('8125');
        --
        --Looping in customer loop to get the cust ids in message for 8125
        IF P_CUST_ID.COUNT > 0 THEN
          FOR VAR IN 1 .. P_CUST_ID.COUNT
          LOOP
            P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
          END LOOP;
        END IF;
        -- Loop ends for customer id concatenation in messages
      END IF;
      --Step -1 get distinct  price lists and price
      IF P_CUST_ID.COUNT > 0 THEN
        --
        V_FLAG_GTA_ERROR       := 'Y';
        V_FLAG_CTRL_SHIP_ERROR := 'Y';
        V_FLAG_AVIALL_ERROR    := 'Y';
        V_FLAG_VENDOR_ERROR    := 'Y';
        V_FLAG_ORG_ERROR       := 'Y';
        V_AMPS_CODE_ERROR      := 'Y';
        V_GENERIC_MESSG_CNT    := 0;
        V_AVAILL_ALL_ERROR     := NULL;
        FOR var IN 1 .. p_CUST_ID.COUNT
        LOOP
          -- to fetch the customer shipping address
          v_price_list_flag := NULL;
          BEGIN
            --
            SELECT V_PRICE_LIST_DTL_BO(stg.PRICE_LIST_ID, stg.account_number, stg.cust_account_id, stg.ORG_ID) BULK COLLECT
            INTO L_PRICE_LIST_DTL
            FROM
              (SELECT DISTINCT HCSUA.PRICE_LIST_ID price_list_id,
                hca.account_number account_number,
                hca.cust_account_id cust_account_id,
                HCSUA.ORG_ID org_id
              FROM hz_parties hp,
                hz_party_sites hps,
                hz_cust_accounts hca,
                hz_cust_acct_sites_all hcasa,
                hz_cust_site_uses_all hcsua
              WHERE hp.party_id                = hps.party_id(+)
              AND hp.party_id                  = hca.party_id(+)
              AND hcasa.party_site_id(+)       = hps.party_site_id
              AND HCSUA.CUST_ACCT_SITE_ID(+)   = HCASA.CUST_ACCT_SITE_ID
              AND HCSUA.PRICE_LIST_ID         IS NOT NULL
              AND hcsua.site_use_code          = 'SHIP_TO'
              AND hps.location_id              = hps.location_id -- AND hps.location_id = hl.location_id
              AND NVL(hcasa.status, 'I')       = 'A'           ----Added NVL
              AND NVL(HCA.STATUS, 'I')         = 'A'           ----Added NVL
              AND NVL(hcsua.primary_flag, 'X') = 'Y'
              AND NVL(hcsua.STATUS, 'I')       = 'A' ----Added NVL
              AND NVL(hps.STATUS, 'I')         = 'A' ----Added NVL
              AND NVL(hp.STATUS, 'I')          = 'A' ----Added NVL
              AND HCSUA.ORG_ID                 = TO_NUMBER(J.OU_ID) -- Added by Ravi S for MYJIRATEST-2758
              AND HCA.CUST_ACCOUNT_ID          = TO_NUMBER(P_CUST_ID(VAR))
              ) stg
            ORDER BY STG.ACCOUNT_NUMBER;
            --
          EXCEPTION
          WHEN NO_DATA_FOUND THEN
            v_price_list_flag := 'N';
          WHEN OTHERS THEN
            v_price_list_flag := 'N';
          END; ---END OF BEGIN OF SELECT STATMENT FOR BULK COLLECT OF PRICELIST
          --Check if the PRICE LIST IDS are NOT NULL else Price cannot be determined
          IF L_PRICE_LIST_DTL.COUNT > 0 THEN
            --
            FOR i IN 1 .. L_PRICE_LIST_DTL.count
            LOOP
              L_PRICE_LIST_DTL_cnt := L_PRICE_LIST_DTL_cnt + 1;
              P_PRICE_LIST_DTL.EXTEND();
              P_PRICE_LIST_DTL(L_PRICE_LIST_DTL_cnt) := L_PRICE_LIST_DTL(i); --BM Commented
            END LOOP;
          ELSE
            --
            NULL;
            --
          END IF;
        END LOOP; ---END LOOP for Lopp of Custids to determine the Pricelist from Active Ship-tos
        IF L_PRICE_LIST_DTL.COUNT = 0 THEN
          --
          SELECT LOOKUP_CODE
            || ': '
            || DESCRIPTION
          INTO p_message
          FROM fnd_lookup_values
          WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
          AND UPPER(LOOKUP_CODE) = UPPER('8137');
          --
          --Looping in customer loop to get the cust ids in message for 8125
          IF P_CUST_ID.COUNT > 0 THEN
            FOR VAR IN 1 .. P_CUST_ID.COUNT
            LOOP
              P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
            END LOOP;
          END IF;
          -- Loop ends for customer id concatenation in messages
        END IF;
      ELSE
        --else of Customer count
        ---Customer Ids are empty hence error
        --
        SELECT LOOKUP_CODE
          || ': '
          || DESCRIPTION
        INTO p_message
        FROM fnd_lookup_values
        WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
        AND UPPER(LOOKUP_CODE) = UPPER('8136');
        --
        --
        --
      END IF;
      --Step 2 get all the BOM and GTA intersection for all customers, consider shippable and vendor parts
      --Step 3 check the control shippability
      FOR var IN 1 .. p_CUST_ID.COUNT
      LOOP
        --
        --
        BEGIN
          SELECT V_PART_VLDTN_BO(CUSTOMER_NUMBER, SUPPLIER_CODE, SHIP_CODE, PAST_SHP_CD, VENDOR_PART, CUST_ACCOUNT_ID ,COMPONENT_ID ,site_to_use,amps_code) BULK COLLECT
          INTO L_PART_VLDTN
          FROM
              (SELECT stg.customer_number,
                stg.supplier_code,
                stg.ship_code,
                stg.past_shp_cd,
                stg.vendor_part,
                STG.CUST_ACCOUNT_ID,
                STG.COMPONENT_ID ,
                stg.site_to_use ,
                stg.amps_code
              FROM
                (SELECT hca.account_number customer_number,
                  bom.attribute8 supplier_code,
                  SUM(
                  CASE
                    WHEN EXISTS
                      (SELECT com.attribute5
                      FROM fnd_flex_value_sets ffs1,
                        FND_FLEX_VALUES_VL FFV1,
                        fnd_lookup_values FLV2,
                        HR_OPERATING_UNITS HOU1,
                        FND_LOOKUP_VALUES FLV1
                      WHERE 1                       = 1
                      AND NVL(ffv1.attribute1, 'N') = 'Y'
                      AND ffv1.flex_value           = com.attribute5
                      AND FFS1.FLEX_VALUE_SET_ID    = FFV1.FLEX_VALUE_SET_ID
                      AND FFS1.FLEX_VALUE_SET_NAME  = flv2.description
                      AND flv2.lookup_code          = flv1.tag
                      AND flv2.lookup_type          = 'GEAE_ONT_PRDLN_SHPCD_OU_LKP'
                      AND flv1.lookup_code          = hou1.organization_id
                      AND FLV1.LOOKUP_TYPE          = 'GEAE_MYGE_OPERATING_UNITS'
                      AND hou1.organization_id      = to_number(J.OU_ID)
                      )
                    THEN 1
                    ELSE 0
                  END) ship_code,
                  SUM(
                  CASE
                    WHEN EXISTS
                      (SELECT com.attribute5
                      FROM HR_OPERATING_UNITS HOU1,
                        FND_LOOKUP_VALUES FLV1,
                        fnd_lookup_values FLV3
                      WHERE 1                       = 1
                      AND flv1.lookup_code          = hou1.organization_id
                      AND FLV1.LOOKUP_TYPE          = 'GEAE_MYGE_OPERATING_UNITS'
                      AND FLV3.lookup_type          = 'GEAE_MYGE_PAST_SHIP_CODES'
                      AND FLV3.tag                  = com.attribute5
                      AND FLV3.enabled_flag         = 'Y'
                      AND FLV3.description          = hou1.organization_id
                      AND hou1.organization_id      = to_number(J.OU_ID)
                      )
                    THEN 1
                    ELSE 0
                  END) past_shp_cd,
                  SUM(
                  CASE
                    WHEN EXISTS
                      (SELECT com.attribute5
                      FROM fnd_lookup_values
                      WHERE lookup_type = 'GEAE_MYGE_VENDOR_CODE'
                      AND lookup_code   = com.attribute5
                      )
                    THEN 1
                    ELSE 0
                  END) vendor_part,
                  hca.cust_account_id cust_account_id,
                  com.component_item_id component_id ,
                  flv.description site_to_use ,
                  com.attribute5 amps_code
                FROM geae_ont_cust_gta_info goc,
                  geae_ont_gta_applblty_v gom,
                  bom_bill_of_materials bom,
                  bom_components_b com,
                  mtl_system_items msi,
                  mtl_parameters mp,
                  hz_cust_accounts_all hca,
                  fnd_lookup_values flv
                WHERE 1                               = 1
                AND gom.engine_model_id               = bom.assembly_item_id
                AND msi.inventory_item_id             = bom.assembly_item_id
                AND com.bill_sequence_id              = bom.bill_sequence_id
                AND com.component_item_id             = p_item_id
                AND hca.cust_account_id               = TO_NUMBER(P_CUST_ID(VAR))
                AND goc.geae_ont_cust_gta_info_seq_id = gom.geae_ont_cust_gta_info_seq_id
                AND goc.customer_id                   = hca.cust_account_id
                AND trunc(goc.end_date)             > = trunc(sysdate)  -- US34704--added by Prasad on 10-NOV-16
                AND NVL(com.disable_date,SYSDATE+1) >  SYSDATE
                AND flv.lookup_type                   = 'GEAE_MYGE_SUPPLIER_ORGS'
                AND flv.enabled_flag                  = 'Y'
                AND TO_NUMBER(flv.description)        = goc.org_id
                AND goc.org_id                        = to_number(J.OU_ID)  --Manisha K 07-DEC Added the OU_ID condition  to fetch the data for cuurent OU_ID as two U_ID will passed in loop; Passport requirement
                AND msi.enabled_flag                  = 'Y'
                AND msi.organization_id               = mp.organization_id
                AND mp.organization_code              = 'CVO'
                AND bom.attribute8                    = flv.meaning
                GROUP BY hca.account_number,
                  bom.attribute8,
                  cust_account_id,
                  com.component_item_id ,
                  FLV.DESCRIPTION,
                  com.attribute5
                ) STG
            );
          --
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
          NULL;
        WHEN OTHERS THEN
          NULL;
        END; ---END of BEGIN of Select statment for bulk collect of Pricelist
        --Check if the PRICE LIST IDS are NOT NULL else Price cannot be determined
        IF L_PART_VLDTN.COUNT = 0 THEN
          --
          --
          --
          BEGIN
            v_cust_account_number := NULL;
            SELECT ACCOUNT_NUMBER
            INTO v_cust_account_number
            FROM hz_cust_accounts
            WHERE 1             = 1
            AND CUST_ACCOUNT_ID = TO_NUMBER(P_CUST_ID(VAR));
          EXCEPTION
          WHEN OTHERS THEN
            V_CUST_ACCOUNT_NUMBER := P_CUST_ID(VAR);
          END;
          --
          --
          IF p_message IS NULL THEN
            SELECT LOOKUP_CODE
              || ': '
              || DESCRIPTION
            INTO p_message
            FROM fnd_lookup_values
            WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
            AND UPPER(LOOKUP_CODE) = UPPER('8127');
            P_MESSAGE             := P_MESSAGE||'~'||P_CUST_ID(VAR);
          ELSE
            P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
          END IF;
          V_FLAG_GTA_ERROR      := 'N';
          IF V_GTA_ERR_MSSG     IS NULL THEN
            V_GTA_ERR_MSSG      := 'Customer GTA does not allow them to buy the part:'||v_cust_account_number;
          ELSE
            V_GTA_ERR_MSSG      := V_GTA_ERR_MSSG||','||v_cust_account_number;
          END IF;
        END IF;
        --IF all results point to other OU, then put a message and come out.
        FOR I IN 1 .. L_PART_VLDTN.COUNT
        LOOP
        DBMS_OUTPUT.PUT_LINE('IN PART... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
           --
          IF J.OU_ID         <> L_PART_VLDTN(I).SITE_TO_USE THEN
           DBMS_OUTPUT.PUT_LINE('1... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
            V_FLAG_ORG_ERROR := 'N';
            --
            IF V_ORG_ERR_MSSG     IS NULL THEN
              V_ORG_ERR_MSSG      := 'Part is being ordered in the wrong OU.'||L_PART_VLDTN(I).CUSTOMER_NUMBER;
            ELSE
              V_ORG_ERR_MSSG      := V_ORG_ERR_MSSG||','||L_PART_VLDTN(I) .CUSTOMER_NUMBER;
            END IF;
            BEGIN
              --
              SELECT attribute2
              INTO v_portal
              FROM FND_LOOKUP_VALUES FLV
              WHERE 1              = 1
              AND flv.lookup_type  = 'GEAE_MYGE_SUPPLIER_ORGS'
              AND flv.enabled_flag = 'Y'
              AND flv.description  = L_PART_VLDTN(I).site_to_use
              AND flv.meaning  =L_PART_VLDTN(I).SUPPLIER_CODE;
            EXCEPTION
            WHEN OTHERS THEN
              --
              v_portal := NULL;
            END;
            --
            IF p_message IS NULL THEN
              SELECT LOOKUP_CODE
                || ': '
                || DESCRIPTION
              INTO p_message
              FROM fnd_lookup_values
              WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
              AND UPPER(LOOKUP_CODE) = UPPER('8126');
              P_MESSAGE             := P_MESSAGE ||'|'||V_PORTAL;
            --ELSE
              --P_MESSAGE := P_MESSAGE ||'|'||V_PORTAL;
            END IF;
            --EXIT;
            CONTINUE; --MYJIRATEST-6058 Ravi S 18-FEB-2015
          END IF;  --J.OU_ID         <> L_PART_VLDTN(I).SITE_TO_USE
        DBMS_OUTPUT.PUT_LINE('2... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
         --
          --Adding the Aviall validation after GTA
          --
          BEGIN
            --
            v_aviall_err_ind := 'N';
            --
            SELECT 'Y'
            INTO v_aviall_part
            FROM mtl_item_categories_v mic
            WHERE 1                                    = 1
            AND SUBSTR(mic.category_concat_segs, 1, 6) = 'AVIALL'
            AND mic.inventory_item_id                  = p_item_id
            AND mic.category_set_name                  = 'GEAE_AMPS_DISTRIBUTION_DEAL'
            AND ROWNUM                                 < 2;
          EXCEPTION
          WHEN OTHERS THEN
            --
            v_aviall_part := 'N';
          END;
          IF V_AVIALL_PART = 'Y' THEN
         DBMS_OUTPUT.PUT_LINE('3... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
            ---Calling the Price API to check if the Part is Priced
            V_AVIALL_SUCESS               := NULL;
            IF NVL(V_PRICE_LIST_FLAG,'Y') <> 'N' THEN
              P_AVIALL_UNIT_PRICE         := NULL;
              FOR PRICELSTID IN
              (SELECT stg.price_list_id,
                stg.account_number,
                STG.CUST_ACCOUNT_ID
              FROM TABLE(CAST(P_PRICE_LIST_DTL AS v_PRICE_LIST_DTL)) stg
              WHERE STG.ACCOUNT_NUMBER = L_PART_VLDTN(I).CUSTOMER_NUMBER
              )
              LOOP
                V_AVIALL_PRICE_LIST_ID := PRICELSTID.PRICE_LIST_ID;
                GET_PRICE(P_SSO ,J.OU_ID, P_ITEM_ID, V_AVIALL_PRICE_LIST_ID, P_AVIALL_UNIT_PRICE, P_AVIALL_LIST_LINE_ID);
                IF P_AVIALL_UNIT_PRICE IS NOT NULL THEN
                  V_AVIALL_SUCESS      := 'Y';
                  EXIT;
                END IF;
              END LOOP;
            ELSE ---NVL(V_PRICE_LIST_FLAG,'Y') <> 'N' then
              IF p_message IS NULL THEN
                SELECT LOOKUP_CODE
                  || ': '
                  || DESCRIPTION
                INTO p_message
                FROM fnd_lookup_values
                WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
                AND UPPER(LOOKUP_CODE) = UPPER('8132');
                --
                p_message := p_message||'~'||P_CUST_ID(VAR);
                --
              ELSE
                P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
              END IF;
              v_aviall_err_ind     := 'Y';
              V_FLAG_AVIALL_ERROR  := 'N';
              IF V_AVIALL_ERR_MSSG IS NULL THEN
                --
                V_AVIALL_ERR_MSSG   := 'The part is a Aviall part :'||L_PART_VLDTN(I).CUSTOMER_NUMBER;
              ELSE
                V_AVIALL_ERR_MSSG   := V_AVIALL_ERR_MSSG||','||L_PART_VLDTN(I).CUSTOMER_NUMBER;
              END IF;
                 EXIT;
            END IF;--NVL(V_PRICE_LIST_FLAG,'Y') <> 'N' then
            --
            -- Checking if the Aviall part has price

           IF V_AVIALL_SUCESS = 'Y' THEN
              NULL;
            ELSE
              IF p_message IS NULL THEN
                SELECT LOOKUP_CODE
                  || ': '
                  || DESCRIPTION
                INTO p_message
                FROM fnd_lookup_values
                WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
                AND UPPER(LOOKUP_CODE) = UPPER('8132');
                --
                p_message := p_message||'~'||P_CUST_ID(VAR);
                --
              ELSE
                P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
              END IF;
              --
              v_aviall_err_ind     := 'Y';
              V_FLAG_AVIALL_ERROR  := 'N';
              IF V_AVIALL_ERR_MSSG IS NULL THEN
                --
                V_AVIALL_ERR_MSSG   := 'The part is a Aviall part :'||L_PART_VLDTN(I).CUSTOMER_NUMBER;
              ELSE
                V_AVIALL_ERR_MSSG   := V_AVIALL_ERR_MSSG||','||L_PART_VLDTN(I).CUSTOMER_NUMBER;
              END IF;
              --
               EXIT;
            END IF;--if V_AVIALL_SUCESS = 'Y'
          END IF;----if V_AVIALL_PART = 'Y' then
          --Aviall Validation ends
        DBMS_OUTPUT.PUT_LINE('4... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
          IF  L_PART_VLDTN(I).AMPS_CODE = 'C' THEN      --US46803-Change ship code C to non shippable in portal
             V_FSCM_SUPPLIER := NULL;
                BEGIN
                  SELECT MIC.CATEGORY_CONCAT_SEGS
                  INTO v_FSCM_supplier
                  FROM MTL_ITEM_CATEGORIES_V MIC,
                    FND_LOOKUP_VALUES FLV,
                    mtl_parameters mp,
                    hr_operating_units hou
                  WHERE 1                   = 1
                  AND MIC.INVENTORY_ITEM_ID = P_ITEM_ID
                  AND MIC.CATEGORY_SET_NAME = 'FSCM supplier'
                  AND mic.organization_id   = mp.organization_id
                  AND flv.lookup_type = 'GEAE_MYGE_PART_APPLICABLE_ORGS'
                  AND mp.organization_code  = flv.tag  --MYJIRATEST-3993 Ravi S 30-OCT-2014
                  AND FLV.DESCRIPTION       = HOU.NAME
                  AND HOU.ORGANIZATION_ID   = TO_NUMBER(J.OU_ID)
                  AND ROWNUM                < 2;
                EXCEPTION
                WHEN OTHERS THEN
                  V_FSCM_SUPPLIER := NULL;
                END;
             IF p_message IS NULL THEN
               dbms_output.put_line('p_message::::'||p_message);
               SELECT LOOKUP_CODE
                 || ': '
                 || DESCRIPTION
               INTO p_message
               FROM fnd_lookup_values
               WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
               AND UPPER(LOOKUP_CODE) = UPPER('8204');
                     --
               P_MESSAGE := P_MESSAGE||'|'||V_FSCM_SUPPLIER||'~'||P_CUST_ID(VAR);
             END IF;
             --
            CONTINUE; --US41783-User customer code is not populating while adding a part to cart
              EXIT;
            END IF;
      DBMS_OUTPUT.PUT_LINE('5... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
       IF  L_PART_VLDTN(I).AMPS_CODE IN('P','Z','N') THEN      --MYJIRATEST-9281 Neelima Y 12-OCT-2015 ---MYJIRATEST-13902 Trupti D. 07-APR-2016
       DBMS_OUTPUT.PUT_LINE('12... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
            V_FSCM_SUPPLIER := NULL;
                BEGIN
                  SELECT MIC.CATEGORY_CONCAT_SEGS
                  INTO v_FSCM_supplier
                  FROM MTL_ITEM_CATEGORIES_V MIC,
                    FND_LOOKUP_VALUES FLV,
                    mtl_parameters mp,
                    hr_operating_units hou
                  WHERE 1                   = 1
                  AND MIC.INVENTORY_ITEM_ID = P_ITEM_ID
                  AND MIC.CATEGORY_SET_NAME = 'FSCM supplier'
                  AND mic.organization_id   = mp.organization_id
                  AND flv.lookup_type = 'GEAE_MYGE_PART_APPLICABLE_ORGS'
                  AND mp.organization_code  = flv.tag  --MYJIRATEST-3993 Ravi S 30-OCT-2014
                  AND FLV.DESCRIPTION       = HOU.NAME
                  AND HOU.ORGANIZATION_ID   = TO_NUMBER(J.OU_ID)
                  AND ROWNUM                < 2;
                EXCEPTION
                WHEN OTHERS THEN
                  V_FSCM_SUPPLIER := NULL;
                END;
             IF p_message IS NULL THEN
               SELECT LOOKUP_CODE
                 || ': '
                 || DESCRIPTION
               INTO p_message
               FROM fnd_lookup_values
               WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
               AND UPPER(LOOKUP_CODE) = UPPER('8203');
                     --
               P_MESSAGE := P_MESSAGE||'|'||V_FSCM_SUPPLIER||'~'||P_CUST_ID(VAR);
             END IF;
             --
             V_AMPS_CODE_ERROR  := 'N';
             IF V_AMPS_CODE_ERR_MSSG IS NULL THEN
               V_AMPS_CODE_ERR_MSSG  := 'Dear Customers, if you need to place an order or know the availability/price of this part, contact CAM:'||L_PART_VLDTN(I) .CUSTOMER_NUMBER;
             ELSE
               V_AMPS_CODE_ERR_MSSG := V_AMPS_CODE_ERR_MSSG||','||L_PART_VLDTN(I) .CUSTOMER_NUMBER;
             END IF;
            CONTINUE;
              EXIT;
        ELSE
          IF L_PART_VLDTN(I).SHIP_CODE > 0 THEN
          DBMS_OUTPUT.PUT_LINE('13... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
            --
            --If all ship codes are past use, validate procurement code and on hand

           IF L_PART_VLDTN(I).SHIP_CODE = L_PART_VLDTN(I).PAST_SHP_CD THEN

DBMS_OUTPUT.PUT_LINE('14... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
  --            v_proc_status
               BEGIN
                  SELECT mcb.segment1
                    INTO v_proc_code
                    FROM mtl_item_categories mic, mtl_category_sets mcs, mtl_categories_b mcb, mtl_parameters mp, fnd_lookup_values supp
                   WHERE mic.category_set_id = mcs.category_set_id
                     AND mic.category_id = mcb.category_id
                     AND mic.organization_id = mp.organization_id
                     AND mcs.category_set_name = 'Procurement Code'
                     AND supp.lookup_type = 'GEAE_MYGE_SUPPLIER_ORGS'
                     AND supp.description = J.OU_ID
                     AND mp.organization_code = supp.attribute1
                     AND supp.meaning = L_PART_VLDTN(I).SUPPLIER_CODE
                     AND mic.inventory_item_id = L_PART_VLDTN(I).COMPONENT_ID;
               EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                     v_proc_code := 'NA';
               END;
               IF v_proc_code IS NULL THEN
                  v_proc_code := 'NA';
               END IF;
               IF v_proc_code IN ('X','Y','NA') THEN
                  v_proc_status := 'Y';
               ELSE
                  BEGIN
                   --Added by OWMS Team : Start
                           v_item_source := NULL;
                           v_item_number := NULL;
                           BEGIN
                             SELECT DISTINCT segment1
                                 INTO v_item_number
                                 FROM mtl_system_items_b
                                 WHERE INVENTORY_ITEM_ID   = P_ITEM_ID;
                             EXCEPTION
                               WHEN OTHERS THEN
                                          v_item_number := NULL;
                             END;
                               --
                              SELECT DECODE(COUNT(1),1,'Y','N')
                              INTO v_hnd_flag
                               FROM HR_OPERATING_UNITS HOU,
                                  FND_LOOKUP_VALUES FLV
                              WHERE  HOU.ORGANIZATION_ID = TO_NUMBER(j.OU_ID) --116797
                                AND HOU.NAME = FLV.DESCRIPTION
                                AND FLV.TAG = 'HAI'
                                AND FLV.LOOKUP_TYPE = 'GEAE_MYGE_PART_APPLICABLE_ORGS';
                               --
                               IF v_hnd_flag = 'Y' THEN
					   v_item_source := 'HAI';
                               ELSIF v_hnd_flag = 'N' THEN
					   --
					   v_er1_source := GEAE_INV_GET_SOURCE_CODE ('ER1',v_item_number,'Y');
					   v_er2_source := GEAE_INV_GET_SOURCE_CODE ('ER2',v_item_number,'Y');
					   v_er3_source := GEAE_INV_GET_SOURCE_CODE ('ER3',v_item_number,'Y');
					   --
					   IF v_er1_source = 'CPL' OR v_er2_source = 'CPL' OR v_er3_source = 'CPL' THEN
						v_item_source := 'CPL';
					   ELSE
						 v_item_source := 'ERL';
					   END IF;
					   --
                               END IF;
                               --
                            SELECT NVL(SUM(QTY),0)
                                INTO v_on_hand
                                FROM (SELECT (A.QTY - B.QTY)  QTY
				    FROM (SELECT (geae_wms_total_onhand_erl_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
						geae_wms_total_pick_release(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
						 FROM apps.mtl_system_items_b msib,
						      apps.mtl_parameters mp
						 WHERE 1 = 1
						   and msib.inventory_item_id = L_PART_VLDTN(I).COMPONENT_ID
						   and msib.organization_id = mp.organization_id
						   and mp.organization_code = v_item_source
						   AND v_item_source NOT IN ('CPL','HAI')) A,
					 (SELECT (geae_wms_resv_qty_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
						geae_wms_total_resv(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
						 FROM apps.mtl_system_items_b msib,
						      apps.mtl_parameters mp
						 WHERE 1 = 1
						   and msib.inventory_item_id = L_PART_VLDTN(I).COMPONENT_ID
						   and msib.organization_id = mp.organization_id
						   and mp.organization_code = v_item_source
						   AND v_item_source NOT IN ('CPL','HAI')) B
                                      UNION ALL -- Neelima Y MYJIRATEST-8631 on 18-AUG-2015
                                      SELECT SUM(HND.QTY)
                                        FROM (SELECT DISTINCT MSIB.INVENTORY_ITEM_ID, GIF.ONHAND_QTY QTY
                                                FROM GEAE_INV_FOXTROT_DATA_STG GIF,
                                                     MTL_SYSTEM_ITEMS_B        MSIB,
                                                     HR_OPERATING_UNITS        HOU,
                                                     MTL_PARAMETERS            MTP,
                                                     FND_LOOKUP_VALUES         FLV
                                               WHERE MSIB.SEGMENT1 = GIF.PRT_NUM
                                                 AND HOU.ORGANIZATION_ID = TO_NUMBER(J.OU_ID)
                                                 AND HOU.NAME = FLV.DESCRIPTION
                                                 AND MTP.ORGANIZATION_CODE = FLV.TAG
           			                 AND FLV.TAG	= v_item_Source
						 AND v_item_Source NOT IN ('CPL','ERL')
                                                 AND FLV.LOOKUP_TYPE = 'GEAE_MYGE_PART_APPLICABLE_ORGS'
                                                 AND GIF.ORG_CODE = MTP.ORGANIZATION_CODE
                                                 AND MSIB.INVENTORY_ITEM_ID = L_PART_VLDTN(I).COMPONENT_ID
                                                 AND GIF.SRC_SYS = 'HONDA') HND
                                      UNION
                                      SELECT (A.QTY - B.QTY)  QTY
                                        FROM (SELECT NVL(SUM(MOQ.TRANSACTION_QUANTITY), 0) QTY
                                                FROM GEAE_INV_MTL_ONHANDS_V MOQ
                                               WHERE INVENTORY_ITEM_ID = L_PART_VLDTN(I).COMPONENT_ID
                                                 AND SUBINVENTORY_CODE IN ('STOCK','STG')
                                                 AND ORGANIZATION_ID IN
                                                     (SELECT ORGANIZATION_ID
                                                        FROM MTL_PARAMETERS
                                                       WHERE ORGANIZATION_CODE = V_ITEM_SOURCE)
                                                  AND v_item_source NOT IN ('ERL','HAI')    ) A,
                                             (SELECT NVL(SUM(RESERVATION_QUANTITY), 0) QTY
                                                FROM MTL_RESERVATIONS
                                               WHERE INVENTORY_ITEM_ID = L_PART_VLDTN(I).COMPONENT_ID
                                                 AND ORGANIZATION_ID IN
                                                     (SELECT ORGANIZATION_ID
                                                        FROM MTL_PARAMETERS
                                                       WHERE ORGANIZATION_CODE = V_ITEM_SOURCE)
                                                  AND v_item_source NOT IN ('ERL','HAI')    ) B);
--Added by OWMS Team : END
                  EXCEPTION
                     WHEN NO_DATA_FOUND THEN
                        v_on_hand := 0;
                  END;
                  IF v_on_hand > 0 THEN
                     v_proc_status := 'Y';
                  ELSE
                     v_proc_status := 'N';
                  END IF;
              DBMS_OUTPUT.PUT_LINE('17... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
         END IF;
            --Fetch data for proc_yes
            END IF;
            IF (L_PART_VLDTN(I).SHIP_CODE = L_PART_VLDTN(I).PAST_SHP_CD AND v_proc_status = 'Y') OR L_PART_VLDTN(I).SHIP_CODE > L_PART_VLDTN(I).PAST_SHP_CD THEN
            DBMS_OUTPUT.PUT_LINE('15... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
            DBMS_OUTPUT.PUT_LINE('L_PART_VLDTN(I).SHIP_CODE-->'||L_PART_VLDTN(I).SHIP_CODE);
            DBMS_OUTPUT.PUT_LINE('L_PART_VLDTN(I).PAST_SHP_CD-->'||L_PART_VLDTN(I).PAST_SHP_CD);
            DBMS_OUTPUT.PUT_LINE('v_proc_status-->'||v_proc_status);
            DBMS_OUTPUT.PUT_LINE('L_PART_VLDTN(I).PAST_SHP_CD-->'||L_PART_VLDTN(I).PAST_SHP_CD);
               BEGIN
                 SELECT mp.organization_id
                 INTO V_ORG_ID
                 FROM MTL_PARAMETERS MP,
                   FND_LOOKUP_VALUES FLV
                 WHERE 1                  = 1
                 AND MP.ORGANIZATION_CODE = FLV.ATTRIBUTE1
                 AND FLV.meaning          = L_PART_VLDTN(I).SUPPLIER_CODE
                 AND FLV.LOOKUP_TYPE      = 'GEAE_MYGE_SUPPLIER_ORGS';
               EXCEPTION
               WHEN OTHERS THEN
                 v_org_id := 60378;
               END ;
               --
               V_CONTROL_SHIP      := NVL(GEAE_AMPS_OM_CONFIG_VAL.FUN_CONTROL_SHIPPABLE_ITEM(L_PART_VLDTN(I).COMPONENT_ID, L_PART_VLDTN(I).CUST_ACCOUNT_ID, V_ORG_ID, L_PART_VLDTN(I).SITE_TO_USE), 0);
               v_control_shippable := NVL(geae_inv_amps_common_utils_pkg.get_category_value(V_ORG_ID, L_PART_VLDTN(I).component_id, 'Control Shippable'), 'N');
               IF V_CONTROL_SHIP IN (1, 3) THEN
                 --
                 IF V_CONTROL_SHIPPABLE = 'A' THEN
                   --
                   IF p_message IS NULL THEN
                     SELECT LOOKUP_CODE
                       || ': '
                       || DESCRIPTION
                     INTO p_message
                     FROM fnd_lookup_values
                     WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
                     AND UPPER(LOOKUP_CODE) = UPPER('8135');
                     --
                     P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
                   ELSE
                     P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
                   END IF;
                   --
                   V_FLAG_CTRL_SHIP_ERROR  := 'N';
                   IF V_CTRL_SHIP_ERR_MSSG IS NULL THEN
                     V_CTRL_SHIP_ERR_MSSG  := 'Part is approval required but customer doesnot have Approval :'||L_PART_VLDTN(I) .CUSTOMER_NUMBER;
                   ELSE
                     V_CTRL_SHIP_ERR_MSSG := V_CTRL_SHIP_ERR_MSSG||','||L_PART_VLDTN(I) .CUSTOMER_NUMBER;
                   END IF;
                     EXIT;
                 ELSE
                   --
                   IF p_message IS NULL THEN
                     SELECT LOOKUP_CODE
                       || ': '
                       || DESCRIPTION
                     INTO p_message
                     FROM fnd_lookup_values
                     WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
                     AND UPPER(LOOKUP_CODE) = UPPER('8129');
                     --
                     P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
                   ELSE
                     P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
                   END IF;
                   --
                   V_FLAG_CTRL_SHIP_ERROR  := 'N';
                   IF V_CTRL_SHIP_ERR_MSSG IS NULL THEN
                     V_CTRL_SHIP_ERR_MSSG  := 'Part is a license control and customer is not set up to buy it:'||L_PART_VLDTN(I) .CUSTOMER_NUMBER;
                   ELSE
                     V_CTRL_SHIP_ERR_MSSG := V_CTRL_SHIP_ERR_MSSG||','||L_PART_VLDTN(I) .CUSTOMER_NUMBER;
                   END IF;
                     EXIT;
                 END IF;  --end of V_CONTROL_SHIPPABLE = 'A'
               END IF;  -- end of V_CONTROL_SHIP IN (1, 3)
         DBMS_OUTPUT.PUT_LINE('16... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
         ELSIF L_PART_VLDTN(I).SHIP_CODE = L_PART_VLDTN(I).PAST_SHP_CD AND v_proc_status = 'N' THEN
         DBMS_OUTPUT.PUT_LINE('19... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
              IF P_message IS NULL THEN
                  SELECT LOOKUP_CODE
                         || ': '
                         || DESCRIPTION
                    INTO p_message
                    FROM fnd_lookup_values
                   WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
                     AND UPPER(LOOKUP_CODE) = UPPER('8179');
                   --
                  P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
               ELSE
                  P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
               END IF;
               --
              continue;
                  EXIT;
            END IF;  --  IF (L_PART_VLDTN(I).SHIP_CODE = L_PART_VLDTN(I).PAST_SHP_CD AND v_proc_status = 'Y')
          ELSIF L_PART_VLDTN(I).VENDOR_PART > 0 THEN
            --   Adding logic to get the FSCM supplier from Item Category
           DBMS_OUTPUT.PUT_LINE('20... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
           V_FSCM_SUPPLIER := NULL;
            BEGIN
              SELECT MIC.CATEGORY_CONCAT_SEGS
              INTO v_FSCM_supplier
              FROM MTL_ITEM_CATEGORIES_V MIC,
                FND_LOOKUP_VALUES FLV,
                mtl_parameters mp,
                hr_operating_units hou
              WHERE 1                   = 1
              AND MIC.INVENTORY_ITEM_ID = P_ITEM_ID
              AND MIC.CATEGORY_SET_NAME = 'FSCM supplier'
              AND mic.organization_id   = mp.organization_id
              AND flv.lookup_type = 'GEAE_MYGE_PART_APPLICABLE_ORGS'
              AND mp.organization_code  = flv.tag  --MYJIRATEST-3993 Ravi S 30-OCT-2014
              AND FLV.DESCRIPTION       = HOU.NAME
              AND HOU.ORGANIZATION_ID   = TO_NUMBER(J.OU_ID)
              AND ROWNUM                < 2;
            EXCEPTION
            WHEN OTHERS THEN
              V_FSCM_SUPPLIER := NULL;
            END;
            --   Adding logic to get the FSCM supplier from Item Category
            IF P_MESSAGE IS NULL THEN
              SELECT LOOKUP_CODE
                || ': '
                || DESCRIPTION
              INTO p_message
              FROM fnd_lookup_values
              WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
              AND UPPER(LOOKUP_CODE) = UPPER('8131');
              --
              P_MESSAGE := P_MESSAGE||'|'||V_FSCM_SUPPLIER;
           -- ELSE
           --   P_MESSAGE := P_MESSAGE||'|'||V_FSCM_SUPPLIER;
            END IF;
            V_FLAG_VENDOR_ERROR   := 'N';
            IF V_VENDOR_ERR_MSSG  IS NULL THEN
              V_VENDOR_ERR_MSSG   := 'Vendor part and GE does not have permission to sell this part to the customer:'||L_PART_VLDTN(I).CUSTOMER_NUMBER;
            ELSE
              V_VENDOR_ERR_MSSG   := V_VENDOR_ERR_MSSG||','||L_PART_VLDTN(I) .CUSTOMER_NUMBER;
            END IF;
              EXIT;
            --
          DBMS_OUTPUT.PUT_LINE('18... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
          ELSE
            IF P_message IS NULL THEN
              SELECT LOOKUP_CODE
                || ': '
                || DESCRIPTION
              INTO p_message
              FROM fnd_lookup_values
              WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
              AND UPPER(LOOKUP_CODE) = UPPER('8125');
              --
              P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
            ELSE
              P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
            END IF;
            --
          --  EXIT; --JIRA 12358 TRUPTI D. 28-12-2015
DBMS_OUTPUT.PUT_LINE('22... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
          END IF;
          DBMS_OUTPUT.PUT_LINE('21... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
        END IF;  -- end if for ampcode =P Z N
        DBMS_OUTPUT.PUT_LINE('6... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
          -- line is control shippable then get the pricelist
          --
          --Adding if to check if the customer has the price list attached if not then populate the Applicability array and price will be NULL;
          IF NVL(v_price_list_flag,'Y') <> 'N' THEN
            DBMS_OUTPUT.PUT_LINE('7... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
            FOR PRICELSTID IN
            (SELECT stg.price_list_id,
              stg.account_number,
              STG.CUST_ACCOUNT_ID
            FROM TABLE(CAST(P_PRICE_LIST_DTL AS v_PRICE_LIST_DTL)) stg
            WHERE STG.ACCOUNT_NUMBER = L_PART_VLDTN(I) .CUSTOMER_NUMBER
            )
            LOOP
            DBMS_OUTPUT.PUT_LINE('8... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
              --
              P_UNIT_PRICE    := NULL;
              V_PRICE_LIST_ID := PRICELSTID.PRICE_LIST_ID;
              v_cust_account_id := PRICELSTID.cust_account_id;
              V_PUBLISH         := NULL;
              v_price_list_api  := NULL;
              --Calling the procedure GET_PRICE which internally calls  QP_PREQ_PUB.PRICE_REQUEST
              IF V_PRICE_LIST_ID <> NVL(V_PRICE_LIST_ID_OLD, 0) OR V_CUST_ACCOUNT_ID <> NVL(V_CUST_ACCOUNT_ID_OLD, 0) THEN
              DBMS_OUTPUT.PUT_LINE('9... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
                v_price_list_id_old   := v_price_list_id;
                V_Cust_Account_Id_Old := V_Cust_Account_Id;
                GET_PRICE(P_SSO,J.OU_ID, P_ITEM_ID, V_PRICE_LIST_ID, P_UNIT_PRICE, P_LIST_LINE_ID);
                IF P_UNIT_PRICE     IS NOT NULL THEN
                  IF P_LIST_LINE_ID IS NOT NULL THEN
                    BEGIN
                      SELECT NVL(ATTRIBUTE13,'Y')
                             ,list_header_id
                      INTO V_PUBLISH
                           ,v_price_list_api
                      FROM QP_LIST_LINES
                      WHERE 1          = 1
                      AND LIST_LINE_ID = P_LIST_LINE_ID;
                    EXCEPTION
                    WHEN OTHERS THEN
                      V_PUBLISH := 'N';
                      v_price_list_api := NULL;
                    END;
                    IF V_PUBLISH = 'Y' THEN
                      SELECT V_PART_PRICE_LIST_BO(GQIPV.inventory_item_id, GET_PRICE_LIST_NAME(V_PRICE_LIST_ID), P_UNIT_PRICE, NVL(GQIPV.CATALOG_UPQ,1), GQIPV.CATALOG_LEAD_TIME) BULK COLLECT
                      INTO L_PART_PRICE_V
                      FROM GEAE_QP_ITEM_PRICES_V GQIPV,
                        QP_LIST_HEADERS_TL QLH
                      WHERE 1                     = 1
                      AND GQIPV.inventory_item_id = to_char(P_ITEM_ID)
                      AND GQIPV.PRICE_LIST_NAME   = QLH.NAME
                      AND QLH.LIST_HEADER_ID      = v_price_list_api; --L_PRICE_LIST_ID(PRICELSTID);
                      --
                      IF SQL%rowcount > 0 THEN
                        FOR i IN 1 .. L_PART_PRICE_V.count
                        LOOP
                          v_PART_PRICE_V_add := v_PART_PRICE_V_add + 1;
                          l_PART_PRICE_DUP.extend();
                          l_PART_PRICE_DUP(v_PART_PRICE_V_add) := L_PART_PRICE_V(i); --BM Commented
                        END LOOP;
                      ELSE
                        IF p_message IS NULL THEN
                          SELECT LOOKUP_CODE
                            || ': '
                            || DESCRIPTION
                          INTO p_message
                          FROM fnd_lookup_values
                          WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
                          AND UPPER(LOOKUP_CODE) = UPPER('8134');
                          --
                          P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
                        ELSE
                          P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
                        END IF;
                        --
                        EXIT;
                      END IF;
                      --Adding condition to check for No data for QLH.LIST_HEADER_ID
                      SELECT   COUNT(*) INTO l_List_id_count
                           FROM     GEAE_QP_ITEM_PRICES_V GQIPV,
                                    QP_LIST_HEADERS_TL QLH
                           WHERE 1                     = 1
                            AND GQIPV.inventory_item_id = to_char(P_ITEM_ID)
                            AND GQIPV.PRICE_LIST_NAME   = QLH.NAME
                            AND QLH.LIST_HEADER_ID      = v_price_list_api;
                         IF (l_List_id_count)>0 THEN
                         DBMS_OUTPUT.PUT_LINE('10... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
                          --Ravi S: Price list id is passed even if part does not exist in price list MYJIRATEST-2629
                          SELECT V_PART_APPLICABLE_LIST_BO(GQIPV.inventory_item_id,PRICELSTID.account_number, L_PART_VLDTN(I).supplier_code, PRICELSTID.cust_account_id, NVL(GQIPV.CATALOG_UPQ,1), v_price_list_id) BULK COLLECT
                          INTO L_PART_APPLICABLE
                          FROM GEAE_QP_ITEM_PRICES_V GQIPV,
                            QP_LIST_HEADERS_TL QLH
                          WHERE 1                     = 1
                          AND GQIPV.inventory_item_id = P_ITEM_ID
                          AND GQIPV.PRICE_LIST_NAME   = QLH.NAME
                          AND QLH.LIST_HEADER_ID      = v_price_list_api; --L_PRICE_LIST_ID(PRICELSTID);
                        ELSE -- Ankita S:L_PART_APPLICABLE varray will still be populated
                          SELECT V_PART_APPLICABLE_LIST_BO(P_ITEM_ID,PRICELSTID.account_number, L_PART_VLDTN(I).supplier_code, PRICELSTID.cust_account_id, 1, v_price_list_id) BULK COLLECT
                          INTO L_PART_APPLICABLE
                          FROM GEAE_QP_ITEM_PRICES_V GQIPV
                          WHERE 1                     = 1
                        --  AND GQIPV.inventory_item_id = P_ITEM_ID
                          AND rownum = 1;
                        END IF;
                        DBMS_OUTPUT.PUT_LINE('11... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
                      --
                      IF SQL%rowcount > 0 THEN
                        FOR i IN 1 .. L_PART_APPLICABLE.count
                        LOOP
                          V_PART_APPL_CNT := V_PART_APPL_CNT + 1;
                          l_PART_APPLICABLE_DUP.extend();
                          l_PART_APPLICABLE_DUP(V_PART_APPL_CNT) := L_PART_APPLICABLE(i); --BM Commented
                        END LOOP;
                      ELSE
                        IF p_message IS NULL THEN
                          SELECT LOOKUP_CODE
                            || ': '
                            || DESCRIPTION
                          INTO p_message
                          FROM fnd_lookup_values
                          WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
                          AND UPPER(LOOKUP_CODE) = UPPER('8134'); -----
                          --
                          P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
                        ELSE
                          P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
                        END IF;
                        --
                      END IF;
                      --
                  DBMS_OUTPUT.PUT_LINE('PRICELSTID.account_number3-->'||PRICELSTID.account_number||' '||'L_PART_VLDTN(I) .supplier_code3-->'||L_PART_VLDTN(I) .supplier_code);
                   ELSE --ELSE OF  V_PUBLISH = 'Y' THEN
                      ---Part is priced but publish is N
                      --Populating the Applicability Array such that the Item can be bought
                      ---Populating The Applicability Array even if the Price is nULL as Customer can still buy the parts if the Price is not there Ravi S: However price list id can be passed. MYJIRATEST-2629
                      DBMS_OUTPUT.PUT_LINE('PRICELSTID.account_number-->'||PRICELSTID.account_number||' '||'L_PART_VLDTN(I) .supplier_code-->'||L_PART_VLDTN(I) .supplier_code);
                      SELECT V_PART_APPLICABLE_LIST_BO(msi.inventory_item_id, PRICELSTID.account_number, L_PART_VLDTN(I) .supplier_code, PRICELSTID.cust_account_id, 1, V_PRICE_LIST_ID) BULK COLLECT
                      INTO L_PART_APPLICABLE
                      FROM mtl_system_items_b msi,
                        mtl_parameters mp
                      WHERE 1                   = 1
                      AND msi.inventory_item_id = P_ITEM_ID
                      AND msi.organization_id   = mp.organization_id
                     AND mp.organization_code  = 'CVO';
                     DBMS_OUTPUT.PUT_LINE('PRICELSTID.account_number1-->'||PRICELSTID.account_number||' '||'L_PART_VLDTN(I) .supplier_code1-->'||L_PART_VLDTN(I) .supplier_code);

                      --
                      IF SQL%rowcount > 0 THEN
                        FOR i IN 1 .. L_PART_APPLICABLE.count
                        LOOP
                          V_PART_APPL_CNT := V_PART_APPL_CNT + 1;
                          l_PART_APPLICABLE_DUP.extend();
                         l_PART_APPLICABLE_DUP(V_PART_APPL_CNT) := L_PART_APPLICABLE(i); --BM Commented
                        END LOOP;
                      ELSE
                        IF p_message IS NULL THEN
                          SELECT LOOKUP_CODE
                            || ': '
                            || DESCRIPTION
                          INTO p_message
                          FROM fnd_lookup_values
                          WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
                          AND UPPER(LOOKUP_CODE) = UPPER('8139'); -----
                          --
                          P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
                        ELSE
                          P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
                        END IF;
                        --
                      END IF;
                    END IF; --v_publish is not null and v_publish is 'Y'
                  END IF;   -- P_LIST_LINE_ID is not null
                ELSE        --ELSE OF IF P_UNIT_PRICE IS NOT NULL THEN
                  ---Populating The Applicability Array even if the Price is nULL as Customer can still buy the parts if the Price is not there. Ravi S: However price list id can be passed.  MYJIRATEST-2629
                  DBMS_OUTPUT.PUT_LINE('PRICELSTID.account_number2-->'||PRICELSTID.account_number||' '||'L_PART_VLDTN(I) .supplier_code2-->'||L_PART_VLDTN(I) .supplier_code);
                  SELECT V_PART_APPLICABLE_LIST_BO(msi.inventory_item_id, PRICELSTID.account_number, L_PART_VLDTN(I) .supplier_code, PRICELSTID.cust_account_id, 1, V_PRICE_LIST_ID) BULK COLLECT
                  INTO L_PART_APPLICABLE
                  FROM mtl_system_items_b msi,
                    mtl_parameters mp
                  WHERE 1                   = 1
                  AND msi.inventory_item_id = P_ITEM_ID
                  AND msi.organization_id   = mp.organization_id
                  AND mp.organization_code  = 'CVO';
                  --
                  IF SQL%rowcount > 0 THEN
                    FOR i IN 1 .. L_PART_APPLICABLE.count
                    LOOP
                      V_PART_APPL_CNT := V_PART_APPL_CNT + 1;
                      l_PART_APPLICABLE_DUP.extend();
                      l_PART_APPLICABLE_DUP(V_PART_APPL_CNT) := L_PART_APPLICABLE(i); --BM Commented
                    END LOOP;
                  ELSE
                    IF p_message IS NULL THEN
                      SELECT LOOKUP_CODE
                        || ': '
                        || DESCRIPTION
                      INTO p_message
                      FROM fnd_lookup_values
                      WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
                      AND UPPER(LOOKUP_CODE) = UPPER('8139'); -----
                      --
                      P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
                    ELSE
                      P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
                    END IF;
                    --
                  END IF;
                END IF; -- IF P_UNIT_PRICE IS NOT NULL THEN
             --END IF;
              END IF;  --- IF v_price_list_id <> NVL(v_price_list_id_old, 0) OR
            END LOOP;   --FOR PRICELSTID IN
          ELSE         ---ELSE OF  IF NVL(v_price_list_flag,'Y') <> 'N' THEN
            --Price list could not be detrmined at customer ship to level Populating the Applicability array as customer can still buy the part
          DBMS_OUTPUT.PUT_LINE('L_PART_VLDTN(I).CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
           SELECT V_PART_APPLICABLE_LIST_BO(msi.inventory_item_id, L_PART_VLDTN(I).CUSTOMER_NUMBER, L_PART_VLDTN(I).supplier_code, L_PART_VLDTN(I).CUST_ACCOUNT_ID, 1, NULL) BULK COLLECT
            INTO L_PART_APPLICABLE
            FROM mtl_system_items_b msi,
              mtl_parameters mp
            WHERE 1                   = 1
            AND msi.inventory_item_id = P_ITEM_ID
            AND msi.organization_id   = mp.organization_id
            AND mp.organization_code  = 'CVO';
            --
            IF SQL%rowcount > 0 THEN
              FOR i IN 1 .. L_PART_APPLICABLE.count
              LOOP
                V_PART_APPL_CNT := V_PART_APPL_CNT + 1;
                l_PART_APPLICABLE_DUP.extend();
                l_PART_APPLICABLE_DUP(V_PART_APPL_CNT) := L_PART_APPLICABLE(i); --BM Commented
              END LOOP;
            ELSE
              IF p_message IS NULL THEN
                SELECT LOOKUP_CODE
                  || ': '
                  || DESCRIPTION
                INTO p_message
                FROM fnd_lookup_values
                WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
                AND UPPER(LOOKUP_CODE) = UPPER('8139'); -----
                --
                P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
              ELSE
                P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
              END IF;
              --
            END IF;
            --
          END IF; ---END IF OF  IF NVL(v_price_list_flag,'Y') <> 'N' THEN
DBMS_OUTPUT.PUT_LINE('IN PART... CUSTOMER_NUMBER1-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
DBMS_OUTPUT.PUT_LINE('IN CUST... p_CUST_ID(var)1-->'||p_CUST_ID(var));
        END LOOP;  --FOR I IN 1 .. L_PART_VLDTN.COUNT LOOP
        --
      END LOOP; --FOR var IN 1 .. p_CUST_ID.COUNT LOOP
      ---
      --Populating the Onhand VArray outside Customer Loop.
      --
--Added by OWMS Team : START
         v_item_source := NULL;
         v_item_number := NULL;
         BEGIN
           SELECT DISTINCT segment1
               INTO v_item_number
               FROM mtl_system_items_b
               WHERE INVENTORY_ITEM_ID   = P_ITEM_ID;
           EXCEPTION
             WHEN OTHERS THEN
                        v_item_number := NULL;
           END;
	  --
		SELECT DECODE(COUNT(1),1,'Y','N')
		INTO v_hnd_flag
		 FROM HR_OPERATING_UNITS HOU,
			  FND_LOOKUP_VALUES FLV
		WHERE  HOU.ORGANIZATION_ID = TO_NUMBER(j.OU_ID) --116797
		  AND HOU.NAME = FLV.DESCRIPTION
		  AND FLV.TAG = 'HAI'
		  AND FLV.LOOKUP_TYPE = 'GEAE_MYGE_PART_APPLICABLE_ORGS';
	   --
	   IF v_hnd_flag = 'Y' THEN
	     v_item_source := 'HAI';
	   ELSIF v_hnd_flag = 'N' THEN
	   --
	   v_er1_source := GEAE_INV_GET_SOURCE_CODE ('ER1',v_item_number,'Y');
	   v_er2_source := GEAE_INV_GET_SOURCE_CODE ('ER2',v_item_number,'Y');
	   v_er3_source := GEAE_INV_GET_SOURCE_CODE ('ER3',v_item_number,'Y');
	   --
	   IF v_er1_source = 'CPL' OR v_er2_source = 'CPL' OR v_er3_source = 'CPL' THEN
		v_item_source := 'CPL';
	   ELSE
		 v_item_source := 'ERL';
	   END IF;
	   --
	   END IF;
      SELECT V_PART_AVAILABILITY_LIST_BO(tab.INVENTORY_ITEM_ID, tab.ORGANIZATION_CODE, NVL(tab.QTY,0)) BULK collect
      INTO L_PART_AVAIL
      FROM
      (SELECT STG.INVENTORY_ITEM_ID,STG.ORGANIZATION_CODE,sum(stg.qty) qty
          FROM (SELECT P_ITEM_ID INVENTORY_ITEM_ID ,
                        'On-Hand Stock' ORGANIZATION_CODE,
                         (a.qty-b.qty) QTY
            FROM (SELECT (geae_wms_total_onhand_erl_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
			geae_wms_total_pick_release(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
			 FROM apps.mtl_system_items_b msib,
			      apps.mtl_parameters mp
			 WHERE 1 = 1
			   and msib.inventory_item_id = P_ITEM_ID
			   and msib.organization_id = mp.organization_id
			   and mp.organization_code = v_item_source
			   AND v_item_source NOT IN ('CPL','HAI')) A,
                 (SELECT (geae_wms_resv_qty_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
			geae_wms_total_resv(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
			 FROM apps.mtl_system_items_b msib,
			      apps.mtl_parameters mp
			 WHERE 1 = 1
			   and msib.inventory_item_id = P_ITEM_ID
			   and msib.organization_id = mp.organization_id
			   and mp.organization_code = v_item_source
			   AND v_item_source NOT IN ('CPL','HAI')) B
           UNION ALL
                SELECT P_ITEM_ID INVENTORY_ITEM_ID ,
                        'On-Hand Stock' ORGANIZATION_CODE,
                        (b.qty-c.qty) QTY
                FROM
                     (SELECT NVL(SUM(MOQ.TRANSACTION_QUANTITY),0) qty
                        FROM GEAE_INV_MTL_ONHANDS_V MOQ
                       WHERE INVENTORY_ITEM_ID = P_ITEM_ID
                         AND SUBINVENTORY_CODE IN ('STOCK','STG')
                         AND ORGANIZATION_ID IN (SELECT ORGANIZATION_ID
                                                   FROM MTL_PARAMETERS
                                                  WHERE ORGANIZATION_CODE = V_ITEM_SOURCE)
                          AND v_item_source NOT IN ('ERL','HAI')
                    ) b,
                 (SELECT NVL(SUM(RESERVATION_QUANTITY),0) qty
                             FROM MTL_RESERVATIONS
                     WHERE INVENTORY_ITEM_ID = P_ITEM_ID
                         AND ORGANIZATION_ID IN (SELECT ORGANIZATION_ID
                                                   FROM MTL_PARAMETERS
                                                  WHERE ORGANIZATION_CODE = V_ITEM_SOURCE)
                          AND v_item_source NOT IN ('ERL','HAI')
                   ) C
        UNION ALL
        SELECT DISTINCT MSIB.INVENTORY_ITEM_ID,
                'On-Hand Stock' ORGANIZATION_CODE,
               GIF.ONHAND_QTY  QTY
          FROM GEAE_INV_FOXTROT_DATA_STG GIF,
               MTL_SYSTEM_ITEMS_B MSIB,
               HR_OPERATING_UNITS HOU,
               MTL_PARAMETERS MTP,
               FND_LOOKUP_VALUES FLV
         WHERE MSIB.SEGMENT1=GIF.PRT_NUM
           AND HOU.ORGANIZATION_ID       = TO_NUMBER(J.OU_ID)
           AND HOU.NAME                   = FLV.DESCRIPTION
           AND MTP.ORGANIZATION_CODE      = FLV.TAG
	        AND FLV.TAG					 = v_item_Source
            AND v_item_source NOT IN ('ERL','CPL')
           AND FLV.LOOKUP_TYPE            = 'GEAE_MYGE_PART_APPLICABLE_ORGS'
           AND GIF.ORG_CODE               = MTP.ORGANIZATION_CODE
           AND MSIB.INVENTORY_ITEM_ID =P_ITEM_ID
           AND GIF.SRC_SYS ='HONDA'
          ) STG
--Added by OWMS Team : END
       GROUP BY INVENTORY_ITEM_ID,
          ORGANIZATION_CODE)TAB ;
      -- Onhand Varray Ends

      IF SQL%rowcount > 0 THEN
        FOR i IN 1 .. L_PART_AVAIL.count
        LOOP
          V_PART_AVAIL_cnt := V_PART_AVAIL_cnt + 1;
          P_PART_AVAIL.EXTEND();
          P_PART_AVAIL(V_PART_AVAIL_cnt) := L_PART_AVAIL(i) ; --BM Commented
        END LOOP;
      ELSE
        SELECT LOOKUP_CODE
          || ': '
          || DESCRIPTION
        INTO p_message
        FROM fnd_lookup_values
        WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
        AND UPPER(LOOKUP_CODE) = UPPER('8133');
        --
        --
        --Looping in customer loop to get the cust ids in message for 8133
        IF P_CUST_ID.COUNT > 0 THEN
          FOR VAR IN 1 .. P_CUST_ID.COUNT
          LOOP
            P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
          END LOOP;
        END IF;
        -- Loop ends for customer id concatenation in messages
      END IF;--- End If Part Avaliability list BO
      --End of Onhand Varray Population
      --Making P_MESSAGE NULL if the Array is populated
      IF l_PART_APPLICABLE_DUP.COUNT > 0 THEN
        --
        P_MESSAGE := NULL;
        -- Setting the P_PRICE_MESSAGE
        IF L_PART_PRICE_DUP.COUNT = 0 THEN
          IF p_ROLE              <> 'Cust Enquiry' THEN
            P_PRICE_MESSAGE      := 'Price_Msg:';
            P_PRICE_MESSAGE      := P_PRICE_MESSAGE||'Part is not priced but you can still order part';
          ELSE
            P_PRICE_MESSAGE := 'Price_Msg_01:';
            P_PRICE_MESSAGE := P_PRICE_MESSAGE||'Part is not priced';
          END IF;
          IF P_CUST_ID.COUNT > 0 THEN
            FOR VAR IN 1 .. P_CUST_ID.COUNT
            LOOP
              P_PRICE_MESSAGE := P_PRICE_MESSAGE||'~'||P_CUST_ID(VAR);
            END LOOP;
          END IF;
        ELSE
       --   l_PART_PRICE_DUP_CNT :=0;  Manisha commented on 12 dec to avoid losing the data of P_PART_PRICE array if count initialize again
          ---P_PART_PRICE := l_PART_PRICE_DUP;

          FOR var IN 1 .. l_PART_PRICE_DUP.COUNT
          LOOP

            IF var                  =1  AND P_PART_PRICE.COUNT = 0 THEN --Manisha Added the condition
              l_PART_PRICE_DUP_CNT := l_PART_PRICE_DUP_CNT + 1;
              P_PART_PRICE.extend();
              P_PART_PRICE(l_PART_PRICE_DUP_CNT) := l_PART_PRICE_DUP(var);
            ELSE
              v_price_dup_flag := true;
              FOR dup IN 1 .. P_PART_PRICE.count
              LOOP
                IF l_PART_PRICE_DUP(var).INVENTORY_ITEM_ID = P_PART_PRICE(dup).INVENTORY_ITEM_ID AND l_PART_PRICE_DUP(var).CATALOG = P_PART_PRICE(dup).CATALOG AND l_PART_PRICE_DUP(var).UNIT_PRICE = P_PART_PRICE(dup).UNIT_PRICE AND l_PART_PRICE_DUP(var).UPQ = P_PART_PRICE(dup).UPQ AND l_PART_PRICE_DUP(var).LEAD_TIME = P_PART_PRICE(dup).LEAD_TIME THEN
                  v_price_dup_flag                        := false;
                END IF;
                NULL;
              END LOOP;
              IF v_price_dup_flag THEN
                l_PART_PRICE_DUP_CNT := l_PART_PRICE_DUP_CNT + 1;
                P_PART_PRICE.extend();
                P_PART_PRICE(l_PART_PRICE_DUP_CNT) := l_PART_PRICE_DUP(var);
              END IF;
            END IF;
          END LOOP;
          --Remove Duplicates from P_PART_PRICE  l_PART_PRICE_DUP
        END IF;
        -- Looping in the Onhadn Varray to find if we have onhand
        v_onhand_flag_non_zero := 'N';
        FOR I IN 1 .. P_PART_AVAIL.COUNT
        LOOP
          IF P_PART_AVAIL(I).QUANTITY > 0 THEN
            V_ONHAND_FLAG_NON_ZERO   := 'Y';
               EXIT;
          END IF;
        END LOOP ;
               -- Neelima Y MYJIRATEST-8631 on 18-AUG-2015
       BEGIN
          SELECT tag
            INTO V_OU_TAG
            FROM fnd_lookup_values
           WHERE lookup_type = 'GEAE_MYGE_OPERATING_UNITS'
             AND enabled_flag = 'Y'
             AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(start_date_active, SYSDATE)) AND
                 TRUNC(NVL(end_date_active, SYSDATE))
             AND lookup_code = J.OU_ID;
        Exception
          When Others then
            V_OU_TAG := NULL;
        End; --Fetching Operating Unit Code
        -- Setting the P_AVAIL_MESSAGE
      IF (P_CRITICAL_PART ='Y') AND (V_OU_TAG <>'HND') THEN  -- MYJIRATEST-7056 Ankita.S 04-MAY-2015  --AND Condition added by Neelima Y MYJIRATEST-8631 on 18-AUG-2015
           IF p_ROLE = 'Cust Enquiry' THEN
              P_AVAIL_MESSAGE  := 'Avail_Msg_02:';
              P_AVAIL_MESSAGE:= P_AVAIL_MESSAGE||'Current on hand is already being allocated';
           ELSIF p_ROLE = 'Buyer' THEN
                IF P_CUST_ID.COUNT > 0 THEN
                  FOR VAR IN 1 .. P_CUST_ID.COUNT
                  LOOP
                    P_AVAIL_MESSAGE  := 'Avail_Msg_03:';
                    P_AVAIL_MESSAGE:= P_AVAIL_MESSAGE||'Current on hand is already being allocated, you can still purchase the part'||'~'||P_CUST_ID(VAR);
                  END LOOP;
                END IF;
           ELSE
                  NULL;
           END IF;
      ELSE
            IF V_ONHAND_FLAG_NON_ZERO = 'N' THEN
              IF p_ROLE              <> 'Cust Enquiry' THEN
                P_AVAIL_MESSAGE      := 'Avail_Msg:';
                P_AVAIL_MESSAGE      := P_AVAIL_MESSAGE||'Part does not have on-hand but you can still order part';
              ELSE
                P_AVAIL_MESSAGE := 'Avail_Msg_01:';
                P_AVAIL_MESSAGE := P_AVAIL_MESSAGE||'Part does not have on-hand.';
              END IF;
              IF P_CUST_ID.COUNT > 0 THEN
                FOR VAR IN 1 .. P_CUST_ID.COUNT
                LOOP
                  P_AVAIL_MESSAGE := P_AVAIL_MESSAGE||'~'||P_CUST_ID(VAR);
                END LOOP;
              END IF;
            END IF; --END IF OF V_ONHAND_FLAG_NON_ZERO = 'N' THEN
      END IF;
        --
        -- Loop ends for customer id concatenation in messages
        --Remove duplicates from P_PART_APPLICABLE below
       -- l_PART_APPLICABLE_DUP_CNT :=0;  Manisha commented on 12 dec to avoid reintialize inside the loop
        FOR var IN 1 .. l_PART_APPLICABLE_DUP.COUNT
        LOOP
          IF var                       =1 THEN
            l_PART_APPLICABLE_DUP_CNT := l_PART_APPLICABLE_DUP_CNT + 1;
            P_PART_APPLICABLE.extend();
            P_PART_APPLICABLE(l_PART_APPLICABLE_DUP_CNT) := l_PART_APPLICABLE_DUP(var);
          ELSE
            v_part_APP_DUP_FLAG := true;
            FOR dup IN 1 .. P_PART_APPLICABLE.count
            LOOP
              IF l_PART_APPLICABLE_DUP(var).INVENTORY_ITEM_ID = P_PART_APPLICABLE(dup).INVENTORY_ITEM_ID AND l_PART_APPLICABLE_DUP(var).CUST_CODE = P_PART_APPLICABLE(dup).CUST_CODE AND l_PART_APPLICABLE_DUP(var).SUPPLIER_CODE = P_PART_APPLICABLE(dup).SUPPLIER_CODE AND l_PART_APPLICABLE_DUP(var).CUST_ID = P_PART_APPLICABLE(dup).CUST_ID AND l_PART_APPLICABLE_DUP(var).UPQ = P_PART_APPLICABLE(dup).UPQ AND l_PART_APPLICABLE_DUP(var).PRICE_LIST_ID = P_PART_APPLICABLE(dup).PRICE_LIST_ID THEN
                v_part_APP_DUP_FLAG                          := false;
              END IF;
            END LOOP;
            IF v_part_APP_DUP_FLAG THEN
              l_PART_APPLICABLE_DUP_CNT := l_PART_APPLICABLE_DUP_CNT + 1;
              P_PART_APPLICABLE.extend();
              P_PART_APPLICABLE(l_PART_APPLICABLE_DUP_CNT) := l_PART_APPLICABLE_DUP(var);
            END IF;
          END IF;
        END LOOP;
      END IF; --END IF of P_PART_APPLICABLE.COUNT > 0
      --
      --
      --Looping in customer loop to get the cust ids in message for 8125
      --
      V_GENERIC_MSSG := NULL;
      --
      IF P_PART_APPLICABLE.COUNT = 0 THEN
        --
        P_PART_AVAIL.DELETE;
        V_PART_AVAIL_cnt := 0;  --Manisha 02-Jan Added this to initialize the count if P_PART_AVAIL array is getting deleted
        P_PART_PRICE.DELETE;
        -- If There are more than one 1 message then only return Generic message else return P_MESSAGE
        IF V_GTA_ERR_MSSG     IS NOT NULL THEN
          V_GENERIC_MESSG_CNT := V_GENERIC_MESSG_CNT + 1;
        END IF;
        IF V_ORG_ERR_MSSG     IS NOT NULL THEN
          V_GENERIC_MESSG_CNT := V_GENERIC_MESSG_CNT + 1;
        END IF;
        IF V_CTRL_SHIP_ERR_MSSG    IS NOT NULL THEN
          V_GENERIC_MESSG_CNT := V_GENERIC_MESSG_CNT + 1;
        END IF;
        IF V_AVIALL_ERR_MSSG  IS NOT NULL THEN
          V_GENERIC_MESSG_CNT := V_GENERIC_MESSG_CNT + 1;
        END IF;
        IF V_VENDOR_ERR_MSSG  IS NOT NULL THEN
          V_GENERIC_MESSG_CNT := V_GENERIC_MESSG_CNT + 1;
        END IF;
        IF V_AMPS_CODE_ERR_MSSG IS NOT NULL THEN
          V_GENERIC_MESSG_CNT := V_GENERIC_MESSG_CNT + 1;
        END IF;
        IF V_GENERIC_MESSG_CNT > 1 THEN
          SELECT LOOKUP_CODE
            || ': '
          INTO V_GENERIC_MSSG
          FROM fnd_lookup_values
          WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
          AND UPPER(LOOKUP_CODE) = UPPER('8200');
          V_GENERIC_MSSG        := V_GENERIC_MSSG||V_GTA_ERR_MSSG||'.'||V_ORG_ERR_MSSG||'.'||V_CTRL_SHIP_ERR_MSSG||'.'||V_AVIALL_ERR_MSSG||'.'||V_VENDOR_ERR_MSSG||'.'||V_AMPS_CODE_ERR_MSSG;
          P_MESSAGE             := V_GENERIC_MSSG;
          IF P_CUST_ID.COUNT     > 0 THEN
            FOR VAR IN 1 .. P_CUST_ID.COUNT
            LOOP
              P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
            END LOOP;
          END IF;
        END IF; --END IF Of IF V_GENERIC_MESSG_CNT > 1
      END IF;   --END IF of  P_PART_APPLICABLE.COUNT = 0 THEN
      --
      --MYJIRATEST-6272 Ravi S 03-MAR-2015
      IF v_prod_line_on = 'Y' THEN --   MYJIRATEST-7139 23-MAR-2015    Engine family to Product line changes
         l_bom_counter := 0;
         IF P_CUST_ID.COUNT > 0 AND P_PART_APPLICABLE.COUNT > 0 THEN
            FOR part_bom IN (SELECT DISTINCT prt_apl.cust_code, bom.product_line product_line --   MYJIRATEST-7139 23-MAR-2015    Engine family to Product line changes
                               FROM geae_myge_bom_details_v bom, geae_ont_cust_gta_info gta_hdr, geae_ont_gta_applblty_v gta_line,
                                    TABLE(CAST(P_PART_APPLICABLE AS V_PART_APPLICABLE)) prt_apl
                              WHERE bom.search_ou_id = gta_hdr.org_id
                                AND gta_hdr.geae_ont_cust_gta_info_seq_id = gta_line.geae_ont_cust_gta_info_seq_id
                                AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(gta_hdr.start_date,SYSDATE)) AND TRUNC(NVL(gta_hdr.end_date,SYSDATE))
                                AND bom.eng_mod = gta_line.engine_model
                                AND bom.search_ou_id = J.OU_ID
                                AND bom.inventory_item_id = prt_apl.inventory_item_id
                                AND gta_hdr.customer_id = prt_apl.cust_id) LOOP
               P_PART_BOM.EXTEND(1);
               l_bom_counter := l_bom_counter + 1;
               P_PART_BOM(P_PART_BOM.last):= V_PART_BOM_BO(part_bom.cust_code, part_bom.product_line , l_bom_counter);--   MYJIRATEST-7139 23-MAR-2015    Engine family to Product line changes
            END LOOP;
         END IF;
      END IF;
    ELSE --Else of  IF V_ITEM_STATUS = 'Y' THEN
      --
      SELECT LOOKUP_CODE
        || ': '
        || DESCRIPTION
      INTO p_message
      FROM fnd_lookup_values
      WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
      AND UPPER(LOOKUP_CODE) = UPPER('8125');
      --
      --Looping in customer loop to get the cust ids in message for 8125
      IF P_CUST_ID.COUNT > 0 THEN
        FOR VAR IN 1 .. P_CUST_ID.COUNT
        LOOP
          P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
        END LOOP;
      END IF;
      -- Loop ends for customer id concatenation in messages
    END IF; ---END IF of IF V_ITEM_STATUS = 'Y' THEN
  END IF;   ---END IF of p_ROLE = 'Global Enquiry'
  --Ravi S MYJIRATEST-5063 21-JAN-2015
  l_disc_counter := 0;
  IF P_CUST_ID.COUNT > 0 AND P_PART_APPLICABLE.COUNT > 0 THEN
     FOR i IN 1 .. P_CUST_ID.COUNT LOOP
        l_pr_fr_disc := NULL;
        FOR part_appl IN (SELECT prt_apl.supplier_code, prt_apl.price_list_id, NVL(prt_apl.upq,1) upq
                            FROM TABLE(CAST(P_PART_APPLICABLE AS V_PART_APPLICABLE)) prt_apl,
                                 fnd_lookup_values supp_code
                           WHERE prt_apl.cust_id = P_CUST_ID(i)
                             AND prt_apl.inventory_item_id = P_ITEM_ID
                             AND prt_apl.supplier_code = supp_code.meaning
                             AND supp_code.lookup_type = 'GEAE_MYGE_SUPPLIER_ORGS'
                             AND supp_code.description = J.OU_ID
                           ORDER BY supp_code.attribute3) LOOP
           GET_PRICE(P_SSO,J.OU_ID,P_ITEM_ID,part_appl.price_list_id,l_pr_fr_disc,l_disc_line_id);
           IF l_pr_fr_disc IS NOT NULL THEN
              l_disc_list_id := part_appl.price_list_id;

                EXIT;
           END IF;
           l_disc_list_id := NULL;
        END LOOP;
        FOR r_disc IN C_DISCOUNTS(P_CUST_ID(i),J.OU_ID,P_ITEM_ID,l_disc_list_id) LOOP
           IF r_disc.line_auto_flag = 'Y' THEN
              l_disc_end_date := NULL;
              IF l_disc_end_date > r_disc.qual_end_date OR l_disc_end_date IS NULL THEN
                 l_disc_end_date := r_disc.qual_end_date;
              END IF;
              IF l_disc_end_date > r_disc.line_end_date OR l_disc_end_date IS NULL THEN
                 l_disc_end_date := r_disc.line_end_date;
              END IF;
              IF l_disc_end_date > r_disc.list_end_date OR l_disc_end_date IS NULL THEN
                 l_disc_end_date := r_disc.list_end_date;
              END IF;
              IF l_disc_end_date > r_disc.grants_end_date OR l_disc_end_date IS NULL THEN
                 l_disc_end_date := r_disc.grants_end_date;
              END IF;
              SELECT NVL(SUM(amount),0)
                INTO l_disc_consumed
                FROM qp_limit_transactions
               WHERE list_header_id = r_disc.list_header_id
                 AND list_line_id = r_disc.list_line_id;
              IF r_disc.limit > l_disc_consumed OR r_disc.basis IS NULL THEN
                 l_disc_price := l_pr_fr_disc*(100-r_disc.disc_value)/100;
              ELSE
                 l_disc_price := l_pr_fr_disc;
              END IF;
              P_PART_DISCOUNTS.EXTEND(1);
              l_disc_counter := l_disc_counter + 1;
              P_PART_DISCOUNTS(P_PART_DISCOUNTS.last):= V_PART_DISCOUNTS_BO(r_disc.account_number, r_disc.line_number, r_disc.disc_value, l_disc_price, r_disc.limit, GREATEST(r_disc.limit-l_disc_consumed,0), l_disc_end_date, r_disc.list_name, r_disc.list_description, r_disc.line_number, r_disc.line_comments, r_disc.arithmetic_operator, r_disc.list_header_id, r_disc.list_line_id, l_disc_counter, r_disc.qualifier_id);
          ELSE
              IF P_CUST_ID.COUNT > 0 THEN
                FOR VAR IN 1 .. P_CUST_ID.COUNT
                  LOOP
                    P_DISC_MESSAGE :=GEAE_MYGE_CART_PKG.GET_ERR_MSG(8199)||'~'||P_CUST_ID(VAR);--MYJIRATEST-7192: Ankita.S 04-MAY-2015
                  END LOOP;
              END IF;
           END IF;
        END LOOP;
     END LOOP;
  END IF;
----MYJIRATEST-7138   24-MAR-2015    Oderable Vs Non Oderable changes  starts
 BEGIN
  BEGIN
     SELECT description
--       INTO NVL(v_oderable_on,'N')
      INTO v_oderable_on
       FROM fnd_lookup_values
      WHERE lookup_type = 'GEAE_MYGE_ENABLE_ORDERABLE'
        AND lookup_code = J.OU_ID
        AND enabled_flag = 'Y'
        AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(start_date_active,SYSDATE)) AND TRUNC(NVL(end_date_active,SYSDATE));
  EXCEPTION
     WHEN NO_DATA_FOUND THEN
        v_oderable_on := 'N';
     WHEN OTHERS THEN
        v_oderable_on := 'N';
  END;
  IF v_oderable_on = 'Y' THEN
  --Calls the Procedure for getting Inventory Item status Code
   get_inventory_item_status_code ( lp_inventory_item_id=> P_ITEM_ID ,
                                    P_OU_ID =>J.OU_ID,
                                    lp_inventory_item_status_code => V_ISODERABLE ,
                                    pp_message => V_ISODERABLE_MESSAGE);
   P_ISODERABLE :=V_ISODERABLE;
   IF V_ISODERABLE_MESSAGE  IS NOT NULL THEN
      P_MESSAGE := P_MESSAGE||'.'||V_ISODERABLE_MESSAGE;
   END IF;
  END IF;--v_oderable_on flag
 END;  ----MYJIRATEST-7138   24-MAR-2015    Oderable Vs Non Oderable changes  Ends
--<<END_CODE>>
  NULL;
 END LOOP; --End of Loop J.OU_ID


 /******************************************************
 Manisha K. 10-Aug Added the below code to  remove the duplicates from the loop
 because of OU_ID loop
 *******************************************************/

 FOR i IN 1 .. P_PART_PRICE.COUNT  LOOP

 T_PART_PRICE_LOOP_DUP.extend();
 T_PART_PRICE_LOOP_DUP(T_PART_PRICE_LOOP_DUP.last):= V_PART_PRICE_LIST_BO(P_PART_PRICE(i).INVENTORY_ITEM_ID, P_PART_PRICE(i).CATALOG, P_PART_PRICE(i).UNIT_PRICE, P_PART_PRICE(i).UPQ ,P_PART_PRICE(i).LEAD_TIME);
 END LOOP;

 FOR i IN 1 .. P_PART_APPLICABLE.COUNT  LOOP
 T_PART_APPLICABLE_LOOP_DUP.extend();
 T_PART_APPLICABLE_LOOP_DUP(T_PART_APPLICABLE_LOOP_DUP.LAST):=V_PART_APPLICABLE_LIST_BO(P_PART_APPLICABLE(i).INVENTORY_ITEM_ID,P_PART_APPLICABLE(i).CUST_CODE,P_PART_APPLICABLE(i).SUPPLIER_CODE,P_PART_APPLICABLE(i).CUST_ID,P_PART_APPLICABLE(i).UPQ,P_PART_APPLICABLE(i).PRICE_LIST_ID);
 END LOOP;

 FOR i IN 1 .. P_PART_AVAIL.COUNT  LOOP

 T_PART_AVAIL_LOOP_DUP.extend();
 T_PART_AVAIL_LOOP_DUP(T_PART_AVAIL_LOOP_DUP.last):= V_PART_AVAILABILITY_LIST_BO(P_PART_AVAIL(i).INVENTORY_ITEM_ID, P_PART_AVAIL(i).LOCATION , P_PART_AVAIL(i).QUANTITY);

 END LOOP;

 P_PART_PRICE.DELETE;
 P_PART_APPLICABLE.DELETE;
 P_PART_AVAIL.DELETE;

   i_PART_PRICE_DUP_CNT :=0;
  FOR var IN 1 .. T_PART_PRICE_LOOP_DUP.COUNT     LOOP
      IF var                  =1 THEN
        i_PART_PRICE_DUP_CNT := i_PART_PRICE_DUP_CNT + 1;
        P_PART_PRICE.extend();

        P_PART_PRICE(i_PART_PRICE_DUP_CNT) := T_PART_PRICE_LOOP_DUP(var);

      ELSE

        i_price_dup_flag := true;
        FOR dup IN 1 .. P_PART_PRICE.count
        LOOP
          IF T_PART_PRICE_LOOP_DUP(var).INVENTORY_ITEM_ID = P_PART_PRICE(dup).INVENTORY_ITEM_ID AND T_PART_PRICE_LOOP_DUP(var).CATALOG = P_PART_PRICE(dup).CATALOG AND T_PART_PRICE_LOOP_DUP(var).UNIT_PRICE = P_PART_PRICE(dup).UNIT_PRICE AND T_PART_PRICE_LOOP_DUP(var).UPQ = P_PART_PRICE(dup).UPQ AND T_PART_PRICE_LOOP_DUP(var).LEAD_TIME = P_PART_PRICE(dup).LEAD_TIME THEN
            i_price_dup_flag                        := false;
          END IF;
          NULL;
        END LOOP;
        IF i_price_dup_flag THEN
          i_PART_PRICE_DUP_CNT := i_PART_PRICE_DUP_CNT + 1;
          P_PART_PRICE.extend();
          P_PART_PRICE(i_PART_PRICE_DUP_CNT) := T_PART_PRICE_LOOP_DUP(var);
        END IF;
      END IF;
 END LOOP;

 i_PART_APPLICABLE_DUP_CNT :=0;

 FOR var IN 1 .. T_PART_APPLICABLE_LOOP_DUP.COUNT
        LOOP
          IF var                       =1 THEN
            i_PART_APPLICABLE_DUP_CNT := i_PART_APPLICABLE_DUP_CNT + 1;
            P_PART_APPLICABLE.extend();
            P_PART_APPLICABLE(i_PART_APPLICABLE_DUP_CNT) := T_PART_APPLICABLE_LOOP_DUP(var);
          ELSE
            i_part_APP_DUP_FLAG := true;
            FOR dup IN 1 .. P_PART_APPLICABLE.count
            LOOP
              IF T_PART_APPLICABLE_LOOP_DUP(var).INVENTORY_ITEM_ID = P_PART_APPLICABLE(dup).INVENTORY_ITEM_ID AND T_PART_APPLICABLE_LOOP_DUP(var).CUST_CODE = P_PART_APPLICABLE(dup).CUST_CODE AND T_PART_APPLICABLE_LOOP_DUP(var).SUPPLIER_CODE = P_PART_APPLICABLE(dup).SUPPLIER_CODE AND T_PART_APPLICABLE_LOOP_DUP(var).CUST_ID = P_PART_APPLICABLE(dup).CUST_ID AND T_PART_APPLICABLE_LOOP_DUP(var).UPQ = P_PART_APPLICABLE(dup).UPQ AND T_PART_APPLICABLE_LOOP_DUP(var).PRICE_LIST_ID = P_PART_APPLICABLE(dup).PRICE_LIST_ID THEN
                i_part_APP_DUP_FLAG                          := false;
              END IF;
            END LOOP;
            IF i_part_APP_DUP_FLAG THEN
              i_PART_APPLICABLE_DUP_CNT := i_PART_APPLICABLE_DUP_CNT + 1;
              P_PART_APPLICABLE.extend();
              P_PART_APPLICABLE(i_PART_APPLICABLE_DUP_CNT) := T_PART_APPLICABLE_LOOP_DUP(var);
            END IF;
          END IF;
        END LOOP;
      --remoeve duplicate for p_part_avail
       i_PART_AVAIL_DUP_CNT :=0;

 FOR var IN 1 .. T_PART_AVAIL_LOOP_DUP.COUNT
        LOOP
          IF var                       =1 THEN
            i_PART_AVAIL_DUP_CNT := i_PART_AVAIL_DUP_CNT + 1;
            P_PART_AVAIL.extend();
            P_PART_AVAIL(i_PART_AVAIL_DUP_CNT) := T_PART_AVAIL_LOOP_DUP(var);
          ELSE
            i_part_AVAIL_DUP_FLAG := true;
            FOR dup IN 1 .. P_PART_AVAIL.count
            LOOP
              IF T_PART_AVAIL_LOOP_DUP(var).INVENTORY_ITEM_ID = P_PART_AVAIL(dup).INVENTORY_ITEM_ID AND T_PART_AVAIL_LOOP_DUP(var).QUANTITY = P_PART_AVAIL(dup).QUANTITY AND T_PART_AVAIL_LOOP_DUP(var).LOCATION = P_PART_AVAIL(dup).LOCATION THEN
                i_part_AVAIL_DUP_FLAG                          := false;
              END IF;
            END LOOP;
            IF i_part_AVAIL_DUP_FLAG THEN
              i_PART_AVAIL_DUP_CNT := i_PART_AVAIL_DUP_CNT + 1;
              P_PART_AVAIL.extend();
              P_PART_AVAIL(i_PART_AVAIL_DUP_CNT) := T_PART_AVAIL_LOOP_DUP(var);
            END IF;
          END IF;
        END LOOP;
END GET_ITEM_PRICE_AVAIL;
--MYJIRATEST-7138 Added new procedure for calculating Inventory Item status Code for Oderable Vs Non Oderable Change Starts
PROCEDURE get_inventory_item_status_code(lp_inventory_item_id          IN VARCHAR2,
                                         P_OU_ID                       IN VARCHAR2,
                                         lp_inventory_item_status_code OUT VARCHAR2,
                                         pp_message                    OUT VARCHAR2) IS
  v_procurement_code  mtl_item_categories_v.category_concat_segs%TYPE := NULL;
  v_all_ship_a        bom_components_b.attribute5%type;
  v_all_ship_b        bom_components_b.attribute5%type;
  v_all_ship_c        bom_components_b.attribute5%type;
  v_status_cd         VARCHAR2(255);
  v_future_part       VARCHAR2(255);
  v_prime_ship        VARCHAR2(255);
  v_error_code        VARCHAR2(255) := Null;
  v_ou_tag            VARCHAR2(255) := Null;
  v_onhand_qty        mtl_onhand_quantities.transaction_quantity%type;
  v_operating_unit_id hr_operating_units.organization_id%type;
  v_validation_org_id mtl_parameters.organization_id%type;
  lp_organization_id  mtl_system_items_b.organization_id%type;
  e_exit exception;
  v_cpl_org_id ORG_ORGANIZATION_DEFINITIONS.ORGANIZATION_CODE%type; /*Added by Capgemini OWMS Team for MyGE Changes*/
  v_sdc_org_id ORG_ORGANIZATION_DEFINITIONS.ORGANIZATION_CODE%type; /*Added by Capgemini OWMS Team for MyGE Changes*/
  v_erl_org_id ORG_ORGANIZATION_DEFINITIONS.ORGANIZATION_CODE%type; /*Added by Capgemini OWMS Team for MyGE Changes*/
  v_item_source                VARCHAR2(10); -- Added for OWMS Implementation US192483/US192484
  v_item_number                VARCHAR2(30); -- Added for OWMS Implementation US192483/US192484
  CURSOR ship_codes(p_organization_id NUMBER, p_inventory_item_id NUMBER) IS
    SELECT distinct cmp.attribute5 shippability_code
      FROM bom_structures_b bom, bom_components_b cmp
     WHERE bom.bill_sequence_id = cmp.bill_sequence_id
       AND SYSDATE BETWEEN cmp.effectivity_date AND
           NVL(cmp.disable_date, SYSDATE)
       AND bom.attribute12 = v_ou_tag
       AND bom.organization_id = v_validation_org_id
       AND cmp.component_item_id = lp_inventory_item_id;
BEGIN
  /*Added by Capgemini OWMS Team for MyGE Changes*/
  BEGIN
    SELECT ORGANIZATION_ID
      INTO v_cpl_org_id
      FROM ORG_ORGANIZATION_DEFINITIONS
     WHERE ORGANIZATION_CODE = 'CPL';
  EXCEPTION
    WHEN OTHERS THEN
    v_cpl_org_id:= 0;
  END;
--Added by OWMS Team : START
  BEGIN
    SELECT ORGANIZATION_ID
      INTO v_erl_org_id
      FROM ORG_ORGANIZATION_DEFINITIONS
     WHERE ORGANIZATION_CODE = 'ERL';
  EXCEPTION
    WHEN OTHERS THEN
    v_erl_org_id:= 0;
  END;
--Added by OWMS Team : END
  BEGIN
    SELECT ORGANIZATION_ID
      INTO v_sdc_org_id
      FROM ORG_ORGANIZATION_DEFINITIONS
     WHERE ORGANIZATION_CODE = 'SDC';
  EXCEPTION
    WHEN OTHERS THEN
    v_sdc_org_id:= 0;
  END;
  /*Added by Capgemini OWMS Team for MyGE Changes*/
  BEGIN
    --Fetching Operating Unit Code
    SELECT tag
      INTO v_ou_tag
      FROM fnd_lookup_values
     WHERE lookup_type = 'GEAE_MYGE_OPERATING_UNITS'
       AND enabled_flag = 'Y'
       AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(start_date_active, SYSDATE)) AND
           TRUNC(NVL(end_date_active, SYSDATE))
       AND lookup_code = P_OU_ID;
  Exception
    When Others then
      v_error_code := '8066';
      RAISE e_exit;
  End; --Fetching Operating Unit Code
  BEGIN
    --Fetching Organization ID and Org Code
    SELECT msib.organization_id, ood.operating_unit
      INTO lp_organization_id, v_operating_unit_id
      FROM mtl_system_items_b           msib,
           org_organization_definitions ood,
           fnd_lookup_values            flv
     WHERE msib.organization_id = ood.organization_id
       AND ood.organization_code = flv.attribute1
       AND msib.item_type NOT IN ('OC')
       AND inventory_item_id = lp_inventory_item_id
       AND flv.lookup_type = 'GEAE_MYGE_SUPPLIER_ORGS'
       AND flv.enabled_flag = 'Y'
       AND flv.attribute3 = '1'
       AND TRUNC(SYSDATE) BETWEEN
           TRUNC(NVL(flv.start_date_active, SYSDATE)) AND
           TRUNC(NVL(flv.end_date_active, SYSDATE))
       AND flv.description = P_OU_ID;
    v_validation_org_id := oe_sys_parameters.VALUE('MASTER_ORGANIZATION_ID',
                                                   v_operating_unit_id);
  Exception
    When Others then
      v_error_code := '8066';
      RAISE e_exit;
  End; --Fetching Organization ID and Org Code
  v_all_ship_a  := '-1';
  v_all_ship_b  := '-1';
  v_all_ship_c  := '-1';
  v_future_part := '-1';
  v_status_cd   := 'Ltd-Usage';
  -- r_foxt_data_stg.attribute12 := 'ALL-SHIPPABLE-OTHERS';
  v_onhand_qty       := 0;
  v_procurement_code := NULL;
  FOR sel_model_ship_codes IN ship_codes(to_number(v_validation_org_id),
                                         to_number(lp_inventory_item_id)) loop
--    fnd_file.put_line(fnd_file.log,'Shipability code:' ||sel_model_ship_codes.shippability_code);
    IF sel_model_ship_codes.shippability_code = 'A' -- AND v_all_ship_a <> 'N'  --Commented for Aero AMPS Nov-13 Release Scenario 3
     THEN
      v_all_ship_a  := 'Y';
      v_all_ship_b  := 'N';
      v_all_ship_c  := 'N';
      v_future_part := 'N';
    ELSIF sel_model_ship_codes.shippability_code = 'B' AND
          v_all_ship_b <> 'N' THEN
      v_all_ship_b  := 'Y';
      v_all_ship_a  := 'N';
      v_all_ship_c  := 'N';
      v_future_part := 'N';
    ELSIF sel_model_ship_codes.shippability_code = 'C' AND
          v_all_ship_c <> 'N' THEN
      v_all_ship_c  := 'Y';
      v_all_ship_a  := 'N';
      v_all_ship_b  := 'N';
      v_future_part := 'N';
    ELSIF sel_model_ship_codes.shippability_code IN ('1', '2') AND
          v_future_part <> 'N' --Removed "4" for AeroAMPS Nov-13 release Scenario 1
     THEN
      v_future_part := 'Y';
      v_all_ship_a  := 'N';
      v_all_ship_b  := 'N';
      v_all_ship_c  := 'N';
    ELSIF sel_model_ship_codes.shippability_code IN ('X', 'Y', '3', '4') --Added "4" for AeroAMPS Nov-13 release Scenario 2
     THEN
      v_prime_ship  := 'Y';
      v_all_ship_a  := 'N';
      v_all_ship_b  := 'N';
      v_all_ship_c  := 'N';
      v_future_part := 'N';
    ELSE
      v_all_ship_a  := 'N';
      v_all_ship_b  := 'N';
      v_all_ship_c  := 'N';
      v_future_part := 'N';
    END IF;
  END LOOP;
  --fnd_file.put_line(fnd_file.LOG, 'v_prime_ship:' || v_prime_ship);
  v_procurement_code := geae_inv_amps_common_utils_pkg.get_category_value(p_organization_id   => to_number(lp_organization_id),
                                                                          p_inventory_item_id => to_number(lp_inventory_item_id),
                                                                          p_category_set_name => 'Procurement Code');
  --r_foxt_data_stg.attribute13 := v_procurement_code;
  --fnd_file.put_line(fnd_file.LOG,'v_procurement_code:' || v_procurement_code);
  IF v_prime_ship = 'Y' AND v_procurement_code = 'X' THEN
    v_status_cd := 'Active';
    --  r_foxt_data_stg.attribute12 := 'SHIP-X-Y-3-4-AND-PRIMESHIP';  --Added "4" for AeroAMPS Nov-13 release Scenario 2
    /*Added for AeroAMPS Nov-13 release Scenario 2*/
  ELSIF v_prime_ship = 'Y' AND v_procurement_code = 'V' THEN
    /*Added by Capgemini OWMS Team for MyGE Changes*/
   IF v_cpl_org_id = lp_organization_id OR v_sdc_org_id = lp_organization_id THEN
--Added by OWMS Team : START
  	SELECT NVL((b.qty-c.qty),0) QTY
			   INTO v_onhand_qty
		FROM (SELECT NVL(SUM(MOQ.TRANSACTION_QUANTITY),0) qty
				FROM GEAE_INV_MTL_ONHANDS_V MOQ
			   WHERE INVENTORY_ITEM_ID = to_number(lp_inventory_item_id)
        AND SUBINVENTORY_CODE IN ('STOCK','STG')
				 AND ORGANIZATION_ID = to_number(lp_organization_id)
			) b,
		 (SELECT NVL(SUM(RESERVATION_QUANTITY),0) qty
					 FROM MTL_RESERVATIONS
			 WHERE INVENTORY_ITEM_ID = to_number(lp_inventory_item_id)
				 AND ORGANIZATION_ID = to_number(lp_organization_id)
			) C ;
		---- OWMS team Changes for DE25546 : End
    ELSIF v_erl_org_id = lp_organization_id THEN
          SELECT NVL((A.QTY - B.QTY),0)  QTY
       		   INTO v_onhand_qty
            FROM (SELECT (geae_wms_total_onhand_erl_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
			geae_wms_total_pick_release(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
			 FROM apps.mtl_system_items_b msib,
			      apps.mtl_parameters mp
			 WHERE 1 = 1
			   and msib.inventory_item_id = to_number(lp_inventory_item_id)
			   and msib.organization_id = mp.organization_id
			   and mp.organization_id = to_number(lp_organization_id)) A,
                 (SELECT (geae_wms_resv_qty_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
			geae_wms_total_resv(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
			 FROM apps.mtl_system_items_b msib,
			      apps.mtl_parameters mp
			 WHERE 1 = 1
			   and msib.inventory_item_id = to_number(lp_inventory_item_id)
			   and msib.organization_id = mp.organization_id
			   and mp.organization_id = to_number(lp_organization_id)) B;
--Added by OWMS Team : END
    ELSE
    /*Added by Capgemini OWMS Team for MyGE Changes*/
    SELECT nvl(sum(transaction_quantity), 0)
      INTO v_onhand_qty
      FROM GEAE_INV_MTL_ONHANDS_V moq
     WHERE moq.inventory_item_id = to_number(lp_inventory_item_id)
       AND moq.organization_id = to_number(lp_organization_id);
    /*Added by Capgemini OWMS Team for MyGE Changes*/
    END IF;
    /*Added by Capgemini OWMS Team for MyGE Changes*/
    IF v_onhand_qty = 0 THEN
      v_status_cd := 'Ltd-Usage';
    END IF;
    /*Added for AeroAMPS Nov-13 release*/
  ELSIF v_all_ship_b = 'Y' THEN
    v_status_cd := 'Rework';
    -- r_foxt_data_stg.attribute12 := 'ALL-SHIPPABLE-B';
  ELSIF v_all_ship_c = 'Y' THEN
    v_status_cd := 'Obsolete';
    -- r_foxt_data_stg.attribute12 := 'ALL-SHIPPABLE-C';
  ELSIF v_future_part = 'Y' THEN
    v_status_cd := 'DO-NOT-SEND';
    --  r_foxt_data_stg.attribute12 := 'FUTURE-1-2'; --Removed '4' for Nov-13 Release
  ELSIF v_all_ship_a = 'Y' THEN
    /* SELECT  nvl(max('SDC'),'NON-SDC')
    INTO  v_prt_src_cd
    FROM  mtl_system_items_b msib,
    mtl_parameters mp
                     WHERE  msib.inventory_item_id = to_number(lp_inventory_item_id)
     AND  msib.organization_id = mp.organization_id
     AND  mp.organization_code = g_sdc_org_code;*/
    /*Added by Capgemini OWMS Team for MyGE Changes*/
   IF v_cpl_org_id = lp_organization_id OR v_sdc_org_id = lp_organization_id THEN
--Added by OWMS Team : START
  	SELECT NVL((b.qty-c.qty),0) QTY
			   INTO v_onhand_qty
		FROM (SELECT NVL(SUM(MOQ.TRANSACTION_QUANTITY),0) qty
				FROM GEAE_INV_MTL_ONHANDS_V MOQ
			   WHERE INVENTORY_ITEM_ID = to_number(lp_inventory_item_id)
         AND SUBINVENTORY_CODE IN ('STOCK','STG')
				 AND ORGANIZATION_ID = to_number(lp_organization_id)
			) b,
		 (SELECT NVL(SUM(RESERVATION_QUANTITY),0) qty
					 FROM MTL_RESERVATIONS
			 WHERE INVENTORY_ITEM_ID = to_number(lp_inventory_item_id)
				 AND ORGANIZATION_ID = to_number(lp_organization_id)
			) C ;
    ELSIF v_erl_org_id = lp_organization_id THEN
          SELECT NVL((A.QTY - B.QTY),0)  QTY
       		   INTO v_onhand_qty
            FROM (SELECT (geae_wms_total_onhand_erl_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
			geae_wms_total_pick_release(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
			 FROM apps.mtl_system_items_b msib,
			      apps.mtl_parameters mp
			 WHERE 1 = 1
			   and msib.inventory_item_id = to_number(lp_inventory_item_id)
			   and msib.organization_id = mp.organization_id
			   and mp.organization_id = to_number(lp_organization_id)) A,
                 (SELECT (geae_wms_resv_qty_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
			geae_wms_total_resv(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
			 FROM apps.mtl_system_items_b msib,
			      apps.mtl_parameters mp
			 WHERE 1 = 1
			   and msib.inventory_item_id = to_number(lp_inventory_item_id)
			   and msib.organization_id = mp.organization_id
			   and mp.organization_id = to_number(lp_organization_id)) B;
--Added by OWMS Team : END
	ELSE
    /*Added by Capgemini OWMS Team for MyGE Changes*/
    SELECT nvl(sum(transaction_quantity), 0)
      INTO v_onhand_qty
      FROM GEAE_INV_MTL_ONHANDS_V moq
     WHERE moq.inventory_item_id = to_number(lp_inventory_item_id)
       AND moq.organization_id = to_number(lp_organization_id);
    /*Added by Capgemini OWMS Team for MyGE Changes*/
    END IF;
       /*Added by Capgemini OWMS Team for MyGE Changes*/
    --END IF;
    --  fnd_file.put_line(fnd_file.log,'10  on hand qty before if  -> :'||v_onhand_qty);
    IF v_onhand_qty > 0 THEN
      --   r_foxt_data_stg.attribute12 := 'ALL-SHIPPABLE-A-WITH-ONHAND';
      v_status_cd := 'Active';
      -- fnd_file.put_line(fnd_file.log,'20  SHIPPABLE-A-WITH-ONHAND  -> :'||r_foxt_data_stg.attribute12);
      --   r_foxt_data_stg.attribute12 := 'ALL-SHIPPABLE-A-WITHOUT-ONHAND';
      --fnd_file.put_line(fnd_file.log,'30  SHIPPABLE-A-WITHOUT-ONHAND -> :'||r_foxt_data_stg.attribute12);
    end if;
    /*Added for AeroAMPS Nov-13 release Scenario 4 Anything with Inventory in fndderlanger /with out Inventory in erlanger*/
  END IF;
  IF v_status_cd = 'Ltd-Usage' THEN
   IF v_cpl_org_id = lp_organization_id OR v_sdc_org_id = lp_organization_id THEN
--Added by OWMS Team : START
  	SELECT NVL((b.qty-c.qty),0) QTY
			   INTO v_onhand_qty
		FROM (SELECT NVL(SUM(MOQ.TRANSACTION_QUANTITY),0) qty
				FROM GEAE_INV_MTL_ONHANDS_V MOQ
			   WHERE INVENTORY_ITEM_ID = to_number(lp_inventory_item_id)
         AND SUBINVENTORY_CODE IN ('STOCK','STG')
				 AND ORGANIZATION_ID = to_number(lp_organization_id)
			) b,
		 (SELECT NVL(SUM(RESERVATION_QUANTITY),0) qty
					 FROM MTL_RESERVATIONS
			 WHERE INVENTORY_ITEM_ID = to_number(lp_inventory_item_id)
				 AND ORGANIZATION_ID = to_number(lp_organization_id)
			) C ;
		---- OWMS team Changes for DE25546 : End
    ELSIF v_erl_org_id = lp_organization_id THEN
          SELECT NVL((A.QTY - B.QTY),0)  QTY
       		   INTO v_onhand_qty
            FROM (SELECT (geae_wms_total_onhand_erl_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
			geae_wms_total_pick_release(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
			 FROM apps.mtl_system_items_b msib,
			      apps.mtl_parameters mp
			 WHERE 1 = 1
			   and msib.inventory_item_id = to_number(lp_inventory_item_id)
			   and msib.organization_id = mp.organization_id
			   and mp.organization_id = to_number(lp_organization_id)) A,
                 (SELECT (geae_wms_resv_qty_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
			geae_wms_total_resv(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
			 FROM apps.mtl_system_items_b msib,
			      apps.mtl_parameters mp
			 WHERE 1 = 1
			   and msib.inventory_item_id = to_number(lp_inventory_item_id)
			   and msib.organization_id = mp.organization_id
			   and mp.organization_id = to_number(lp_organization_id)) B;
--Added by OWMS Team : End
    /*Added by Capgemini OWMS Team for MyGE Changes*/
	ELSE
    SELECT nvl(sum(transaction_quantity), 0)
      INTO v_onhand_qty
      FROM GEAE_INV_MTL_ONHANDS_V moq
     WHERE moq.inventory_item_id = to_number(lp_inventory_item_id)
       AND moq.organization_id = to_number(lp_organization_id);
    /*Added by Capgemini OWMS Team for MyGE Changes*/
    END IF;
       /*Added by Capgemini OWMS Team for MyGE Changes*/
    /*Added by Capgemini OWMS Team for MyGE Changes*/
    IF v_onhand_qty > 0 THEN
      v_status_cd := 'Active';
    END IF;
    /*Added for AeroAMPS Nov-13 release Scenario 4 Anything with Inventory in erlanger /with out Inventory in erlanger*/
  END IF;
  IF v_status_cd = 'Active' THEN
    lp_inventory_item_status_code := 'Y';
  ELSIF v_status_cd = 'DO-NOT-SEND' THEN
    lp_inventory_item_status_code := 'D';
  ELSE
    lp_inventory_item_status_code := 'N';
  END IF;
  --  fnd_file.put_line(fnd_file.LOG,'inv_item_status onhand_qty - '||r_foxt_data_stg.onhand_qty );
  --  fnd_file.put_line(fnd_file.log,'attribute12 after item status:'|| r_foxt_data_stg.attribute12);
EXCEPTION
  WHEN e_exit THEN
    SELECT LOOKUP_CODE || ': ' || DESCRIPTION
      INTO pp_message
      FROM fnd_lookup_values
     WHERE LOOKUP_TYPE = 'GEAE_MYGE_ERROR_CODES'
       AND UPPER(LOOKUP_CODE) = v_error_code;
END get_inventory_item_status_code;
--MYJIRATEST-7138 Added new procedure for calculating Inventory Item status Code for Oderable Vs Non Oderable Change Ends
PROCEDURE GET_PRICE(
    P_SSO               VARCHAR2,
    P_OU_ID             VARCHAR2,
    P_INVENTORY_ITEM_ID NUMBER,
    P_PRICE_LIST_ID     NUMBER,
    P_UNIT_PRICE OUT NUMBER,
    P_LIST_LINE_ID OUT NUMBER )
AS
  --
  p_line_tbl QP_PREQ_GRP.LINE_TBL_TYPE;
  p_qual_tbl QP_PREQ_GRP.QUAL_TBL_TYPE;
  p_line_attr_tbl QP_PREQ_GRP.LINE_ATTR_TBL_TYPE;
  p_LINE_DETAIL_tbl QP_PREQ_GRP.LINE_DETAIL_TBL_TYPE;
  p_LINE_DETAIL_qual_tbl QP_PREQ_GRP.LINE_DETAIL_QUAL_TBL_TYPE;
  p_LINE_DETAIL_attr_tbl QP_PREQ_GRP.LINE_DETAIL_ATTR_TBL_TYPE;
  p_related_lines_tbl QP_PREQ_GRP.RELATED_LINES_TBL_TYPE;
  p_control_rec QP_PREQ_GRP.CONTROL_RECORD_TYPE;
  x_line_tbl QP_PREQ_GRP.LINE_TBL_TYPE;
  x_line_qual QP_PREQ_GRP.QUAL_TBL_TYPE;
  x_line_attr_tbl QP_PREQ_GRP.LINE_ATTR_TBL_TYPE;
  x_line_detail_tbl QP_PREQ_GRP.LINE_DETAIL_TBL_TYPE;
  x_line_detail_qual_tbl QP_PREQ_GRP.LINE_DETAIL_QUAL_TBL_TYPE;
  x_line_detail_attr_tbl QP_PREQ_GRP.LINE_DETAIL_ATTR_TBL_TYPE;
  x_related_lines_tbl QP_PREQ_GRP.RELATED_LINES_TBL_TYPE;
  x_return_status      VARCHAR2(240);
  x_return_status_text VARCHAR2(240);
  qual_rec QP_PREQ_GRP.QUAL_REC_TYPE;
  line_attr_rec QP_PREQ_GRP.LINE_ATTR_REC_TYPE;
  line_rec QP_PREQ_GRP.LINE_REC_TYPE;
  detail_rec QP_PREQ_GRP.LINE_DETAIL_REC_TYPE;
  ldet_rec QP_PREQ_GRP.LINE_DETAIL_REC_TYPE;
  rltd_rec QP_PREQ_GRP.RELATED_LINES_REC_TYPE;
  l_pricing_contexts_Tbl QP_Attr_Mapping_PUB.Contexts_Result_Tbl_Type;
  l_qualifier_contexts_Tbl QP_Attr_Mapping_PUB.Contexts_Result_Tbl_Type;
  v_line_tbl_cnt INTEGER;
  I BINARY_INTEGER;
  J BINARY_INTEGER;
  l_version  VARCHAR2(240);
  --L_File_Val Varchar2(60);
  V_User_Id Number := Null;
  V_Resp_Id Number := Null;
  v_RESP_APPL_ID Number := Null;
  v_app_short_name VARCHAR2(10);
BEGIN
  --oe_debug_pub.debug_on;
  --oe_debug_pub.initialize;
  --l_file_val := OE_DEBUG_PUB.Set_Debug_Mode('FILE');
  --OE_DEBUG_PUB.SETDEBUGLEVEL(5);
 -- QP_Attr_Mapping_PUB.Build_Contexts(p_request_type_code => 'ONT', p_pricing_type => 'L', x_price_contexts_result_tbl => l_pricing_contexts_Tbl, x_qual_contexts_result_tbl => l_qualifier_Contexts_Tbl);
  v_line_tbl_cnt := 1;
  ---- Control Record
  p_control_rec.pricing_event            := 'LINE'; -- 'BATCH'; LINE
  p_control_rec.calculate_flag           := 'Y';     --QP_PREQ_GRP.G_SEARCH_N_CALCULATE;
  p_control_rec.simulation_flag          := 'N';
  p_control_rec.rounding_flag            := 'Q';
  p_control_Rec.manual_discount_flag     := 'Y';
  p_control_rec.request_type_code        := 'ONT';
  p_control_rec.TEMP_TABLE_INSERT_FLAG   := 'Y';
  p_control_rec.source_order_amount_flag := 'Y';
  -------------------------
  ---- Line Records ---------
  line_rec.request_type_code := 'ONT';
  --line_rec.line_id := 2125125; -- Order Line Id. This can be any thing for this script
  line_rec.line_Index              := '1';       -- Request Line Index
  line_rec.line_type_code          := 'LINE';    -- LINE or ORDER(Summary Line)
  line_rec.pricing_effective_date  := SYSDATE;   -- Pricing as of what date ?
  line_rec.active_date_first       := SYSDATE;   -- Can be Ordered Date or Ship Date
  line_rec.active_date_second      := SYSDATE;   -- Can be Ordered Date or Ship Date
  line_rec.active_date_first_type  := 'NO TYPE'; -- ORD/SHIP
  line_rec.active_date_second_type := 'NO TYPE'; -- ORD/SHIP
  line_rec.line_quantity           := 1;         -- Ordered Quantity
  line_rec.line_uom_code           := 'EA';      -- Ordered UOM Code
  line_rec.currency_code           := 'USD';     -- Currency Code
  line_rec.price_flag              := 'Y';       -- Price Flag can have 'Y' , 'N'(No pricing) , 'P'(Phase)
  p_line_tbl(1)                    := line_rec;
  ---- Line Attribute Record
  line_attr_rec.LINE_INDEX              := 1;
  line_attr_rec.PRICING_CONTEXT         := 'ITEM'; --
  line_attr_rec.PRICING_ATTRIBUTE       := 'PRICING_ATTRIBUTE3';
  line_attr_rec.PRICING_ATTR_VALUE_FROM := 'ALL';
  line_attr_rec.VALIDATED_FLAG          := 'N';
  p_line_attr_tbl(1)                    := line_attr_rec;
  line_attr_rec.LINE_INDEX              := 1;
  line_attr_rec.PRICING_CONTEXT         := 'ITEM'; --
  line_attr_rec.PRICING_ATTRIBUTE       := 'PRICING_ATTRIBUTE1';
  line_attr_rec.PRICING_ATTR_VALUE_FROM := TO_CHAR(P_INVENTORY_ITEM_ID); -- INVENTORY ITEM ID
  line_attr_rec.VALIDATED_FLAG          := 'N';
  p_line_attr_tbl(2)                    := line_attr_rec;
  ---- Qualifier Attribute Record
  qual_rec.LINE_INDEX                := 1; -- Attributes for the above line. Attributes are attached with the line index
  qual_rec.QUALIFIER_CONTEXT         := 'MODLIST';
  qual_rec.QUALIFIER_ATTRIBUTE       := 'QUALIFIER_ATTRIBUTE4';
  qual_rec.QUALIFIER_ATTR_VALUE_FROM := TO_CHAR(P_PRICE_LIST_ID); -- PRICE LIST ID;
  qual_rec.COMPARISON_OPERATOR_CODE  := '=';
  qual_rec.VALIDATED_FLAG            := 'Y';
  p_qual_tbl(1)                      := qual_rec;
  --
 -- FND_GLOBAL.APPS_INITIALIZE(USER_ID => 43867, RESP_ID => 54274, RESP_APPL_ID => 660);
  --
  Begin
    Select User_Id
      into V_User_Id
     From Fnd_User
    Where 1 = 1
    And  User_Name = P_Sso;
   Exception
     when OTHERS THEN
     V_User_Id := Null;
  End;
  --MYJIRATEST-3512 Ravi S 18-NOV-2014
  IF V_User_Id IS NULL THEN
     BEGIN
        SELECT usr.user_id
          INTO V_User_Id
          FROM fnd_user usr, fnd_lookup_values dflt
         WHERE dflt.lookup_type = 'GEAE_MYGE_DEFAULT_LOGIN'
           AND dflt.enabled_flag = 'Y'
           AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(dflt.start_date_active,SYSDATE)) AND TRUNC(NVL(dflt.end_date_active,SYSDATE))
           AND dflt.lookup_code = P_OU_ID
           AND dflt.description = usr.user_name;
     EXCEPTION
        WHEN OTHERS THEN
           V_User_Id := Null;
     END;
  END IF;
--
--
   Begin
    Select frt.Responsibility_Id
          ,fa.Application_Id
          ,fa.application_short_name
      Into V_Resp_Id
           ,V_Resp_Appl_Id
           ,v_app_short_name
     From Fnd_Responsibility_Tl  Frt
         ,Fnd_Lookup_Values Flv
         ,Hr_Operating_Units Hru
         ,fnd_application fa
      Where 1 = 1
       and frt.language = 'US'
       and frt.responsibility_name = flv.description
       And flv.meaning = hru.name
       And flv.lookup_type = 'GEAE_MYGE_PRICE_RESPONSIBILITY'
       and fa.application_id = frt.application_id
       And Hru.Organization_Id = To_Number(P_Ou_Id);
      Exception
        When Others Then
        V_Resp_Id := Null;
        V_Resp_Appl_Id := NULL;
   END;
--
--  APPS INTIALIZE
 FND_GLOBAL.APPS_INITIALIZE(USER_ID => V_User_Id, RESP_ID => V_Resp_Id, RESP_APPL_ID => V_Resp_Appl_Id);
 MO_GLOBAL.SET_POLICY_CONTEXT('S', P_OU_ID);
 MO_GLOBAL.INIT(v_app_short_name);
--
  QP_PREQ_PUB.PRICE_REQUEST(p_line_tbl, p_qual_tbl, p_line_attr_tbl, p_line_detail_tbl, p_line_detail_qual_tbl, p_line_detail_attr_tbl, p_related_lines_tbl, p_control_rec, x_line_tbl, x_line_qual, x_line_attr_tbl, x_line_detail_tbl, x_line_detail_qual_tbl, x_line_detail_attr_tbl, x_related_lines_tbl, x_return_status, x_return_status_text);
  I    := X_LINE_TBL.first;
  IF I IS NOT NULL THEN
    LOOP
      EXIT
    WHEN I = X_LINE_TBL.LAST;
      I   := x_line_tbl.NEXT(I);
    END LOOP;
  END IF;
  J    := x_line_detail_tbl.FIRST;
  IF J IS NOT NULL THEN
    LOOP
      Exit
    When X_Line_Detail_Tbl(J).List_Line_Type_Code = 'PLL';
    --J = X_Line_Detail_Tbl.Last;
      J   := x_line_detail_tbl.NEXT(J);
    END LOOP;
  end if;
  If I               Is Not Null Then
    P_UNIT_PRICE     := X_LINE_TBL(I).UNIT_PRICE;
    IF J             IS NOT NULL THEN
      P_List_Line_Id := X_Line_Detail_Tbl(J).List_Line_Id;
    ELSE
      P_LIST_LINE_ID := NULL;
      P_UNIT_PRICE   := NULL;
    END IF;
  ELSE
    P_UNIT_PRICE   := NULL;
    P_LIST_LINE_ID := NULL;
  END IF;
End Get_Price;
FUNCTION GET_PRICE_LIST_NAME(P_PRICE_LIST_ID     NUMBER)
     RETURN VARCHAR2
AS
   L_PRICE_LIST_NAME VARCHAR2(240);
BEGIN
   BEGIN
      SELECT DESCRIPTION
        INTO L_PRICE_LIST_NAME
        FROM fnd_lookup_values
       WHERE lookup_type = 'GEAE_MYGE_PRICE_LIST_NAME'
         AND lookup_code = P_PRICE_LIST_ID;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         SELECT NAME
           INTO L_PRICE_LIST_NAME
           FROM qp_list_headers_tl
          WHERE list_header_id = P_PRICE_LIST_ID;
   END;
   RETURN L_PRICE_LIST_NAME;
EXCEPTION
   WHEN OTHERS THEN
      RETURN NULL;
END GET_PRICE_LIST_NAME;
PROCEDURE GET_KIT_STRUCTURE(
    P_SSO       VARCHAR2,
    P_IACO_CODE VARCHAR2,
    P_CUST_ID V_CUST_ID_ARRAY,
    P_ROLE    VARCHAR2,
    P_OU_ID   VARCHAR2,
    P_ITEM_ID NUMBER,
    P_KIT_HDR_DTL OUT V_KIT_HDR_INFO_ARRAY,
    P_KIT_COMP_DTL OUT V_KIT_COMP_INFO_ARRAY,
    P_MSG OUT VARCHAR2
)
AS
   CURSOR C_EXPL(P_ITEM_ID NUMBER) IS
      SELECT msib.segment1 part_number, msib.description part_description, bcb.attribute6 default_value, bet.*
        FROM bom_explosion_temp bet, mtl_system_items_b msib, bom_components_b bcb
       WHERE bet.top_item_id = P_ITEM_ID
         AND bet.component_item_id = msib.inventory_item_id
         AND bet.organization_id = msib.organization_id
         AND bet.component_item_id = bcb.component_item_id(+)
         AND bet.component_sequence_id  = bcb.component_sequence_id(+)
         AND NVL(bcb.disable_date,TRUNC(SYSDATE+1)) >= TRUNC(SYSDATE)
      ORDER BY bet.sort_order;
   l_cfg_hdr_id NUMBER;
   l_part_details V_PART_DETAILS;
   l_part_avail V_PART_AVAIL;
   l_part_price V_PART_PRICE;
   l_part_applicable V_PART_APPLICABLE;
   l_message VARCHAR2(500);
   l_avail_message VARCHAR2(500);
   l_price_message VARCHAR2(500);
   l_kit_ind VARCHAR2(1);
   l_user_id NUMBER;
   l_resp_id NUMBER;
   l_app_id NUMBER;
   l_loc_msg VARCHAR2(100);
   l_config_err VARCHAR2(500);
   l_comp_count NUMBER;
   l_hdr_count NUMBER;
   l_comp_level VARCHAR2(100);
   l_comp_avail NUMBER;
   l_kit_avail NUMBER;
   l_kit_price NUMBER;
   l_unit_price NUMBER;
   l_sum_price NUMBER;
   l_list_line_id NUMBER;
   l_ext_price NUMBER;
   l_kit_message VARCHAR2(500);
   l_kit_pr_er_cd NUMBER;
   l_exploded VARCHAR2(1);
   l_one_indent VARCHAR2(20) := '     ';
   l_indent VARCHAR2(50);
   l_null_avail NUMBER;
   l_price_list_id NUMBER;
   l_config_exists NUMBER;
   e_exit EXCEPTION;
   l_part_discounts V_PART_DISCOUNTS;
   l_discount_message VARCHAR2(100);
   l_critical_part VARCHAR2(10);
   l_part_bom V_PART_BOM; --MYJIRATEST-6272 Ravi S 03-MAR-2015
   l_ISODERABLE VARCHAR2(1);--MYJIRATEST-7138 24-MAR-2015   Abhinav Srivastava Oderable Vs Non Oderable changes
  v_item_source                VARCHAR2(500); -- Added for OWMS Implementation US192483/US192484
  v_er1_source VARCHAR2(500); -- Added for OWMS Implementation US192483/US192484
  v_er2_source VARCHAR2(500); -- Added for OWMS Implementation US192483/US192484
  v_er3_source VARCHAR2(500); -- Added for OWMS Implementation US192483/US192484
  v_item_number                VARCHAR2(30); -- Added for OWMS Implementation US192483/US192484
BEGIN
   l_loc_msg := ' Getting user ID ';
   SELECT USER_ID INTO l_user_id
     FROM FND_USER
    WHERE USER_NAME=P_SSO;
   l_loc_msg := ' Fetching responsibility and application for kit explosion ';
   SELECT RESP.RESPONSIBILITY_ID,RESP.APPLICATION_ID
     INTO l_resp_id,l_app_id
     FROM FND_RESPONSIBILITY_TL RESP,
          FND_LOOKUP_VALUES FLV,
          HR_OPERATING_UNITS HOU
    WHERE HOU.NAME = FLV.MEANING
      AND RESP.RESPONSIBILITY_NAME = FLV.DESCRIPTION
      AND HOU.ORGANIZATION_ID = P_OU_ID
      AND FLV.LOOKUP_TYPE = 'GEAE_MYGE_ORDER_RESPONSIBILITY';
   SELECT COUNT(1)
     INTO l_config_exists
     FROM bom_explosion_temp bet, mtl_system_items_b msib, bom_components_b bcb
    WHERE bet.top_item_id = P_ITEM_ID
      AND bet.component_item_id = msib.inventory_item_id
      AND bet.organization_id = msib.organization_id
      AND bet.component_item_id = bcb.component_item_id(+)
      AND bet.component_sequence_id  = bcb.component_sequence_id(+)
      AND NVL(bcb.disable_date,TRUNC(SYSDATE+1)) >= TRUNC(SYSDATE);
   IF l_config_exists = 0 THEN
      l_loc_msg := ' Calling CREATE_KIT_CONFIG ';
      GEAE_MYGE_CART_PKG.CREATE_KIT_CONFIG(l_user_id,l_app_id,l_resp_id,P_ITEM_ID,1,'N',l_cfg_hdr_id,l_config_err); --MYJIRATEST-3512 Ravi S 18-NOV-2014
      IF l_config_err IS NOT NULL THEN
         P_MSG := 'Error in CREATE_KIT_CONFIG '||l_config_err;
         RAISE e_exit;
      END IF;
   END IF;
   l_loc_msg := ' Initializing Output VARRAYS ';
   l_comp_count := 0;
   l_hdr_count := 0;
   P_KIT_HDR_DTL := V_KIT_HDR_INFO_ARRAY();
   P_KIT_COMP_DTL := V_KIT_COMP_INFO_ARRAY();
   l_exploded := 'N';
   l_loc_msg := ' Calling cursor C_EXPL ';
   FOR r_expl IN C_EXPL(P_ITEM_ID) LOOP
      l_exploded := 'Y';
      IF r_expl.assembly_item_id IS NULL THEN
         l_hdr_count := l_hdr_count + 1;
         P_KIT_HDR_DTL.EXTEND(1);
         l_loc_msg := ' Assignment to P_KIT_HDR_DTL '||l_hdr_count||' ';
         P_KIT_HDR_DTL(l_hdr_count) := V_KIT_HDR_INFO_BO(r_expl.part_number,r_expl.part_description,NULL,NULL,NULL,NULL,r_expl.component_item_id,l_hdr_count);
      ELSE
         l_comp_count := l_comp_count + 1;
         P_KIT_COMP_DTL.EXTEND(1);
         l_loc_msg := ' Assignment to P_KIT_COMP_DTL '||l_comp_count||' ';
         P_KIT_COMP_DTL(l_comp_count) := V_KIT_COMP_INFO_BO(NULL,r_expl.part_number,r_expl.part_description,r_expl.component_quantity,NULL,NULL,NULL,NULL,r_expl.default_value,r_expl.sort_order,r_expl.component_item_id,r_expl.assembly_item_id,r_expl.top_item_id,l_comp_count,r_expl.plan_level,r_expl.bom_item_type);
      END IF;
   END LOOP;
   IF l_exploded = 'N' THEN
      P_MSG := 'The KIT could not be exploded';
      RAISE e_exit;
   END IF;
   l_loc_msg := ' Start logic for COMP_LEVEL ';
   FOR r_level IN (SELECT *
                     FROM TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY))
                    WHERE comp_level IS NULL
                   ORDER BY row_num) LOOP
      IF r_level.assembly_item_id = P_ITEM_ID THEN
         l_loc_msg := ' Assigning COMP_LEVEL for top level ';
         SELECT TO_CHAR(MAX(NVL(TO_NUMBER(comp_level),0))+1)
           INTO l_comp_level
           FROM TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY))
          WHERE assembly_item_id = P_ITEM_ID;
      ELSE
         l_loc_msg := ' Assigning COMP_LEVEL for lower level ';
         SELECT parent.comp_level||'.'||TO_CHAR(MAX(NVL(TO_NUMBER(SUBSTR(child.comp_level,INSTR(child.comp_level,parent.comp_level)+2)),0))+1)
           INTO l_comp_level
           FROM TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY)) parent,
                TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY)) child
          WHERE parent.component_item_id = child.assembly_item_id
            AND child.component_item_id = r_level.component_item_id
         GROUP BY parent.comp_level;
      END IF;
      l_loc_msg := ' Assignment to P_KIT_COMP_DTL '||r_level.row_num||' for comp_level ';
      P_KIT_COMP_DTL(r_level.row_num) := V_KIT_COMP_INFO_BO(l_comp_level,r_level.comp_part_number,r_level.comp_part_desc,r_level.comp_qty,r_level.comp_availability,r_level.comp_unit_price,r_level.comp_ext_price,r_level.customer_code,r_level.default_value,r_level.sort_order,r_level.component_item_id,r_level.assembly_item_id,r_level.top_model_item_id,r_level.row_num,r_level.plan_level,r_level.bom_item_type);
   END LOOP;
   l_loc_msg := ' Start logic for COMP_AVAIL ';
   FOR r_avail IN (SELECT *
                     FROM TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY))
                    WHERE comp_availability IS NULL
                   ORDER BY row_num) LOOP
      IF r_avail.bom_item_type = 2 THEN
         l_comp_avail := NULL; --MYJIRATEST-4654 Ravi S 28-NOV-2014
      ELSE
         l_loc_msg := ' Fetch COMP_AVAIL for '||r_avail.comp_part_number||' ';
--Added by OWMS Team : START
                  BEGIN
                        --
                           v_item_source := NULL;
			   --
			   v_er1_source := GEAE_INV_GET_SOURCE_CODE ('ER1',r_avail.comp_part_number,'Y');
			   v_er2_source := GEAE_INV_GET_SOURCE_CODE ('ER2',r_avail.comp_part_number,'Y');
			   v_er3_source := GEAE_INV_GET_SOURCE_CODE ('ER3',r_avail.comp_part_number,'Y');
			   --
			   IF v_er1_source = 'CPL' OR v_er2_source = 'CPL' OR v_er3_source = 'CPL' THEN
				v_item_source := 'CPL';
			   ELSE
				 v_item_source := 'ERL';
			   END IF;
			   --

                            SELECT NVL(SUM(QTY),0)
                                INTO l_comp_avail
                                FROM (SELECT NVL((A.QTY - B.QTY),0)  QTY
				    FROM (SELECT (geae_wms_total_onhand_erl_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
						geae_wms_total_pick_release(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
						 FROM apps.mtl_system_items_b msib,
						      apps.mtl_parameters mp
						 WHERE 1 = 1
						   and msib.inventory_item_id = r_avail.component_item_id
						   and msib.organization_id = mp.organization_id
						   and mp.organization_code = v_item_source
						   AND v_item_source <> 'CPL') A,
					 (SELECT (geae_wms_resv_qty_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
						geae_wms_total_resv(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
						 FROM apps.mtl_system_items_b msib,
						      apps.mtl_parameters mp
						 WHERE 1 = 1
						   and msib.inventory_item_id = r_avail.component_item_id
						   and msib.organization_id = mp.organization_id
						   and mp.organization_code = v_item_source
						   AND v_item_source <> 'CPL') B
                                      UNION ALL
                                      SELECT (A.QTY - B.QTY)  QTY
                                        FROM (SELECT NVL(SUM(MOQ.TRANSACTION_QUANTITY), 0) QTY
                                                FROM GEAE_INV_MTL_ONHANDS_V MOQ
                                               WHERE INVENTORY_ITEM_ID = r_avail.component_item_id
                                                 AND SUBINVENTORY_CODE IN ('STOCK','STG')
                                                 AND ORGANIZATION_ID IN
                                                     (SELECT ORGANIZATION_ID
                                                        FROM MTL_PARAMETERS
                                                       WHERE ORGANIZATION_CODE = V_ITEM_SOURCE)
                                                  AND v_item_source <> 'ERL'     ) A,
                                             (SELECT NVL(SUM(RESERVATION_QUANTITY), 0) QTY
                                                FROM MTL_RESERVATIONS
                                               WHERE INVENTORY_ITEM_ID = r_avail.component_item_id
                                                 AND ORGANIZATION_ID IN
                                                     (SELECT ORGANIZATION_ID
                                                        FROM MTL_PARAMETERS
                                                       WHERE ORGANIZATION_CODE = V_ITEM_SOURCE)
                                                  AND v_item_source <> 'ERL'     ) B);
                             EXCEPTION
                                WHEN OTHERS THEN
                                               l_comp_avail := 0;
                              END;
--Added by OWMS Team : END
      END IF;
      l_loc_msg := ' Assignment to P_KIT_COMP_DTL '||r_avail.row_num||' for comp_avail ';
      P_KIT_COMP_DTL(r_avail.row_num) := V_KIT_COMP_INFO_BO(r_avail.comp_level,r_avail.comp_part_number,r_avail.comp_part_desc,r_avail.comp_qty,l_comp_avail,r_avail.comp_unit_price,r_avail.comp_ext_price,r_avail.customer_code,r_avail.default_value,r_avail.sort_order,r_avail.component_item_id,r_avail.assembly_item_id,r_avail.top_model_item_id,r_avail.row_num,r_avail.plan_level,r_avail.bom_item_type);
   END LOOP;
   l_loc_msg := ' Logic for KIT_AVAIL ';
   SELECT COUNT(1)
     INTO l_null_avail
     FROM TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY))
    WHERE comp_qty IS NULL;
   IF l_null_avail > 0 THEN
      l_kit_avail := NULL;
   ELSE
      SELECT FLOOR(MIN(NVL(comp_availability,0)/comp_qty))
        INTO l_kit_avail
        FROM TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY))
       WHERE comp_qty IS NOT NULL
         AND bom_item_type <> 2; --MYJIRATEST-4645 Ravi S 27-NOV-2014
   END IF;
   l_loc_msg := ' Assignment to P_KIT_HDR_DTL '||l_hdr_count||' for kit_avail ';
   P_KIT_HDR_DTL(l_hdr_count) := V_KIT_HDR_INFO_BO(P_KIT_HDR_DTL(l_hdr_count).kit_name,P_KIT_HDR_DTL(l_hdr_count).kit_description,l_kit_avail,P_KIT_HDR_DTL(l_hdr_count).kit_message,P_KIT_HDR_DTL(l_hdr_count).customer_code,P_KIT_HDR_DTL(l_hdr_count).kit_price,P_KIT_HDR_DTL(l_hdr_count).kit_item_id,l_hdr_count);
   IF P_ROLE      = 'Global Enquiry' THEN --MYJIRATEST-4645 Ravi S 27-NOV-2014
      l_loc_msg := ' Start logic for Kit Price for Global Enquiry ';
      BEGIN
         SELECT qlht.list_header_id
           INTO l_price_list_id
           FROM qp_list_headers_tl qlht, fnd_lookup_values def_pl
          WHERE def_pl.lookup_code = 'GEAE_MYGE_ITEM_CONFG_DFLT_ORG'
            AND def_pl.enabled_flag = 'Y'
            AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(def_pl.start_date_active,SYSDATE)) AND TRUNC(NVL(def_pl.end_date_active,SYSDATE))
            AND def_pl.meaning = P_OU_ID
            AND def_pl.description = qlht.name;
      EXCEPTION
         WHEN OTHERS THEN
            l_price_list_id := NULL;
      END;
      IF l_price_list_id IS NOT NULL THEN
         l_loc_msg := ' Get KIT price from GET_PRICE proc ';
         GET_PRICE(P_SSO,P_OU_ID,P_ITEM_ID,l_price_list_id,l_kit_price,l_list_line_id);
         l_loc_msg := ' Assignment to P_KIT_HDR_DTL '||l_hdr_count||' for Global Enquiry ';
         P_KIT_HDR_DTL(l_hdr_count) := V_KIT_HDR_INFO_BO(P_KIT_HDR_DTL(l_hdr_count).kit_name,P_KIT_HDR_DTL(l_hdr_count).kit_description,P_KIT_HDR_DTL(l_hdr_count).kit_availability,P_KIT_HDR_DTL(l_hdr_count).kit_message,P_KIT_HDR_DTL(l_hdr_count).customer_code,l_kit_price,P_KIT_HDR_DTL(l_hdr_count).kit_item_id,l_hdr_count);
         l_loc_msg := ' Start logic for COMP_PRICE for Global Enquiry ';
         FOR r_price IN (SELECT *
                           FROM TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY))
                         ORDER BY row_num) LOOP
            l_loc_msg := ' Fetching COMP price for '||r_price.comp_part_number||' ';
            l_unit_price := NULL;
            GET_PRICE(P_SSO,P_OU_ID,r_price.component_item_id,l_price_list_id,l_unit_price,l_list_line_id);
            IF l_unit_price IS NOT NULL THEN
               l_ext_price := l_unit_price*r_price.comp_qty;
            ELSE
               l_ext_price := NULL;
            END IF;
            l_loc_msg := ' Assignment to P_KIT_COMP_DTL '||r_price.row_num||' for Global Enquiry ';
            P_KIT_COMP_DTL(r_price.row_num) := V_KIT_COMP_INFO_BO(r_price.comp_level,r_price.comp_part_number,r_price.comp_part_desc,r_price.comp_qty,r_price.comp_availability,l_unit_price,l_ext_price,r_price.customer_code,r_price.default_value,r_price.sort_order,r_price.component_item_id,r_price.assembly_item_id,r_price.top_model_item_id,r_price.row_num,r_price.plan_level,r_price.bom_item_type);
         END LOOP;
      END IF;
   ELSE
      l_loc_msg := ' Get KIT data from Item Details proc ';
      GET_ITEM_PRICE_AVAIL(P_SSO,P_IACO_CODE,P_CUST_ID,P_ROLE,P_OU_ID,P_ITEM_ID,l_part_details,l_part_avail,l_part_price,l_part_applicable,l_message,l_avail_message,l_price_message,l_kit_ind,l_part_discounts,l_discount_message,l_critical_part,l_part_bom,l_ISODERABLE); --Added l_part_bom MYJIRATEST-6272 Ravi S 03-MAR-2015 and MYJIRATEST-7138 24-MAR-2015   Abhinav Added l_ISODERABLE for Oderable Vs Non Oderable changes
      l_loc_msg := ' Loop for kit part applicable list ';
      FOR r_kit_cc IN 1..l_part_applicable.COUNT LOOP
         l_loc_msg := ' Getting Kit Price ';
         BEGIN
            SELECT unit_price
              INTO l_kit_price
              FROM TABLE(CAST(l_part_price AS V_PART_PRICE))
             WHERE catalog = GET_PRICE_LIST_NAME(l_part_applicable(r_kit_cc).price_list_id)
               AND inventory_item_id = P_ITEM_ID;
         EXCEPTION
            WHEN NO_DATA_FOUND THEN
               l_kit_price := NULL;
         END;
         IF P_KIT_HDR_DTL(l_hdr_count).customer_code IS NOT NULL THEN
            l_hdr_count := l_hdr_count + 1;
            P_KIT_HDR_DTL.EXTEND(1);
            l_loc_msg := ' Assignment to P_KIT_HDR_DTL '||l_hdr_count||' for cust_code '||l_part_applicable(r_kit_cc).cust_code||' ';
            P_KIT_HDR_DTL(l_hdr_count) := V_KIT_HDR_INFO_BO(P_KIT_HDR_DTL(1).kit_name,P_KIT_HDR_DTL(1).kit_description,P_KIT_HDR_DTL(1).kit_availability,P_KIT_HDR_DTL(1).kit_message,l_part_applicable(r_kit_cc).cust_code,l_kit_price,P_KIT_HDR_DTL(1).kit_item_id,l_hdr_count);
         ELSE
            l_loc_msg := ' Assignment to P_KIT_HDR_DTL '||l_hdr_count||' for cust_code '||l_part_applicable(r_kit_cc).cust_code||' ';
            P_KIT_HDR_DTL(l_hdr_count) := V_KIT_HDR_INFO_BO(P_KIT_HDR_DTL(l_hdr_count).kit_name,P_KIT_HDR_DTL(l_hdr_count).kit_description,P_KIT_HDR_DTL(l_hdr_count).kit_availability,P_KIT_HDR_DTL(l_hdr_count).kit_message,l_part_applicable(r_kit_cc).cust_code,l_kit_price,P_KIT_HDR_DTL(l_hdr_count).kit_item_id,l_hdr_count);
         END IF;
         l_loc_msg := ' Start logic for COMP_PRICE ';
         FOR r_price IN (SELECT *
                           FROM TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY))
                         ORDER BY row_num) LOOP
            l_loc_msg := ' Fetching COMP price for '||r_price.comp_part_number||' ';
            l_unit_price := NULL;
            GET_PRICE(P_SSO,P_OU_ID,r_price.component_item_id,l_part_applicable(r_kit_cc).price_list_id,l_unit_price,l_list_line_id);
            IF l_unit_price IS NOT NULL THEN
               l_ext_price := l_unit_price*r_price.comp_qty;
            ELSE
               l_ext_price := NULL;
            END IF;
            IF r_price.customer_code IS NOT NULL THEN
               l_comp_count := l_comp_count + 1;
               P_KIT_COMP_DTL.EXTEND(1);
               l_loc_msg := ' Assignment to P_KIT_COMP_DTL '||l_comp_count||' for cust_code '||l_part_applicable(r_kit_cc).cust_code||' ';
               P_KIT_COMP_DTL(l_comp_count) := V_KIT_COMP_INFO_BO(r_price.comp_level,r_price.comp_part_number,r_price.comp_part_desc,r_price.comp_qty,r_price.comp_availability,l_unit_price,l_ext_price,l_part_applicable(r_kit_cc).cust_code,r_price.default_value,r_price.sort_order,r_price.component_item_id,r_price.assembly_item_id,r_price.top_model_item_id,l_comp_count,r_price.plan_level,r_price.bom_item_type);
            ELSE
               l_loc_msg := ' Assignment to P_KIT_COMP_DTL '||r_price.row_num||' for cust_code '||l_part_applicable(r_kit_cc).cust_code||' ';
               P_KIT_COMP_DTL(r_price.row_num) := V_KIT_COMP_INFO_BO(r_price.comp_level,r_price.comp_part_number,r_price.comp_part_desc,r_price.comp_qty,r_price.comp_availability,l_unit_price,l_ext_price,l_part_applicable(r_kit_cc).cust_code,r_price.default_value,r_price.sort_order,r_price.component_item_id,r_price.assembly_item_id,r_price.top_model_item_id,r_price.row_num,r_price.plan_level,r_price.bom_item_type);
            END IF;
         END LOOP;
      END LOOP;
   END IF;
   l_loc_msg := ' Start logic for Kit price comparison ';
   FOR r_comp_pr IN (SELECT *
                       FROM TABLE(CAST(P_KIT_HDR_DTL AS V_KIT_HDR_INFO_ARRAY))
                     ORDER BY row_num) LOOP
      DBMS_OUTPUT.PUT_LINE('In Kit hdr loop for message');
      IF r_comp_pr.kit_price IS NULL THEN
         l_kit_pr_er_cd := 8041;
      ELSE
         IF r_comp_pr.customer_code IS NOT NULL THEN
            l_loc_msg := ' Getting sum for cust '||r_comp_pr.customer_code||' ';
            SELECT SUM(comp_ext_price)
              INTO l_sum_price
              FROM TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY))
             WHERE customer_code = r_comp_pr.customer_code;
         ELSE --MYJIRATEST-4645 Ravi S 27-NOV-2014
            l_loc_msg := ' Getting sum for null cust ';
            SELECT SUM(comp_ext_price)
              INTO l_sum_price
              FROM TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY))
             WHERE customer_code IS NULL;
         END IF;
         l_loc_msg := ' Setting the kit message when kit price found ';
         IF l_sum_price = r_comp_pr.kit_price THEN
            l_kit_pr_er_cd := NULL;
         ELSE
            l_kit_pr_er_cd := 8042;
         END IF;
      END IF;
      IF l_kit_pr_er_cd IS NOT NULL THEN
         l_kit_message := SUBSTR(GEAE_MYGE_CART_PKG.GET_ERR_MSG(l_kit_pr_er_cd),6);
      ELSE
         l_kit_message := NULL;
      END IF;
      l_loc_msg := ' Assignment to P_KIT_HDR_DTL '||r_comp_pr.row_num||' for kit_message ';
      P_KIT_HDR_DTL(r_comp_pr.row_num) := V_KIT_HDR_INFO_BO(P_KIT_HDR_DTL(r_comp_pr.row_num).kit_name,P_KIT_HDR_DTL(r_comp_pr.row_num).kit_description,P_KIT_HDR_DTL(r_comp_pr.row_num).kit_availability,l_kit_message,P_KIT_HDR_DTL(r_comp_pr.row_num).customer_code,P_KIT_HDR_DTL(r_comp_pr.row_num).kit_price,P_KIT_HDR_DTL(r_comp_pr.row_num).kit_item_id,r_comp_pr.row_num);
   END LOOP;
/*   --MYJIRATEST-4645 Ravi S 27-NOV-2014
   FOR r_indent IN (SELECT comp.*, REGEXP_COUNT(REPLACE(comp.comp_level,'.','#'),'#') point_count
                      FROM TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY)) comp
                      ORDER BY comp.row_num) LOOP
      l_loc_msg := ' Deciding indentation for '||r_indent.comp_part_number||' ';
      l_indent := NULL;
      FOR i IN 1..r_indent.point_count LOOP
         l_indent := l_indent||l_one_indent;
      END LOOP;
      l_loc_msg := ' Doing indentation for '||r_indent.comp_part_number||' by '||r_indent.point_count;
      P_KIT_COMP_DTL(r_indent.row_num) := V_KIT_COMP_INFO_BO(r_indent.comp_level,l_indent||r_indent.comp_part_number,r_indent.comp_part_desc,r_indent.comp_qty,r_indent.comp_availability,r_indent.comp_unit_price,r_indent.comp_ext_price,r_indent.customer_code,r_indent.default_value,r_indent.sort_order,r_indent.component_item_id,r_indent.assembly_item_id,r_indent.top_model_item_id,r_indent.row_num,r_indent.plan_level,r_indent.bom_item_type);
   END LOOP;
   l_loc_msg := ' Start logic for COMP_PRICE ';
   FOR r_price IN (SELECT *
                     FROM TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY))
                    WHERE customer_code IS NULL
                   ORDER BY row_num) LOOP
      l_loc_msg := ' Get COMP data from Item Details proc '||r_price.comp_part_number||' ';
      GET_ITEM_PRICE_AVAIL(P_SSO,P_IACO_CODE,P_CUST_ID,P_ROLE,P_OU_ID,r_price.component_item_id,l_part_details,l_part_avail,l_part_price,l_part_applicable,l_message,l_avail_message,l_price_message,l_kit_ind);
      l_loc_msg := ' Putting Customer code, price in P_KIT_COMP_DTL ';
      FOR r_comp_cc IN 1..l_part_applicable.COUNT LOOP
         IF l_part_applicable(r_comp_cc).price_list_id IS NOT NULL THEN
            l_loc_msg := ' Fetching COMP price for '||r_price.comp_part_number||' ';
            BEGIN
               SELECT unit_price
                 INTO l_unit_price
                 FROM TABLE(CAST(l_part_price AS V_PART_PRICE))
                WHERE catalog = GET_PRICE_LIST_NAME(l_part_applicable(r_comp_cc).price_list_id)
                  AND inventory_item_id = r_price.component_item_id;
            EXCEPTION
               WHEN NO_DATA_FOUND THEN
                  l_unit_price := NULL;
            END;
            IF l_unit_price IS NOT NULL THEN
               l_ext_price := l_unit_price*r_price.comp_qty;
            ELSE
               l_ext_price := NULL;
            END IF;
         ELSE
            l_unit_price := NULL;
            l_ext_price := NULL;
         END IF;
         IF r_price.customer_code IS NOT NULL THEN
            l_comp_count := l_comp_count + 1;
            P_KIT_COMP_DTL.EXTEND(1);
            l_loc_msg := ' Before assignment to P_KIT_COMP_DTL '||l_comp_count||' for cust_code '||l_part_applicable(r_comp_cc).cust_code||' ';
            P_KIT_COMP_DTL(l_comp_count) := V_KIT_COMP_INFO_BO(r_price.comp_level,r_price.comp_part_number,r_price.comp_part_desc,r_price.comp_qty,r_price.comp_availability,l_unit_price,l_ext_price,l_part_applicable(r_comp_cc).cust_code,r_price.default_value,r_price.sort_order,r_price.component_item_id,r_price.assembly_item_id,r_price.top_model_item_id,l_comp_count);
            l_loc_msg := ' After assignment to P_KIT_COMP_DTL '||l_comp_count||' for cust_code '||l_part_applicable(r_comp_cc).cust_code||' ';
         ELSE
            l_loc_msg := ' Before assignment to P_KIT_COMP_DTL '||r_price.row_num||' for cust_code '||l_part_applicable(r_comp_cc).cust_code||' ';
            P_KIT_COMP_DTL(r_price.row_num) := V_KIT_COMP_INFO_BO(r_price.comp_level,r_price.comp_part_number,r_price.comp_part_desc,r_price.comp_qty,r_price.comp_availability,l_unit_price,l_ext_price,l_part_applicable(r_comp_cc).cust_code,r_price.default_value,r_price.sort_order,r_price.component_item_id,r_price.assembly_item_id,r_price.top_model_item_id,r_price.row_num);
            l_loc_msg := ' After assignment to P_KIT_COMP_DTL '||r_price.row_num||' for cust_code '||l_part_applicable(r_comp_cc).cust_code||' ';
         END IF;
      END LOOP;
   END LOOP;
   */
EXCEPTION
   WHEN e_exit THEN
      NULL;
   WHEN OTHERS THEN
      P_MSG := 'Oracle Error while '|| l_loc_msg ||SUBSTR(SQLERRM,1,100);
END GET_KIT_STRUCTURE;
--Ankita S MYJIRATEST-8466 on 02-JUN-2015
PROCEDURE ITEM_DTL_PART_NUM(
    P_SSO       VARCHAR2,
    P_IACO_CODE VARCHAR2,
    P_CUST_ID V_CUST_ID_ARRAY,
    P_ROLE    VARCHAR2,
    P_OU_ID   VARCHAR2,
    P_PART_NUM VARCHAR2,
    P_PART_DETAILS OUT V_PART_DETAILS,
    P_PART_AVAIL OUT V_PART_AVAIL,
    P_PART_PRICE OUT V_PART_PRICE,
    P_PART_APPLICABLE OUT V_PART_APPLICABLE,
    P_MESSAGE OUT VARCHAR2,
    P_AVAIL_MESSAGE OUT VARCHAR2,
    P_PRICE_MESSAGE OUT VARCHAR2,
    P_KIT_IND         OUT VARCHAR2,
    P_PART_DISCOUNTS  OUT V_PART_DISCOUNTS,
    P_DISC_MESSAGE    OUT VARCHAR2,
    P_CRITICAL_PART   OUT VARCHAR2,
    P_PART_BOM        OUT V_PART_BOM, --MYJIRATEST-6272 Ravi S 03-MAR-2015
    P_ISODERABLE      OUT VARCHAR2  --MYJIRATEST-7138 24-MAR-2015   Abhinav  Oderable Vs Non Oderable changes
    )
AS
l_inventory_item_id   NUMBER;
BEGIN
 /*   P_PART_DETAILS    := V_PART_DETAILS();
    P_PART_AVAIL      := V_PART_AVAIL();
    P_PART_PRICE      := V_PART_PRICE();
    P_PART_APPLICABLE := V_PART_APPLICABLE();
    P_PART_DISCOUNTS  := V_PART_DISCOUNTS();
    P_PART_BOM        := V_PART_BOM();*/
   BEGIN
    SELECT INVENTORY_ITEM_ID
      INTO l_inventory_item_id
      FROM mtl_system_items_b
     WHERE SEGMENT1=P_PART_NUM
       AND rownum=1;
   EXCEPTION
     WHEN NO_DATA_FOUND THEN
       SELECT LOOKUP_CODE
       || ': '
       || DESCRIPTION
       INTO p_message
       FROM fnd_lookup_values
       WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
       AND UPPER(LOOKUP_CODE) = UPPER('8033');
     goto end_proc;
   END;
  --Calling GET_ITEM_PRICE_AVAIL
  apps.GEAE_MYGE_ITEM_DTL_PKG.GET_ITEM_PRICE_AVAIL(P_SSO,
                                                   P_IACO_CODE,
                                                   P_CUST_ID,
                                                   P_ROLE,
                                                   P_OU_ID,
                                                   l_inventory_item_id,
                                                   P_PART_DETAILS,
                                                   P_PART_AVAIL,
                                                   P_PART_PRICE,
                                                   P_PART_APPLICABLE,
                                                   P_MESSAGE,
                                                   P_AVAIL_MESSAGE,
                                                   P_PRICE_MESSAGE,
                                                   P_KIT_IND,
                                                   P_PART_DISCOUNTS,
                                                   P_DISC_MESSAGE,
                                                   P_CRITICAL_PART,
                                                   P_PART_BOM,
                                                   P_ISODERABLE);
  <<end_proc>>
  NULL;
END ITEM_DTL_PART_NUM;
--Neelima Y MYJIRATEST-9104 on 18-AUG-2015
PROCEDURE ITEM_DTL_PART_NUM_BULK( P_SSO               VARCHAR2,
                                  P_IACO_CODE         VARCHAR2,
                                  P_CUST_ID           V_CUST_ID_ARRAY,
                                  P_ROLE              VARCHAR2,
                                  P_OU_ID             VARCHAR2,
                                  P_PART_NUM          V_PART_NUM_LIST_ARRAY,
                                  P_BULK_PART_DETAILS OUT V_BULK_PART_DETAILS,
                                  P_MESSAGE           OUT VARCHAR2
                                 )
  AS
  V_INVENTORY_ITEM_ID     NUMBER;
  V_EXIST                 VARCHAR2(1);
  V_MESSAGE               VARCHAR2(2000);
  V_QTY_TOTAL             NUMBER;
  V_INV_ITEM_ID           NUMBER;
  V_PRT_DESC              VARCHAR2(100);
  P_MSG                   VARCHAR2(1000);
  P_AVAIL_MESSAGE         VARCHAR2(1000);
  P_PRICE_MESSAGE         VARCHAR2(1000);
  P_DISC_MESSAGE          VARCHAR2(1000);
  P_CRITICAL_PART         VARCHAR2(1000);
  P_ISODERABLE            VARCHAR2(1000);
  P_KIT_IND               VARCHAR2(1000);
  V_UNIT_PRICE            VARCHAR2(1000);
  V_UPQ                   VARCHAR2(1000);
  V_LEAD_TIME             VARCHAR2(1000);
  V_DISC_PERCENT          NUMBER;
  V_DISC_PRICE            NUMBER;
  P_PART_DETAILS     V_PART_DETAILS    := V_PART_DETAILS();
  P_PART_AVAIL       V_PART_AVAIL      := V_PART_AVAIL();
  P_PART_PRICE       V_PART_PRICE      := V_PART_PRICE();
  P_PART_APPLICABLE  V_PART_APPLICABLE := V_PART_APPLICABLE();
  P_PART_DISCOUNTS   V_PART_DISCOUNTS  := V_PART_DISCOUNTS();
  P_PART_BOM         V_PART_BOM        := V_PART_BOM();
BEGIN
  P_MESSAGE :=NULL;
  P_BULK_PART_DETAILS :=V_BULK_PART_DETAILS();
  IF P_PART_NUM.COUNT =0 THEN
    P_MESSAGE := 'No Part Num. is passed';
    goto end_proc;
  END IF;
   FOR J in 1..P_PART_NUM.COUNT
   LOOP
      V_QTY_TOTAL      := 0;
      V_UNIT_PRICE     := NULL;
      V_UPQ            := NULL;
      V_LEAD_TIME      := NULL;
      V_DISC_PERCENT   := NULL;
      V_INV_ITEM_ID    := NULL;
      V_PRT_DESC       := NULL;
    --  V_DISC_PRICE     := NULL;
     BEGIN
        V_EXIST :='Y';
       SELECT INVENTORY_ITEM_ID
         INTO V_INVENTORY_ITEM_ID
         FROM MTL_SYSTEM_ITEMS_B
        WHERE SEGMENT1=P_PART_NUM(J)
          AND ROWNUM=1;
     EXCEPTION
       WHEN NO_DATA_FOUND THEN
         SELECT LOOKUP_CODE
         || ': '
         || DESCRIPTION
         ||'~'||P_PART_NUM(J)
         INTO V_MESSAGE
         FROM FND_LOOKUP_VALUES
         WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
         AND UPPER(LOOKUP_CODE) = UPPER('8033');
         V_EXIST :='N';
     END;
    IF V_EXIST ='Y' THEN
     --Calling GET_ITEM_PRICE_AVAIL
     apps.GEAE_MYGE_ITEM_DTL_PKG.GET_ITEM_PRICE_AVAIL(P_SSO,
                                                      P_IACO_CODE,
                                                      P_CUST_ID,
                                                      P_ROLE,
                                                      P_OU_ID,
                                                      V_INVENTORY_ITEM_ID,
                                                      P_PART_DETAILS ,
                                                      P_PART_AVAIL ,
                                                      P_PART_PRICE ,
                                                      P_PART_APPLICABLE ,
                                                      P_MSG ,
                                                      P_AVAIL_MESSAGE ,
                                                      P_PRICE_MESSAGE ,
                                                      P_KIT_IND ,
                                                      P_PART_DISCOUNTS ,
                                                      P_DISC_MESSAGE ,
                                                      P_CRITICAL_PART ,
                                                      P_PART_BOM ,
                                                      P_ISODERABLE );
     IF  P_PART_DETAILS.COUNT > 0 THEN
       V_INVENTORY_ITEM_ID := P_PART_DETAILS(1).INVENTORY_ITEM_ID;
       V_PRT_DESC          := P_PART_DETAILS(1).PART_DESCRIPTION;
     END IF;

/**************************************************
US267084: The on hand quantity is not displayed correctly on Part bulk search screen . Because of the recent change
the part_avail count is 1. So modifying the below condition to check the count >0
******************************************************/
  --   IF P_PART_AVAIL.COUNT > 1 THEN
       IF P_PART_AVAIL.COUNT > 0 THEN   ---US267084
       FOR i IN 1 ..P_PART_AVAIL.COUNT
       LOOP
         V_QTY_TOTAL := V_QTY_TOTAL + P_PART_AVAIL(i).QUANTITY ;
       END LOOP;

/*Added the below code, to show quantity = 0 of critical parts for external users */
        IF P_CRITICAL_PART ='Y' and P_ROLE <> 'Global Enquiry' THEN
            V_QTY_TOTAL := 0;
        END IF;

     END IF;
     IF P_PART_PRICE.COUNT > 1 THEN
       P_PART_PRICE.DELETE;
       P_PRICE_MESSAGE := 'Price_Msg_02:';
       P_PRICE_MESSAGE :=P_PRICE_MESSAGE||'Please click on Part No. for complete information';
     ELSIF P_PART_PRICE.COUNT =1 THEN
       V_UNIT_PRICE := P_PART_PRICE(1).UNIT_PRICE;
       V_UPQ        := P_PART_PRICE(1).UPQ;
       V_LEAD_TIME  := P_PART_PRICE(1).LEAD_TIME;
     ELSE
       V_UNIT_PRICE := NULL;
       V_UPQ        := NULL;
       V_LEAD_TIME  := NULL;
     END IF;
     IF P_PART_DISCOUNTS.COUNT > 0 THEN
       IF P_PART_DISCOUNTS.COUNT > 1 THEN
         IF P_CUST_ID.COUNT > 0 THEN
            FOR VAR IN 1 .. P_CUST_ID.COUNT
               LOOP
               P_DISC_MESSAGE := GEAE_MYGE_CART_PKG.GET_ERR_MSG(8202)||'~'||P_CUST_ID(VAR);
             END LOOP;
          END IF;
         P_PART_DISCOUNTS.DELETE;
         V_DISC_PERCENT := NULL;
       --  V_DISC_PRICE   := NULL;
       ELSE
         V_DISC_PERCENT := P_PART_DISCOUNTS(1).DISC_PERCENT;
        -- V_DISC_PRICE   := P_PART_DISCOUNTS(1).DISC_PRICE;
       END IF;
     ELSE
       V_DISC_PERCENT := NULL;
      -- V_DISC_PRICE   := NULL;
     END IF;
     P_BULK_PART_DETAILS.EXTEND();
     P_BULK_PART_DETAILS(J):=   V_BULK_PART_DETAILS_LIST_BO(V_INVENTORY_ITEM_ID ,
                                                            P_PART_NUM(J) ,
                                                            V_PRT_DESC ,
                                                            V_QTY_TOTAL ,
                                                            V_UNIT_PRICE ,
                                                            V_UPQ ,
                                                            V_LEAD_TIME ,
                                                            V_DISC_PERCENT ,
                                                          --  V_DISC_PRICE ,
                                                            P_MSG ,
                                                            P_AVAIL_MESSAGE ,
                                                            P_PRICE_MESSAGE ,
                                                            P_DISC_MESSAGE ,
                                                            P_CRITICAL_PART
                                                           );
     ELSE
       P_BULK_PART_DETAILS.EXTEND();
        P_BULK_PART_DETAILS(J):= V_BULK_PART_DETAILS_LIST_BO('' ,
                                                             P_PART_NUM(J) ,
                                                             '' ,
                                                             '' ,
                                                             '' ,
                                                             '' ,
                                                             '' ,
                                                             '' ,
                                                           --  '' ,
                                                             '' ,
                                                             '' ,
                                                             '' ,
                                                             '' ,
                                                             ''
                                                            );
    END IF;
   END LOOP;
  <<end_proc>>
  NULL;
EXCEPTION
   WHEN OTHERS THEN
      P_MESSAGE := '8000:'||SUBSTR(SQLERRM,1,100);
END ITEM_DTL_PART_NUM_BULK;

END GEAE_MYGE_ITEM_DTL_PKG;

create or replace PACKAGE BODY "GEAE_MYGE_ITEM_DTL_PKG"
AS
  --
--------Change Log-------------------------------------
/*
Date          Changed By         Description
10-SEP-2014   Ravi Saxena        MYJIRATEST-3012 Fix to get translated price list name for display
17-SEP-2014   Ravi Saxena        MYJIRATEST-2956 Add logic to allow ordering based on procurement code if all ship codes are past use
30-OCT-2014   Ravi Saxena        MYJIRATEST-3993 Ensure lookup GEAE_MYGE_PART_APPLICABLE_ORGS is used and tag is used in it for organization_code
04-NOV-2014   Ravi Saxena        MYJIRATEST-3989 Add KIT Indicator to the GET_ITEM_PRICE_AVAIL procedure
06-NOV-2014   Ravi Saxena        MYJIRATEST-3876 Added procedure for KIT Structure
18-NOV-2014   Ravi Saxena        MYJIRATEST-3512 Change in call to CREATE_KIT_CONFIG
27-NOV-2014   Ravi Saxena        MYJIRATEST-4645 Kit structure changes
28-NOV-2014   Ravi Saxena        MYJIRATEST-4654 For Option class availability should come as blank
03-DEC-2014   Ravi Saxena        MYJIRATEST-4757 Have ability to enable or disable Kit structure
21-JAN-2015   Ravi Saxena        MYJIRATEST-5063 Discounts added
21-JAN-2015   Ravi Saxena        MYJIRATEST-5102 Remove hard coding of Aero for discount indicator
21-JAN-2015   Ravi Saxena        MYJIRATEST-5093 Add Critical part indicator
10-FEB-2015   Ravi Saxena        MYJIRATEST-5919 Discount changes
18-FEB-2015   Ravi Saxena        MYJIRATEST-6058 Fix for Common parts
03-MAR-2015   Ravi Saxena        MYJIRATEST-6272 Aero enhancement changes
23-MAR-2015   Abhinav Srivastava MYJIRATEST-7139 Engine family to Product line changes
24-MAR-2015   Abhinav Srivastava MYJIRATEST-7138 Oderable Vs Non Oderable changes
27-APR-2015   Ankita S           MYJIRATEST-5059 Add part to cart using PART_NUM
04-MAY-2015   Ankita Shetty      MYJIRATEST-7192 Change the message format for Manual discounts
04-MAY-2015   Ankita Shetty      MYJIRATEST-7056 Changed logic for populating Allocation Message
02-JUN-2015   Ankita S           MYJIRATEST-8466 on 02-JUN-2015
18-AUG-2015   Neelima Y          MYJIRATEST-8631 on 18-AUG-2015 Honda warehouse onhand visibility change
18-AUG-2015   Neelima Y          MYJIRATEST-9104 on 18-AUG-2015 Bulk Search
12-OCT-2015   Neelima Y          MYJIRATEST-9281 on 12-OCT-2015 Vendor part
28-DEC-2015   Trupti D           MYJIRATEST-12358 on 28-DEC-2015
29-JAN-2016   Trupti D           MYJIRATEST-7273 on 29-JAN-2016
26-FEB-2016   Trupti D           MYJIRATEST-13720 changed the logic for populating price list for GLobal Enquiry role
07-APR-2016   Trupti D           MYJIRATEST-13902 PZN ship code
21-JUN-2016   R Prasad           MYJIRATEST-7252  Enabled the Lumpsum as discount.
10-NOV-2016   R Prasad           US34704 - GTA validation check is added
12-DEC-2016   R Prasad     US46803 -Change ship code C to non shippable in portal
12-DEC-2016   R Prasad           US41783 -User customer code is not populating while adding a part to cart
08-MAR-2017   R Prasad           US52826 -Currently GEAE user can see all the inventory location, we should make the change so that they can only view what  a GE shop user see it. They should only see Erlanger and West chester.
18-APR-2017   R Prasad           US63772 -Remove Expired Discount Lines - myGEA, myCFM, myHonda, Aero
19-JUN-2018   OWMS Team          Changes for US192483 and US192484
28-Nov-2018   Manisha K          US198256- Passport requiement; Modified proc GET_ITEM_PRICE_AVAIL to find the Part details in case of two OU_ID passed as input.
27-Mar-2018   Manisha K          US267084- The on hand quantity is not displayed correctly on Part bulk search screen.
 */
PROCEDURE GET_ITEM_PRICE_AVAIL(
    P_SSO       VARCHAR2,
    P_IACO_CODE VARCHAR2,
    P_CUST_ID V_CUST_ID_ARRAY,
    P_ROLE    VARCHAR2,
    P_OU_ID   VARCHAR2,
    P_ITEM_ID NUMBER,
    P_PART_DETAILS OUT V_PART_DETAILS,
    P_PART_AVAIL OUT V_PART_AVAIL,
    P_PART_PRICE OUT V_PART_PRICE,
    P_PART_APPLICABLE OUT V_PART_APPLICABLE,
    P_MESSAGE OUT VARCHAR2,
    P_AVAIL_MESSAGE OUT VARCHAR2,
    P_PRICE_MESSAGE OUT VARCHAR2,
    P_KIT_IND         OUT VARCHAR2,
    P_PART_DISCOUNTS  OUT V_PART_DISCOUNTS,
    P_DISC_MESSAGE    OUT VARCHAR2,
    P_CRITICAL_PART   OUT VARCHAR2,
    P_PART_BOM        OUT V_PART_BOM, --MYJIRATEST-6272 Ravi S 03-MAR-2015
    P_ISODERABLE      OUT VARCHAR2  --MYJIRATEST-7138 24-MAR-2015   Abhinav  Oderable Vs Non Oderable changes
    )
AS
  --
  -- DECLARATION OF COUNTERS
  v_cust_cnt             NUMBER := 0;
  v_part_cnt             NUMBER := 0;
  v_part_avail_cnt       NUMBER := 0;
  v_part_price_cnt       NUMBER := 0;
  V_PART_APPL_CNT        NUMBER := 0;
  v_PART_PRICE_V_add     NUMBER := 0;
  V_PRICE_LIST_ID        NUMBER := 0;
  V_AVIALL_PRICE_LIST_ID NUMBER := 0;
  L_PRICE_LIST_DTL_cnt   NUMBER := 0;
  v_price_list_id_old    NUMBER := 0;
  p_aviall_price         NUMBER := 0;
  V_PART_dtl_cnt         NUMBER := 0;
  v_valdn_org            NUMBER;
  v_item_status          VARCHAR2(1);
  v_aviall_part          VARCHAR2(1);
  v_aviall_price         NUMBER;
  v_prc_id               NUMBER;
  V_ACT_NUM              VARCHAR2(30);
  v_aviall_err_ind       VARCHAR2(1);
  v_cust_account_id      NUMBER;
  V_CUST_ACCOUNT_ID_OLD  NUMBER;
  V_ONHAND_FLAG_NON_ZERO VARCHAR2(1);
  v_generic_messg_cnt    NUMBER;
  V_PRICE_LIST_FLAG      VARCHAR2(1);
  V_CUST_ACCOUNT_NUMBER  VARCHAR2(50);
  V_FSCM_SUPPLIER        VARCHAR2(50);
  v_price_list_api       NUMBER := 0;
  v_ou_name              VARCHAR2(240);
  v_parent_wh_id         NUMBER;
  l_disc_price           NUMBER;
  l_pr_fr_disc           NUMBER;
  l_disc_list_id         NUMBER;
  l_disc_line_id         NUMBER;
  l_disc_end_date        DATE;
  l_disc_consumed        NUMBER;
  l_disc_counter         NUMBER;
  l_bom_counter          NUMBER;  --MYJIRATEST-6272 Ravi S 03-MAR-2015
  V_OU_TAG               VARCHAR2(255) := Null;      -- Neelima Y MYJIRATEST-8631 on 18-AUG-2015
  --
  -- DECLARATIONS OF BULK COLLECT ARRAY
  L_PART_DETAILS V_PART_DETAILS           := V_PART_DETAILS();
  L_PART_AVAIL V_PART_AVAIL               := V_PART_AVAIL();
  L_PART_PRICE_V V_PART_PRICE             := V_PART_PRICE();
  L_PART_PRICE V_PART_PRICE               := V_PART_PRICE();
  L_PART_APPLICABLE V_PART_APPLICABLE     := V_PART_APPLICABLE();
  L_PRICE_LIST_ID V_PRICE_LIST_ID_ARRAY   := V_PRICE_LIST_ID_ARRAY();
  L_PRICE_LIST_DTL V_PRICE_LIST_DTL       := V_PRICE_LIST_DTL();
  P_PRICE_LIST_DTL V_PRICE_LIST_DTL       := V_PRICE_LIST_DTL();
  L_PART_VLDTN V_PART_VLDTN               := V_PART_VLDTN();
  l_PART_PRICE_DUP V_PART_PRICE           := V_PART_PRICE();
  l_PART_APPLICABLE_DUP V_PART_APPLICABLE := V_PART_APPLICABLE();
  T_PART_PRICE_LOOP_DUP V_PART_PRICE           := V_PART_PRICE(); --US198256;Passport requirement; Manisha added the variable to remove the duplicates from P_PART_PRICE array after introducing OU_ID loop.
  T_PART_APPLICABLE_LOOP_DUP V_PART_APPLICABLE := V_PART_APPLICABLE();  --US198256; Passport requirement;Manisha added the variable to remove the duplicates from P_PART_APPLICABLE array after introducing OU_ID loop.
  T_PART_AVAIL_LOOP_DUP V_PART_AVAIL := V_PART_AVAIL();  --US198256; Passport requirement; Manisha added the variable to remove the duplicates from P_PART_AVAIL array after introducing OU_ID loop.
  --
  --Declarations of Variables
  l_List_id_count           NUMBER ;
  l_PART_PRICE_DUP_CNT      NUMBER         := 0;
  v_price_dup_flag          BOOLEAN        := true;
  l_PART_APPLICABLE_DUP_CNT NUMBER         := 0;
  v_part_APP_DUP_FLAG       BOOLEAN        := true;
  P_VALID_FLAG              VARCHAR2(1)    := NULL;
  P_UNIT_PRICE              NUMBER         := NULL;
  P_LIST_LINE_ID            NUMBER         := NULL;
  P_AVIALL_UNIT_PRICE       NUMBER         := NULL;
  P_AVIALL_LIST_LINE_ID     NUMBER         := NULL;
  V_CONTROL_SHIP            NUMBER         := NULL;
  V_CONTROL_SHIPPABLE       VARCHAR2(10)   := NULL;
  V_ORG_ID                  NUMBER         := NULL;
  V_PORTAL                  VARCHAR2(150)  := NULL;
  V_FLAG_GTA_ERROR          VARCHAR2(1)    := NULL;
  V_FLAG_CTRL_SHIP_ERROR    VARCHAR2(1)    := NULL;
  V_AMPS_CODE_ERROR         VARCHAR2(1)    := NULL;
  V_FLAG_AVIALL_ERROR       VARCHAR2(1)    := NULL;
  V_FLAG_VENDOR_ERROR       VARCHAR2(1)    := NULL;
  V_FLAG_ORG_ERROR          VARCHAR2(1)    := NULL;
  V_GENERIC_MSSG            VARCHAR2(5000) := NULL;
  V_GTA_ERR_MSSG            VARCHAR2(5000) := NULL;
  V_CTRL_SHIP_ERR_MSSG      VARCHAR2(5000) := NULL;
  V_AVIALL_ERR_MSSG         VARCHAR2(5000) := NULL;
  V_VENDOR_ERR_MSSG         VARCHAR2(5000) := NULL;
  V_AMPS_CODE_ERR_MSSG      VARCHAR2(5000) := NULL;
  V_ORG_ERR_MSSG            VARCHAR2(5000) := NULL;
  V_PUBLISH                 VARCHAR2(10)   := NULL;
  V_AVAILL_ALL_ERROR        VARCHAR2(1)    := NULL;
  V_AVIALL_SUCESS           VARCHAR2(1)    := NULL;
  v_proc_status             VARCHAR2(1);
  v_proc_code               VARCHAR2(5);
  v_on_hand                 NUMBER;
  v_kit_ind_on              VARCHAR2(1);
  v_prod_line_on              VARCHAR2(1);  --MYJIRATEST-6272 Ravi S 03-MAR-2015 and  MYJIRATEST-7139 Engine family to Product line changes    23-MAR-2015    Abhinav
  v_oderable_on               VARCHAR2(1);  --MYJIRATEST-7138 24-MAR-2015   Oderable Vs Non Oderable changes
  V_ISODERABLE                VARCHAR2(1);  --MYJIRATEST-7138 24-MAR-2015   Oderable Vs Non Oderable changes
  V_ISODERABLE_MESSAGE        VARCHAR2(5000) := NULL;  --MYJIRATEST-7138 24-MAR-2015   Oderable Vs Non Oderable changes
  v_item_source                VARCHAR2(500); -- Added for OWMS Implementation US192483/US192484
  v_er1_source VARCHAR2(500); -- Added for OWMS Implementation US192483/US192484
  v_er2_source VARCHAR2(500); -- Added for OWMS Implementation US192483/US192484
  v_er3_source VARCHAR2(500); -- Added for OWMS Implementation US192483/US192484
  v_item_number                VARCHAR2(30); -- Added for OWMS Implementation US192483/US192484
  v_hnd_flag	  VARCHAR2(5);-- Added for OWMS Implementation US192483/US192484
  --
  v_ou_id                      VARCHAR2(30)   := NULL; --Added By Manisha;12-JUL-18;Passport requirement to save the OU_ID separated by comma
  v_ou_id1                      VARCHAR2(30)   := NULL;
  v_ou_id2                      VARCHAR2(30)   := NULL;
  i_PART_PRICE_DUP_CNT      NUMBER         := 0;  --Manisha 10-Aug; Used to increase the counter for loop(to remove duplicate from P_PART_PRICE array after adding OU_ID loop)
  i_price_dup_flag          BOOLEAN        := true; --Manisha 10-Aug; Flag to check for duplicates in P_PART_PRICE
  i_PART_APPLICABLE_DUP_CNT NUMBER         := 0; --US198256; Manisha 10- Aug; Added variable to increase the counter for loop(to remove duplicate from P_PART_APPLICABLE array after adding OU_ID loop)
  i_part_APP_DUP_FLAG       BOOLEAN        := true; --US198256; Manisha 10-Aug; Flag to check for duplicates in P_PART_APPLICABLE
  i_PART_AVAIL_DUP_CNT NUMBER         := 0; --US198256; Manisha 10- Aug;Added variable to increase the counter for loop(to remove duplicate from P_PART_AVAIL after adding OU_ID loop)
  i_part_AVAIL_DUP_FLAG       BOOLEAN        := true; --US198256; Manisha 10-Aug; Flag to check for duplicates in P_PART_AVAIL
  /*******************************
  --Added the variable to save the intermediate value while passing both OU_ID in loop before displaying in the out parameter
  ******************************************/

  v_message                    VARCHAR2(5000) := NULL;
  v_avail_message              VARCHAR2(5000) := NULL;
  v_price_message              VARCHAR2(5000) := NULL;
  v_disc_message               VARCHAR2(5000) := NULL;
  l_isoderable                 VARCHAR2(5000) := NULL;
  ----------------------------------------

  CURSOR C_DISCOUNTS(P_CUSTOMER_ID NUMBER, P_OU_ID NUMBER, P_ITEM_ID NUMBER, P_PRICE_LIST_ID NUMBER) IS
     SELECT cust_account_id, account_number, list_name, list_description, line_number, line_comments, disc_value, arithmetic_operator,
            qual_end_date, line_end_date, list_end_date, grants_end_date, list_auto_flag, line_auto_flag, basis, limit_level_code, limit,
            product_attribute_context, product_attribute, product_attr_value, list_header_id, list_line_id, qualifier_id, qualifier_context
       FROM (
        SELECT hca.cust_account_id, hca.account_number, qlh.name list_name, qlh.description list_description, qll.list_line_no line_number,
               qll.attribute4 line_comments, qll.operand disc_value, qll.arithmetic_operator, qq.end_date_active qual_end_date,
               qll.end_date_active line_end_date, qlh.end_date_active list_end_date, qg.end_date grants_end_date, qlh.automatic_flag list_auto_flag,
               qll.automatic_flag line_auto_flag, ql.basis, ql.limit_level_code, ql.amount limit, qpa.product_attribute_context, qpa.product_attribute,
               qpa.product_attr_value, qll.list_header_id, qll.list_line_id, qq.qualifier_id, qq.qualifier_context
          FROM hz_cust_accounts hca, qp_grants qg, qp_list_headers qlh, qp_list_lines qll, qp_qualifiers qq, qp_pricing_attributes qpa,
               (SELECT * FROM qp_limits WHERE basis = 'QUANTITY' AND limit_level_code = 'ACROSS_TRANSACTION') ql
         WHERE 1 = 1
           AND ((to_char(hca.cust_account_id) = qq.qualifier_attr_value AND qq.qualifier_context = 'CUSTOMER')
             OR (to_char(P_PRICE_LIST_ID) = qq.qualifier_attr_value AND qq.qualifier_context = 'MODLIST'))
           AND hca.status = 'A'
           AND qq.comparison_operator_code = '='
           AND hca.cust_account_id = P_CUSTOMER_ID
           AND qq.active_flag = 'Y'
           AND qq.list_header_id = qlh.list_header_id
           AND DECODE(qq.list_line_id,-1,qll.list_line_id,qq.list_line_id) = qll.list_line_id
           AND qlh.list_type_code = 'DLT'
           AND qlh.active_flag = 'Y'
           AND qlh.list_header_id = qg.instance_id
           AND qg.grantee_type = 'OU'
           AND qg.instance_type = 'MOD'
           AND qg.grantee_id = P_OU_ID
           AND qll.list_line_type_code = 'DIS'
           AND qlh.list_header_id = qll.list_header_id
           AND qll.pricing_phase_id > 1
           AND qll.qualification_ind IN (0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,32)
           AND qll.list_header_id = qpa.list_header_id(+)
           AND qll.list_line_id = qpa.list_line_id(+)
           AND (qpa.pricing_attribute_context = 'VOLUME' OR qpa.pricing_attribute_context IS NULL)
           AND ql.list_header_id(+) = qll.list_header_id
           AND ql.list_line_id(+) = qll.list_line_id
           --AND qll.arithmetic_operator = '%'             MYJIRATEST-7252 Commented by Prasad on 21-Jun-2016
           AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(qlh.start_date_active,SYSDATE)) AND TRUNC(NVL(qlh.end_date_active,SYSDATE))
           AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(qll.start_date_active,SYSDATE)) AND TRUNC(NVL(qll.end_date_active,SYSDATE))  --MYJIRATEST-7273 Trupti D. 29-JAN-2016 --US63772 18-APR-17
           AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(qq.start_date_active,SYSDATE)) AND TRUNC(NVL(qq.end_date_active,SYSDATE))
           AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(qg.start_date,SYSDATE)) AND TRUNC(NVL(qg.end_date,SYSDATE))
         --AND trunc(NVL(qll.end_date_active, SYSDATE))>=add_months(sysdate,-6)                                              --MYJIRATEST-7273 Trupti D. 29-JAN-2016 --US63772 18-APR-17
           )
      WHERE ((product_attribute = 'PRICING_ATTRIBUTE3' AND product_attr_value = 'ALL')
               OR (product_attribute = 'PRICING_ATTRIBUTE1' AND product_attr_value = P_ITEM_ID)
               OR product_attribute IS NULL) AND (product_attribute_context = 'ITEM' OR product_attribute_context IS NULL);
BEGIN
  ---Start of Procedure GET_ITEM_PRICE_AVAIL
  --
  P_PART_DETAILS    := V_PART_DETAILS();
  P_PART_AVAIL      := V_PART_AVAIL();
  P_PART_PRICE      := V_PART_PRICE();
  P_PART_APPLICABLE := V_PART_APPLICABLE();
  P_PART_DISCOUNTS  := V_PART_DISCOUNTS();
  P_PART_BOM        := V_PART_BOM(); --MYJIRATEST-6272 Ravi S 03-MAR-2015


  /*********************************************
  US198256: Manisha K; Passport requirements 12-July-2018
  As part of Passport Requirement: Two OU_ID will be passed separated by ~ symbol.
  So, the part price will be calculated separately for each OU_ID using loop
  **************************************************/
P_PART_DETAILS.EXTEND();   --US198256; Manisha K; Creating element for the PART_DETAILS array ,outside the OU_ID loop to avoid duplicates.

 v_ou_id:=Replace(P_OU_ID,'~',',');

    FOR j IN
     (SELECT trim(regexp_substr(v_ou_id, '[^,]+', 1, LEVEL)) ou_id
    FROM dual
      CONNECT BY LEVEL <= regexp_count(v_ou_id, ',')+1
    )
   LOOP
---  US198256; Manisha K; Passport Changes End here

  SELECT name
    INTO v_ou_name
    FROM HR_OPERATING_UNITS
   WHERE organization_id = J.OU_ID;
  --MYJIRATEST-5102 Ravi S 21-JAN-2015
  BEGIN
     SELECT mp.organization_id
       INTO v_parent_wh_id
       FROM MTL_PARAMETERS MP,
            FND_LOOKUP_VALUES FLV
      WHERE MP.ORGANIZATION_CODE = FLV.ATTRIBUTE1
        AND FLV.description      = J.OU_ID
        AND FLV.LOOKUP_TYPE      = 'GEAE_MYGE_SUPPLIER_ORGS'
        AND FLV.ATTRIBUTE3       = (SELECT MIN(FLV2.ATTRIBUTE3)
                                      FROM MTL_PARAMETERS MP2,
                                           FND_LOOKUP_VALUES FLV2
                                     WHERE MP2.ORGANIZATION_CODE = FLV2.ATTRIBUTE1
                                       AND FLV2.description      = J.OU_ID
                                       AND FLV2.LOOKUP_TYPE      = 'GEAE_MYGE_SUPPLIER_ORGS');
  EXCEPTION
     WHEN NO_DATA_FOUND THEN
        v_parent_wh_id := NULL;
  END;
  -- MYJIRATEST-4757 Ravi S 03-DEC-2014
  BEGIN
     SELECT description
       INTO v_kit_ind_on
       FROM fnd_lookup_values
      WHERE lookup_type = 'GEAE_MYGE_ENABLE_KIT_STRUCTURE'
        AND lookup_code = J.OU_ID
        AND enabled_flag = 'Y'
        AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(start_date_active,SYSDATE)) AND TRUNC(NVL(end_date_active,SYSDATE));
  EXCEPTION
     WHEN NO_DATA_FOUND THEN
        v_kit_ind_on := 'N';
  END;
  --MYJIRATEST-6272 Ravi S 03-MAR-2015
  BEGIN
     SELECT description
       INTO v_prod_line_on  --  MYJIRATEST-7139 23-MAR-2015    Engine family to Product line changes
       FROM fnd_lookup_values
      WHERE lookup_type = 'GEAE_MYGE_ENABLE_ENGINE_FAMILY'
        AND lookup_code = J.OU_ID
        AND enabled_flag = 'Y'
        AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(start_date_active,SYSDATE)) AND TRUNC(NVL(end_date_active,SYSDATE));
  EXCEPTION
     WHEN NO_DATA_FOUND THEN
        v_prod_line_on := 'N';  --  MYJIRATEST-7139 23-MAR-2015    Engine family to Product line changes
  END;
  --
  -- If Role is Global Enquiry fetch the Item Availiability accross Orgs
  --If role is Global Enquiry fetch the Item Price across all price list for that operating unit pass as parameter

  IF p_ROLE      = 'Global Enquiry' THEN
    V_VALDN_ORG := GEAE_CNV_UTILITY_PACKAGE.GET_ORGANIZATION_ID('CVO');

    -- validate whether part is orderable the organization used is CVO
    BEGIN
      SELECT 'Y'
      INTO v_item_status
      FROM mtl_system_items_b msi
      WHERE msi.organization_id           = v_valdn_org
      AND msi.CUSTOMER_ORDER_FLAG         = 'Y'
      AND msi.CUSTOMER_ORDER_ENABLED_FLAg = 'Y'
      AND msi.inventory_item_id           = P_ITEM_ID;
    EXCEPTION
    WHEN OTHERS THEN
      V_ITEM_STATUS := 'N';
      --
      SELECT LOOKUP_CODE
        || ': '
        || DESCRIPTION
      INTO p_message
      FROM fnd_lookup_values
      WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
      AND UPPER(LOOKUP_CODE) = UPPER('8125');
      --
      /*  IF P_CUST_ID.COUNT > 0 THEN
      FOR VAR IN 1 .. P_CUST_ID.COUNT
      LOOP
      P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
      END LOOP;
      END IF;  */
      --
    END;
    IF V_ITEM_STATUS = 'Y' THEN
      --Getting KIT Flag
      BEGIN
         SELECT 'Y'
           INTO P_KIT_IND
           FROM mtl_system_items_b
          WHERE organization_id = v_valdn_org
            AND inventory_item_id = P_ITEM_ID
            AND bom_item_type = 1;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            P_KIT_IND := 'N';
      END;
      IF v_kit_ind_on <> 'Y' THEN
         P_KIT_IND := 'N'; -- MYJIRATEST-4757 Ravi S 03-DEC-2014
      END IF;
      --MYJIRATEST-5093 Ravi S 21-JAN-2015
      BEGIN
         SELECT 'Y'
           INTO P_CRITICAL_PART
           FROM oe_hold_definitions ohd, oe_hold_sources_all ohsa, fnd_lookup_values flv
          WHERE ohd.hold_id = ohsa.hold_id
            AND ohd.name = flv.description
            AND flv.lookup_type = 'GEAE_MYGE_CRITICAL_PART_HOLDS'
            AND flv.enabled_flag = 'Y'
            AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(flv.start_date_active,SYSDATE)) AND TRUNC(NVL(flv.end_date_active,SYSDATE))
            AND ohsa.hold_entity_code = 'I'
            AND ohsa.released_flag <>'Y'   -- MYJIRATEST-12046  23-NOV-2015
            AND ohsa.hold_entity_id = P_ITEM_ID
            AND rownum = 1;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            P_CRITICAL_PART := 'N';
      END;
      ---------------------------------------
      ---Creating the Price List Array for Price if the role is global enquiry across all Price list in Operating unit passed
      --added this to fix the price list is not diplayed for internal GEAE users US267081 on 28th March 2019
      MO_GLOBAL.SET_POLICY_CONTEXT('S',J.OU_ID);
      --end of the change
      SELECT V_PART_PRICE_LIST_BO(GQIPV.inventory_item_id, GQIPV.PRICE_LIST_NAME, GQIPV.list_price, NVL(GQIPV.CATALOG_UPQ,1), GQIPV.CATALOG_LEAD_TIME) BULK COLLECT
      INTO L_PART_PRICE_V
      FROM GEAE_QP_ITEM_PRICES_V GQIPV
      WHERE 1                     = 1
      AND GQIPV.inventory_item_id = to_char(P_ITEM_ID) -- added by Mohammed Yadul on 16.Oct.2014 for Item data type issue, this issue raised by bala
      --AND NVL(GQIPV.OPERATING_UNIT,TO_NUMBER(P_OU_ID))    = TO_NUMBER(P_OU_ID)
      AND NVL(GQIPV.OPERATING_UNIT,TO_NUMBER(J.OU_ID))=To_Number(Decode((SELECT GLOBAL_FLAG FROM QP_LIST_HEADERS WHERE NAME = GQIPV.PRICE_LIST_NAME AND ACTIVE_FLAG ='Y' AND Nvl(END_DATE_ACTIVE,SYSDATE+1) > SYSDATE )
                                                                  ,'Y'
                                                                     ,GEAE_CSO_FIN_UTL_PKG.GET_CSO_ORG_ID
                                                                     ,J.OU_ID))   ----------MYJIRATEST-13720 Trupti D. 26-FEB-2016
      AND NOT EXISTS
        (SELECT 'X'
        FROM fnd_lookup_values flv
        WHERE flv.enabled_flag = 'Y'
        AND FLV.LOOKUP_TYPE    = 'GEAE_INV_PIS_CATALOG_EXCLUSION'
        AND FLV.DESCRIPTION    = GQIPV.PRICE_LIST_NAME
        );
      --
      IF SQL%ROWCOUNT > 0 THEN
        FOR i IN 1 .. L_PART_PRICE_V.count
        LOOP
          v_PART_PRICE_V_add := v_PART_PRICE_V_add + 1;
          P_PART_PRICE.extend();
          P_PART_PRICE(V_PART_PRICE_V_ADD) := L_PART_PRICE_V(I);
        END LOOP;
      ELSE
        SELECT LOOKUP_CODE
          || ': '
          || DESCRIPTION
        INTO p_message
        FROM fnd_lookup_values
        WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
        AND UPPER(LOOKUP_CODE) = UPPER('8134'); --
        p_message             := NULL;
        --EXIT;
        /* IF P_CUST_ID.COUNT > 0 THEN
        FOR VAR IN 1 .. P_CUST_ID.COUNT
        LOOP
        P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
        END LOOP;
        END IF;  */
      END IF;

      --
      --   Getting the Global Availability across all valid organization across SPR, OSW and SCP
      --
      /*SELECT V_PART_AVAILABILITY_LIST_BO(STG.INVENTORY_ITEM_ID, STG.ORGANIZATION_CODE, NVL(STG.QTY,0) ) BULK collect
      INTO L_PART_AVAIL
      FROM
        (SELECT STG3.INVENTORY_ITEM_ID,
          STG3.ORGANIZATION_CODE,
          NVL(STG3.TOTAL_QTY,0) - NVL(STG3.RESERVE_QTY,0) QTY
        FROM
          (SELECT MSI.INVENTORY_ITEM_ID ,
            MTP.ORGANIZATION_CODE ,
            NVL(SUM(MOQ.TRANSACTION_QUANTITY),0) TOTAL_QTY ,
            stg2.reserve_qty
          FROM MTL_ONHAND_QUANTITIES MOQ,
            MTL_SYSTEM_ITEMS_B msi,
            MTL_PARAMETERS MTP ,
            (SELECT MRS.INVENTORY_ITEM_ID ,
              MRS.ORGANIZATION_ID ,
              SUM(MRS.RESERVATION_QUANTITY) reserve_qty
            FROM MTL_RESERVATIONS MRS
            GROUP BY MRS.INVENTORY_ITEM_ID,
              MRS.ORGANIZATION_ID
            ) stg2
          WHERE 1                        = 1
          AND stg2.INVENTORY_ITEM_ID (+) = MSI.INVENTORY_ITEM_ID
          AND stg2.organization_id (+)   = MSI.ORGANIZATION_ID
          AND MOQ.ORGANIZATION_ID(+)     = MSI.ORGANIZATION_ID
          AND MOQ.INVENTORY_ITEM_ID(+)   = MSI.INVENTORY_ITEM_ID
          AND MTP.organization_code NOT IN
            (SELECT FFV.flex_value
            FROM fnd_flex_values FFV ,
              fnd_flex_value_sets FVS
            WHERE FFV.flex_value_set_id=FVS.flex_value_set_id
            AND FVS.FLEX_VALUE_SET_NAME='GEAE_AMPS_RETIRED_ORGS'
            )
          AND MTP.attribute_category IN ('SPR','OSW','SCP')
          AND MSI.ORGANIZATION_ID     = MTP.ORGANIZATION_ID
          AND MSI.INVENTORY_ITEM_ID   = P_ITEM_ID
          AND MTP.ORGANIZATION_CODE  <> 'HAI'
          GROUP BY MSI.INVENTORY_ITEM_ID ,
            MTP.ORGANIZATION_CODE ,
            STG2.RESERVE_QTY
          ) STG3
        UNION ALL
          SELECT distinct msib.inventory_item_id,
                 gif.org_code ORGANIZATION_CODE,
                 gif.onhand_Qty QTY
            FROM geae_inv_foxtrot_data_stg gif,
                 mtl_system_items_b msib
           WHERE msib.segment1=gif.prt_num
             AND msib.inventory_item_id =P_ITEM_ID
             AND gif.SRC_SYS ='HONDA'
             )stg;*/  --Commeted for Rally#US52826
          -- replicated query for  Rally#US52826  --Started
--Added by OWMS Team : Start
   v_item_source := NULL;
   v_item_number := NULL;
   BEGIN
     SELECT DISTINCT segment1
         INTO v_item_number
         FROM mtl_system_items_b
         WHERE INVENTORY_ITEM_ID   = P_ITEM_ID;
     EXCEPTION
       WHEN OTHERS THEN
                  v_item_number := NULL;
     END;
  --
 	SELECT DECODE(COUNT(1),1,'Y','N')
	INTO v_hnd_flag
	 FROM HR_OPERATING_UNITS HOU,
		  FND_LOOKUP_VALUES FLV
	WHERE  HOU.ORGANIZATION_ID = TO_NUMBER(j.OU_ID) --116797
	  AND HOU.NAME = FLV.DESCRIPTION
	  AND FLV.TAG = 'HAI'
	  AND FLV.LOOKUP_TYPE = 'GEAE_MYGE_PART_APPLICABLE_ORGS';
   --
   IF v_hnd_flag = 'Y' THEN
     v_item_source := 'HAI';
   ELSIF v_hnd_flag = 'N' THEN
	   --
	   v_er1_source := GEAE_INV_GET_SOURCE_CODE ('ER1',v_item_number,'Y');
	   v_er2_source := GEAE_INV_GET_SOURCE_CODE ('ER2',v_item_number,'Y');
	   v_er3_source := GEAE_INV_GET_SOURCE_CODE ('ER3',v_item_number,'Y');
	   --
	   IF v_er1_source = 'CPL' OR v_er2_source = 'CPL' OR v_er3_source = 'CPL' THEN
		v_item_source := 'CPL';
	   ELSE
		 v_item_source := 'ERL';
	   END IF;
   END IF;

--Added by OWMS Team : End

           SELECT V_PART_AVAILABILITY_LIST_BO(tab.INVENTORY_ITEM_ID, tab.ORGANIZATION_CODE, NVL(tab.QTY,0)) BULK collect
      INTO L_PART_AVAIL
      FROM
--Added by OWMS Team : Start
      (SELECT STG.INVENTORY_ITEM_ID,STG.ORGANIZATION_CODE,sum(stg.qty) qty
          FROM (SELECT P_ITEM_ID INVENTORY_ITEM_ID ,
                        'On-Hand Stock' ORGANIZATION_CODE,
                         (a.qty-b.qty) QTY
            FROM (SELECT (geae_wms_total_onhand_erl_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
			geae_wms_total_pick_release(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
			 FROM apps.mtl_system_items_b msib,
			      apps.mtl_parameters mp
			 WHERE 1 = 1
			   and msib.inventory_item_id = P_ITEM_ID
			   and msib.organization_id = mp.organization_id
			   and mp.organization_code = v_item_source
			   AND v_item_source NOT IN ('CPL','HAI')) A,
                 (SELECT (geae_wms_resv_qty_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
			geae_wms_total_resv(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
			 FROM apps.mtl_system_items_b msib,
			      apps.mtl_parameters mp
			 WHERE 1 = 1
			   and msib.inventory_item_id = P_ITEM_ID
			   and msib.organization_id = mp.organization_id
			   and mp.organization_code = v_item_source
			   AND v_item_source NOT IN ('CPL','HAI')) B
           UNION ALL
                SELECT P_ITEM_ID INVENTORY_ITEM_ID ,
                        'On-Hand Stock' ORGANIZATION_CODE,
                        (b.qty-c.qty) QTY
                FROM
                     (SELECT NVL(SUM(MOQ.TRANSACTION_QUANTITY),0) qty
                        FROM GEAE_INV_MTL_ONHANDS_V MOQ
                       WHERE INVENTORY_ITEM_ID = P_ITEM_ID
                         AND SUBINVENTORY_CODE in ('STOCK','STG')
                         AND ORGANIZATION_ID IN (SELECT ORGANIZATION_ID
                                                   FROM MTL_PARAMETERS
                                                  WHERE ORGANIZATION_CODE = V_ITEM_SOURCE)
                          AND v_item_source NOT IN ('ERL','HAI')
                    ) b,
                 (SELECT NVL(SUM(RESERVATION_QUANTITY),0) qty
                             FROM MTL_RESERVATIONS
                     WHERE INVENTORY_ITEM_ID = P_ITEM_ID
                         AND ORGANIZATION_ID IN (SELECT ORGANIZATION_ID
                                                   FROM MTL_PARAMETERS
                                                  WHERE ORGANIZATION_CODE = V_ITEM_SOURCE)
                          AND v_item_source NOT IN ('ERL','HAI')
                   ) C
        UNION ALL
        SELECT DISTINCT MSIB.INVENTORY_ITEM_ID,
                 'On-Hand Stock' ORGANIZATION_CODE,
               GIF.ONHAND_QTY  QTY
          FROM GEAE_INV_FOXTROT_DATA_STG GIF,
               MTL_SYSTEM_ITEMS_B MSIB,
               HR_OPERATING_UNITS HOU,
               MTL_PARAMETERS MTP,
               FND_LOOKUP_VALUES FLV
         WHERE MSIB.SEGMENT1=GIF.PRT_NUM
           AND HOU.ORGANIZATION_ID       = TO_NUMBER(J.OU_ID)
           AND HOU.NAME                   = FLV.DESCRIPTION
           AND MTP.ORGANIZATION_CODE      = FLV.TAG
           AND FLV.LOOKUP_TYPE            = 'GEAE_MYGE_PART_APPLICABLE_ORGS'
           AND GIF.ORG_CODE               = MTP.ORGANIZATION_CODE
           AND MSIB.INVENTORY_ITEM_ID =P_ITEM_ID
	   AND FLV.TAG					 = v_item_Source
	   and  v_item_Source NOT IN ('CPL','ERL')
           AND GIF.SRC_SYS ='HONDA'
          ) STG
       GROUP BY INVENTORY_ITEM_ID, ORGANIZATION_CODE ) TAB		  ;
                -- replicated query for  Rally#US52826  --Ended
      --
      IF SQL%rowcount > 0 THEN
        FOR i IN 1 .. L_PART_AVAIL.count
        LOOP
          V_PART_AVAIL_cnt := V_PART_AVAIL_cnt + 1;
          P_PART_AVAIL.EXTEND();
          P_PART_AVAIL(V_PART_AVAIL_cnt) := L_PART_AVAIL(i);
        END LOOP;
      ELSE
        SELECT LOOKUP_CODE
          || ': '
          || DESCRIPTION
        INTO p_message
        FROM fnd_lookup_values
        WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
        AND UPPER(LOOKUP_CODE) = UPPER('8133');
        --
        -- EXIT;
        --Looping in customer loop to get the cust ids in message for 8133
        /* IF P_CUST_ID.COUNT > 0 THEN
        FOR VAR IN 1 .. P_CUST_ID.COUNT
        LOOP
        P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
        END LOOP;
        END IF;  */
        -- Loop ends for customer id concatenation in messages
      END IF;
      --
      --
      SELECT V_PART_DETAILS_LIST_BO(MSI.INVENTORY_ITEM_ID, MSI.SEGMENT1, DECODE(GEAE_MYGE_CTRL_SHIPBILITY(MSI.INVENTORY_ITEM_ID),'Y',NULL,MSI.DESCRIPTION),
             DECODE(v_parent_wh_id,NULL,NULL,GEAE_INV_AMPS_COMMON_UTILS_PKG.GET_CATEGORY_VALUE(v_parent_wh_id,MSI.INVENTORY_ITEM_ID,'Discount Indicator'))) BULK COLLECT
      INTO L_PART_DETAILS
      FROM mtl_system_items_b msi,
        mtl_parameters mtp
      WHERE 1                   = 1
      AND msi.organization_id   = mtp.organization_id
      AND INVENTORY_ITEM_ID     = P_ITEM_ID
      AND MTP.ORGANIZATION_CODE = 'CVO';
      --
      IF SQL%rowcount > 0 THEN
        FOR I IN 1 .. L_PART_DETAILS.COUNT
        LOOP
         V_PART_dtl_cnt  := 0;  --Manisha K. 27 Jul Initializing the variable so that the array P_PART_DETAILS fetch single record.
          V_PART_dtl_cnt := V_PART_dtl_cnt + 1;
       --   P_PART_DETAILS.EXTEND();  --Manisha 14 Dec Have added this code in the beginning outside the loop, to fetch only one record
          P_PART_DETAILS(V_PART_dtl_cnt) := L_PART_DETAILS(I);
        END LOOP;
      END IF;
      --
      IF SQL%ROWCOUNT = 0 THEN
        --
        SELECT LOOKUP_CODE
          || ': '
          || DESCRIPTION
        INTO p_message
        FROM fnd_lookup_values
        WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
        AND UPPER(LOOKUP_CODE) = UPPER('8125');
        --
        --Looping in customer loop to get the cust ids in message for 8125
        IF P_CUST_ID.COUNT > 0 THEN
          FOR VAR IN 1 .. P_CUST_ID.COUNT
          LOOP
            P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
          END LOOP;
        END IF;
        -- Loop ends for customer id concatenation in messages
      END IF;
      --
      --MYJIRATEST-6272 Ravi S 03-MAR-2015
      IF v_prod_line_on = 'Y' THEN
         l_bom_counter := 0;
         FOR part_bom IN (SELECT --DISTINCT bom.eng_fam engine_family    MYJIRATEST-7139 23-MAR-2015    Commented for Engine family to Product line changes
                                 DISTINCT bom.product_line product_line
                            FROM geae_myge_bom_details_v bom
                           WHERE bom.search_ou_id = J.OU_ID
                             AND bom.inventory_item_id = P_ITEM_ID) LOOP
            P_PART_BOM.EXTEND(1);
            l_bom_counter := l_bom_counter + 1;
            P_PART_BOM(P_PART_BOM.last):= V_PART_BOM_BO(NULL, part_bom.product_line , l_bom_counter);--   MYJIRATEST-7139 23-MAR-2015    Engine family to Product line changes
         END LOOP;
      END IF;
      --
    END IF; --END IF of IF V_ITEM_STATUS = 'Y'
  ELSE     ---ELSE OF  p_ROLE = 'Global Enquiry'
    -- Step-0 -Check part is valid or not
    V_VALDN_ORG := GEAE_CNV_UTILITY_PACKAGE.GET_ORGANIZATION_ID('CVO');
    -- validate whether part is orderable the organization used is CVO
    BEGIN
      --
      SELECT 'Y'
      INTO v_item_status
      FROM mtl_system_items_b msi
      WHERE msi.organization_id           = v_valdn_org
      AND msi.CUSTOMER_ORDER_FLAG         = 'Y'
      AND msi.CUSTOMER_ORDER_ENABLED_FLAg = 'Y'
      AND MSI.INVENTORY_ITEM_ID           = P_ITEM_ID;
      --
    EXCEPTION
    WHEN OTHERS THEN
      v_item_STATUS := 'N';
      SELECT LOOKUP_CODE
        || ': '
        || DESCRIPTION
      INTO p_message
      FROM fnd_lookup_values
      WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
      AND UPPER(LOOKUP_CODE) = UPPER('8125');
      --
      --Looping in customer loop to get the cust ids in message for 8125
      IF P_CUST_ID.COUNT > 0 THEN
        FOR VAR IN 1 .. P_CUST_ID.COUNT
        LOOP
          P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
        END LOOP;
      END IF;
      -- Loop ends for customer id concatenation in messages
    END;
    IF V_ITEM_STATUS = 'Y' THEN
      -- Inside the If condition of Item is Valid and orderable
      --Getting KIT Flag
      BEGIN
         SELECT 'Y'
           INTO P_KIT_IND
           FROM mtl_system_items_b
          WHERE organization_id = v_valdn_org
            AND inventory_item_id = P_ITEM_ID
            AND bom_item_type = 1;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            P_KIT_IND := 'N';
      END;
      IF v_kit_ind_on <> 'Y' THEN
         P_KIT_IND := 'N'; -- MYJIRATEST-4757 Ravi S 03-DEC-2014
      END IF;
      --MYJIRATEST-5093 Ravi S 21-JAN-2015
      BEGIN
         SELECT 'Y'
           INTO P_CRITICAL_PART
           FROM oe_hold_definitions ohd, oe_hold_sources_all ohsa, fnd_lookup_values flv
          WHERE ohd.hold_id = ohsa.hold_id
            AND ohd.name = flv.description
            AND flv.lookup_type = 'GEAE_MYGE_CRITICAL_PART_HOLDS'
            AND flv.enabled_flag = 'Y'
            AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(flv.start_date_active,SYSDATE)) AND TRUNC(NVL(flv.end_date_active,SYSDATE))
            AND ohsa.hold_entity_code = 'I'
            AND ohsa.released_flag <>'Y'   -- MYJIRATEST-12046  23-NOV-2015
            AND ohsa.hold_entity_id = P_ITEM_ID
            AND rownum = 1;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            P_CRITICAL_PART := 'N';
      END;
      -- Populating Below the Item details
      SELECT V_PART_DETAILS_LIST_BO(MSI.INVENTORY_ITEM_ID, MSI.SEGMENT1, DECODE(GEAE_MYGE_CTRL_SHIPBILITY(MSI.INVENTORY_ITEM_ID),'Y',NULL,MSI.DESCRIPTION),
             DECODE(v_parent_wh_id,NULL,NULL,GEAE_INV_AMPS_COMMON_UTILS_PKG.GET_CATEGORY_VALUE(v_parent_wh_id,MSI.INVENTORY_ITEM_ID,'Discount Indicator'))) BULK COLLECT
      INTO L_PART_DETAILS
      FROM mtl_system_items_b msi,
        mtl_parameters mtp
      WHERE 1                   = 1
      AND msi.organization_id   = mtp.organization_id
      AND INVENTORY_ITEM_ID     = P_ITEM_ID
      AND MTP.ORGANIZATION_CODE = 'CVO';
      --
      IF SQL%rowcount > 0 THEN
        FOR I IN 1 .. L_PART_DETAILS.COUNT
        LOOP
         V_PART_dtl_cnt  := 0;  --Manisha K. 27 Jul Initializing the variable so that the array P_PART_DETAILS fetch single record.
          V_PART_dtl_cnt := V_PART_dtl_cnt + 1;
        --  P_PART_DETAILS.EXTEND(); --Manisha 14 Dec Have added this code in the beginning outside the loop, to fetch only one record
          P_PART_DETAILS(V_PART_dtl_cnt) := L_PART_DETAILS(I);
        END LOOP;
      END IF;
      --
      IF SQL%ROWCOUNT = 0 THEN
        --
        SELECT LOOKUP_CODE
          || ': '
          || DESCRIPTION
        INTO p_message
        FROM fnd_lookup_values
        WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
        AND UPPER(LOOKUP_CODE) = UPPER('8125');
        --
        --Looping in customer loop to get the cust ids in message for 8125
        IF P_CUST_ID.COUNT > 0 THEN
          FOR VAR IN 1 .. P_CUST_ID.COUNT
          LOOP
            P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
          END LOOP;
        END IF;
        -- Loop ends for customer id concatenation in messages
      END IF;
      --Step -1 get distinct  price lists and price
      IF P_CUST_ID.COUNT > 0 THEN
        --
        V_FLAG_GTA_ERROR       := 'Y';
        V_FLAG_CTRL_SHIP_ERROR := 'Y';
        V_FLAG_AVIALL_ERROR    := 'Y';
        V_FLAG_VENDOR_ERROR    := 'Y';
        V_FLAG_ORG_ERROR       := 'Y';
        V_AMPS_CODE_ERROR      := 'Y';
        V_GENERIC_MESSG_CNT    := 0;
        V_AVAILL_ALL_ERROR     := NULL;
        FOR var IN 1 .. p_CUST_ID.COUNT
        LOOP
          -- to fetch the customer shipping address
          v_price_list_flag := NULL;
          BEGIN
            --
            SELECT V_PRICE_LIST_DTL_BO(stg.PRICE_LIST_ID, stg.account_number, stg.cust_account_id, stg.ORG_ID) BULK COLLECT
            INTO L_PRICE_LIST_DTL
            FROM
              (SELECT DISTINCT HCSUA.PRICE_LIST_ID price_list_id,
                hca.account_number account_number,
                hca.cust_account_id cust_account_id,
                HCSUA.ORG_ID org_id
              FROM hz_parties hp,
                hz_party_sites hps,
                hz_cust_accounts hca,
                hz_cust_acct_sites_all hcasa,
                hz_cust_site_uses_all hcsua
              WHERE hp.party_id                = hps.party_id(+)
              AND hp.party_id                  = hca.party_id(+)
              AND hcasa.party_site_id(+)       = hps.party_site_id
              AND HCSUA.CUST_ACCT_SITE_ID(+)   = HCASA.CUST_ACCT_SITE_ID
              AND HCSUA.PRICE_LIST_ID         IS NOT NULL
              AND hcsua.site_use_code          = 'SHIP_TO'
              AND hps.location_id              = hps.location_id -- AND hps.location_id = hl.location_id
              AND NVL(hcasa.status, 'I')       = 'A'           ----Added NVL
              AND NVL(HCA.STATUS, 'I')         = 'A'           ----Added NVL
              AND NVL(hcsua.primary_flag, 'X') = 'Y'
              AND NVL(hcsua.STATUS, 'I')       = 'A' ----Added NVL
              AND NVL(hps.STATUS, 'I')         = 'A' ----Added NVL
              AND NVL(hp.STATUS, 'I')          = 'A' ----Added NVL
              AND HCSUA.ORG_ID                 = TO_NUMBER(J.OU_ID) -- Added by Ravi S for MYJIRATEST-2758
              AND HCA.CUST_ACCOUNT_ID          = TO_NUMBER(P_CUST_ID(VAR))
              ) stg
            ORDER BY STG.ACCOUNT_NUMBER;
            --
          EXCEPTION
          WHEN NO_DATA_FOUND THEN
            v_price_list_flag := 'N';
          WHEN OTHERS THEN
            v_price_list_flag := 'N';
          END; ---END OF BEGIN OF SELECT STATMENT FOR BULK COLLECT OF PRICELIST
          --Check if the PRICE LIST IDS are NOT NULL else Price cannot be determined
          IF L_PRICE_LIST_DTL.COUNT > 0 THEN
            --
            FOR i IN 1 .. L_PRICE_LIST_DTL.count
            LOOP
              L_PRICE_LIST_DTL_cnt := L_PRICE_LIST_DTL_cnt + 1;
              P_PRICE_LIST_DTL.EXTEND();
              P_PRICE_LIST_DTL(L_PRICE_LIST_DTL_cnt) := L_PRICE_LIST_DTL(i); --BM Commented
            END LOOP;
          ELSE
            --
            NULL;
            --
          END IF;
        END LOOP; ---END LOOP for Lopp of Custids to determine the Pricelist from Active Ship-tos
        IF L_PRICE_LIST_DTL.COUNT = 0 THEN
          --
          SELECT LOOKUP_CODE
            || ': '
            || DESCRIPTION
          INTO p_message
          FROM fnd_lookup_values
          WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
          AND UPPER(LOOKUP_CODE) = UPPER('8137');
          --
          --Looping in customer loop to get the cust ids in message for 8125
          IF P_CUST_ID.COUNT > 0 THEN
            FOR VAR IN 1 .. P_CUST_ID.COUNT
            LOOP
              P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
            END LOOP;
          END IF;
          -- Loop ends for customer id concatenation in messages
        END IF;
      ELSE
        --else of Customer count
        ---Customer Ids are empty hence error
        --
        SELECT LOOKUP_CODE
          || ': '
          || DESCRIPTION
        INTO p_message
        FROM fnd_lookup_values
        WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
        AND UPPER(LOOKUP_CODE) = UPPER('8136');
        --
        --
        --
      END IF;
      --Step 2 get all the BOM and GTA intersection for all customers, consider shippable and vendor parts
      --Step 3 check the control shippability
      FOR var IN 1 .. p_CUST_ID.COUNT
      LOOP
        --
        --
        BEGIN
          SELECT V_PART_VLDTN_BO(CUSTOMER_NUMBER, SUPPLIER_CODE, SHIP_CODE, PAST_SHP_CD, VENDOR_PART, CUST_ACCOUNT_ID ,COMPONENT_ID ,site_to_use,amps_code) BULK COLLECT
          INTO L_PART_VLDTN
          FROM
              (SELECT stg.customer_number,
                stg.supplier_code,
                stg.ship_code,
                stg.past_shp_cd,
                stg.vendor_part,
                STG.CUST_ACCOUNT_ID,
                STG.COMPONENT_ID ,
                stg.site_to_use ,
                stg.amps_code
              FROM
                (SELECT hca.account_number customer_number,
                  bom.attribute8 supplier_code,
                  SUM(
                  CASE
                    WHEN EXISTS
                      (SELECT com.attribute5
                      FROM fnd_flex_value_sets ffs1,
                        FND_FLEX_VALUES_VL FFV1,
                        fnd_lookup_values FLV2,
                        HR_OPERATING_UNITS HOU1,
                        FND_LOOKUP_VALUES FLV1
                      WHERE 1                       = 1
                      AND NVL(ffv1.attribute1, 'N') = 'Y'
                      AND ffv1.flex_value           = com.attribute5
                      AND FFS1.FLEX_VALUE_SET_ID    = FFV1.FLEX_VALUE_SET_ID
                      AND FFS1.FLEX_VALUE_SET_NAME  = flv2.description
                      AND flv2.lookup_code          = flv1.tag
                      AND flv2.lookup_type          = 'GEAE_ONT_PRDLN_SHPCD_OU_LKP'
                      AND flv1.lookup_code          = hou1.organization_id
                      AND FLV1.LOOKUP_TYPE          = 'GEAE_MYGE_OPERATING_UNITS'
                      AND hou1.organization_id      = to_number(J.OU_ID)
                      )
                    THEN 1
                    ELSE 0
                  END) ship_code,
                  SUM(
                  CASE
                    WHEN EXISTS
                      (SELECT com.attribute5
                      FROM HR_OPERATING_UNITS HOU1,
                        FND_LOOKUP_VALUES FLV1,
                        fnd_lookup_values FLV3
                      WHERE 1                       = 1
                      AND flv1.lookup_code          = hou1.organization_id
                      AND FLV1.LOOKUP_TYPE          = 'GEAE_MYGE_OPERATING_UNITS'
                      AND FLV3.lookup_type          = 'GEAE_MYGE_PAST_SHIP_CODES'
                      AND FLV3.tag                  = com.attribute5
                      AND FLV3.enabled_flag         = 'Y'
                      AND FLV3.description          = hou1.organization_id
                      AND hou1.organization_id      = to_number(J.OU_ID)
                      )
                    THEN 1
                    ELSE 0
                  END) past_shp_cd,
                  SUM(
                  CASE
                    WHEN EXISTS
                      (SELECT com.attribute5
                      FROM fnd_lookup_values
                      WHERE lookup_type = 'GEAE_MYGE_VENDOR_CODE'
                      AND lookup_code   = com.attribute5
                      )
                    THEN 1
                    ELSE 0
                  END) vendor_part,
                  hca.cust_account_id cust_account_id,
                  com.component_item_id component_id ,
                  flv.description site_to_use ,
                  com.attribute5 amps_code
                FROM geae_ont_cust_gta_info goc,
                  geae_ont_gta_applblty_v gom,
                  bom_bill_of_materials bom,
                  bom_components_b com,
                  mtl_system_items msi,
                  mtl_parameters mp,
                  hz_cust_accounts_all hca,
                  fnd_lookup_values flv
                WHERE 1                               = 1
                AND gom.engine_model_id               = bom.assembly_item_id
                AND msi.inventory_item_id             = bom.assembly_item_id
                AND com.bill_sequence_id              = bom.bill_sequence_id
                AND com.component_item_id             = p_item_id
                AND hca.cust_account_id               = TO_NUMBER(P_CUST_ID(VAR))
                AND goc.geae_ont_cust_gta_info_seq_id = gom.geae_ont_cust_gta_info_seq_id
                AND goc.customer_id                   = hca.cust_account_id
                AND trunc(goc.end_date)             > = trunc(sysdate)  -- US34704--added by Prasad on 10-NOV-16
                AND NVL(com.disable_date,SYSDATE+1) >  SYSDATE
                AND flv.lookup_type                   = 'GEAE_MYGE_SUPPLIER_ORGS'
                AND flv.enabled_flag                  = 'Y'
                AND TO_NUMBER(flv.description)        = goc.org_id
                AND goc.org_id                        = to_number(J.OU_ID)  --Manisha K 07-DEC Added the OU_ID condition  to fetch the data for cuurent OU_ID as two U_ID will passed in loop; Passport requirement
                AND msi.enabled_flag                  = 'Y'
                AND msi.organization_id               = mp.organization_id
                AND mp.organization_code              = 'CVO'
                AND bom.attribute8                    = flv.meaning
                GROUP BY hca.account_number,
                  bom.attribute8,
                  cust_account_id,
                  com.component_item_id ,
                  FLV.DESCRIPTION,
                  com.attribute5
                ) STG
            );
          --
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
          NULL;
        WHEN OTHERS THEN
          NULL;
        END; ---END of BEGIN of Select statment for bulk collect of Pricelist
        --Check if the PRICE LIST IDS are NOT NULL else Price cannot be determined
        IF L_PART_VLDTN.COUNT = 0 THEN
          --
          --
          --
          BEGIN
            v_cust_account_number := NULL;
            SELECT ACCOUNT_NUMBER
            INTO v_cust_account_number
            FROM hz_cust_accounts
            WHERE 1             = 1
            AND CUST_ACCOUNT_ID = TO_NUMBER(P_CUST_ID(VAR));
          EXCEPTION
          WHEN OTHERS THEN
            V_CUST_ACCOUNT_NUMBER := P_CUST_ID(VAR);
          END;
          --
          --
          IF p_message IS NULL THEN
            SELECT LOOKUP_CODE
              || ': '
              || DESCRIPTION
            INTO p_message
            FROM fnd_lookup_values
            WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
            AND UPPER(LOOKUP_CODE) = UPPER('8127');
            P_MESSAGE             := P_MESSAGE||'~'||P_CUST_ID(VAR);
          ELSE
            P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
          END IF;
          V_FLAG_GTA_ERROR      := 'N';
          IF V_GTA_ERR_MSSG     IS NULL THEN
            V_GTA_ERR_MSSG      := 'Customer GTA does not allow them to buy the part:'||v_cust_account_number;
          ELSE
            V_GTA_ERR_MSSG      := V_GTA_ERR_MSSG||','||v_cust_account_number;
          END IF;
        END IF;
        --IF all results point to other OU, then put a message and come out.
        FOR I IN 1 .. L_PART_VLDTN.COUNT
        LOOP
        DBMS_OUTPUT.PUT_LINE('IN PART... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
           --
          IF J.OU_ID         <> L_PART_VLDTN(I).SITE_TO_USE THEN
           DBMS_OUTPUT.PUT_LINE('1... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
            V_FLAG_ORG_ERROR := 'N';
            --
            IF V_ORG_ERR_MSSG     IS NULL THEN
              V_ORG_ERR_MSSG      := 'Part is being ordered in the wrong OU.'||L_PART_VLDTN(I).CUSTOMER_NUMBER;
            ELSE
              V_ORG_ERR_MSSG      := V_ORG_ERR_MSSG||','||L_PART_VLDTN(I) .CUSTOMER_NUMBER;
            END IF;
            BEGIN
              --
              SELECT attribute2
              INTO v_portal
              FROM FND_LOOKUP_VALUES FLV
              WHERE 1              = 1
              AND flv.lookup_type  = 'GEAE_MYGE_SUPPLIER_ORGS'
              AND flv.enabled_flag = 'Y'
              AND flv.description  = L_PART_VLDTN(I).site_to_use
              AND flv.meaning  =L_PART_VLDTN(I).SUPPLIER_CODE;
            EXCEPTION
            WHEN OTHERS THEN
              --
              v_portal := NULL;
            END;
            --
            IF p_message IS NULL THEN
              SELECT LOOKUP_CODE
                || ': '
                || DESCRIPTION
              INTO p_message
              FROM fnd_lookup_values
              WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
              AND UPPER(LOOKUP_CODE) = UPPER('8126');
              P_MESSAGE             := P_MESSAGE ||'|'||V_PORTAL;
            --ELSE
              --P_MESSAGE := P_MESSAGE ||'|'||V_PORTAL;
            END IF;
            --EXIT;
            CONTINUE; --MYJIRATEST-6058 Ravi S 18-FEB-2015
          END IF;  --J.OU_ID         <> L_PART_VLDTN(I).SITE_TO_USE
        DBMS_OUTPUT.PUT_LINE('2... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
         --
          --Adding the Aviall validation after GTA
          --
          BEGIN
            --
            v_aviall_err_ind := 'N';
            --
            SELECT 'Y'
            INTO v_aviall_part
            FROM mtl_item_categories_v mic
            WHERE 1                                    = 1
            AND SUBSTR(mic.category_concat_segs, 1, 6) = 'AVIALL'
            AND mic.inventory_item_id                  = p_item_id
            AND mic.category_set_name                  = 'GEAE_AMPS_DISTRIBUTION_DEAL'
            AND ROWNUM                                 < 2;
          EXCEPTION
          WHEN OTHERS THEN
            --
            v_aviall_part := 'N';
          END;
          IF V_AVIALL_PART = 'Y' THEN
         DBMS_OUTPUT.PUT_LINE('3... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
            ---Calling the Price API to check if the Part is Priced
            V_AVIALL_SUCESS               := NULL;
            IF NVL(V_PRICE_LIST_FLAG,'Y') <> 'N' THEN
              P_AVIALL_UNIT_PRICE         := NULL;
              FOR PRICELSTID IN
              (SELECT stg.price_list_id,
                stg.account_number,
                STG.CUST_ACCOUNT_ID
              FROM TABLE(CAST(P_PRICE_LIST_DTL AS v_PRICE_LIST_DTL)) stg
              WHERE STG.ACCOUNT_NUMBER = L_PART_VLDTN(I).CUSTOMER_NUMBER
              )
              LOOP
                V_AVIALL_PRICE_LIST_ID := PRICELSTID.PRICE_LIST_ID;
                GET_PRICE(P_SSO ,J.OU_ID, P_ITEM_ID, V_AVIALL_PRICE_LIST_ID, P_AVIALL_UNIT_PRICE, P_AVIALL_LIST_LINE_ID);
                IF P_AVIALL_UNIT_PRICE IS NOT NULL THEN
                  V_AVIALL_SUCESS      := 'Y';
                  EXIT;
                END IF;
              END LOOP;
            ELSE ---NVL(V_PRICE_LIST_FLAG,'Y') <> 'N' then
              IF p_message IS NULL THEN
                SELECT LOOKUP_CODE
                  || ': '
                  || DESCRIPTION
                INTO p_message
                FROM fnd_lookup_values
                WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
                AND UPPER(LOOKUP_CODE) = UPPER('8132');
                --
                p_message := p_message||'~'||P_CUST_ID(VAR);
                --
              ELSE
                P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
              END IF;
              v_aviall_err_ind     := 'Y';
              V_FLAG_AVIALL_ERROR  := 'N';
              IF V_AVIALL_ERR_MSSG IS NULL THEN
                --
                V_AVIALL_ERR_MSSG   := 'The part is a Aviall part :'||L_PART_VLDTN(I).CUSTOMER_NUMBER;
              ELSE
                V_AVIALL_ERR_MSSG   := V_AVIALL_ERR_MSSG||','||L_PART_VLDTN(I).CUSTOMER_NUMBER;
              END IF;
                 EXIT;
            END IF;--NVL(V_PRICE_LIST_FLAG,'Y') <> 'N' then
            --
            -- Checking if the Aviall part has price

           IF V_AVIALL_SUCESS = 'Y' THEN
              NULL;
            ELSE
              IF p_message IS NULL THEN
                SELECT LOOKUP_CODE
                  || ': '
                  || DESCRIPTION
                INTO p_message
                FROM fnd_lookup_values
                WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
                AND UPPER(LOOKUP_CODE) = UPPER('8132');
                --
                p_message := p_message||'~'||P_CUST_ID(VAR);
                --
              ELSE
                P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
              END IF;
              --
              v_aviall_err_ind     := 'Y';
              V_FLAG_AVIALL_ERROR  := 'N';
              IF V_AVIALL_ERR_MSSG IS NULL THEN
                --
                V_AVIALL_ERR_MSSG   := 'The part is a Aviall part :'||L_PART_VLDTN(I).CUSTOMER_NUMBER;
              ELSE
                V_AVIALL_ERR_MSSG   := V_AVIALL_ERR_MSSG||','||L_PART_VLDTN(I).CUSTOMER_NUMBER;
              END IF;
              --
               EXIT;
            END IF;--if V_AVIALL_SUCESS = 'Y'
          END IF;----if V_AVIALL_PART = 'Y' then
          --Aviall Validation ends
        DBMS_OUTPUT.PUT_LINE('4... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
          IF  L_PART_VLDTN(I).AMPS_CODE = 'C' THEN      --US46803-Change ship code C to non shippable in portal
             V_FSCM_SUPPLIER := NULL;
                BEGIN
                  SELECT MIC.CATEGORY_CONCAT_SEGS
                  INTO v_FSCM_supplier
                  FROM MTL_ITEM_CATEGORIES_V MIC,
                    FND_LOOKUP_VALUES FLV,
                    mtl_parameters mp,
                    hr_operating_units hou
                  WHERE 1                   = 1
                  AND MIC.INVENTORY_ITEM_ID = P_ITEM_ID
                  AND MIC.CATEGORY_SET_NAME = 'FSCM supplier'
                  AND mic.organization_id   = mp.organization_id
                  AND flv.lookup_type = 'GEAE_MYGE_PART_APPLICABLE_ORGS'
                  AND mp.organization_code  = flv.tag  --MYJIRATEST-3993 Ravi S 30-OCT-2014
                  AND FLV.DESCRIPTION       = HOU.NAME
                  AND HOU.ORGANIZATION_ID   = TO_NUMBER(J.OU_ID)
                  AND ROWNUM                < 2;
                EXCEPTION
                WHEN OTHERS THEN
                  V_FSCM_SUPPLIER := NULL;
                END;
             IF p_message IS NULL THEN
               dbms_output.put_line('p_message::::'||p_message);
               SELECT LOOKUP_CODE
                 || ': '
                 || DESCRIPTION
               INTO p_message
               FROM fnd_lookup_values
               WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
               AND UPPER(LOOKUP_CODE) = UPPER('8204');
                     --
               P_MESSAGE := P_MESSAGE||'|'||V_FSCM_SUPPLIER||'~'||P_CUST_ID(VAR);
             END IF;
             --
            CONTINUE; --US41783-User customer code is not populating while adding a part to cart
              EXIT;
            END IF;
      DBMS_OUTPUT.PUT_LINE('5... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
       IF  L_PART_VLDTN(I).AMPS_CODE IN('P','Z','N') THEN      --MYJIRATEST-9281 Neelima Y 12-OCT-2015 ---MYJIRATEST-13902 Trupti D. 07-APR-2016
       DBMS_OUTPUT.PUT_LINE('12... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
            V_FSCM_SUPPLIER := NULL;
                BEGIN
                  SELECT MIC.CATEGORY_CONCAT_SEGS
                  INTO v_FSCM_supplier
                  FROM MTL_ITEM_CATEGORIES_V MIC,
                    FND_LOOKUP_VALUES FLV,
                    mtl_parameters mp,
                    hr_operating_units hou
                  WHERE 1                   = 1
                  AND MIC.INVENTORY_ITEM_ID = P_ITEM_ID
                  AND MIC.CATEGORY_SET_NAME = 'FSCM supplier'
                  AND mic.organization_id   = mp.organization_id
                  AND flv.lookup_type = 'GEAE_MYGE_PART_APPLICABLE_ORGS'
                  AND mp.organization_code  = flv.tag  --MYJIRATEST-3993 Ravi S 30-OCT-2014
                  AND FLV.DESCRIPTION       = HOU.NAME
                  AND HOU.ORGANIZATION_ID   = TO_NUMBER(J.OU_ID)
                  AND ROWNUM                < 2;
                EXCEPTION
                WHEN OTHERS THEN
                  V_FSCM_SUPPLIER := NULL;
                END;
             IF p_message IS NULL THEN
               SELECT LOOKUP_CODE
                 || ': '
                 || DESCRIPTION
               INTO p_message
               FROM fnd_lookup_values
               WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
               AND UPPER(LOOKUP_CODE) = UPPER('8203');
                     --
               P_MESSAGE := P_MESSAGE||'|'||V_FSCM_SUPPLIER||'~'||P_CUST_ID(VAR);
             END IF;
             --
             V_AMPS_CODE_ERROR  := 'N';
             IF V_AMPS_CODE_ERR_MSSG IS NULL THEN
               V_AMPS_CODE_ERR_MSSG  := 'Dear Customers, if you need to place an order or know the availability/price of this part, contact CAM:'||L_PART_VLDTN(I) .CUSTOMER_NUMBER;
             ELSE
               V_AMPS_CODE_ERR_MSSG := V_AMPS_CODE_ERR_MSSG||','||L_PART_VLDTN(I) .CUSTOMER_NUMBER;
             END IF;
            CONTINUE;
              EXIT;
        ELSE
          IF L_PART_VLDTN(I).SHIP_CODE > 0 THEN
          DBMS_OUTPUT.PUT_LINE('13... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
            --
            --If all ship codes are past use, validate procurement code and on hand

           IF L_PART_VLDTN(I).SHIP_CODE = L_PART_VLDTN(I).PAST_SHP_CD THEN

DBMS_OUTPUT.PUT_LINE('14... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
  --            v_proc_status
               BEGIN
                  SELECT mcb.segment1
                    INTO v_proc_code
                    FROM mtl_item_categories mic, mtl_category_sets mcs, mtl_categories_b mcb, mtl_parameters mp, fnd_lookup_values supp
                   WHERE mic.category_set_id = mcs.category_set_id
                     AND mic.category_id = mcb.category_id
                     AND mic.organization_id = mp.organization_id
                     AND mcs.category_set_name = 'Procurement Code'
                     AND supp.lookup_type = 'GEAE_MYGE_SUPPLIER_ORGS'
                     AND supp.description = J.OU_ID
                     AND mp.organization_code = supp.attribute1
                     AND supp.meaning = L_PART_VLDTN(I).SUPPLIER_CODE
                     AND mic.inventory_item_id = L_PART_VLDTN(I).COMPONENT_ID;
               EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                     v_proc_code := 'NA';
               END;
               IF v_proc_code IS NULL THEN
                  v_proc_code := 'NA';
               END IF;
               IF v_proc_code IN ('X','Y','NA') THEN
                  v_proc_status := 'Y';
               ELSE
                  BEGIN
                   --Added by OWMS Team : Start
                           v_item_source := NULL;
                           v_item_number := NULL;
                           BEGIN
                             SELECT DISTINCT segment1
                                 INTO v_item_number
                                 FROM mtl_system_items_b
                                 WHERE INVENTORY_ITEM_ID   = P_ITEM_ID;
                             EXCEPTION
                               WHEN OTHERS THEN
                                          v_item_number := NULL;
                             END;
                               --
                              SELECT DECODE(COUNT(1),1,'Y','N')
                              INTO v_hnd_flag
                               FROM HR_OPERATING_UNITS HOU,
                                  FND_LOOKUP_VALUES FLV
                              WHERE  HOU.ORGANIZATION_ID = TO_NUMBER(j.OU_ID) --116797
                                AND HOU.NAME = FLV.DESCRIPTION
                                AND FLV.TAG = 'HAI'
                                AND FLV.LOOKUP_TYPE = 'GEAE_MYGE_PART_APPLICABLE_ORGS';
                               --
                               IF v_hnd_flag = 'Y' THEN
					   v_item_source := 'HAI';
                               ELSIF v_hnd_flag = 'N' THEN
					   --
					   v_er1_source := GEAE_INV_GET_SOURCE_CODE ('ER1',v_item_number,'Y');
					   v_er2_source := GEAE_INV_GET_SOURCE_CODE ('ER2',v_item_number,'Y');
					   v_er3_source := GEAE_INV_GET_SOURCE_CODE ('ER3',v_item_number,'Y');
					   --
					   IF v_er1_source = 'CPL' OR v_er2_source = 'CPL' OR v_er3_source = 'CPL' THEN
						v_item_source := 'CPL';
					   ELSE
						 v_item_source := 'ERL';
					   END IF;
					   --
                               END IF;
                               --
                            SELECT NVL(SUM(QTY),0)
                                INTO v_on_hand
                                FROM (SELECT (A.QTY - B.QTY)  QTY
				    FROM (SELECT (geae_wms_total_onhand_erl_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
						geae_wms_total_pick_release(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
						 FROM apps.mtl_system_items_b msib,
						      apps.mtl_parameters mp
						 WHERE 1 = 1
						   and msib.inventory_item_id = L_PART_VLDTN(I).COMPONENT_ID
						   and msib.organization_id = mp.organization_id
						   and mp.organization_code = v_item_source
						   AND v_item_source NOT IN ('CPL','HAI')) A,
					 (SELECT (geae_wms_resv_qty_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
						geae_wms_total_resv(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
						 FROM apps.mtl_system_items_b msib,
						      apps.mtl_parameters mp
						 WHERE 1 = 1
						   and msib.inventory_item_id = L_PART_VLDTN(I).COMPONENT_ID
						   and msib.organization_id = mp.organization_id
						   and mp.organization_code = v_item_source
						   AND v_item_source NOT IN ('CPL','HAI')) B
                                      UNION ALL -- Neelima Y MYJIRATEST-8631 on 18-AUG-2015
                                      SELECT SUM(HND.QTY)
                                        FROM (SELECT DISTINCT MSIB.INVENTORY_ITEM_ID, GIF.ONHAND_QTY QTY
                                                FROM GEAE_INV_FOXTROT_DATA_STG GIF,
                                                     MTL_SYSTEM_ITEMS_B        MSIB,
                                                     HR_OPERATING_UNITS        HOU,
                                                     MTL_PARAMETERS            MTP,
                                                     FND_LOOKUP_VALUES         FLV
                                               WHERE MSIB.SEGMENT1 = GIF.PRT_NUM
                                                 AND HOU.ORGANIZATION_ID = TO_NUMBER(J.OU_ID)
                                                 AND HOU.NAME = FLV.DESCRIPTION
                                                 AND MTP.ORGANIZATION_CODE = FLV.TAG
           			                 AND FLV.TAG	= v_item_Source
						 AND v_item_Source NOT IN ('CPL','ERL')
                                                 AND FLV.LOOKUP_TYPE = 'GEAE_MYGE_PART_APPLICABLE_ORGS'
                                                 AND GIF.ORG_CODE = MTP.ORGANIZATION_CODE
                                                 AND MSIB.INVENTORY_ITEM_ID = L_PART_VLDTN(I).COMPONENT_ID
                                                 AND GIF.SRC_SYS = 'HONDA') HND
                                      UNION
                                      SELECT (A.QTY - B.QTY)  QTY
                                        FROM (SELECT NVL(SUM(MOQ.TRANSACTION_QUANTITY), 0) QTY
                                                FROM GEAE_INV_MTL_ONHANDS_V MOQ
                                               WHERE INVENTORY_ITEM_ID = L_PART_VLDTN(I).COMPONENT_ID
                                                 AND SUBINVENTORY_CODE IN ('STOCK','STG')
                                                 AND ORGANIZATION_ID IN
                                                     (SELECT ORGANIZATION_ID
                                                        FROM MTL_PARAMETERS
                                                       WHERE ORGANIZATION_CODE = V_ITEM_SOURCE)
                                                  AND v_item_source NOT IN ('ERL','HAI')    ) A,
                                             (SELECT NVL(SUM(RESERVATION_QUANTITY), 0) QTY
                                                FROM MTL_RESERVATIONS
                                               WHERE INVENTORY_ITEM_ID = L_PART_VLDTN(I).COMPONENT_ID
                                                 AND ORGANIZATION_ID IN
                                                     (SELECT ORGANIZATION_ID
                                                        FROM MTL_PARAMETERS
                                                       WHERE ORGANIZATION_CODE = V_ITEM_SOURCE)
                                                  AND v_item_source NOT IN ('ERL','HAI')    ) B);
--Added by OWMS Team : END
                  EXCEPTION
                     WHEN NO_DATA_FOUND THEN
                        v_on_hand := 0;
                  END;
                  IF v_on_hand > 0 THEN
                     v_proc_status := 'Y';
                  ELSE
                     v_proc_status := 'N';
                  END IF;
              DBMS_OUTPUT.PUT_LINE('17... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
         END IF;
            --Fetch data for proc_yes
            END IF;
            IF (L_PART_VLDTN(I).SHIP_CODE = L_PART_VLDTN(I).PAST_SHP_CD AND v_proc_status = 'Y') OR L_PART_VLDTN(I).SHIP_CODE > L_PART_VLDTN(I).PAST_SHP_CD THEN
            DBMS_OUTPUT.PUT_LINE('15... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
            DBMS_OUTPUT.PUT_LINE('L_PART_VLDTN(I).SHIP_CODE-->'||L_PART_VLDTN(I).SHIP_CODE);
            DBMS_OUTPUT.PUT_LINE('L_PART_VLDTN(I).PAST_SHP_CD-->'||L_PART_VLDTN(I).PAST_SHP_CD);
            DBMS_OUTPUT.PUT_LINE('v_proc_status-->'||v_proc_status);
            DBMS_OUTPUT.PUT_LINE('L_PART_VLDTN(I).PAST_SHP_CD-->'||L_PART_VLDTN(I).PAST_SHP_CD);
               BEGIN
                 SELECT mp.organization_id
                 INTO V_ORG_ID
                 FROM MTL_PARAMETERS MP,
                   FND_LOOKUP_VALUES FLV
                 WHERE 1                  = 1
                 AND MP.ORGANIZATION_CODE = FLV.ATTRIBUTE1
                 AND FLV.meaning          = L_PART_VLDTN(I).SUPPLIER_CODE
                 AND FLV.LOOKUP_TYPE      = 'GEAE_MYGE_SUPPLIER_ORGS';
               EXCEPTION
               WHEN OTHERS THEN
                 v_org_id := 60378;
               END ;
               --
               V_CONTROL_SHIP      := NVL(GEAE_AMPS_OM_CONFIG_VAL.FUN_CONTROL_SHIPPABLE_ITEM(L_PART_VLDTN(I).COMPONENT_ID, L_PART_VLDTN(I).CUST_ACCOUNT_ID, V_ORG_ID, L_PART_VLDTN(I).SITE_TO_USE), 0);
               v_control_shippable := NVL(geae_inv_amps_common_utils_pkg.get_category_value(V_ORG_ID, L_PART_VLDTN(I).component_id, 'Control Shippable'), 'N');
               IF V_CONTROL_SHIP IN (1, 3) THEN
                 --
                 IF V_CONTROL_SHIPPABLE = 'A' THEN
                   --
                   IF p_message IS NULL THEN
                     SELECT LOOKUP_CODE
                       || ': '
                       || DESCRIPTION
                     INTO p_message
                     FROM fnd_lookup_values
                     WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
                     AND UPPER(LOOKUP_CODE) = UPPER('8135');
                     --
                     P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
                   ELSE
                     P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
                   END IF;
                   --
                   V_FLAG_CTRL_SHIP_ERROR  := 'N';
                   IF V_CTRL_SHIP_ERR_MSSG IS NULL THEN
                     V_CTRL_SHIP_ERR_MSSG  := 'Part is approval required but customer doesnot have Approval :'||L_PART_VLDTN(I) .CUSTOMER_NUMBER;
                   ELSE
                     V_CTRL_SHIP_ERR_MSSG := V_CTRL_SHIP_ERR_MSSG||','||L_PART_VLDTN(I) .CUSTOMER_NUMBER;
                   END IF;
                     EXIT;
                 ELSE
                   --
                   IF p_message IS NULL THEN
                     SELECT LOOKUP_CODE
                       || ': '
                       || DESCRIPTION
                     INTO p_message
                     FROM fnd_lookup_values
                     WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
                     AND UPPER(LOOKUP_CODE) = UPPER('8129');
                     --
                     P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
                   ELSE
                     P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
                   END IF;
                   --
                   V_FLAG_CTRL_SHIP_ERROR  := 'N';
                   IF V_CTRL_SHIP_ERR_MSSG IS NULL THEN
                     V_CTRL_SHIP_ERR_MSSG  := 'Part is a license control and customer is not set up to buy it:'||L_PART_VLDTN(I) .CUSTOMER_NUMBER;
                   ELSE
                     V_CTRL_SHIP_ERR_MSSG := V_CTRL_SHIP_ERR_MSSG||','||L_PART_VLDTN(I) .CUSTOMER_NUMBER;
                   END IF;
                     EXIT;
                 END IF;  --end of V_CONTROL_SHIPPABLE = 'A'
               END IF;  -- end of V_CONTROL_SHIP IN (1, 3)
         DBMS_OUTPUT.PUT_LINE('16... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
         ELSIF L_PART_VLDTN(I).SHIP_CODE = L_PART_VLDTN(I).PAST_SHP_CD AND v_proc_status = 'N' THEN
         DBMS_OUTPUT.PUT_LINE('19... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
              IF P_message IS NULL THEN
                  SELECT LOOKUP_CODE
                         || ': '
                         || DESCRIPTION
                    INTO p_message
                    FROM fnd_lookup_values
                   WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
                     AND UPPER(LOOKUP_CODE) = UPPER('8179');
                   --
                  P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
               ELSE
                  P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
               END IF;
               --
              continue;
                  EXIT;
            END IF;  --  IF (L_PART_VLDTN(I).SHIP_CODE = L_PART_VLDTN(I).PAST_SHP_CD AND v_proc_status = 'Y')
          ELSIF L_PART_VLDTN(I).VENDOR_PART > 0 THEN
            --   Adding logic to get the FSCM supplier from Item Category
           DBMS_OUTPUT.PUT_LINE('20... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
           V_FSCM_SUPPLIER := NULL;
            BEGIN
              SELECT MIC.CATEGORY_CONCAT_SEGS
              INTO v_FSCM_supplier
              FROM MTL_ITEM_CATEGORIES_V MIC,
                FND_LOOKUP_VALUES FLV,
                mtl_parameters mp,
                hr_operating_units hou
              WHERE 1                   = 1
              AND MIC.INVENTORY_ITEM_ID = P_ITEM_ID
              AND MIC.CATEGORY_SET_NAME = 'FSCM supplier'
              AND mic.organization_id   = mp.organization_id
              AND flv.lookup_type = 'GEAE_MYGE_PART_APPLICABLE_ORGS'
              AND mp.organization_code  = flv.tag  --MYJIRATEST-3993 Ravi S 30-OCT-2014
              AND FLV.DESCRIPTION       = HOU.NAME
              AND HOU.ORGANIZATION_ID   = TO_NUMBER(J.OU_ID)
              AND ROWNUM                < 2;
            EXCEPTION
            WHEN OTHERS THEN
              V_FSCM_SUPPLIER := NULL;
            END;
            --   Adding logic to get the FSCM supplier from Item Category
            IF P_MESSAGE IS NULL THEN
              SELECT LOOKUP_CODE
                || ': '
                || DESCRIPTION
              INTO p_message
              FROM fnd_lookup_values
              WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
              AND UPPER(LOOKUP_CODE) = UPPER('8131');
              --
              P_MESSAGE := P_MESSAGE||'|'||V_FSCM_SUPPLIER;
           -- ELSE
           --   P_MESSAGE := P_MESSAGE||'|'||V_FSCM_SUPPLIER;
            END IF;
            V_FLAG_VENDOR_ERROR   := 'N';
            IF V_VENDOR_ERR_MSSG  IS NULL THEN
              V_VENDOR_ERR_MSSG   := 'Vendor part and GE does not have permission to sell this part to the customer:'||L_PART_VLDTN(I).CUSTOMER_NUMBER;
            ELSE
              V_VENDOR_ERR_MSSG   := V_VENDOR_ERR_MSSG||','||L_PART_VLDTN(I) .CUSTOMER_NUMBER;
            END IF;
              EXIT;
            --
          DBMS_OUTPUT.PUT_LINE('18... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
          ELSE
            IF P_message IS NULL THEN
              SELECT LOOKUP_CODE
                || ': '
                || DESCRIPTION
              INTO p_message
              FROM fnd_lookup_values
              WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
              AND UPPER(LOOKUP_CODE) = UPPER('8125');
              --
              P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
            ELSE
              P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
            END IF;
            --
          --  EXIT; --JIRA 12358 TRUPTI D. 28-12-2015
DBMS_OUTPUT.PUT_LINE('22... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
          END IF;
          DBMS_OUTPUT.PUT_LINE('21... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
        END IF;  -- end if for ampcode =P Z N
        DBMS_OUTPUT.PUT_LINE('6... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
          -- line is control shippable then get the pricelist
          --
          --Adding if to check if the customer has the price list attached if not then populate the Applicability array and price will be NULL;
          IF NVL(v_price_list_flag,'Y') <> 'N' THEN
            DBMS_OUTPUT.PUT_LINE('7... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
            FOR PRICELSTID IN
            (SELECT stg.price_list_id,
              stg.account_number,
              STG.CUST_ACCOUNT_ID
            FROM TABLE(CAST(P_PRICE_LIST_DTL AS v_PRICE_LIST_DTL)) stg
            WHERE STG.ACCOUNT_NUMBER = L_PART_VLDTN(I) .CUSTOMER_NUMBER
            )
            LOOP
            DBMS_OUTPUT.PUT_LINE('8... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
              --
              P_UNIT_PRICE    := NULL;
              V_PRICE_LIST_ID := PRICELSTID.PRICE_LIST_ID;
              v_cust_account_id := PRICELSTID.cust_account_id;
              V_PUBLISH         := NULL;
              v_price_list_api  := NULL;
              --Calling the procedure GET_PRICE which internally calls  QP_PREQ_PUB.PRICE_REQUEST
              IF V_PRICE_LIST_ID <> NVL(V_PRICE_LIST_ID_OLD, 0) OR V_CUST_ACCOUNT_ID <> NVL(V_CUST_ACCOUNT_ID_OLD, 0) THEN
              DBMS_OUTPUT.PUT_LINE('9... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
                v_price_list_id_old   := v_price_list_id;
                V_Cust_Account_Id_Old := V_Cust_Account_Id;
                GET_PRICE(P_SSO,J.OU_ID, P_ITEM_ID, V_PRICE_LIST_ID, P_UNIT_PRICE, P_LIST_LINE_ID);
                IF P_UNIT_PRICE     IS NOT NULL THEN
                  IF P_LIST_LINE_ID IS NOT NULL THEN
                    BEGIN
                      SELECT NVL(ATTRIBUTE13,'Y')
                             ,list_header_id
                      INTO V_PUBLISH
                           ,v_price_list_api
                      FROM QP_LIST_LINES
                      WHERE 1          = 1
                      AND LIST_LINE_ID = P_LIST_LINE_ID;
                    EXCEPTION
                    WHEN OTHERS THEN
                      V_PUBLISH := 'N';
                      v_price_list_api := NULL;
                    END;
                    IF V_PUBLISH = 'Y' THEN
                      SELECT V_PART_PRICE_LIST_BO(GQIPV.inventory_item_id, GET_PRICE_LIST_NAME(V_PRICE_LIST_ID), P_UNIT_PRICE, NVL(GQIPV.CATALOG_UPQ,1), GQIPV.CATALOG_LEAD_TIME) BULK COLLECT
                      INTO L_PART_PRICE_V
                      FROM GEAE_QP_ITEM_PRICES_V GQIPV,
                        QP_LIST_HEADERS_TL QLH
                      WHERE 1                     = 1
                      AND GQIPV.inventory_item_id = to_char(P_ITEM_ID)
                      AND GQIPV.PRICE_LIST_NAME   = QLH.NAME
                      AND QLH.LIST_HEADER_ID      = v_price_list_api; --L_PRICE_LIST_ID(PRICELSTID);
                      --
                      IF SQL%rowcount > 0 THEN
                        FOR i IN 1 .. L_PART_PRICE_V.count
                        LOOP
                          v_PART_PRICE_V_add := v_PART_PRICE_V_add + 1;
                          l_PART_PRICE_DUP.extend();
                          l_PART_PRICE_DUP(v_PART_PRICE_V_add) := L_PART_PRICE_V(i); --BM Commented
                        END LOOP;
                      ELSE
                        IF p_message IS NULL THEN
                          SELECT LOOKUP_CODE
                            || ': '
                            || DESCRIPTION
                          INTO p_message
                          FROM fnd_lookup_values
                          WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
                          AND UPPER(LOOKUP_CODE) = UPPER('8134');
                          --
                          P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
                        ELSE
                          P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
                        END IF;
                        --
                        EXIT;
                      END IF;
                      --Adding condition to check for No data for QLH.LIST_HEADER_ID
                      SELECT   COUNT(*) INTO l_List_id_count
                           FROM     GEAE_QP_ITEM_PRICES_V GQIPV,
                                    QP_LIST_HEADERS_TL QLH
                           WHERE 1                     = 1
                            AND GQIPV.inventory_item_id = to_char(P_ITEM_ID)
                            AND GQIPV.PRICE_LIST_NAME   = QLH.NAME
                            AND QLH.LIST_HEADER_ID      = v_price_list_api;
                         IF (l_List_id_count)>0 THEN
                         DBMS_OUTPUT.PUT_LINE('10... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
                          --Ravi S: Price list id is passed even if part does not exist in price list MYJIRATEST-2629
                          SELECT V_PART_APPLICABLE_LIST_BO(GQIPV.inventory_item_id,PRICELSTID.account_number, L_PART_VLDTN(I).supplier_code, PRICELSTID.cust_account_id, NVL(GQIPV.CATALOG_UPQ,1), v_price_list_id) BULK COLLECT
                          INTO L_PART_APPLICABLE
                          FROM GEAE_QP_ITEM_PRICES_V GQIPV,
                            QP_LIST_HEADERS_TL QLH
                          WHERE 1                     = 1
                          AND GQIPV.inventory_item_id = P_ITEM_ID
                          AND GQIPV.PRICE_LIST_NAME   = QLH.NAME
                          AND QLH.LIST_HEADER_ID      = v_price_list_api; --L_PRICE_LIST_ID(PRICELSTID);
                        ELSE -- Ankita S:L_PART_APPLICABLE varray will still be populated
                          SELECT V_PART_APPLICABLE_LIST_BO(P_ITEM_ID,PRICELSTID.account_number, L_PART_VLDTN(I).supplier_code, PRICELSTID.cust_account_id, 1, v_price_list_id) BULK COLLECT
                          INTO L_PART_APPLICABLE
                          FROM GEAE_QP_ITEM_PRICES_V GQIPV
                          WHERE 1                     = 1
                        --  AND GQIPV.inventory_item_id = P_ITEM_ID
                          AND rownum = 1;
                        END IF;
                        DBMS_OUTPUT.PUT_LINE('11... CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
                      --
                      IF SQL%rowcount > 0 THEN
                        FOR i IN 1 .. L_PART_APPLICABLE.count
                        LOOP
                          V_PART_APPL_CNT := V_PART_APPL_CNT + 1;
                          l_PART_APPLICABLE_DUP.extend();
                          l_PART_APPLICABLE_DUP(V_PART_APPL_CNT) := L_PART_APPLICABLE(i); --BM Commented
                        END LOOP;
                      ELSE
                        IF p_message IS NULL THEN
                          SELECT LOOKUP_CODE
                            || ': '
                            || DESCRIPTION
                          INTO p_message
                          FROM fnd_lookup_values
                          WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
                          AND UPPER(LOOKUP_CODE) = UPPER('8134'); -----
                          --
                          P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
                        ELSE
                          P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
                        END IF;
                        --
                      END IF;
                      --
                  DBMS_OUTPUT.PUT_LINE('PRICELSTID.account_number3-->'||PRICELSTID.account_number||' '||'L_PART_VLDTN(I) .supplier_code3-->'||L_PART_VLDTN(I) .supplier_code);
                   ELSE --ELSE OF  V_PUBLISH = 'Y' THEN
                      ---Part is priced but publish is N
                      --Populating the Applicability Array such that the Item can be bought
                      ---Populating The Applicability Array even if the Price is nULL as Customer can still buy the parts if the Price is not there Ravi S: However price list id can be passed. MYJIRATEST-2629
                      DBMS_OUTPUT.PUT_LINE('PRICELSTID.account_number-->'||PRICELSTID.account_number||' '||'L_PART_VLDTN(I) .supplier_code-->'||L_PART_VLDTN(I) .supplier_code);
                      SELECT V_PART_APPLICABLE_LIST_BO(msi.inventory_item_id, PRICELSTID.account_number, L_PART_VLDTN(I) .supplier_code, PRICELSTID.cust_account_id, 1, V_PRICE_LIST_ID) BULK COLLECT
                      INTO L_PART_APPLICABLE
                      FROM mtl_system_items_b msi,
                        mtl_parameters mp
                      WHERE 1                   = 1
                      AND msi.inventory_item_id = P_ITEM_ID
                      AND msi.organization_id   = mp.organization_id
                     AND mp.organization_code  = 'CVO';
                     DBMS_OUTPUT.PUT_LINE('PRICELSTID.account_number1-->'||PRICELSTID.account_number||' '||'L_PART_VLDTN(I) .supplier_code1-->'||L_PART_VLDTN(I) .supplier_code);

                      --
                      IF SQL%rowcount > 0 THEN
                        FOR i IN 1 .. L_PART_APPLICABLE.count
                        LOOP
                          V_PART_APPL_CNT := V_PART_APPL_CNT + 1;
                          l_PART_APPLICABLE_DUP.extend();
                         l_PART_APPLICABLE_DUP(V_PART_APPL_CNT) := L_PART_APPLICABLE(i); --BM Commented
                        END LOOP;
                      ELSE
                        IF p_message IS NULL THEN
                          SELECT LOOKUP_CODE
                            || ': '
                            || DESCRIPTION
                          INTO p_message
                          FROM fnd_lookup_values
                          WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
                          AND UPPER(LOOKUP_CODE) = UPPER('8139'); -----
                          --
                          P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
                        ELSE
                          P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
                        END IF;
                        --
                      END IF;
                    END IF; --v_publish is not null and v_publish is 'Y'
                  END IF;   -- P_LIST_LINE_ID is not null
                ELSE        --ELSE OF IF P_UNIT_PRICE IS NOT NULL THEN
                  ---Populating The Applicability Array even if the Price is nULL as Customer can still buy the parts if the Price is not there. Ravi S: However price list id can be passed.  MYJIRATEST-2629
                  DBMS_OUTPUT.PUT_LINE('PRICELSTID.account_number2-->'||PRICELSTID.account_number||' '||'L_PART_VLDTN(I) .supplier_code2-->'||L_PART_VLDTN(I) .supplier_code);
                  SELECT V_PART_APPLICABLE_LIST_BO(msi.inventory_item_id, PRICELSTID.account_number, L_PART_VLDTN(I) .supplier_code, PRICELSTID.cust_account_id, 1, V_PRICE_LIST_ID) BULK COLLECT
                  INTO L_PART_APPLICABLE
                  FROM mtl_system_items_b msi,
                    mtl_parameters mp
                  WHERE 1                   = 1
                  AND msi.inventory_item_id = P_ITEM_ID
                  AND msi.organization_id   = mp.organization_id
                  AND mp.organization_code  = 'CVO';
                  --
                  IF SQL%rowcount > 0 THEN
                    FOR i IN 1 .. L_PART_APPLICABLE.count
                    LOOP
                      V_PART_APPL_CNT := V_PART_APPL_CNT + 1;
                      l_PART_APPLICABLE_DUP.extend();
                      l_PART_APPLICABLE_DUP(V_PART_APPL_CNT) := L_PART_APPLICABLE(i); --BM Commented
                    END LOOP;
                  ELSE
                    IF p_message IS NULL THEN
                      SELECT LOOKUP_CODE
                        || ': '
                        || DESCRIPTION
                      INTO p_message
                      FROM fnd_lookup_values
                      WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
                      AND UPPER(LOOKUP_CODE) = UPPER('8139'); -----
                      --
                      P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
                    ELSE
                      P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
                    END IF;
                    --
                  END IF;
                END IF; -- IF P_UNIT_PRICE IS NOT NULL THEN
             --END IF;
              END IF;  --- IF v_price_list_id <> NVL(v_price_list_id_old, 0) OR
            END LOOP;   --FOR PRICELSTID IN
          ELSE         ---ELSE OF  IF NVL(v_price_list_flag,'Y') <> 'N' THEN
            --Price list could not be detrmined at customer ship to level Populating the Applicability array as customer can still buy the part
          DBMS_OUTPUT.PUT_LINE('L_PART_VLDTN(I).CUSTOMER_NUMBER-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
           SELECT V_PART_APPLICABLE_LIST_BO(msi.inventory_item_id, L_PART_VLDTN(I).CUSTOMER_NUMBER, L_PART_VLDTN(I).supplier_code, L_PART_VLDTN(I).CUST_ACCOUNT_ID, 1, NULL) BULK COLLECT
            INTO L_PART_APPLICABLE
            FROM mtl_system_items_b msi,
              mtl_parameters mp
            WHERE 1                   = 1
            AND msi.inventory_item_id = P_ITEM_ID
            AND msi.organization_id   = mp.organization_id
            AND mp.organization_code  = 'CVO';
            --
            IF SQL%rowcount > 0 THEN
              FOR i IN 1 .. L_PART_APPLICABLE.count
              LOOP
                V_PART_APPL_CNT := V_PART_APPL_CNT + 1;
                l_PART_APPLICABLE_DUP.extend();
                l_PART_APPLICABLE_DUP(V_PART_APPL_CNT) := L_PART_APPLICABLE(i); --BM Commented
              END LOOP;
            ELSE
              IF p_message IS NULL THEN
                SELECT LOOKUP_CODE
                  || ': '
                  || DESCRIPTION
                INTO p_message
                FROM fnd_lookup_values
                WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
                AND UPPER(LOOKUP_CODE) = UPPER('8139'); -----
                --
                P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
              ELSE
                P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
              END IF;
              --
            END IF;
            --
          END IF; ---END IF OF  IF NVL(v_price_list_flag,'Y') <> 'N' THEN
DBMS_OUTPUT.PUT_LINE('IN PART... CUSTOMER_NUMBER1-->'||L_PART_VLDTN(I).CUSTOMER_NUMBER);
DBMS_OUTPUT.PUT_LINE('IN CUST... p_CUST_ID(var)1-->'||p_CUST_ID(var));
        END LOOP;  --FOR I IN 1 .. L_PART_VLDTN.COUNT LOOP
        --
      END LOOP; --FOR var IN 1 .. p_CUST_ID.COUNT LOOP
      ---
      --Populating the Onhand VArray outside Customer Loop.
      --
--Added by OWMS Team : START
         v_item_source := NULL;
         v_item_number := NULL;
         BEGIN
           SELECT DISTINCT segment1
               INTO v_item_number
               FROM mtl_system_items_b
               WHERE INVENTORY_ITEM_ID   = P_ITEM_ID;
           EXCEPTION
             WHEN OTHERS THEN
                        v_item_number := NULL;
           END;
	  --
		SELECT DECODE(COUNT(1),1,'Y','N')
		INTO v_hnd_flag
		 FROM HR_OPERATING_UNITS HOU,
			  FND_LOOKUP_VALUES FLV
		WHERE  HOU.ORGANIZATION_ID = TO_NUMBER(j.OU_ID) --116797
		  AND HOU.NAME = FLV.DESCRIPTION
		  AND FLV.TAG = 'HAI'
		  AND FLV.LOOKUP_TYPE = 'GEAE_MYGE_PART_APPLICABLE_ORGS';
	   --
	   IF v_hnd_flag = 'Y' THEN
	     v_item_source := 'HAI';
	   ELSIF v_hnd_flag = 'N' THEN
	   --
	   v_er1_source := GEAE_INV_GET_SOURCE_CODE ('ER1',v_item_number,'Y');
	   v_er2_source := GEAE_INV_GET_SOURCE_CODE ('ER2',v_item_number,'Y');
	   v_er3_source := GEAE_INV_GET_SOURCE_CODE ('ER3',v_item_number,'Y');
	   --
	   IF v_er1_source = 'CPL' OR v_er2_source = 'CPL' OR v_er3_source = 'CPL' THEN
		v_item_source := 'CPL';
	   ELSE
		 v_item_source := 'ERL';
	   END IF;
	   --
	   END IF;
      SELECT V_PART_AVAILABILITY_LIST_BO(tab.INVENTORY_ITEM_ID, tab.ORGANIZATION_CODE, NVL(tab.QTY,0)) BULK collect
      INTO L_PART_AVAIL
      FROM
      (SELECT STG.INVENTORY_ITEM_ID,STG.ORGANIZATION_CODE,sum(stg.qty) qty
          FROM (SELECT P_ITEM_ID INVENTORY_ITEM_ID ,
                        'On-Hand Stock' ORGANIZATION_CODE,
                         (a.qty-b.qty) QTY
            FROM (SELECT (geae_wms_total_onhand_erl_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
			geae_wms_total_pick_release(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
			 FROM apps.mtl_system_items_b msib,
			      apps.mtl_parameters mp
			 WHERE 1 = 1
			   and msib.inventory_item_id = P_ITEM_ID
			   and msib.organization_id = mp.organization_id
			   and mp.organization_code = v_item_source
			   AND v_item_source NOT IN ('CPL','HAI')) A,
                 (SELECT (geae_wms_resv_qty_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
			geae_wms_total_resv(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
			 FROM apps.mtl_system_items_b msib,
			      apps.mtl_parameters mp
			 WHERE 1 = 1
			   and msib.inventory_item_id = P_ITEM_ID
			   and msib.organization_id = mp.organization_id
			   and mp.organization_code = v_item_source
			   AND v_item_source NOT IN ('CPL','HAI')) B
           UNION ALL
                SELECT P_ITEM_ID INVENTORY_ITEM_ID ,
                        'On-Hand Stock' ORGANIZATION_CODE,
                        (b.qty-c.qty) QTY
                FROM
                     (SELECT NVL(SUM(MOQ.TRANSACTION_QUANTITY),0) qty
                        FROM GEAE_INV_MTL_ONHANDS_V MOQ
                       WHERE INVENTORY_ITEM_ID = P_ITEM_ID
                         AND SUBINVENTORY_CODE IN ('STOCK','STG')
                         AND ORGANIZATION_ID IN (SELECT ORGANIZATION_ID
                                                   FROM MTL_PARAMETERS
                                                  WHERE ORGANIZATION_CODE = V_ITEM_SOURCE)
                          AND v_item_source NOT IN ('ERL','HAI')
                    ) b,
                 (SELECT NVL(SUM(RESERVATION_QUANTITY),0) qty
                             FROM MTL_RESERVATIONS
                     WHERE INVENTORY_ITEM_ID = P_ITEM_ID
                         AND ORGANIZATION_ID IN (SELECT ORGANIZATION_ID
                                                   FROM MTL_PARAMETERS
                                                  WHERE ORGANIZATION_CODE = V_ITEM_SOURCE)
                          AND v_item_source NOT IN ('ERL','HAI')
                   ) C
        UNION ALL
        SELECT DISTINCT MSIB.INVENTORY_ITEM_ID,
                'On-Hand Stock' ORGANIZATION_CODE,
               GIF.ONHAND_QTY  QTY
          FROM GEAE_INV_FOXTROT_DATA_STG GIF,
               MTL_SYSTEM_ITEMS_B MSIB,
               HR_OPERATING_UNITS HOU,
               MTL_PARAMETERS MTP,
               FND_LOOKUP_VALUES FLV
         WHERE MSIB.SEGMENT1=GIF.PRT_NUM
           AND HOU.ORGANIZATION_ID       = TO_NUMBER(J.OU_ID)
           AND HOU.NAME                   = FLV.DESCRIPTION
           AND MTP.ORGANIZATION_CODE      = FLV.TAG
	        AND FLV.TAG					 = v_item_Source
            AND v_item_source NOT IN ('ERL','CPL')
           AND FLV.LOOKUP_TYPE            = 'GEAE_MYGE_PART_APPLICABLE_ORGS'
           AND GIF.ORG_CODE               = MTP.ORGANIZATION_CODE
           AND MSIB.INVENTORY_ITEM_ID =P_ITEM_ID
           AND GIF.SRC_SYS ='HONDA'
          ) STG
--Added by OWMS Team : END
       GROUP BY INVENTORY_ITEM_ID,
          ORGANIZATION_CODE)TAB ;
      -- Onhand Varray Ends

      IF SQL%rowcount > 0 THEN
        FOR i IN 1 .. L_PART_AVAIL.count
        LOOP
          V_PART_AVAIL_cnt := V_PART_AVAIL_cnt + 1;
          P_PART_AVAIL.EXTEND();
          P_PART_AVAIL(V_PART_AVAIL_cnt) := L_PART_AVAIL(i) ; --BM Commented
        END LOOP;
      ELSE
        SELECT LOOKUP_CODE
          || ': '
          || DESCRIPTION
        INTO p_message
        FROM fnd_lookup_values
        WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
        AND UPPER(LOOKUP_CODE) = UPPER('8133');
        --
        --
        --Looping in customer loop to get the cust ids in message for 8133
        IF P_CUST_ID.COUNT > 0 THEN
          FOR VAR IN 1 .. P_CUST_ID.COUNT
          LOOP
            P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
          END LOOP;
        END IF;
        -- Loop ends for customer id concatenation in messages
      END IF;--- End If Part Avaliability list BO
      --End of Onhand Varray Population
      --Making P_MESSAGE NULL if the Array is populated
      IF l_PART_APPLICABLE_DUP.COUNT > 0 THEN
        --
        P_MESSAGE := NULL;
        -- Setting the P_PRICE_MESSAGE
        IF L_PART_PRICE_DUP.COUNT = 0 THEN
          IF p_ROLE              <> 'Cust Enquiry' THEN
            P_PRICE_MESSAGE      := 'Price_Msg:';
            P_PRICE_MESSAGE      := P_PRICE_MESSAGE||'Part is not priced but you can still order part';
          ELSE
            P_PRICE_MESSAGE := 'Price_Msg_01:';
            P_PRICE_MESSAGE := P_PRICE_MESSAGE||'Part is not priced';
          END IF;
          IF P_CUST_ID.COUNT > 0 THEN
            FOR VAR IN 1 .. P_CUST_ID.COUNT
            LOOP
              P_PRICE_MESSAGE := P_PRICE_MESSAGE||'~'||P_CUST_ID(VAR);
            END LOOP;
          END IF;
        ELSE
       --   l_PART_PRICE_DUP_CNT :=0;  Manisha commented on 12 dec to avoid losing the data of P_PART_PRICE array if count initialize again
          ---P_PART_PRICE := l_PART_PRICE_DUP;

          FOR var IN 1 .. l_PART_PRICE_DUP.COUNT
          LOOP

            IF var                  =1  AND P_PART_PRICE.COUNT = 0 THEN --Manisha Added the condition
              l_PART_PRICE_DUP_CNT := l_PART_PRICE_DUP_CNT + 1;
              P_PART_PRICE.extend();
              P_PART_PRICE(l_PART_PRICE_DUP_CNT) := l_PART_PRICE_DUP(var);
            ELSE
              v_price_dup_flag := true;
              FOR dup IN 1 .. P_PART_PRICE.count
              LOOP
                IF l_PART_PRICE_DUP(var).INVENTORY_ITEM_ID = P_PART_PRICE(dup).INVENTORY_ITEM_ID AND l_PART_PRICE_DUP(var).CATALOG = P_PART_PRICE(dup).CATALOG AND l_PART_PRICE_DUP(var).UNIT_PRICE = P_PART_PRICE(dup).UNIT_PRICE AND l_PART_PRICE_DUP(var).UPQ = P_PART_PRICE(dup).UPQ AND l_PART_PRICE_DUP(var).LEAD_TIME = P_PART_PRICE(dup).LEAD_TIME THEN
                  v_price_dup_flag                        := false;
                END IF;
                NULL;
              END LOOP;
              IF v_price_dup_flag THEN
                l_PART_PRICE_DUP_CNT := l_PART_PRICE_DUP_CNT + 1;
                P_PART_PRICE.extend();
                P_PART_PRICE(l_PART_PRICE_DUP_CNT) := l_PART_PRICE_DUP(var);
              END IF;
            END IF;
          END LOOP;
          --Remove Duplicates from P_PART_PRICE  l_PART_PRICE_DUP
        END IF;
        -- Looping in the Onhadn Varray to find if we have onhand
        v_onhand_flag_non_zero := 'N';
        FOR I IN 1 .. P_PART_AVAIL.COUNT
        LOOP
          IF P_PART_AVAIL(I).QUANTITY > 0 THEN
            V_ONHAND_FLAG_NON_ZERO   := 'Y';
               EXIT;
          END IF;
        END LOOP ;
               -- Neelima Y MYJIRATEST-8631 on 18-AUG-2015
       BEGIN
          SELECT tag
            INTO V_OU_TAG
            FROM fnd_lookup_values
           WHERE lookup_type = 'GEAE_MYGE_OPERATING_UNITS'
             AND enabled_flag = 'Y'
             AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(start_date_active, SYSDATE)) AND
                 TRUNC(NVL(end_date_active, SYSDATE))
             AND lookup_code = J.OU_ID;
        Exception
          When Others then
            V_OU_TAG := NULL;
        End; --Fetching Operating Unit Code
        -- Setting the P_AVAIL_MESSAGE
      IF (P_CRITICAL_PART ='Y') AND (V_OU_TAG <>'HND') THEN  -- MYJIRATEST-7056 Ankita.S 04-MAY-2015  --AND Condition added by Neelima Y MYJIRATEST-8631 on 18-AUG-2015
           IF p_ROLE = 'Cust Enquiry' THEN
              P_AVAIL_MESSAGE  := 'Avail_Msg_02:';
              P_AVAIL_MESSAGE:= P_AVAIL_MESSAGE||'Current on hand is already being allocated';
           ELSIF p_ROLE = 'Buyer' THEN
                IF P_CUST_ID.COUNT > 0 THEN
                  FOR VAR IN 1 .. P_CUST_ID.COUNT
                  LOOP
                    P_AVAIL_MESSAGE  := 'Avail_Msg_03:';
                    P_AVAIL_MESSAGE:= P_AVAIL_MESSAGE||'Current on hand is already being allocated, you can still purchase the part'||'~'||P_CUST_ID(VAR);
                  END LOOP;
                END IF;
           ELSE
                  NULL;
           END IF;
      ELSE
            IF V_ONHAND_FLAG_NON_ZERO = 'N' THEN
              IF p_ROLE              <> 'Cust Enquiry' THEN
                P_AVAIL_MESSAGE      := 'Avail_Msg:';
                P_AVAIL_MESSAGE      := P_AVAIL_MESSAGE||'Part does not have on-hand but you can still order part';
              ELSE
                P_AVAIL_MESSAGE := 'Avail_Msg_01:';
                P_AVAIL_MESSAGE := P_AVAIL_MESSAGE||'Part does not have on-hand.';
              END IF;
              IF P_CUST_ID.COUNT > 0 THEN
                FOR VAR IN 1 .. P_CUST_ID.COUNT
                LOOP
                  P_AVAIL_MESSAGE := P_AVAIL_MESSAGE||'~'||P_CUST_ID(VAR);
                END LOOP;
              END IF;
            END IF; --END IF OF V_ONHAND_FLAG_NON_ZERO = 'N' THEN
      END IF;
        --
        -- Loop ends for customer id concatenation in messages
        --Remove duplicates from P_PART_APPLICABLE below
       -- l_PART_APPLICABLE_DUP_CNT :=0;  Manisha commented on 12 dec to avoid reintialize inside the loop
        FOR var IN 1 .. l_PART_APPLICABLE_DUP.COUNT
        LOOP
          IF var                       =1 THEN
            l_PART_APPLICABLE_DUP_CNT := l_PART_APPLICABLE_DUP_CNT + 1;
            P_PART_APPLICABLE.extend();
            P_PART_APPLICABLE(l_PART_APPLICABLE_DUP_CNT) := l_PART_APPLICABLE_DUP(var);
          ELSE
            v_part_APP_DUP_FLAG := true;
            FOR dup IN 1 .. P_PART_APPLICABLE.count
            LOOP
              IF l_PART_APPLICABLE_DUP(var).INVENTORY_ITEM_ID = P_PART_APPLICABLE(dup).INVENTORY_ITEM_ID AND l_PART_APPLICABLE_DUP(var).CUST_CODE = P_PART_APPLICABLE(dup).CUST_CODE AND l_PART_APPLICABLE_DUP(var).SUPPLIER_CODE = P_PART_APPLICABLE(dup).SUPPLIER_CODE AND l_PART_APPLICABLE_DUP(var).CUST_ID = P_PART_APPLICABLE(dup).CUST_ID AND l_PART_APPLICABLE_DUP(var).UPQ = P_PART_APPLICABLE(dup).UPQ AND l_PART_APPLICABLE_DUP(var).PRICE_LIST_ID = P_PART_APPLICABLE(dup).PRICE_LIST_ID THEN
                v_part_APP_DUP_FLAG                          := false;
              END IF;
            END LOOP;
            IF v_part_APP_DUP_FLAG THEN
              l_PART_APPLICABLE_DUP_CNT := l_PART_APPLICABLE_DUP_CNT + 1;
              P_PART_APPLICABLE.extend();
              P_PART_APPLICABLE(l_PART_APPLICABLE_DUP_CNT) := l_PART_APPLICABLE_DUP(var);
            END IF;
          END IF;
        END LOOP;
      END IF; --END IF of P_PART_APPLICABLE.COUNT > 0
      --
      --
      --Looping in customer loop to get the cust ids in message for 8125
      --
      V_GENERIC_MSSG := NULL;
      --
      IF P_PART_APPLICABLE.COUNT = 0 THEN
        --
        P_PART_AVAIL.DELETE;
        V_PART_AVAIL_cnt := 0;  --Manisha 02-Jan Added this to initialize the count if P_PART_AVAIL array is getting deleted
        P_PART_PRICE.DELETE;
        -- If There are more than one 1 message then only return Generic message else return P_MESSAGE
        IF V_GTA_ERR_MSSG     IS NOT NULL THEN
          V_GENERIC_MESSG_CNT := V_GENERIC_MESSG_CNT + 1;
        END IF;
        IF V_ORG_ERR_MSSG     IS NOT NULL THEN
          V_GENERIC_MESSG_CNT := V_GENERIC_MESSG_CNT + 1;
        END IF;
        IF V_CTRL_SHIP_ERR_MSSG    IS NOT NULL THEN
          V_GENERIC_MESSG_CNT := V_GENERIC_MESSG_CNT + 1;
        END IF;
        IF V_AVIALL_ERR_MSSG  IS NOT NULL THEN
          V_GENERIC_MESSG_CNT := V_GENERIC_MESSG_CNT + 1;
        END IF;
        IF V_VENDOR_ERR_MSSG  IS NOT NULL THEN
          V_GENERIC_MESSG_CNT := V_GENERIC_MESSG_CNT + 1;
        END IF;
        IF V_AMPS_CODE_ERR_MSSG IS NOT NULL THEN
          V_GENERIC_MESSG_CNT := V_GENERIC_MESSG_CNT + 1;
        END IF;
        IF V_GENERIC_MESSG_CNT > 1 THEN
          SELECT LOOKUP_CODE
            || ': '
          INTO V_GENERIC_MSSG
          FROM fnd_lookup_values
          WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
          AND UPPER(LOOKUP_CODE) = UPPER('8200');
          V_GENERIC_MSSG        := V_GENERIC_MSSG||V_GTA_ERR_MSSG||'.'||V_ORG_ERR_MSSG||'.'||V_CTRL_SHIP_ERR_MSSG||'.'||V_AVIALL_ERR_MSSG||'.'||V_VENDOR_ERR_MSSG||'.'||V_AMPS_CODE_ERR_MSSG;
          P_MESSAGE             := V_GENERIC_MSSG;
          IF P_CUST_ID.COUNT     > 0 THEN
            FOR VAR IN 1 .. P_CUST_ID.COUNT
            LOOP
              P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
            END LOOP;
          END IF;
        END IF; --END IF Of IF V_GENERIC_MESSG_CNT > 1
      END IF;   --END IF of  P_PART_APPLICABLE.COUNT = 0 THEN
      --
      --MYJIRATEST-6272 Ravi S 03-MAR-2015
      IF v_prod_line_on = 'Y' THEN --   MYJIRATEST-7139 23-MAR-2015    Engine family to Product line changes
         l_bom_counter := 0;
         IF P_CUST_ID.COUNT > 0 AND P_PART_APPLICABLE.COUNT > 0 THEN
            FOR part_bom IN (SELECT DISTINCT prt_apl.cust_code, bom.product_line product_line --   MYJIRATEST-7139 23-MAR-2015    Engine family to Product line changes
                               FROM geae_myge_bom_details_v bom, geae_ont_cust_gta_info gta_hdr, geae_ont_gta_applblty_v gta_line,
                                    TABLE(CAST(P_PART_APPLICABLE AS V_PART_APPLICABLE)) prt_apl
                              WHERE bom.search_ou_id = gta_hdr.org_id
                                AND gta_hdr.geae_ont_cust_gta_info_seq_id = gta_line.geae_ont_cust_gta_info_seq_id
                                AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(gta_hdr.start_date,SYSDATE)) AND TRUNC(NVL(gta_hdr.end_date,SYSDATE))
                                AND bom.eng_mod = gta_line.engine_model
                                AND bom.search_ou_id = J.OU_ID
                                AND bom.inventory_item_id = prt_apl.inventory_item_id
                                AND gta_hdr.customer_id = prt_apl.cust_id) LOOP
               P_PART_BOM.EXTEND(1);
               l_bom_counter := l_bom_counter + 1;
               P_PART_BOM(P_PART_BOM.last):= V_PART_BOM_BO(part_bom.cust_code, part_bom.product_line , l_bom_counter);--   MYJIRATEST-7139 23-MAR-2015    Engine family to Product line changes
            END LOOP;
         END IF;
      END IF;
    ELSE --Else of  IF V_ITEM_STATUS = 'Y' THEN
      --
      SELECT LOOKUP_CODE
        || ': '
        || DESCRIPTION
      INTO p_message
      FROM fnd_lookup_values
      WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
      AND UPPER(LOOKUP_CODE) = UPPER('8125');
      --
      --Looping in customer loop to get the cust ids in message for 8125
      IF P_CUST_ID.COUNT > 0 THEN
        FOR VAR IN 1 .. P_CUST_ID.COUNT
        LOOP
          P_MESSAGE := P_MESSAGE||'~'||P_CUST_ID(VAR);
        END LOOP;
      END IF;
      -- Loop ends for customer id concatenation in messages
    END IF; ---END IF of IF V_ITEM_STATUS = 'Y' THEN
  END IF;   ---END IF of p_ROLE = 'Global Enquiry'
  --Ravi S MYJIRATEST-5063 21-JAN-2015
  l_disc_counter := 0;
  IF P_CUST_ID.COUNT > 0 AND P_PART_APPLICABLE.COUNT > 0 THEN
     FOR i IN 1 .. P_CUST_ID.COUNT LOOP
        l_pr_fr_disc := NULL;
        FOR part_appl IN (SELECT prt_apl.supplier_code, prt_apl.price_list_id, NVL(prt_apl.upq,1) upq
                            FROM TABLE(CAST(P_PART_APPLICABLE AS V_PART_APPLICABLE)) prt_apl,
                                 fnd_lookup_values supp_code
                           WHERE prt_apl.cust_id = P_CUST_ID(i)
                             AND prt_apl.inventory_item_id = P_ITEM_ID
                             AND prt_apl.supplier_code = supp_code.meaning
                             AND supp_code.lookup_type = 'GEAE_MYGE_SUPPLIER_ORGS'
                             AND supp_code.description = J.OU_ID
                           ORDER BY supp_code.attribute3) LOOP
           GET_PRICE(P_SSO,J.OU_ID,P_ITEM_ID,part_appl.price_list_id,l_pr_fr_disc,l_disc_line_id);
           IF l_pr_fr_disc IS NOT NULL THEN
              l_disc_list_id := part_appl.price_list_id;

                EXIT;
           END IF;
           l_disc_list_id := NULL;
        END LOOP;
        FOR r_disc IN C_DISCOUNTS(P_CUST_ID(i),J.OU_ID,P_ITEM_ID,l_disc_list_id) LOOP
           IF r_disc.line_auto_flag = 'Y' THEN
              l_disc_end_date := NULL;
              IF l_disc_end_date > r_disc.qual_end_date OR l_disc_end_date IS NULL THEN
                 l_disc_end_date := r_disc.qual_end_date;
              END IF;
              IF l_disc_end_date > r_disc.line_end_date OR l_disc_end_date IS NULL THEN
                 l_disc_end_date := r_disc.line_end_date;
              END IF;
              IF l_disc_end_date > r_disc.list_end_date OR l_disc_end_date IS NULL THEN
                 l_disc_end_date := r_disc.list_end_date;
              END IF;
              IF l_disc_end_date > r_disc.grants_end_date OR l_disc_end_date IS NULL THEN
                 l_disc_end_date := r_disc.grants_end_date;
              END IF;
              SELECT NVL(SUM(amount),0)
                INTO l_disc_consumed
                FROM qp_limit_transactions
               WHERE list_header_id = r_disc.list_header_id
                 AND list_line_id = r_disc.list_line_id;
              IF r_disc.limit > l_disc_consumed OR r_disc.basis IS NULL THEN
                 l_disc_price := l_pr_fr_disc*(100-r_disc.disc_value)/100;
              ELSE
                 l_disc_price := l_pr_fr_disc;
              END IF;
              P_PART_DISCOUNTS.EXTEND(1);
              l_disc_counter := l_disc_counter + 1;
              P_PART_DISCOUNTS(P_PART_DISCOUNTS.last):= V_PART_DISCOUNTS_BO(r_disc.account_number, r_disc.line_number, r_disc.disc_value, l_disc_price, r_disc.limit, GREATEST(r_disc.limit-l_disc_consumed,0), l_disc_end_date, r_disc.list_name, r_disc.list_description, r_disc.line_number, r_disc.line_comments, r_disc.arithmetic_operator, r_disc.list_header_id, r_disc.list_line_id, l_disc_counter, r_disc.qualifier_id);
          ELSE
              IF P_CUST_ID.COUNT > 0 THEN
                FOR VAR IN 1 .. P_CUST_ID.COUNT
                  LOOP
                    P_DISC_MESSAGE :=GEAE_MYGE_CART_PKG.GET_ERR_MSG(8199)||'~'||P_CUST_ID(VAR);--MYJIRATEST-7192: Ankita.S 04-MAY-2015
                  END LOOP;
              END IF;
           END IF;
        END LOOP;
     END LOOP;
  END IF;
----MYJIRATEST-7138   24-MAR-2015    Oderable Vs Non Oderable changes  starts
 BEGIN
  BEGIN
     SELECT description
--       INTO NVL(v_oderable_on,'N')
      INTO v_oderable_on
       FROM fnd_lookup_values
      WHERE lookup_type = 'GEAE_MYGE_ENABLE_ORDERABLE'
        AND lookup_code = J.OU_ID
        AND enabled_flag = 'Y'
        AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(start_date_active,SYSDATE)) AND TRUNC(NVL(end_date_active,SYSDATE));
  EXCEPTION
     WHEN NO_DATA_FOUND THEN
        v_oderable_on := 'N';
     WHEN OTHERS THEN
        v_oderable_on := 'N';
  END;
  IF v_oderable_on = 'Y' THEN
  --Calls the Procedure for getting Inventory Item status Code
   get_inventory_item_status_code ( lp_inventory_item_id=> P_ITEM_ID ,
                                    P_OU_ID =>J.OU_ID,
                                    lp_inventory_item_status_code => V_ISODERABLE ,
                                    pp_message => V_ISODERABLE_MESSAGE);
   P_ISODERABLE :=V_ISODERABLE;
   IF V_ISODERABLE_MESSAGE  IS NOT NULL THEN
      P_MESSAGE := P_MESSAGE||'.'||V_ISODERABLE_MESSAGE;
   END IF;
  END IF;--v_oderable_on flag
 END;  ----MYJIRATEST-7138   24-MAR-2015    Oderable Vs Non Oderable changes  Ends
--<<END_CODE>>
  NULL;
 END LOOP; --End of Loop J.OU_ID


 /******************************************************
 Manisha K. 10-Aug Added the below code to  remove the duplicates from the loop
 because of OU_ID loop
 *******************************************************/

 FOR i IN 1 .. P_PART_PRICE.COUNT  LOOP

 T_PART_PRICE_LOOP_DUP.extend();
 T_PART_PRICE_LOOP_DUP(T_PART_PRICE_LOOP_DUP.last):= V_PART_PRICE_LIST_BO(P_PART_PRICE(i).INVENTORY_ITEM_ID, P_PART_PRICE(i).CATALOG, P_PART_PRICE(i).UNIT_PRICE, P_PART_PRICE(i).UPQ ,P_PART_PRICE(i).LEAD_TIME);
 END LOOP;

 FOR i IN 1 .. P_PART_APPLICABLE.COUNT  LOOP
 T_PART_APPLICABLE_LOOP_DUP.extend();
 T_PART_APPLICABLE_LOOP_DUP(T_PART_APPLICABLE_LOOP_DUP.LAST):=V_PART_APPLICABLE_LIST_BO(P_PART_APPLICABLE(i).INVENTORY_ITEM_ID,P_PART_APPLICABLE(i).CUST_CODE,P_PART_APPLICABLE(i).SUPPLIER_CODE,P_PART_APPLICABLE(i).CUST_ID,P_PART_APPLICABLE(i).UPQ,P_PART_APPLICABLE(i).PRICE_LIST_ID);
 END LOOP;

 FOR i IN 1 .. P_PART_AVAIL.COUNT  LOOP

 T_PART_AVAIL_LOOP_DUP.extend();
 T_PART_AVAIL_LOOP_DUP(T_PART_AVAIL_LOOP_DUP.last):= V_PART_AVAILABILITY_LIST_BO(P_PART_AVAIL(i).INVENTORY_ITEM_ID, P_PART_AVAIL(i).LOCATION , P_PART_AVAIL(i).QUANTITY);

 END LOOP;

 P_PART_PRICE.DELETE;
 P_PART_APPLICABLE.DELETE;
 P_PART_AVAIL.DELETE;

   i_PART_PRICE_DUP_CNT :=0;
  FOR var IN 1 .. T_PART_PRICE_LOOP_DUP.COUNT     LOOP
      IF var                  =1 THEN
        i_PART_PRICE_DUP_CNT := i_PART_PRICE_DUP_CNT + 1;
        P_PART_PRICE.extend();

        P_PART_PRICE(i_PART_PRICE_DUP_CNT) := T_PART_PRICE_LOOP_DUP(var);

      ELSE

        i_price_dup_flag := true;
        FOR dup IN 1 .. P_PART_PRICE.count
        LOOP
          IF T_PART_PRICE_LOOP_DUP(var).INVENTORY_ITEM_ID = P_PART_PRICE(dup).INVENTORY_ITEM_ID AND T_PART_PRICE_LOOP_DUP(var).CATALOG = P_PART_PRICE(dup).CATALOG AND T_PART_PRICE_LOOP_DUP(var).UNIT_PRICE = P_PART_PRICE(dup).UNIT_PRICE AND T_PART_PRICE_LOOP_DUP(var).UPQ = P_PART_PRICE(dup).UPQ AND T_PART_PRICE_LOOP_DUP(var).LEAD_TIME = P_PART_PRICE(dup).LEAD_TIME THEN
            i_price_dup_flag                        := false;
          END IF;
          NULL;
        END LOOP;
        IF i_price_dup_flag THEN
          i_PART_PRICE_DUP_CNT := i_PART_PRICE_DUP_CNT + 1;
          P_PART_PRICE.extend();
          P_PART_PRICE(i_PART_PRICE_DUP_CNT) := T_PART_PRICE_LOOP_DUP(var);
        END IF;
      END IF;
 END LOOP;

 i_PART_APPLICABLE_DUP_CNT :=0;

 FOR var IN 1 .. T_PART_APPLICABLE_LOOP_DUP.COUNT
        LOOP
          IF var                       =1 THEN
            i_PART_APPLICABLE_DUP_CNT := i_PART_APPLICABLE_DUP_CNT + 1;
            P_PART_APPLICABLE.extend();
            P_PART_APPLICABLE(i_PART_APPLICABLE_DUP_CNT) := T_PART_APPLICABLE_LOOP_DUP(var);
          ELSE
            i_part_APP_DUP_FLAG := true;
            FOR dup IN 1 .. P_PART_APPLICABLE.count
            LOOP
              IF T_PART_APPLICABLE_LOOP_DUP(var).INVENTORY_ITEM_ID = P_PART_APPLICABLE(dup).INVENTORY_ITEM_ID AND T_PART_APPLICABLE_LOOP_DUP(var).CUST_CODE = P_PART_APPLICABLE(dup).CUST_CODE AND T_PART_APPLICABLE_LOOP_DUP(var).SUPPLIER_CODE = P_PART_APPLICABLE(dup).SUPPLIER_CODE AND T_PART_APPLICABLE_LOOP_DUP(var).CUST_ID = P_PART_APPLICABLE(dup).CUST_ID AND T_PART_APPLICABLE_LOOP_DUP(var).UPQ = P_PART_APPLICABLE(dup).UPQ AND T_PART_APPLICABLE_LOOP_DUP(var).PRICE_LIST_ID = P_PART_APPLICABLE(dup).PRICE_LIST_ID THEN
                i_part_APP_DUP_FLAG                          := false;
              END IF;
            END LOOP;
            IF i_part_APP_DUP_FLAG THEN
              i_PART_APPLICABLE_DUP_CNT := i_PART_APPLICABLE_DUP_CNT + 1;
              P_PART_APPLICABLE.extend();
              P_PART_APPLICABLE(i_PART_APPLICABLE_DUP_CNT) := T_PART_APPLICABLE_LOOP_DUP(var);
            END IF;
          END IF;
        END LOOP;
      --remoeve duplicate for p_part_avail
       i_PART_AVAIL_DUP_CNT :=0;

 FOR var IN 1 .. T_PART_AVAIL_LOOP_DUP.COUNT
        LOOP
          IF var                       =1 THEN
            i_PART_AVAIL_DUP_CNT := i_PART_AVAIL_DUP_CNT + 1;
            P_PART_AVAIL.extend();
            P_PART_AVAIL(i_PART_AVAIL_DUP_CNT) := T_PART_AVAIL_LOOP_DUP(var);
          ELSE
            i_part_AVAIL_DUP_FLAG := true;
            FOR dup IN 1 .. P_PART_AVAIL.count
            LOOP
              IF T_PART_AVAIL_LOOP_DUP(var).INVENTORY_ITEM_ID = P_PART_AVAIL(dup).INVENTORY_ITEM_ID AND T_PART_AVAIL_LOOP_DUP(var).QUANTITY = P_PART_AVAIL(dup).QUANTITY AND T_PART_AVAIL_LOOP_DUP(var).LOCATION = P_PART_AVAIL(dup).LOCATION THEN
                i_part_AVAIL_DUP_FLAG                          := false;
              END IF;
            END LOOP;
            IF i_part_AVAIL_DUP_FLAG THEN
              i_PART_AVAIL_DUP_CNT := i_PART_AVAIL_DUP_CNT + 1;
              P_PART_AVAIL.extend();
              P_PART_AVAIL(i_PART_AVAIL_DUP_CNT) := T_PART_AVAIL_LOOP_DUP(var);
            END IF;
          END IF;
        END LOOP;
END GET_ITEM_PRICE_AVAIL;
--MYJIRATEST-7138 Added new procedure for calculating Inventory Item status Code for Oderable Vs Non Oderable Change Starts
PROCEDURE get_inventory_item_status_code(lp_inventory_item_id          IN VARCHAR2,
                                         P_OU_ID                       IN VARCHAR2,
                                         lp_inventory_item_status_code OUT VARCHAR2,
                                         pp_message                    OUT VARCHAR2) IS
  v_procurement_code  mtl_item_categories_v.category_concat_segs%TYPE := NULL;
  v_all_ship_a        bom_components_b.attribute5%type;
  v_all_ship_b        bom_components_b.attribute5%type;
  v_all_ship_c        bom_components_b.attribute5%type;
  v_status_cd         VARCHAR2(255);
  v_future_part       VARCHAR2(255);
  v_prime_ship        VARCHAR2(255);
  v_error_code        VARCHAR2(255) := Null;
  v_ou_tag            VARCHAR2(255) := Null;
  v_onhand_qty        mtl_onhand_quantities.transaction_quantity%type;
  v_operating_unit_id hr_operating_units.organization_id%type;
  v_validation_org_id mtl_parameters.organization_id%type;
  lp_organization_id  mtl_system_items_b.organization_id%type;
  e_exit exception;
  v_cpl_org_id ORG_ORGANIZATION_DEFINITIONS.ORGANIZATION_CODE%type; /*Added by Capgemini OWMS Team for MyGE Changes*/
  v_sdc_org_id ORG_ORGANIZATION_DEFINITIONS.ORGANIZATION_CODE%type; /*Added by Capgemini OWMS Team for MyGE Changes*/
  v_erl_org_id ORG_ORGANIZATION_DEFINITIONS.ORGANIZATION_CODE%type; /*Added by Capgemini OWMS Team for MyGE Changes*/
  v_item_source                VARCHAR2(10); -- Added for OWMS Implementation US192483/US192484
  v_item_number                VARCHAR2(30); -- Added for OWMS Implementation US192483/US192484
  CURSOR ship_codes(p_organization_id NUMBER, p_inventory_item_id NUMBER) IS
    SELECT distinct cmp.attribute5 shippability_code
      FROM bom_structures_b bom, bom_components_b cmp
     WHERE bom.bill_sequence_id = cmp.bill_sequence_id
       AND SYSDATE BETWEEN cmp.effectivity_date AND
           NVL(cmp.disable_date, SYSDATE)
       AND bom.attribute12 = v_ou_tag
       AND bom.organization_id = v_validation_org_id
       AND cmp.component_item_id = lp_inventory_item_id;
BEGIN
  /*Added by Capgemini OWMS Team for MyGE Changes*/
  BEGIN
    SELECT ORGANIZATION_ID
      INTO v_cpl_org_id
      FROM ORG_ORGANIZATION_DEFINITIONS
     WHERE ORGANIZATION_CODE = 'CPL';
  EXCEPTION
    WHEN OTHERS THEN
    v_cpl_org_id:= 0;
  END;
--Added by OWMS Team : START
  BEGIN
    SELECT ORGANIZATION_ID
      INTO v_erl_org_id
      FROM ORG_ORGANIZATION_DEFINITIONS
     WHERE ORGANIZATION_CODE = 'ERL';
  EXCEPTION
    WHEN OTHERS THEN
    v_erl_org_id:= 0;
  END;
--Added by OWMS Team : END
  BEGIN
    SELECT ORGANIZATION_ID
      INTO v_sdc_org_id
      FROM ORG_ORGANIZATION_DEFINITIONS
     WHERE ORGANIZATION_CODE = 'SDC';
  EXCEPTION
    WHEN OTHERS THEN
    v_sdc_org_id:= 0;
  END;
  /*Added by Capgemini OWMS Team for MyGE Changes*/
  BEGIN
    --Fetching Operating Unit Code
    SELECT tag
      INTO v_ou_tag
      FROM fnd_lookup_values
     WHERE lookup_type = 'GEAE_MYGE_OPERATING_UNITS'
       AND enabled_flag = 'Y'
       AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(start_date_active, SYSDATE)) AND
           TRUNC(NVL(end_date_active, SYSDATE))
       AND lookup_code = P_OU_ID;
  Exception
    When Others then
      v_error_code := '8066';
      RAISE e_exit;
  End; --Fetching Operating Unit Code
  BEGIN
    --Fetching Organization ID and Org Code
    SELECT msib.organization_id, ood.operating_unit
      INTO lp_organization_id, v_operating_unit_id
      FROM mtl_system_items_b           msib,
           org_organization_definitions ood,
           fnd_lookup_values            flv
     WHERE msib.organization_id = ood.organization_id
       AND ood.organization_code = flv.attribute1
       AND msib.item_type NOT IN ('OC')
       AND inventory_item_id = lp_inventory_item_id
       AND flv.lookup_type = 'GEAE_MYGE_SUPPLIER_ORGS'
       AND flv.enabled_flag = 'Y'
       AND flv.attribute3 = '1'
       AND TRUNC(SYSDATE) BETWEEN
           TRUNC(NVL(flv.start_date_active, SYSDATE)) AND
           TRUNC(NVL(flv.end_date_active, SYSDATE))
       AND flv.description = P_OU_ID;
    v_validation_org_id := oe_sys_parameters.VALUE('MASTER_ORGANIZATION_ID',
                                                   v_operating_unit_id);
  Exception
    When Others then
      v_error_code := '8066';
      RAISE e_exit;
  End; --Fetching Organization ID and Org Code
  v_all_ship_a  := '-1';
  v_all_ship_b  := '-1';
  v_all_ship_c  := '-1';
  v_future_part := '-1';
  v_status_cd   := 'Ltd-Usage';
  -- r_foxt_data_stg.attribute12 := 'ALL-SHIPPABLE-OTHERS';
  v_onhand_qty       := 0;
  v_procurement_code := NULL;
  FOR sel_model_ship_codes IN ship_codes(to_number(v_validation_org_id),
                                         to_number(lp_inventory_item_id)) loop
--    fnd_file.put_line(fnd_file.log,'Shipability code:' ||sel_model_ship_codes.shippability_code);
    IF sel_model_ship_codes.shippability_code = 'A' -- AND v_all_ship_a <> 'N'  --Commented for Aero AMPS Nov-13 Release Scenario 3
     THEN
      v_all_ship_a  := 'Y';
      v_all_ship_b  := 'N';
      v_all_ship_c  := 'N';
      v_future_part := 'N';
    ELSIF sel_model_ship_codes.shippability_code = 'B' AND
          v_all_ship_b <> 'N' THEN
      v_all_ship_b  := 'Y';
      v_all_ship_a  := 'N';
      v_all_ship_c  := 'N';
      v_future_part := 'N';
    ELSIF sel_model_ship_codes.shippability_code = 'C' AND
          v_all_ship_c <> 'N' THEN
      v_all_ship_c  := 'Y';
      v_all_ship_a  := 'N';
      v_all_ship_b  := 'N';
      v_future_part := 'N';
    ELSIF sel_model_ship_codes.shippability_code IN ('1', '2') AND
          v_future_part <> 'N' --Removed "4" for AeroAMPS Nov-13 release Scenario 1
     THEN
      v_future_part := 'Y';
      v_all_ship_a  := 'N';
      v_all_ship_b  := 'N';
      v_all_ship_c  := 'N';
    ELSIF sel_model_ship_codes.shippability_code IN ('X', 'Y', '3', '4') --Added "4" for AeroAMPS Nov-13 release Scenario 2
     THEN
      v_prime_ship  := 'Y';
      v_all_ship_a  := 'N';
      v_all_ship_b  := 'N';
      v_all_ship_c  := 'N';
      v_future_part := 'N';
    ELSE
      v_all_ship_a  := 'N';
      v_all_ship_b  := 'N';
      v_all_ship_c  := 'N';
      v_future_part := 'N';
    END IF;
  END LOOP;
  --fnd_file.put_line(fnd_file.LOG, 'v_prime_ship:' || v_prime_ship);
  v_procurement_code := geae_inv_amps_common_utils_pkg.get_category_value(p_organization_id   => to_number(lp_organization_id),
                                                                          p_inventory_item_id => to_number(lp_inventory_item_id),
                                                                          p_category_set_name => 'Procurement Code');
  --r_foxt_data_stg.attribute13 := v_procurement_code;
  --fnd_file.put_line(fnd_file.LOG,'v_procurement_code:' || v_procurement_code);
  IF v_prime_ship = 'Y' AND v_procurement_code = 'X' THEN
    v_status_cd := 'Active';
    --  r_foxt_data_stg.attribute12 := 'SHIP-X-Y-3-4-AND-PRIMESHIP';  --Added "4" for AeroAMPS Nov-13 release Scenario 2
    /*Added for AeroAMPS Nov-13 release Scenario 2*/
  ELSIF v_prime_ship = 'Y' AND v_procurement_code = 'V' THEN
    /*Added by Capgemini OWMS Team for MyGE Changes*/
   IF v_cpl_org_id = lp_organization_id OR v_sdc_org_id = lp_organization_id THEN
--Added by OWMS Team : START
  	SELECT NVL((b.qty-c.qty),0) QTY
			   INTO v_onhand_qty
		FROM (SELECT NVL(SUM(MOQ.TRANSACTION_QUANTITY),0) qty
				FROM GEAE_INV_MTL_ONHANDS_V MOQ
			   WHERE INVENTORY_ITEM_ID = to_number(lp_inventory_item_id)
        AND SUBINVENTORY_CODE IN ('STOCK','STG')
				 AND ORGANIZATION_ID = to_number(lp_organization_id)
			) b,
		 (SELECT NVL(SUM(RESERVATION_QUANTITY),0) qty
					 FROM MTL_RESERVATIONS
			 WHERE INVENTORY_ITEM_ID = to_number(lp_inventory_item_id)
				 AND ORGANIZATION_ID = to_number(lp_organization_id)
			) C ;
		---- OWMS team Changes for DE25546 : End
    ELSIF v_erl_org_id = lp_organization_id THEN
          SELECT NVL((A.QTY - B.QTY),0)  QTY
       		   INTO v_onhand_qty
            FROM (SELECT (geae_wms_total_onhand_erl_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
			geae_wms_total_pick_release(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
			 FROM apps.mtl_system_items_b msib,
			      apps.mtl_parameters mp
			 WHERE 1 = 1
			   and msib.inventory_item_id = to_number(lp_inventory_item_id)
			   and msib.organization_id = mp.organization_id
			   and mp.organization_id = to_number(lp_organization_id)) A,
                 (SELECT (geae_wms_resv_qty_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
			geae_wms_total_resv(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
			 FROM apps.mtl_system_items_b msib,
			      apps.mtl_parameters mp
			 WHERE 1 = 1
			   and msib.inventory_item_id = to_number(lp_inventory_item_id)
			   and msib.organization_id = mp.organization_id
			   and mp.organization_id = to_number(lp_organization_id)) B;
--Added by OWMS Team : END
    ELSE
    /*Added by Capgemini OWMS Team for MyGE Changes*/
    SELECT nvl(sum(transaction_quantity), 0)
      INTO v_onhand_qty
      FROM GEAE_INV_MTL_ONHANDS_V moq
     WHERE moq.inventory_item_id = to_number(lp_inventory_item_id)
       AND moq.organization_id = to_number(lp_organization_id);
    /*Added by Capgemini OWMS Team for MyGE Changes*/
    END IF;
    /*Added by Capgemini OWMS Team for MyGE Changes*/
    IF v_onhand_qty = 0 THEN
      v_status_cd := 'Ltd-Usage';
    END IF;
    /*Added for AeroAMPS Nov-13 release*/
  ELSIF v_all_ship_b = 'Y' THEN
    v_status_cd := 'Rework';
    -- r_foxt_data_stg.attribute12 := 'ALL-SHIPPABLE-B';
  ELSIF v_all_ship_c = 'Y' THEN
    v_status_cd := 'Obsolete';
    -- r_foxt_data_stg.attribute12 := 'ALL-SHIPPABLE-C';
  ELSIF v_future_part = 'Y' THEN
    v_status_cd := 'DO-NOT-SEND';
    --  r_foxt_data_stg.attribute12 := 'FUTURE-1-2'; --Removed '4' for Nov-13 Release
  ELSIF v_all_ship_a = 'Y' THEN
    /* SELECT  nvl(max('SDC'),'NON-SDC')
    INTO  v_prt_src_cd
    FROM  mtl_system_items_b msib,
    mtl_parameters mp
                     WHERE  msib.inventory_item_id = to_number(lp_inventory_item_id)
     AND  msib.organization_id = mp.organization_id
     AND  mp.organization_code = g_sdc_org_code;*/
    /*Added by Capgemini OWMS Team for MyGE Changes*/
   IF v_cpl_org_id = lp_organization_id OR v_sdc_org_id = lp_organization_id THEN
--Added by OWMS Team : START
  	SELECT NVL((b.qty-c.qty),0) QTY
			   INTO v_onhand_qty
		FROM (SELECT NVL(SUM(MOQ.TRANSACTION_QUANTITY),0) qty
				FROM GEAE_INV_MTL_ONHANDS_V MOQ
			   WHERE INVENTORY_ITEM_ID = to_number(lp_inventory_item_id)
         AND SUBINVENTORY_CODE IN ('STOCK','STG')
				 AND ORGANIZATION_ID = to_number(lp_organization_id)
			) b,
		 (SELECT NVL(SUM(RESERVATION_QUANTITY),0) qty
					 FROM MTL_RESERVATIONS
			 WHERE INVENTORY_ITEM_ID = to_number(lp_inventory_item_id)
				 AND ORGANIZATION_ID = to_number(lp_organization_id)
			) C ;
    ELSIF v_erl_org_id = lp_organization_id THEN
          SELECT NVL((A.QTY - B.QTY),0)  QTY
       		   INTO v_onhand_qty
            FROM (SELECT (geae_wms_total_onhand_erl_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
			geae_wms_total_pick_release(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
			 FROM apps.mtl_system_items_b msib,
			      apps.mtl_parameters mp
			 WHERE 1 = 1
			   and msib.inventory_item_id = to_number(lp_inventory_item_id)
			   and msib.organization_id = mp.organization_id
			   and mp.organization_id = to_number(lp_organization_id)) A,
                 (SELECT (geae_wms_resv_qty_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
			geae_wms_total_resv(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
			 FROM apps.mtl_system_items_b msib,
			      apps.mtl_parameters mp
			 WHERE 1 = 1
			   and msib.inventory_item_id = to_number(lp_inventory_item_id)
			   and msib.organization_id = mp.organization_id
			   and mp.organization_id = to_number(lp_organization_id)) B;
--Added by OWMS Team : END
	ELSE
    /*Added by Capgemini OWMS Team for MyGE Changes*/
    SELECT nvl(sum(transaction_quantity), 0)
      INTO v_onhand_qty
      FROM GEAE_INV_MTL_ONHANDS_V moq
     WHERE moq.inventory_item_id = to_number(lp_inventory_item_id)
       AND moq.organization_id = to_number(lp_organization_id);
    /*Added by Capgemini OWMS Team for MyGE Changes*/
    END IF;
       /*Added by Capgemini OWMS Team for MyGE Changes*/
    --END IF;
    --  fnd_file.put_line(fnd_file.log,'10  on hand qty before if  -> :'||v_onhand_qty);
    IF v_onhand_qty > 0 THEN
      --   r_foxt_data_stg.attribute12 := 'ALL-SHIPPABLE-A-WITH-ONHAND';
      v_status_cd := 'Active';
      -- fnd_file.put_line(fnd_file.log,'20  SHIPPABLE-A-WITH-ONHAND  -> :'||r_foxt_data_stg.attribute12);
      --   r_foxt_data_stg.attribute12 := 'ALL-SHIPPABLE-A-WITHOUT-ONHAND';
      --fnd_file.put_line(fnd_file.log,'30  SHIPPABLE-A-WITHOUT-ONHAND -> :'||r_foxt_data_stg.attribute12);
    end if;
    /*Added for AeroAMPS Nov-13 release Scenario 4 Anything with Inventory in fndderlanger /with out Inventory in erlanger*/
  END IF;
  IF v_status_cd = 'Ltd-Usage' THEN
   IF v_cpl_org_id = lp_organization_id OR v_sdc_org_id = lp_organization_id THEN
--Added by OWMS Team : START
  	SELECT NVL((b.qty-c.qty),0) QTY
			   INTO v_onhand_qty
		FROM (SELECT NVL(SUM(MOQ.TRANSACTION_QUANTITY),0) qty
				FROM GEAE_INV_MTL_ONHANDS_V MOQ
			   WHERE INVENTORY_ITEM_ID = to_number(lp_inventory_item_id)
         AND SUBINVENTORY_CODE IN ('STOCK','STG')
				 AND ORGANIZATION_ID = to_number(lp_organization_id)
			) b,
		 (SELECT NVL(SUM(RESERVATION_QUANTITY),0) qty
					 FROM MTL_RESERVATIONS
			 WHERE INVENTORY_ITEM_ID = to_number(lp_inventory_item_id)
				 AND ORGANIZATION_ID = to_number(lp_organization_id)
			) C ;
		---- OWMS team Changes for DE25546 : End
    ELSIF v_erl_org_id = lp_organization_id THEN
          SELECT NVL((A.QTY - B.QTY),0)  QTY
       		   INTO v_onhand_qty
            FROM (SELECT (geae_wms_total_onhand_erl_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
			geae_wms_total_pick_release(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
			 FROM apps.mtl_system_items_b msib,
			      apps.mtl_parameters mp
			 WHERE 1 = 1
			   and msib.inventory_item_id = to_number(lp_inventory_item_id)
			   and msib.organization_id = mp.organization_id
			   and mp.organization_id = to_number(lp_organization_id)) A,
                 (SELECT (geae_wms_resv_qty_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
			geae_wms_total_resv(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
			 FROM apps.mtl_system_items_b msib,
			      apps.mtl_parameters mp
			 WHERE 1 = 1
			   and msib.inventory_item_id = to_number(lp_inventory_item_id)
			   and msib.organization_id = mp.organization_id
			   and mp.organization_id = to_number(lp_organization_id)) B;
--Added by OWMS Team : End
    /*Added by Capgemini OWMS Team for MyGE Changes*/
	ELSE
    SELECT nvl(sum(transaction_quantity), 0)
      INTO v_onhand_qty
      FROM GEAE_INV_MTL_ONHANDS_V moq
     WHERE moq.inventory_item_id = to_number(lp_inventory_item_id)
       AND moq.organization_id = to_number(lp_organization_id);
    /*Added by Capgemini OWMS Team for MyGE Changes*/
    END IF;
       /*Added by Capgemini OWMS Team for MyGE Changes*/
    /*Added by Capgemini OWMS Team for MyGE Changes*/
    IF v_onhand_qty > 0 THEN
      v_status_cd := 'Active';
    END IF;
    /*Added for AeroAMPS Nov-13 release Scenario 4 Anything with Inventory in erlanger /with out Inventory in erlanger*/
  END IF;
  IF v_status_cd = 'Active' THEN
    lp_inventory_item_status_code := 'Y';
  ELSIF v_status_cd = 'DO-NOT-SEND' THEN
    lp_inventory_item_status_code := 'D';
  ELSE
    lp_inventory_item_status_code := 'N';
  END IF;
  --  fnd_file.put_line(fnd_file.LOG,'inv_item_status onhand_qty - '||r_foxt_data_stg.onhand_qty );
  --  fnd_file.put_line(fnd_file.log,'attribute12 after item status:'|| r_foxt_data_stg.attribute12);
EXCEPTION
  WHEN e_exit THEN
    SELECT LOOKUP_CODE || ': ' || DESCRIPTION
      INTO pp_message
      FROM fnd_lookup_values
     WHERE LOOKUP_TYPE = 'GEAE_MYGE_ERROR_CODES'
       AND UPPER(LOOKUP_CODE) = v_error_code;
END get_inventory_item_status_code;
--MYJIRATEST-7138 Added new procedure for calculating Inventory Item status Code for Oderable Vs Non Oderable Change Ends
PROCEDURE GET_PRICE(
    P_SSO               VARCHAR2,
    P_OU_ID             VARCHAR2,
    P_INVENTORY_ITEM_ID NUMBER,
    P_PRICE_LIST_ID     NUMBER,
    P_UNIT_PRICE OUT NUMBER,
    P_LIST_LINE_ID OUT NUMBER )
AS
  --
  p_line_tbl QP_PREQ_GRP.LINE_TBL_TYPE;
  p_qual_tbl QP_PREQ_GRP.QUAL_TBL_TYPE;
  p_line_attr_tbl QP_PREQ_GRP.LINE_ATTR_TBL_TYPE;
  p_LINE_DETAIL_tbl QP_PREQ_GRP.LINE_DETAIL_TBL_TYPE;
  p_LINE_DETAIL_qual_tbl QP_PREQ_GRP.LINE_DETAIL_QUAL_TBL_TYPE;
  p_LINE_DETAIL_attr_tbl QP_PREQ_GRP.LINE_DETAIL_ATTR_TBL_TYPE;
  p_related_lines_tbl QP_PREQ_GRP.RELATED_LINES_TBL_TYPE;
  p_control_rec QP_PREQ_GRP.CONTROL_RECORD_TYPE;
  x_line_tbl QP_PREQ_GRP.LINE_TBL_TYPE;
  x_line_qual QP_PREQ_GRP.QUAL_TBL_TYPE;
  x_line_attr_tbl QP_PREQ_GRP.LINE_ATTR_TBL_TYPE;
  x_line_detail_tbl QP_PREQ_GRP.LINE_DETAIL_TBL_TYPE;
  x_line_detail_qual_tbl QP_PREQ_GRP.LINE_DETAIL_QUAL_TBL_TYPE;
  x_line_detail_attr_tbl QP_PREQ_GRP.LINE_DETAIL_ATTR_TBL_TYPE;
  x_related_lines_tbl QP_PREQ_GRP.RELATED_LINES_TBL_TYPE;
  x_return_status      VARCHAR2(240);
  x_return_status_text VARCHAR2(240);
  qual_rec QP_PREQ_GRP.QUAL_REC_TYPE;
  line_attr_rec QP_PREQ_GRP.LINE_ATTR_REC_TYPE;
  line_rec QP_PREQ_GRP.LINE_REC_TYPE;
  detail_rec QP_PREQ_GRP.LINE_DETAIL_REC_TYPE;
  ldet_rec QP_PREQ_GRP.LINE_DETAIL_REC_TYPE;
  rltd_rec QP_PREQ_GRP.RELATED_LINES_REC_TYPE;
  l_pricing_contexts_Tbl QP_Attr_Mapping_PUB.Contexts_Result_Tbl_Type;
  l_qualifier_contexts_Tbl QP_Attr_Mapping_PUB.Contexts_Result_Tbl_Type;
  v_line_tbl_cnt INTEGER;
  I BINARY_INTEGER;
  J BINARY_INTEGER;
  l_version  VARCHAR2(240);
  --L_File_Val Varchar2(60);
  V_User_Id Number := Null;
  V_Resp_Id Number := Null;
  v_RESP_APPL_ID Number := Null;
  v_app_short_name VARCHAR2(10);
BEGIN
  --oe_debug_pub.debug_on;
  --oe_debug_pub.initialize;
  --l_file_val := OE_DEBUG_PUB.Set_Debug_Mode('FILE');
  --OE_DEBUG_PUB.SETDEBUGLEVEL(5);
 -- QP_Attr_Mapping_PUB.Build_Contexts(p_request_type_code => 'ONT', p_pricing_type => 'L', x_price_contexts_result_tbl => l_pricing_contexts_Tbl, x_qual_contexts_result_tbl => l_qualifier_Contexts_Tbl);
  v_line_tbl_cnt := 1;
  ---- Control Record
  p_control_rec.pricing_event            := 'LINE'; -- 'BATCH'; LINE
  p_control_rec.calculate_flag           := 'Y';     --QP_PREQ_GRP.G_SEARCH_N_CALCULATE;
  p_control_rec.simulation_flag          := 'N';
  p_control_rec.rounding_flag            := 'Q';
  p_control_Rec.manual_discount_flag     := 'Y';
  p_control_rec.request_type_code        := 'ONT';
  p_control_rec.TEMP_TABLE_INSERT_FLAG   := 'Y';
  p_control_rec.source_order_amount_flag := 'Y';
  -------------------------
  ---- Line Records ---------
  line_rec.request_type_code := 'ONT';
  --line_rec.line_id := 2125125; -- Order Line Id. This can be any thing for this script
  line_rec.line_Index              := '1';       -- Request Line Index
  line_rec.line_type_code          := 'LINE';    -- LINE or ORDER(Summary Line)
  line_rec.pricing_effective_date  := SYSDATE;   -- Pricing as of what date ?
  line_rec.active_date_first       := SYSDATE;   -- Can be Ordered Date or Ship Date
  line_rec.active_date_second      := SYSDATE;   -- Can be Ordered Date or Ship Date
  line_rec.active_date_first_type  := 'NO TYPE'; -- ORD/SHIP
  line_rec.active_date_second_type := 'NO TYPE'; -- ORD/SHIP
  line_rec.line_quantity           := 1;         -- Ordered Quantity
  line_rec.line_uom_code           := 'EA';      -- Ordered UOM Code
  line_rec.currency_code           := 'USD';     -- Currency Code
  line_rec.price_flag              := 'Y';       -- Price Flag can have 'Y' , 'N'(No pricing) , 'P'(Phase)
  p_line_tbl(1)                    := line_rec;
  ---- Line Attribute Record
  line_attr_rec.LINE_INDEX              := 1;
  line_attr_rec.PRICING_CONTEXT         := 'ITEM'; --
  line_attr_rec.PRICING_ATTRIBUTE       := 'PRICING_ATTRIBUTE3';
  line_attr_rec.PRICING_ATTR_VALUE_FROM := 'ALL';
  line_attr_rec.VALIDATED_FLAG          := 'N';
  p_line_attr_tbl(1)                    := line_attr_rec;
  line_attr_rec.LINE_INDEX              := 1;
  line_attr_rec.PRICING_CONTEXT         := 'ITEM'; --
  line_attr_rec.PRICING_ATTRIBUTE       := 'PRICING_ATTRIBUTE1';
  line_attr_rec.PRICING_ATTR_VALUE_FROM := TO_CHAR(P_INVENTORY_ITEM_ID); -- INVENTORY ITEM ID
  line_attr_rec.VALIDATED_FLAG          := 'N';
  p_line_attr_tbl(2)                    := line_attr_rec;
  ---- Qualifier Attribute Record
  qual_rec.LINE_INDEX                := 1; -- Attributes for the above line. Attributes are attached with the line index
  qual_rec.QUALIFIER_CONTEXT         := 'MODLIST';
  qual_rec.QUALIFIER_ATTRIBUTE       := 'QUALIFIER_ATTRIBUTE4';
  qual_rec.QUALIFIER_ATTR_VALUE_FROM := TO_CHAR(P_PRICE_LIST_ID); -- PRICE LIST ID;
  qual_rec.COMPARISON_OPERATOR_CODE  := '=';
  qual_rec.VALIDATED_FLAG            := 'Y';
  p_qual_tbl(1)                      := qual_rec;
  --
 -- FND_GLOBAL.APPS_INITIALIZE(USER_ID => 43867, RESP_ID => 54274, RESP_APPL_ID => 660);
  --
  Begin
    Select User_Id
      into V_User_Id
     From Fnd_User
    Where 1 = 1
    And  User_Name = P_Sso;
   Exception
     when OTHERS THEN
     V_User_Id := Null;
  End;
  --MYJIRATEST-3512 Ravi S 18-NOV-2014
  IF V_User_Id IS NULL THEN
     BEGIN
        SELECT usr.user_id
          INTO V_User_Id
          FROM fnd_user usr, fnd_lookup_values dflt
         WHERE dflt.lookup_type = 'GEAE_MYGE_DEFAULT_LOGIN'
           AND dflt.enabled_flag = 'Y'
           AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(dflt.start_date_active,SYSDATE)) AND TRUNC(NVL(dflt.end_date_active,SYSDATE))
           AND dflt.lookup_code = P_OU_ID
           AND dflt.description = usr.user_name;
     EXCEPTION
        WHEN OTHERS THEN
           V_User_Id := Null;
     END;
  END IF;
--
--
   Begin
    Select frt.Responsibility_Id
          ,fa.Application_Id
          ,fa.application_short_name
      Into V_Resp_Id
           ,V_Resp_Appl_Id
           ,v_app_short_name
     From Fnd_Responsibility_Tl  Frt
         ,Fnd_Lookup_Values Flv
         ,Hr_Operating_Units Hru
         ,fnd_application fa
      Where 1 = 1
       and frt.language = 'US'
       and frt.responsibility_name = flv.description
       And flv.meaning = hru.name
       And flv.lookup_type = 'GEAE_MYGE_PRICE_RESPONSIBILITY'
       and fa.application_id = frt.application_id
       And Hru.Organization_Id = To_Number(P_Ou_Id);
      Exception
        When Others Then
        V_Resp_Id := Null;
        V_Resp_Appl_Id := NULL;
   END;
--
--  APPS INTIALIZE
 FND_GLOBAL.APPS_INITIALIZE(USER_ID => V_User_Id, RESP_ID => V_Resp_Id, RESP_APPL_ID => V_Resp_Appl_Id);
 MO_GLOBAL.SET_POLICY_CONTEXT('S', P_OU_ID);
 MO_GLOBAL.INIT(v_app_short_name);
--
  QP_PREQ_PUB.PRICE_REQUEST(p_line_tbl, p_qual_tbl, p_line_attr_tbl, p_line_detail_tbl, p_line_detail_qual_tbl, p_line_detail_attr_tbl, p_related_lines_tbl, p_control_rec, x_line_tbl, x_line_qual, x_line_attr_tbl, x_line_detail_tbl, x_line_detail_qual_tbl, x_line_detail_attr_tbl, x_related_lines_tbl, x_return_status, x_return_status_text);
  I    := X_LINE_TBL.first;
  IF I IS NOT NULL THEN
    LOOP
      EXIT
    WHEN I = X_LINE_TBL.LAST;
      I   := x_line_tbl.NEXT(I);
    END LOOP;
  END IF;
  J    := x_line_detail_tbl.FIRST;
  IF J IS NOT NULL THEN
    LOOP
      Exit
    When X_Line_Detail_Tbl(J).List_Line_Type_Code = 'PLL';
    --J = X_Line_Detail_Tbl.Last;
      J   := x_line_detail_tbl.NEXT(J);
    END LOOP;
  end if;
  If I               Is Not Null Then
    P_UNIT_PRICE     := X_LINE_TBL(I).UNIT_PRICE;
    IF J             IS NOT NULL THEN
      P_List_Line_Id := X_Line_Detail_Tbl(J).List_Line_Id;
    ELSE
      P_LIST_LINE_ID := NULL;
      P_UNIT_PRICE   := NULL;
    END IF;
  ELSE
    P_UNIT_PRICE   := NULL;
    P_LIST_LINE_ID := NULL;
  END IF;
End Get_Price;
FUNCTION GET_PRICE_LIST_NAME(P_PRICE_LIST_ID     NUMBER)
     RETURN VARCHAR2
AS
   L_PRICE_LIST_NAME VARCHAR2(240);
BEGIN
   BEGIN
      SELECT DESCRIPTION
        INTO L_PRICE_LIST_NAME
        FROM fnd_lookup_values
       WHERE lookup_type = 'GEAE_MYGE_PRICE_LIST_NAME'
         AND lookup_code = P_PRICE_LIST_ID;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         SELECT NAME
           INTO L_PRICE_LIST_NAME
           FROM qp_list_headers_tl
          WHERE list_header_id = P_PRICE_LIST_ID;
   END;
   RETURN L_PRICE_LIST_NAME;
EXCEPTION
   WHEN OTHERS THEN
      RETURN NULL;
END GET_PRICE_LIST_NAME;
PROCEDURE GET_KIT_STRUCTURE(
    P_SSO       VARCHAR2,
    P_IACO_CODE VARCHAR2,
    P_CUST_ID V_CUST_ID_ARRAY,
    P_ROLE    VARCHAR2,
    P_OU_ID   VARCHAR2,
    P_ITEM_ID NUMBER,
    P_KIT_HDR_DTL OUT V_KIT_HDR_INFO_ARRAY,
    P_KIT_COMP_DTL OUT V_KIT_COMP_INFO_ARRAY,
    P_MSG OUT VARCHAR2
)
AS
   CURSOR C_EXPL(P_ITEM_ID NUMBER) IS
      SELECT msib.segment1 part_number, msib.description part_description, bcb.attribute6 default_value, bet.*
        FROM bom_explosion_temp bet, mtl_system_items_b msib, bom_components_b bcb
       WHERE bet.top_item_id = P_ITEM_ID
         AND bet.component_item_id = msib.inventory_item_id
         AND bet.organization_id = msib.organization_id
         AND bet.component_item_id = bcb.component_item_id(+)
         AND bet.component_sequence_id  = bcb.component_sequence_id(+)
         AND NVL(bcb.disable_date,TRUNC(SYSDATE+1)) >= TRUNC(SYSDATE)
      ORDER BY bet.sort_order;
   l_cfg_hdr_id NUMBER;
   l_part_details V_PART_DETAILS;
   l_part_avail V_PART_AVAIL;
   l_part_price V_PART_PRICE;
   l_part_applicable V_PART_APPLICABLE;
   l_message VARCHAR2(500);
   l_avail_message VARCHAR2(500);
   l_price_message VARCHAR2(500);
   l_kit_ind VARCHAR2(1);
   l_user_id NUMBER;
   l_resp_id NUMBER;
   l_app_id NUMBER;
   l_loc_msg VARCHAR2(100);
   l_config_err VARCHAR2(500);
   l_comp_count NUMBER;
   l_hdr_count NUMBER;
   l_comp_level VARCHAR2(100);
   l_comp_avail NUMBER;
   l_kit_avail NUMBER;
   l_kit_price NUMBER;
   l_unit_price NUMBER;
   l_sum_price NUMBER;
   l_list_line_id NUMBER;
   l_ext_price NUMBER;
   l_kit_message VARCHAR2(500);
   l_kit_pr_er_cd NUMBER;
   l_exploded VARCHAR2(1);
   l_one_indent VARCHAR2(20) := '     ';
   l_indent VARCHAR2(50);
   l_null_avail NUMBER;
   l_price_list_id NUMBER;
   l_config_exists NUMBER;
   e_exit EXCEPTION;
   l_part_discounts V_PART_DISCOUNTS;
   l_discount_message VARCHAR2(100);
   l_critical_part VARCHAR2(10);
   l_part_bom V_PART_BOM; --MYJIRATEST-6272 Ravi S 03-MAR-2015
   l_ISODERABLE VARCHAR2(1);--MYJIRATEST-7138 24-MAR-2015   Abhinav Srivastava Oderable Vs Non Oderable changes
  v_item_source                VARCHAR2(500); -- Added for OWMS Implementation US192483/US192484
  v_er1_source VARCHAR2(500); -- Added for OWMS Implementation US192483/US192484
  v_er2_source VARCHAR2(500); -- Added for OWMS Implementation US192483/US192484
  v_er3_source VARCHAR2(500); -- Added for OWMS Implementation US192483/US192484
  v_item_number                VARCHAR2(30); -- Added for OWMS Implementation US192483/US192484
BEGIN
   l_loc_msg := ' Getting user ID ';
   SELECT USER_ID INTO l_user_id
     FROM FND_USER
    WHERE USER_NAME=P_SSO;
   l_loc_msg := ' Fetching responsibility and application for kit explosion ';
   SELECT RESP.RESPONSIBILITY_ID,RESP.APPLICATION_ID
     INTO l_resp_id,l_app_id
     FROM FND_RESPONSIBILITY_TL RESP,
          FND_LOOKUP_VALUES FLV,
          HR_OPERATING_UNITS HOU
    WHERE HOU.NAME = FLV.MEANING
      AND RESP.RESPONSIBILITY_NAME = FLV.DESCRIPTION
      AND HOU.ORGANIZATION_ID = P_OU_ID
      AND FLV.LOOKUP_TYPE = 'GEAE_MYGE_ORDER_RESPONSIBILITY';
   SELECT COUNT(1)
     INTO l_config_exists
     FROM bom_explosion_temp bet, mtl_system_items_b msib, bom_components_b bcb
    WHERE bet.top_item_id = P_ITEM_ID
      AND bet.component_item_id = msib.inventory_item_id
      AND bet.organization_id = msib.organization_id
      AND bet.component_item_id = bcb.component_item_id(+)
      AND bet.component_sequence_id  = bcb.component_sequence_id(+)
      AND NVL(bcb.disable_date,TRUNC(SYSDATE+1)) >= TRUNC(SYSDATE);
   IF l_config_exists = 0 THEN
      l_loc_msg := ' Calling CREATE_KIT_CONFIG ';
      GEAE_MYGE_CART_PKG.CREATE_KIT_CONFIG(l_user_id,l_app_id,l_resp_id,P_ITEM_ID,1,'N',l_cfg_hdr_id,l_config_err); --MYJIRATEST-3512 Ravi S 18-NOV-2014
      IF l_config_err IS NOT NULL THEN
         P_MSG := 'Error in CREATE_KIT_CONFIG '||l_config_err;
         RAISE e_exit;
      END IF;
   END IF;
   l_loc_msg := ' Initializing Output VARRAYS ';
   l_comp_count := 0;
   l_hdr_count := 0;
   P_KIT_HDR_DTL := V_KIT_HDR_INFO_ARRAY();
   P_KIT_COMP_DTL := V_KIT_COMP_INFO_ARRAY();
   l_exploded := 'N';
   l_loc_msg := ' Calling cursor C_EXPL ';
   FOR r_expl IN C_EXPL(P_ITEM_ID) LOOP
      l_exploded := 'Y';
      IF r_expl.assembly_item_id IS NULL THEN
         l_hdr_count := l_hdr_count + 1;
         P_KIT_HDR_DTL.EXTEND(1);
         l_loc_msg := ' Assignment to P_KIT_HDR_DTL '||l_hdr_count||' ';
         P_KIT_HDR_DTL(l_hdr_count) := V_KIT_HDR_INFO_BO(r_expl.part_number,r_expl.part_description,NULL,NULL,NULL,NULL,r_expl.component_item_id,l_hdr_count);
      ELSE
         l_comp_count := l_comp_count + 1;
         P_KIT_COMP_DTL.EXTEND(1);
         l_loc_msg := ' Assignment to P_KIT_COMP_DTL '||l_comp_count||' ';
         P_KIT_COMP_DTL(l_comp_count) := V_KIT_COMP_INFO_BO(NULL,r_expl.part_number,r_expl.part_description,r_expl.component_quantity,NULL,NULL,NULL,NULL,r_expl.default_value,r_expl.sort_order,r_expl.component_item_id,r_expl.assembly_item_id,r_expl.top_item_id,l_comp_count,r_expl.plan_level,r_expl.bom_item_type);
      END IF;
   END LOOP;
   IF l_exploded = 'N' THEN
      P_MSG := 'The KIT could not be exploded';
      RAISE e_exit;
   END IF;
   l_loc_msg := ' Start logic for COMP_LEVEL ';
   FOR r_level IN (SELECT *
                     FROM TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY))
                    WHERE comp_level IS NULL
                   ORDER BY row_num) LOOP
      IF r_level.assembly_item_id = P_ITEM_ID THEN
         l_loc_msg := ' Assigning COMP_LEVEL for top level ';
         SELECT TO_CHAR(MAX(NVL(TO_NUMBER(comp_level),0))+1)
           INTO l_comp_level
           FROM TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY))
          WHERE assembly_item_id = P_ITEM_ID;
      ELSE
         l_loc_msg := ' Assigning COMP_LEVEL for lower level ';
         SELECT parent.comp_level||'.'||TO_CHAR(MAX(NVL(TO_NUMBER(SUBSTR(child.comp_level,INSTR(child.comp_level,parent.comp_level)+2)),0))+1)
           INTO l_comp_level
           FROM TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY)) parent,
                TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY)) child
          WHERE parent.component_item_id = child.assembly_item_id
            AND child.component_item_id = r_level.component_item_id
         GROUP BY parent.comp_level;
      END IF;
      l_loc_msg := ' Assignment to P_KIT_COMP_DTL '||r_level.row_num||' for comp_level ';
      P_KIT_COMP_DTL(r_level.row_num) := V_KIT_COMP_INFO_BO(l_comp_level,r_level.comp_part_number,r_level.comp_part_desc,r_level.comp_qty,r_level.comp_availability,r_level.comp_unit_price,r_level.comp_ext_price,r_level.customer_code,r_level.default_value,r_level.sort_order,r_level.component_item_id,r_level.assembly_item_id,r_level.top_model_item_id,r_level.row_num,r_level.plan_level,r_level.bom_item_type);
   END LOOP;
   l_loc_msg := ' Start logic for COMP_AVAIL ';
   FOR r_avail IN (SELECT *
                     FROM TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY))
                    WHERE comp_availability IS NULL
                   ORDER BY row_num) LOOP
      IF r_avail.bom_item_type = 2 THEN
         l_comp_avail := NULL; --MYJIRATEST-4654 Ravi S 28-NOV-2014
      ELSE
         l_loc_msg := ' Fetch COMP_AVAIL for '||r_avail.comp_part_number||' ';
--Added by OWMS Team : START
                  BEGIN
                        --
                           v_item_source := NULL;
			   --
			   v_er1_source := GEAE_INV_GET_SOURCE_CODE ('ER1',r_avail.comp_part_number,'Y');
			   v_er2_source := GEAE_INV_GET_SOURCE_CODE ('ER2',r_avail.comp_part_number,'Y');
			   v_er3_source := GEAE_INV_GET_SOURCE_CODE ('ER3',r_avail.comp_part_number,'Y');
			   --
			   IF v_er1_source = 'CPL' OR v_er2_source = 'CPL' OR v_er3_source = 'CPL' THEN
				v_item_source := 'CPL';
			   ELSE
				 v_item_source := 'ERL';
			   END IF;
			   --

                            SELECT NVL(SUM(QTY),0)
                                INTO l_comp_avail
                                FROM (SELECT NVL((A.QTY - B.QTY),0)  QTY
				    FROM (SELECT (geae_wms_total_onhand_erl_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
						geae_wms_total_pick_release(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
						 FROM apps.mtl_system_items_b msib,
						      apps.mtl_parameters mp
						 WHERE 1 = 1
						   and msib.inventory_item_id = r_avail.component_item_id
						   and msib.organization_id = mp.organization_id
						   and mp.organization_code = v_item_source
						   AND v_item_source <> 'CPL') A,
					 (SELECT (geae_wms_resv_qty_fun (msib.inventory_item_id, mp.organization_id,'PACK') +
						geae_wms_total_resv(msib.inventory_item_id, mp.organization_id,'PACK')) QTY
						 FROM apps.mtl_system_items_b msib,
						      apps.mtl_parameters mp
						 WHERE 1 = 1
						   and msib.inventory_item_id = r_avail.component_item_id
						   and msib.organization_id = mp.organization_id
						   and mp.organization_code = v_item_source
						   AND v_item_source <> 'CPL') B
                                      UNION ALL
                                      SELECT (A.QTY - B.QTY)  QTY
                                        FROM (SELECT NVL(SUM(MOQ.TRANSACTION_QUANTITY), 0) QTY
                                                FROM GEAE_INV_MTL_ONHANDS_V MOQ
                                               WHERE INVENTORY_ITEM_ID = r_avail.component_item_id
                                                 AND SUBINVENTORY_CODE IN ('STOCK','STG')
                                                 AND ORGANIZATION_ID IN
                                                     (SELECT ORGANIZATION_ID
                                                        FROM MTL_PARAMETERS
                                                       WHERE ORGANIZATION_CODE = V_ITEM_SOURCE)
                                                  AND v_item_source <> 'ERL'     ) A,
                                             (SELECT NVL(SUM(RESERVATION_QUANTITY), 0) QTY
                                                FROM MTL_RESERVATIONS
                                               WHERE INVENTORY_ITEM_ID = r_avail.component_item_id
                                                 AND ORGANIZATION_ID IN
                                                     (SELECT ORGANIZATION_ID
                                                        FROM MTL_PARAMETERS
                                                       WHERE ORGANIZATION_CODE = V_ITEM_SOURCE)
                                                  AND v_item_source <> 'ERL'     ) B);
                             EXCEPTION
                                WHEN OTHERS THEN
                                               l_comp_avail := 0;
                              END;
--Added by OWMS Team : END
      END IF;
      l_loc_msg := ' Assignment to P_KIT_COMP_DTL '||r_avail.row_num||' for comp_avail ';
      P_KIT_COMP_DTL(r_avail.row_num) := V_KIT_COMP_INFO_BO(r_avail.comp_level,r_avail.comp_part_number,r_avail.comp_part_desc,r_avail.comp_qty,l_comp_avail,r_avail.comp_unit_price,r_avail.comp_ext_price,r_avail.customer_code,r_avail.default_value,r_avail.sort_order,r_avail.component_item_id,r_avail.assembly_item_id,r_avail.top_model_item_id,r_avail.row_num,r_avail.plan_level,r_avail.bom_item_type);
   END LOOP;
   l_loc_msg := ' Logic for KIT_AVAIL ';
   SELECT COUNT(1)
     INTO l_null_avail
     FROM TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY))
    WHERE comp_qty IS NULL;
   IF l_null_avail > 0 THEN
      l_kit_avail := NULL;
   ELSE
      SELECT FLOOR(MIN(NVL(comp_availability,0)/comp_qty))
        INTO l_kit_avail
        FROM TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY))
       WHERE comp_qty IS NOT NULL
         AND bom_item_type <> 2; --MYJIRATEST-4645 Ravi S 27-NOV-2014
   END IF;
   l_loc_msg := ' Assignment to P_KIT_HDR_DTL '||l_hdr_count||' for kit_avail ';
   P_KIT_HDR_DTL(l_hdr_count) := V_KIT_HDR_INFO_BO(P_KIT_HDR_DTL(l_hdr_count).kit_name,P_KIT_HDR_DTL(l_hdr_count).kit_description,l_kit_avail,P_KIT_HDR_DTL(l_hdr_count).kit_message,P_KIT_HDR_DTL(l_hdr_count).customer_code,P_KIT_HDR_DTL(l_hdr_count).kit_price,P_KIT_HDR_DTL(l_hdr_count).kit_item_id,l_hdr_count);
   IF P_ROLE      = 'Global Enquiry' THEN --MYJIRATEST-4645 Ravi S 27-NOV-2014
      l_loc_msg := ' Start logic for Kit Price for Global Enquiry ';
      BEGIN
         SELECT qlht.list_header_id
           INTO l_price_list_id
           FROM qp_list_headers_tl qlht, fnd_lookup_values def_pl
          WHERE def_pl.lookup_code = 'GEAE_MYGE_ITEM_CONFG_DFLT_ORG'
            AND def_pl.enabled_flag = 'Y'
            AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(def_pl.start_date_active,SYSDATE)) AND TRUNC(NVL(def_pl.end_date_active,SYSDATE))
            AND def_pl.meaning = P_OU_ID
            AND def_pl.description = qlht.name;
      EXCEPTION
         WHEN OTHERS THEN
            l_price_list_id := NULL;
      END;
      IF l_price_list_id IS NOT NULL THEN
         l_loc_msg := ' Get KIT price from GET_PRICE proc ';
         GET_PRICE(P_SSO,P_OU_ID,P_ITEM_ID,l_price_list_id,l_kit_price,l_list_line_id);
         l_loc_msg := ' Assignment to P_KIT_HDR_DTL '||l_hdr_count||' for Global Enquiry ';
         P_KIT_HDR_DTL(l_hdr_count) := V_KIT_HDR_INFO_BO(P_KIT_HDR_DTL(l_hdr_count).kit_name,P_KIT_HDR_DTL(l_hdr_count).kit_description,P_KIT_HDR_DTL(l_hdr_count).kit_availability,P_KIT_HDR_DTL(l_hdr_count).kit_message,P_KIT_HDR_DTL(l_hdr_count).customer_code,l_kit_price,P_KIT_HDR_DTL(l_hdr_count).kit_item_id,l_hdr_count);
         l_loc_msg := ' Start logic for COMP_PRICE for Global Enquiry ';
         FOR r_price IN (SELECT *
                           FROM TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY))
                         ORDER BY row_num) LOOP
            l_loc_msg := ' Fetching COMP price for '||r_price.comp_part_number||' ';
            l_unit_price := NULL;
            GET_PRICE(P_SSO,P_OU_ID,r_price.component_item_id,l_price_list_id,l_unit_price,l_list_line_id);
            IF l_unit_price IS NOT NULL THEN
               l_ext_price := l_unit_price*r_price.comp_qty;
            ELSE
               l_ext_price := NULL;
            END IF;
            l_loc_msg := ' Assignment to P_KIT_COMP_DTL '||r_price.row_num||' for Global Enquiry ';
            P_KIT_COMP_DTL(r_price.row_num) := V_KIT_COMP_INFO_BO(r_price.comp_level,r_price.comp_part_number,r_price.comp_part_desc,r_price.comp_qty,r_price.comp_availability,l_unit_price,l_ext_price,r_price.customer_code,r_price.default_value,r_price.sort_order,r_price.component_item_id,r_price.assembly_item_id,r_price.top_model_item_id,r_price.row_num,r_price.plan_level,r_price.bom_item_type);
         END LOOP;
      END IF;
   ELSE
      l_loc_msg := ' Get KIT data from Item Details proc ';
      GET_ITEM_PRICE_AVAIL(P_SSO,P_IACO_CODE,P_CUST_ID,P_ROLE,P_OU_ID,P_ITEM_ID,l_part_details,l_part_avail,l_part_price,l_part_applicable,l_message,l_avail_message,l_price_message,l_kit_ind,l_part_discounts,l_discount_message,l_critical_part,l_part_bom,l_ISODERABLE); --Added l_part_bom MYJIRATEST-6272 Ravi S 03-MAR-2015 and MYJIRATEST-7138 24-MAR-2015   Abhinav Added l_ISODERABLE for Oderable Vs Non Oderable changes
      l_loc_msg := ' Loop for kit part applicable list ';
      FOR r_kit_cc IN 1..l_part_applicable.COUNT LOOP
         l_loc_msg := ' Getting Kit Price ';
         BEGIN
            SELECT unit_price
              INTO l_kit_price
              FROM TABLE(CAST(l_part_price AS V_PART_PRICE))
             WHERE catalog = GET_PRICE_LIST_NAME(l_part_applicable(r_kit_cc).price_list_id)
               AND inventory_item_id = P_ITEM_ID;
         EXCEPTION
            WHEN NO_DATA_FOUND THEN
               l_kit_price := NULL;
         END;
         IF P_KIT_HDR_DTL(l_hdr_count).customer_code IS NOT NULL THEN
            l_hdr_count := l_hdr_count + 1;
            P_KIT_HDR_DTL.EXTEND(1);
            l_loc_msg := ' Assignment to P_KIT_HDR_DTL '||l_hdr_count||' for cust_code '||l_part_applicable(r_kit_cc).cust_code||' ';
            P_KIT_HDR_DTL(l_hdr_count) := V_KIT_HDR_INFO_BO(P_KIT_HDR_DTL(1).kit_name,P_KIT_HDR_DTL(1).kit_description,P_KIT_HDR_DTL(1).kit_availability,P_KIT_HDR_DTL(1).kit_message,l_part_applicable(r_kit_cc).cust_code,l_kit_price,P_KIT_HDR_DTL(1).kit_item_id,l_hdr_count);
         ELSE
            l_loc_msg := ' Assignment to P_KIT_HDR_DTL '||l_hdr_count||' for cust_code '||l_part_applicable(r_kit_cc).cust_code||' ';
            P_KIT_HDR_DTL(l_hdr_count) := V_KIT_HDR_INFO_BO(P_KIT_HDR_DTL(l_hdr_count).kit_name,P_KIT_HDR_DTL(l_hdr_count).kit_description,P_KIT_HDR_DTL(l_hdr_count).kit_availability,P_KIT_HDR_DTL(l_hdr_count).kit_message,l_part_applicable(r_kit_cc).cust_code,l_kit_price,P_KIT_HDR_DTL(l_hdr_count).kit_item_id,l_hdr_count);
         END IF;
         l_loc_msg := ' Start logic for COMP_PRICE ';
         FOR r_price IN (SELECT *
                           FROM TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY))
                         ORDER BY row_num) LOOP
            l_loc_msg := ' Fetching COMP price for '||r_price.comp_part_number||' ';
            l_unit_price := NULL;
            GET_PRICE(P_SSO,P_OU_ID,r_price.component_item_id,l_part_applicable(r_kit_cc).price_list_id,l_unit_price,l_list_line_id);
            IF l_unit_price IS NOT NULL THEN
               l_ext_price := l_unit_price*r_price.comp_qty;
            ELSE
               l_ext_price := NULL;
            END IF;
            IF r_price.customer_code IS NOT NULL THEN
               l_comp_count := l_comp_count + 1;
               P_KIT_COMP_DTL.EXTEND(1);
               l_loc_msg := ' Assignment to P_KIT_COMP_DTL '||l_comp_count||' for cust_code '||l_part_applicable(r_kit_cc).cust_code||' ';
               P_KIT_COMP_DTL(l_comp_count) := V_KIT_COMP_INFO_BO(r_price.comp_level,r_price.comp_part_number,r_price.comp_part_desc,r_price.comp_qty,r_price.comp_availability,l_unit_price,l_ext_price,l_part_applicable(r_kit_cc).cust_code,r_price.default_value,r_price.sort_order,r_price.component_item_id,r_price.assembly_item_id,r_price.top_model_item_id,l_comp_count,r_price.plan_level,r_price.bom_item_type);
            ELSE
               l_loc_msg := ' Assignment to P_KIT_COMP_DTL '||r_price.row_num||' for cust_code '||l_part_applicable(r_kit_cc).cust_code||' ';
               P_KIT_COMP_DTL(r_price.row_num) := V_KIT_COMP_INFO_BO(r_price.comp_level,r_price.comp_part_number,r_price.comp_part_desc,r_price.comp_qty,r_price.comp_availability,l_unit_price,l_ext_price,l_part_applicable(r_kit_cc).cust_code,r_price.default_value,r_price.sort_order,r_price.component_item_id,r_price.assembly_item_id,r_price.top_model_item_id,r_price.row_num,r_price.plan_level,r_price.bom_item_type);
            END IF;
         END LOOP;
      END LOOP;
   END IF;
   l_loc_msg := ' Start logic for Kit price comparison ';
   FOR r_comp_pr IN (SELECT *
                       FROM TABLE(CAST(P_KIT_HDR_DTL AS V_KIT_HDR_INFO_ARRAY))
                     ORDER BY row_num) LOOP
      DBMS_OUTPUT.PUT_LINE('In Kit hdr loop for message');
      IF r_comp_pr.kit_price IS NULL THEN
         l_kit_pr_er_cd := 8041;
      ELSE
         IF r_comp_pr.customer_code IS NOT NULL THEN
            l_loc_msg := ' Getting sum for cust '||r_comp_pr.customer_code||' ';
            SELECT SUM(comp_ext_price)
              INTO l_sum_price
              FROM TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY))
             WHERE customer_code = r_comp_pr.customer_code;
         ELSE --MYJIRATEST-4645 Ravi S 27-NOV-2014
            l_loc_msg := ' Getting sum for null cust ';
            SELECT SUM(comp_ext_price)
              INTO l_sum_price
              FROM TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY))
             WHERE customer_code IS NULL;
         END IF;
         l_loc_msg := ' Setting the kit message when kit price found ';
         IF l_sum_price = r_comp_pr.kit_price THEN
            l_kit_pr_er_cd := NULL;
         ELSE
            l_kit_pr_er_cd := 8042;
         END IF;
      END IF;
      IF l_kit_pr_er_cd IS NOT NULL THEN
         l_kit_message := SUBSTR(GEAE_MYGE_CART_PKG.GET_ERR_MSG(l_kit_pr_er_cd),6);
      ELSE
         l_kit_message := NULL;
      END IF;
      l_loc_msg := ' Assignment to P_KIT_HDR_DTL '||r_comp_pr.row_num||' for kit_message ';
      P_KIT_HDR_DTL(r_comp_pr.row_num) := V_KIT_HDR_INFO_BO(P_KIT_HDR_DTL(r_comp_pr.row_num).kit_name,P_KIT_HDR_DTL(r_comp_pr.row_num).kit_description,P_KIT_HDR_DTL(r_comp_pr.row_num).kit_availability,l_kit_message,P_KIT_HDR_DTL(r_comp_pr.row_num).customer_code,P_KIT_HDR_DTL(r_comp_pr.row_num).kit_price,P_KIT_HDR_DTL(r_comp_pr.row_num).kit_item_id,r_comp_pr.row_num);
   END LOOP;
/*   --MYJIRATEST-4645 Ravi S 27-NOV-2014
   FOR r_indent IN (SELECT comp.*, REGEXP_COUNT(REPLACE(comp.comp_level,'.','#'),'#') point_count
                      FROM TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY)) comp
                      ORDER BY comp.row_num) LOOP
      l_loc_msg := ' Deciding indentation for '||r_indent.comp_part_number||' ';
      l_indent := NULL;
      FOR i IN 1..r_indent.point_count LOOP
         l_indent := l_indent||l_one_indent;
      END LOOP;
      l_loc_msg := ' Doing indentation for '||r_indent.comp_part_number||' by '||r_indent.point_count;
      P_KIT_COMP_DTL(r_indent.row_num) := V_KIT_COMP_INFO_BO(r_indent.comp_level,l_indent||r_indent.comp_part_number,r_indent.comp_part_desc,r_indent.comp_qty,r_indent.comp_availability,r_indent.comp_unit_price,r_indent.comp_ext_price,r_indent.customer_code,r_indent.default_value,r_indent.sort_order,r_indent.component_item_id,r_indent.assembly_item_id,r_indent.top_model_item_id,r_indent.row_num,r_indent.plan_level,r_indent.bom_item_type);
   END LOOP;
   l_loc_msg := ' Start logic for COMP_PRICE ';
   FOR r_price IN (SELECT *
                     FROM TABLE(CAST(P_KIT_COMP_DTL AS V_KIT_COMP_INFO_ARRAY))
                    WHERE customer_code IS NULL
                   ORDER BY row_num) LOOP
      l_loc_msg := ' Get COMP data from Item Details proc '||r_price.comp_part_number||' ';
      GET_ITEM_PRICE_AVAIL(P_SSO,P_IACO_CODE,P_CUST_ID,P_ROLE,P_OU_ID,r_price.component_item_id,l_part_details,l_part_avail,l_part_price,l_part_applicable,l_message,l_avail_message,l_price_message,l_kit_ind);
      l_loc_msg := ' Putting Customer code, price in P_KIT_COMP_DTL ';
      FOR r_comp_cc IN 1..l_part_applicable.COUNT LOOP
         IF l_part_applicable(r_comp_cc).price_list_id IS NOT NULL THEN
            l_loc_msg := ' Fetching COMP price for '||r_price.comp_part_number||' ';
            BEGIN
               SELECT unit_price
                 INTO l_unit_price
                 FROM TABLE(CAST(l_part_price AS V_PART_PRICE))
                WHERE catalog = GET_PRICE_LIST_NAME(l_part_applicable(r_comp_cc).price_list_id)
                  AND inventory_item_id = r_price.component_item_id;
            EXCEPTION
               WHEN NO_DATA_FOUND THEN
                  l_unit_price := NULL;
            END;
            IF l_unit_price IS NOT NULL THEN
               l_ext_price := l_unit_price*r_price.comp_qty;
            ELSE
               l_ext_price := NULL;
            END IF;
         ELSE
            l_unit_price := NULL;
            l_ext_price := NULL;
         END IF;
         IF r_price.customer_code IS NOT NULL THEN
            l_comp_count := l_comp_count + 1;
            P_KIT_COMP_DTL.EXTEND(1);
            l_loc_msg := ' Before assignment to P_KIT_COMP_DTL '||l_comp_count||' for cust_code '||l_part_applicable(r_comp_cc).cust_code||' ';
            P_KIT_COMP_DTL(l_comp_count) := V_KIT_COMP_INFO_BO(r_price.comp_level,r_price.comp_part_number,r_price.comp_part_desc,r_price.comp_qty,r_price.comp_availability,l_unit_price,l_ext_price,l_part_applicable(r_comp_cc).cust_code,r_price.default_value,r_price.sort_order,r_price.component_item_id,r_price.assembly_item_id,r_price.top_model_item_id,l_comp_count);
            l_loc_msg := ' After assignment to P_KIT_COMP_DTL '||l_comp_count||' for cust_code '||l_part_applicable(r_comp_cc).cust_code||' ';
         ELSE
            l_loc_msg := ' Before assignment to P_KIT_COMP_DTL '||r_price.row_num||' for cust_code '||l_part_applicable(r_comp_cc).cust_code||' ';
            P_KIT_COMP_DTL(r_price.row_num) := V_KIT_COMP_INFO_BO(r_price.comp_level,r_price.comp_part_number,r_price.comp_part_desc,r_price.comp_qty,r_price.comp_availability,l_unit_price,l_ext_price,l_part_applicable(r_comp_cc).cust_code,r_price.default_value,r_price.sort_order,r_price.component_item_id,r_price.assembly_item_id,r_price.top_model_item_id,r_price.row_num);
            l_loc_msg := ' After assignment to P_KIT_COMP_DTL '||r_price.row_num||' for cust_code '||l_part_applicable(r_comp_cc).cust_code||' ';
         END IF;
      END LOOP;
   END LOOP;
   */
EXCEPTION
   WHEN e_exit THEN
      NULL;
   WHEN OTHERS THEN
      P_MSG := 'Oracle Error while '|| l_loc_msg ||SUBSTR(SQLERRM,1,100);
END GET_KIT_STRUCTURE;
--Ankita S MYJIRATEST-8466 on 02-JUN-2015
PROCEDURE ITEM_DTL_PART_NUM(
    P_SSO       VARCHAR2,
    P_IACO_CODE VARCHAR2,
    P_CUST_ID V_CUST_ID_ARRAY,
    P_ROLE    VARCHAR2,
    P_OU_ID   VARCHAR2,
    P_PART_NUM VARCHAR2,
    P_PART_DETAILS OUT V_PART_DETAILS,
    P_PART_AVAIL OUT V_PART_AVAIL,
    P_PART_PRICE OUT V_PART_PRICE,
    P_PART_APPLICABLE OUT V_PART_APPLICABLE,
    P_MESSAGE OUT VARCHAR2,
    P_AVAIL_MESSAGE OUT VARCHAR2,
    P_PRICE_MESSAGE OUT VARCHAR2,
    P_KIT_IND         OUT VARCHAR2,
    P_PART_DISCOUNTS  OUT V_PART_DISCOUNTS,
    P_DISC_MESSAGE    OUT VARCHAR2,
    P_CRITICAL_PART   OUT VARCHAR2,
    P_PART_BOM        OUT V_PART_BOM, --MYJIRATEST-6272 Ravi S 03-MAR-2015
    P_ISODERABLE      OUT VARCHAR2  --MYJIRATEST-7138 24-MAR-2015   Abhinav  Oderable Vs Non Oderable changes
    )
AS
l_inventory_item_id   NUMBER;
BEGIN
 /*   P_PART_DETAILS    := V_PART_DETAILS();
    P_PART_AVAIL      := V_PART_AVAIL();
    P_PART_PRICE      := V_PART_PRICE();
    P_PART_APPLICABLE := V_PART_APPLICABLE();
    P_PART_DISCOUNTS  := V_PART_DISCOUNTS();
    P_PART_BOM        := V_PART_BOM();*/
   BEGIN
    SELECT INVENTORY_ITEM_ID
      INTO l_inventory_item_id
      FROM mtl_system_items_b
     WHERE SEGMENT1=P_PART_NUM
       AND rownum=1;
   EXCEPTION
     WHEN NO_DATA_FOUND THEN
       SELECT LOOKUP_CODE
       || ': '
       || DESCRIPTION
       INTO p_message
       FROM fnd_lookup_values
       WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
       AND UPPER(LOOKUP_CODE) = UPPER('8033');
     goto end_proc;
   END;
  --Calling GET_ITEM_PRICE_AVAIL
  apps.GEAE_MYGE_ITEM_DTL_PKG.GET_ITEM_PRICE_AVAIL(P_SSO,
                                                   P_IACO_CODE,
                                                   P_CUST_ID,
                                                   P_ROLE,
                                                   P_OU_ID,
                                                   l_inventory_item_id,
                                                   P_PART_DETAILS,
                                                   P_PART_AVAIL,
                                                   P_PART_PRICE,
                                                   P_PART_APPLICABLE,
                                                   P_MESSAGE,
                                                   P_AVAIL_MESSAGE,
                                                   P_PRICE_MESSAGE,
                                                   P_KIT_IND,
                                                   P_PART_DISCOUNTS,
                                                   P_DISC_MESSAGE,
                                                   P_CRITICAL_PART,
                                                   P_PART_BOM,
                                                   P_ISODERABLE);
  <<end_proc>>
  NULL;
END ITEM_DTL_PART_NUM;
--Neelima Y MYJIRATEST-9104 on 18-AUG-2015
PROCEDURE ITEM_DTL_PART_NUM_BULK( P_SSO               VARCHAR2,
                                  P_IACO_CODE         VARCHAR2,
                                  P_CUST_ID           V_CUST_ID_ARRAY,
                                  P_ROLE              VARCHAR2,
                                  P_OU_ID             VARCHAR2,
                                  P_PART_NUM          V_PART_NUM_LIST_ARRAY,
                                  P_BULK_PART_DETAILS OUT V_BULK_PART_DETAILS,
                                  P_MESSAGE           OUT VARCHAR2
                                 )
  AS
  V_INVENTORY_ITEM_ID     NUMBER;
  V_EXIST                 VARCHAR2(1);
  V_MESSAGE               VARCHAR2(2000);
  V_QTY_TOTAL             NUMBER;
  V_INV_ITEM_ID           NUMBER;
  V_PRT_DESC              VARCHAR2(100);
  P_MSG                   VARCHAR2(1000);
  P_AVAIL_MESSAGE         VARCHAR2(1000);
  P_PRICE_MESSAGE         VARCHAR2(1000);
  P_DISC_MESSAGE          VARCHAR2(1000);
  P_CRITICAL_PART         VARCHAR2(1000);
  P_ISODERABLE            VARCHAR2(1000);
  P_KIT_IND               VARCHAR2(1000);
  V_UNIT_PRICE            VARCHAR2(1000);
  V_UPQ                   VARCHAR2(1000);
  V_LEAD_TIME             VARCHAR2(1000);
  V_DISC_PERCENT          NUMBER;
  V_DISC_PRICE            NUMBER;
  P_PART_DETAILS     V_PART_DETAILS    := V_PART_DETAILS();
  P_PART_AVAIL       V_PART_AVAIL      := V_PART_AVAIL();
  P_PART_PRICE       V_PART_PRICE      := V_PART_PRICE();
  P_PART_APPLICABLE  V_PART_APPLICABLE := V_PART_APPLICABLE();
  P_PART_DISCOUNTS   V_PART_DISCOUNTS  := V_PART_DISCOUNTS();
  P_PART_BOM         V_PART_BOM        := V_PART_BOM();
BEGIN
  P_MESSAGE :=NULL;
  P_BULK_PART_DETAILS :=V_BULK_PART_DETAILS();
  IF P_PART_NUM.COUNT =0 THEN
    P_MESSAGE := 'No Part Num. is passed';
    goto end_proc;
  END IF;
   FOR J in 1..P_PART_NUM.COUNT
   LOOP
      V_QTY_TOTAL      := 0;
      V_UNIT_PRICE     := NULL;
      V_UPQ            := NULL;
      V_LEAD_TIME      := NULL;
      V_DISC_PERCENT   := NULL;
      V_INV_ITEM_ID    := NULL;
      V_PRT_DESC       := NULL;
    --  V_DISC_PRICE     := NULL;
     BEGIN
        V_EXIST :='Y';
       SELECT INVENTORY_ITEM_ID
         INTO V_INVENTORY_ITEM_ID
         FROM MTL_SYSTEM_ITEMS_B
        WHERE SEGMENT1=P_PART_NUM(J)
          AND ROWNUM=1;
     EXCEPTION
       WHEN NO_DATA_FOUND THEN
         SELECT LOOKUP_CODE
         || ': '
         || DESCRIPTION
         ||'~'||P_PART_NUM(J)
         INTO V_MESSAGE
         FROM FND_LOOKUP_VALUES
         WHERE LOOKUP_TYPE      = 'GEAE_MYGE_ERROR_CODES'
         AND UPPER(LOOKUP_CODE) = UPPER('8033');
         V_EXIST :='N';
     END;
    IF V_EXIST ='Y' THEN
     --Calling GET_ITEM_PRICE_AVAIL
     apps.GEAE_MYGE_ITEM_DTL_PKG.GET_ITEM_PRICE_AVAIL(P_SSO,
                                                      P_IACO_CODE,
                                                      P_CUST_ID,
                                                      P_ROLE,
                                                      P_OU_ID,
                                                      V_INVENTORY_ITEM_ID,
                                                      P_PART_DETAILS ,
                                                      P_PART_AVAIL ,
                                                      P_PART_PRICE ,
                                                      P_PART_APPLICABLE ,
                                                      P_MSG ,
                                                      P_AVAIL_MESSAGE ,
                                                      P_PRICE_MESSAGE ,
                                                      P_KIT_IND ,
                                                      P_PART_DISCOUNTS ,
                                                      P_DISC_MESSAGE ,
                                                      P_CRITICAL_PART ,
                                                      P_PART_BOM ,
                                                      P_ISODERABLE );
     IF  P_PART_DETAILS.COUNT > 0 THEN
       V_INVENTORY_ITEM_ID := P_PART_DETAILS(1).INVENTORY_ITEM_ID;
       V_PRT_DESC          := P_PART_DETAILS(1).PART_DESCRIPTION;
     END IF;

/**************************************************
US267084: The on hand quantity is not displayed correctly on Part bulk search screen . Because of the recent change
the part_avail count is 1. So modifying the below condition to check the count >0
******************************************************/
  --   IF P_PART_AVAIL.COUNT > 1 THEN
       IF P_PART_AVAIL.COUNT > 0 THEN   ---US267084
       FOR i IN 1 ..P_PART_AVAIL.COUNT
       LOOP
         V_QTY_TOTAL := V_QTY_TOTAL + P_PART_AVAIL(i).QUANTITY ;
       END LOOP;

/*Added the below code, to show quantity = 0 of critical parts for external users */
        IF P_CRITICAL_PART ='Y' and P_ROLE <> 'Global Enquiry' THEN
            V_QTY_TOTAL := 0;
        END IF;

     END IF;
     IF P_PART_PRICE.COUNT > 1 THEN
       P_PART_PRICE.DELETE;
       P_PRICE_MESSAGE := 'Price_Msg_02:';
       P_PRICE_MESSAGE :=P_PRICE_MESSAGE||'Please click on Part No. for complete information';
     ELSIF P_PART_PRICE.COUNT =1 THEN
       V_UNIT_PRICE := P_PART_PRICE(1).UNIT_PRICE;
       V_UPQ        := P_PART_PRICE(1).UPQ;
       V_LEAD_TIME  := P_PART_PRICE(1).LEAD_TIME;
     ELSE
       V_UNIT_PRICE := NULL;
       V_UPQ        := NULL;
       V_LEAD_TIME  := NULL;
     END IF;
     IF P_PART_DISCOUNTS.COUNT > 0 THEN
       IF P_PART_DISCOUNTS.COUNT > 1 THEN
         IF P_CUST_ID.COUNT > 0 THEN
            FOR VAR IN 1 .. P_CUST_ID.COUNT
               LOOP
               P_DISC_MESSAGE := GEAE_MYGE_CART_PKG.GET_ERR_MSG(8202)||'~'||P_CUST_ID(VAR);
             END LOOP;
          END IF;
         P_PART_DISCOUNTS.DELETE;
         V_DISC_PERCENT := NULL;
       --  V_DISC_PRICE   := NULL;
       ELSE
         V_DISC_PERCENT := P_PART_DISCOUNTS(1).DISC_PERCENT;
        -- V_DISC_PRICE   := P_PART_DISCOUNTS(1).DISC_PRICE;
       END IF;
     ELSE
       V_DISC_PERCENT := NULL;
      -- V_DISC_PRICE   := NULL;
     END IF;
     P_BULK_PART_DETAILS.EXTEND();
     P_BULK_PART_DETAILS(J):=   V_BULK_PART_DETAILS_LIST_BO(V_INVENTORY_ITEM_ID ,
                                                            P_PART_NUM(J) ,
                                                            V_PRT_DESC ,
                                                            V_QTY_TOTAL ,
                                                            V_UNIT_PRICE ,
                                                            V_UPQ ,
                                                            V_LEAD_TIME ,
                                                            V_DISC_PERCENT ,
                                                          --  V_DISC_PRICE ,
                                                            P_MSG ,
                                                            P_AVAIL_MESSAGE ,
                                                            P_PRICE_MESSAGE ,
                                                            P_DISC_MESSAGE ,
                                                            P_CRITICAL_PART
                                                           );
     ELSE
       P_BULK_PART_DETAILS.EXTEND();
        P_BULK_PART_DETAILS(J):= V_BULK_PART_DETAILS_LIST_BO('' ,
                                                             P_PART_NUM(J) ,
                                                             '' ,
                                                             '' ,
                                                             '' ,
                                                             '' ,
                                                             '' ,
                                                             '' ,
                                                           --  '' ,
                                                             '' ,
                                                             '' ,
                                                             '' ,
                                                             '' ,
                                                             ''
                                                            );
    END IF;
   END LOOP;
  <<end_proc>>
  NULL;
EXCEPTION
   WHEN OTHERS THEN
      P_MESSAGE := '8000:'||SUBSTR(SQLERRM,1,100);
END ITEM_DTL_PART_NUM_BULK;

END GEAE_MYGE_ITEM_DTL_PKG;