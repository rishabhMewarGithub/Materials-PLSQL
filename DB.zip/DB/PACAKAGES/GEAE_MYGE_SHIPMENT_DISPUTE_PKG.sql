


GEAE_MYGE_SHIPMENT_DISPUTE_PKG

create or replace PACKAGE BODY "GEAE_MYGE_SHIPMENT_DISPUTE_PKG" AS

/*********************************************************************************************************************************
Project: myGE Aviation
Application: This package will be used to create Dispute Orders through myGE Aviation portal
Created by: Ravi Saxena
=================================================Change Log=======================================================================
 Date        | Changed by          | Description
==================================================================================================================================
18-NOV-2014  | Ravi Saxena         | MYJIRATEST-4507: Include Order header ID in CREATE_DISPUTE_ORDER response
18-NOV-2014  | Ravi Saxena         | MYJIRATEST-4532: Consider all quantity as dicrepant quantity
20-NOV-2014  | Ravi Saxena         | MYJIRATEST-4580: Removed Reference to Original order in Discrepancy (Ovarage Return Line)
21-NOV-2014  | Ravi Saxena         | MYJIRATEST-4591: Returns should be always to ER warehouses
21-NOV-2014  | Ravi Saxena         | Added Procedure GET_LABEL_INFORMATION
28-NOV-2014  | Ravi Saxena         | MYJIRATEST-4646: Order Value
28-NOV-2014  | Ravi Saxena         | For getting value of return for unknown part, use a hierarchy logic (GEAE_MYGE_OU_PRICE_HIERARCHY)
15-DEC-2014  | Ravi Saxena         | MYJIRATEST-4786: Buyback orders should not be booked
15-DEC-2014  | Ravi Saxena         | MYJIRATEST-4806: Assign error codes of dispute order creation booking
10-FEB-2015  | Ravi Saxena         | MYJIRATEST-5845: Make Order Source configurable by OU ID
11-FEB-2015  | Ravi Saxena         | MYJIRATEST-4756: Fetch COO for Kits from KIT components
28-NOV-2018  | Manisha K           | US230170: Modified proc GET_LABEL_INFORMATION and CREATE_DIPSUTE_ORDER;
                                    Passport Customers should be able to Dispute the Passport Orders

*********************************************************************************************************************************/

g_calc_price     VARCHAR2(1);
--g_partial_price  VARCHAR2(1);
g_freeze_price   VARCHAR2(1);


PROCEDURE CREATE_DISPUTE_ORDER  (
                                --Standard Parameters
                                P_SSO           VARCHAR2,
                                P_IACO_CODE     VARCHAR2,
                                P_CUST_ID       V_CUST_ID_ARRAY,
                                P_ROLE          VARCHAR2,
                                P_OU_ID         VARCHAR2,
                                --Input Parameters
                                P_ORIG_ORDER_ID NUMBER,
                                P_ORIG_LINE_ID  NUMBER,
                                P_DISPUTE       VARCHAR2,
                                P_SND_ATT_SLLST VARCHAR2,
                                P_SND_ATT_RCLST VARCHAR2,
                                P_SND_ATT_FNAME VARCHAR2,
                                P_SND_ATT_FILE  BLOB,
                                P_DD_PN_RCVD    VARCHAR2,
                                P_DD_QTY_RCVD   NUMBER,
                                P_REPLACE       VARCHAR2,
                                P_UD_QTY_RCVD   NUMBER,
                                P_OD_QTY_RCVD   NUMBER,
                                P_BB_REQ_BY     VARCHAR2,
                                P_BB_QTY        NUMBER,
                                P_PE_EXP_PRICE  NUMBER,
                                P_ATT_COMMENTS  VARCHAR2,
                                --Output Parameters
                                P_ORDER_NUMBER  OUT NUMBER,
                                P_ORDER_TYPE    OUT VARCHAR2,
                                P_MSG           OUT VARCHAR2,
                                P_STATUS        OUT VARCHAR2,
                                P_ORIG_PO_NUM   OUT VARCHAR2,
                                P_ORIG_PO_LNUM  OUT VARCHAR2,
                                P_ORDER_VALUE   OUT NUMBER,
                                P_ORDER_ID      OUT NUMBER --MYJIRATEST-4507 Ravi S 18-NOV-2014
                                )
AS
   l_api_version_number NUMBER := 1.0;
   l_return_status VARCHAR2(2000);
   l_msg_count NUMBER;
   l_msg_data VARCHAR2(2000);
   -- PARAMETERS
   l_debug_level number := 5; -- OM DEBUG LEVEL (MAX 5)
   -- INPUT VARIABLES FOR PROCESS_ORDER API
   l_header_rec oe_order_pub.header_rec_type;
   l_line_tbl oe_order_pub.line_tbl_type;
   l_action_request_tbl oe_order_pub.Request_Tbl_Type;
   -- OUT VARIABLES FOR PROCESS_ORDER API
   l_header_rec_out oe_order_pub.header_rec_type;
   l_header_val_rec_out oe_order_pub.header_val_rec_type;
   l_header_adj_tbl_out oe_order_pub.header_adj_tbl_type;
   l_header_adj_val_tbl_out oe_order_pub.header_adj_val_tbl_type;
   l_header_price_att_tbl_out oe_order_pub.header_price_att_tbl_type;
   l_header_adj_att_tbl_out oe_order_pub.header_adj_att_tbl_type;
   l_header_adj_assoc_tbl_out oe_order_pub.header_adj_assoc_tbl_type;
   l_header_scredit_tbl_out oe_order_pub.header_scredit_tbl_type;
   l_header_scredit_val_tbl_out oe_order_pub.header_scredit_val_tbl_type;
   l_line_tbl_out oe_order_pub.line_tbl_type;
   l_line_val_tbl_out oe_order_pub.line_val_tbl_type;
   l_line_adj_tbl_out oe_order_pub.line_adj_tbl_type;
   l_line_adj_val_tbl_out oe_order_pub.line_adj_val_tbl_type;
   l_line_price_att_tbl_out oe_order_pub.line_price_att_tbl_type;
   l_line_adj_att_tbl_out oe_order_pub.line_adj_att_tbl_type;
   l_line_adj_assoc_tbl_out oe_order_pub.line_adj_assoc_tbl_type;
   l_line_scredit_tbl_out oe_order_pub.line_scredit_tbl_type;
   l_line_scredit_val_tbl_out oe_order_pub.line_scredit_val_tbl_type;
   l_lot_serial_tbl_out oe_order_pub.lot_serial_tbl_type;
   l_lot_serial_val_tbl_out oe_order_pub.lot_serial_val_tbl_type;
   l_action_request_tbl_out oe_order_pub.request_tbl_type;
   l_msg_index NUMBER;
   l_data VARCHAR2(2000);
   l_debug_file VARCHAR2(200);
   l_authorized VARCHAR2(1);
   l_cust_id NUMBER;
   l_item_id NUMBER;
   l_disp_price NUMBER;
   l_disp_list_id NUMBER;
   l_dispute_value NUMBER;
   l_dispute_type VARCHAR2(50);
   l_scrap_limit NUMBER;
   l_booked_flag VARCHAR2(1);
   --l_order_success VARCHAR2(1);
   V_RESP_ID FND_RESPONSIBILITY_TL.RESPONSIBILITY_ID%TYPE;
   V_APP_ID FND_RESPONSIBILITY_TL.APPLICATION_ID%TYPE;
   V_USER_ID FND_USER.USER_ID%TYPE;
   v_OU_ID                 VARCHAR2(20);  --11-NOV US230170; Manisha K Added to save the OU_ID

   CURSOR c_price_hierarchy(P_OU_ID IN VARCHAR2) IS
      SELECT qlht.list_header_id, TO_NUMBER(SUBSTR(def_pl.lookup_code,INSTR(def_pl.lookup_code,'-')+1)) hierarchy
        FROM qp_list_headers_tl qlht, fnd_lookup_values def_pl
       WHERE def_pl.lookup_type = 'GEAE_MYGE_OU_PRICE_HIERARCHY'
         AND def_pl.enabled_flag = 'Y'
         AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(def_pl.start_date_active,SYSDATE)) AND TRUNC(NVL(def_pl.end_date_active,SYSDATE))
         AND SUBSTR(def_pl.lookup_code,1,INSTR(def_pl.lookup_code,'-')-1) = P_OU_ID
         AND def_pl.description = qlht.name
      ORDER BY TO_NUMBER(SUBSTR(def_pl.lookup_code,INSTR(def_pl.lookup_code,'-')+1));

BEGIN

/********************************************************
  US230170; Manisha K. 11-NOV-2018 Passport Requirements. Two OU_ID will be passed for input parameter P_OU_ID
  Added below code to find OU_ID using header_id
  ********************************************************/

 IF P_OU_ID like '%~%' THEN
      BEGIN
      SELECT ooh.org_Id
      INTO v_OU_ID
      FROM oe_order_headers_all ooh, oe_order_lines_all ool
      WHERE ooh.header_id = ool.header_id
      AND ool.header_id = P_ORIG_ORDER_ID
      AND ool.line_id = P_ORIG_LINE_ID;
      EXCEPTION
      WHEN OTHERS THEN
      P_MSG := 'Error while fetching the OU_ID: '||SQLCODE||SQLERRM;
      GOTO end_proc;
      END;
  ELSE
    v_OU_ID := P_OU_ID;
  END IF;

   IF v_ou_id IS NULL THEN
      P_MSG := GET_ERR_MSG(8503);
         GOTO end_proc;

    END IF;

   -- INITIALIZATION REQUIRED FOR R12
   mo_global.set_policy_context ('S', v_OU_ID);
   mo_global.init('ONT');
   -- INITIALIZE DEBUG INFO
   IF (l_debug_level > 0) THEN
      l_debug_file := OE_DEBUG_PUB.Set_Debug_Mode('FILE');
      oe_debug_pub.initialize;
      oe_debug_pub.setdebuglevel(l_debug_level);
      Oe_Msg_Pub.initialize;
   END IF;
   -- FETCH RESPONSIBILITY AND APPLICATION ID BASED OU
   BEGIN
      SELECT RESP.RESPONSIBILITY_ID,RESP.APPLICATION_ID
        INTO V_RESP_ID,V_APP_ID
        FROM FND_RESPONSIBILITY_TL RESP,
             FND_LOOKUP_VALUES FLV ,
             HR_OPERATING_UNITS HOU
       WHERE HOU.NAME = FLV.MEANING
         AND RESP.RESPONSIBILITY_NAME = FLV.DESCRIPTION
         AND HOU.ORGANIZATION_ID = v_OU_ID --P_OU_ID
         AND FLV.LOOKUP_TYPE = 'GEAE_MYGE_ORDER_RESPONSIBILITY';
   EXCEPTION
      WHEN no_data_found THEN
         P_MSG := GET_ERR_MSG(8026);
         GOTO end_proc;
   END;
   -- FETCH USER ID
   BEGIN
      SELECT USER_ID
        INTO V_USER_ID
        FROM FND_USER
       WHERE USER_NAME=P_SSO;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         P_MSG := GET_ERR_MSG(8004);
         GOTO end_proc;
   END;
   -- CHECK IF LINE EXISTS AND AUTHORIZATION
   BEGIN
      SELECT ooh.cust_po_number, ool.customer_line_number, ool.sold_to_org_id
        INTO P_ORIG_PO_NUM, P_ORIG_PO_LNUM, l_cust_id
        FROM oe_order_headers_all ooh, oe_order_lines_all ool
       WHERE ooh.header_id = ool.header_id
         AND ool.header_id = P_ORIG_ORDER_ID
         AND ool.line_id = P_ORIG_LINE_ID;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         P_MSG := GET_ERR_MSG(8011);
         GOTO end_proc;
   END;
   l_authorized := 'N';
   FOR i IN 1..P_CUST_ID.COUNT LOOP
      IF P_CUST_ID(i) = l_cust_id THEN
         l_authorized := 'Y';
      END IF;
   END LOOP;
   IF l_authorized = 'N' THEN
      p_MSG:=GET_ERR_MSG(8180);
      goto end_proc;
   END IF;
   BEGIN
      SELECT description
        INTO l_scrap_limit
        FROM fnd_lookup_values
       WHERE lookup_type = 'GEAE_MYGE_DISPUTE_SCRAP_LIMIT'
         AND lookup_code = v_OU_ID ; --P_OU_ID;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         P_MSG := GET_ERR_MSG(8061);
         GOTO end_proc;
   END;
   -- INITIALIZE ENVIRONMENT
   fnd_global.apps_initialize (user_id => V_USER_ID,
                               resp_id => V_RESP_ID,
                               resp_appl_id => V_APP_ID);
   --l_order_success := 'N';
   --FOR i IN 1..10 LOOP
   -- INITIALIZE ACTION REQUEST RECORD
   l_action_request_tbl(1) := OE_ORDER_PUB.G_MISS_REQUEST_REC;
   IF P_DISPUTE <> 'Buyback' THEN --MYJIRATEST-4786 Ravi S 15-DEC-2014
      l_action_request_tbl(1).request_type := oe_globals.g_book_order;
   END IF;
   l_action_request_tbl(1).entity_code := oe_globals.g_entity_header;
   l_action_request_tbl(1).entity_index := 1;
   BEGIN
      SELECT lookup_code
        INTO g_calc_price
        FROM fnd_lookup_values
       WHERE lookup_type = 'CALCULATE_PRICE_FLAG'
         AND meaning = 'Calculate Price'
         AND enabled_flag = 'Y'
         AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(start_date_active,SYSDATE)) AND TRUNC(NVL(end_date_active,SYSDATE));
   EXCEPTION
      WHEN OTHERS THEN
         P_MSG := '8300:Calculate price flag could not be determined';
         GOTO end_proc;
   END;
/*   BEGIN
      SELECT lookup_code
        INTO g_partial_price
        FROM fnd_lookup_values
       WHERE lookup_type = 'CALCULATE_PRICE_FLAG'
         AND meaning = 'Partial Price'
         AND enabled_flag = 'Y'
         AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(start_date_active,SYSDATE)) AND TRUNC(NVL(end_date_active,SYSDATE));
   EXCEPTION
      WHEN OTHERS THEN
         P_MSG := 'Partial Price flag could not be determined';
         GOTO end_proc;
   END;*/
   BEGIN
      SELECT lookup_code
        INTO g_freeze_price
        FROM fnd_lookup_values
       WHERE lookup_type = 'CALCULATE_PRICE_FLAG'
         AND meaning = 'Freeze Price'
         AND enabled_flag = 'Y'
         AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(start_date_active,SYSDATE)) AND TRUNC(NVL(end_date_active,SYSDATE));
   EXCEPTION
      WHEN OTHERS THEN
         P_MSG := '8300:Freeze Price flag could not be determined';
         GOTO end_proc;
   END;
   -- LOAD HEADER RECORD AND LINE TABLE
   IF P_DISPUTE = 'Serial Number Dispute' THEN
      IF P_SND_ATT_SLLST IS NOT NULL AND P_SND_ATT_RCLST IS NOT NULL AND P_SND_ATT_FILE IS NOT NULL AND P_SND_ATT_FNAME IS NOT NULL THEN
         LOAD_SERIAL_DISPUTE_OBJ(v_OU_ID,P_ORIG_ORDER_ID,P_ORIG_LINE_ID,l_header_rec,l_line_tbl,l_return_status);
      ELSE
         l_return_status := GET_ERR_MSG(8062);
      END IF;
   ELSIF P_DISPUTE = 'Discrepancy Dispute' THEN
      IF P_DD_QTY_RCVD IS NULL THEN
         P_MSG := GET_ERR_MSG(8029);
         goto end_proc;
      END IF;
      -- GETTING ITEM_ID
      BEGIN
         SELECT msib.inventory_item_id
           INTO l_item_id
           FROM mtl_system_items_b msib, mtl_parameters mp
          WHERE msib.organization_id = mp.organization_id
            AND mp.organization_code = 'CVO'
            AND msib.segment1 = P_DD_PN_RCVD;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            p_MSG := GET_ERR_MSG(8033);
            goto end_proc;
      END;
      -- DECIDING LINE TYPE FOR OVERAGE
      FOR r_price_hierarchy IN c_price_hierarchy(v_OU_ID) LOOP
         GEAE_MYGE_ITEM_DTL_PKG.GET_PRICE(P_SSO,v_OU_ID,l_item_id,r_price_hierarchy.list_header_id,l_disp_price,l_disp_list_id);
         IF l_disp_price IS NOT NULL THEN
            EXIT;
         END IF;
      END LOOP;
      IF l_disp_price IS NOT NULL THEN
         l_dispute_value := l_disp_price*P_DD_QTY_RCVD;
      ELSE
         l_dispute_value := NULL;
      END IF;
      IF l_dispute_value IS NULL THEN
         p_MSG := GET_ERR_MSG(8034);
         goto end_proc;
      END IF;
      IF l_dispute_value > l_scrap_limit THEN
         l_dispute_type := '-OVERAGE RETURN';
         P_ORDER_TYPE := 'OVERAGE RETURN';
      ELSE
         l_dispute_type := '-OVERAGE SCRAP';
         P_ORDER_TYPE := 'OVERAGE SCRAP';
      END IF;
      IF P_DD_QTY_RCVD IS NOT NULL THEN
         LOAD_DISCREPANCY_OBJ(v_OU_ID,P_ORIG_ORDER_ID,P_ORIG_LINE_ID,l_item_id,P_DD_QTY_RCVD,l_dispute_type,P_REPLACE,l_header_rec,l_line_tbl,l_return_status);
      ELSE
         l_return_status := GET_ERR_MSG(8029);
      END IF;
   ELSIF P_DISPUTE = 'Under Shipment' THEN
      IF P_UD_QTY_RCVD IS NOT NULL THEN
         LOAD_SHORTAGE_OBJ(v_OU_ID,P_ORIG_ORDER_ID,P_ORIG_LINE_ID,P_UD_QTY_RCVD,P_REPLACE,l_header_rec,l_line_tbl,l_return_status);
      ELSE
         l_return_status := GET_ERR_MSG(8029);
      END IF;
   ELSIF P_DISPUTE = 'Overage Dispute' THEN
      IF P_OD_QTY_RCVD IS NULL THEN
         P_MSG := GET_ERR_MSG(8029);
         goto end_proc;
      END IF;
      -- DECIDING LINE TYPE FOR OVERAGE
      SELECT unit_selling_price*P_OD_QTY_RCVD
        INTO l_dispute_value
        FROM oe_order_lines_all
       WHERE line_id = P_ORIG_LINE_ID;
      IF l_dispute_value IS NULL THEN
         p_MSG := GET_ERR_MSG(8034);
         goto end_proc;
      END IF;
      IF l_dispute_value > l_scrap_limit THEN
         l_dispute_type := '-OVERAGE RETURN';
         P_ORDER_TYPE := 'OVERAGE RETURN';
      ELSE
         l_dispute_type := '-OVERAGE SCRAP';
         P_ORDER_TYPE := 'OVERAGE SCRAP';
      END IF;
      IF P_OD_QTY_RCVD IS NOT NULL THEN
         LOAD_OVRG_RET_OBJ(v_OU_ID,P_ORIG_ORDER_ID,P_ORIG_LINE_ID,P_OD_QTY_RCVD,l_dispute_type,l_header_rec,l_line_tbl,l_return_status);
      ELSE
         l_return_status := GET_ERR_MSG(8029);
      END IF;
   ELSIF P_DISPUTE = 'Buyback' THEN
      IF P_BB_QTY IS NOT NULL THEN
         LOAD_BUYBACK_OBJ(v_OU_ID,P_ORIG_ORDER_ID,P_ORIG_LINE_ID,P_BB_QTY,l_header_rec,l_line_tbl,l_return_status);
      ELSE
         l_return_status := GET_ERR_MSG(8029);
      END IF;
   ELSIF P_DISPUTE = 'Pricing Error' THEN
      LOAD_PRICING_ERR_OBJ(v_OU_ID,P_ORIG_ORDER_ID,P_ORIG_LINE_ID,P_PE_EXP_PRICE,l_header_rec,l_line_tbl,l_return_status);
   ELSE
      l_return_status := GET_ERR_MSG(8029);
   END IF;
   IF l_return_status IS NOT NULL THEN
      P_MSG := l_return_status;
      GOTO end_proc;
   END IF;
   DBMS_OUTPUT.PUT_LINE('Before Process Order');
   DBMS_OUTPUT.PUT_LINE('Order type: '||l_header_rec.order_type_id);
   FOR i IN 1..l_line_tbl.COUNT LOOP
      DBMS_OUTPUT.PUT_LINE('Line type: '||l_line_tbl(i).line_type_id);
   END LOOP;
   DBMS_OUTPUT.PUT_LINE('Salesrep: '||l_header_rec.salesrep_id);
   -- CALL PROCESS ORDER API
   oe_order_pub.process_order(
                            --  p_org_id => P_OU_ID,
                              p_api_version_number => l_api_version_number,
                              p_header_rec => l_header_rec,
                              p_line_tbl => l_line_tbl,
                              p_action_request_tbl => l_action_request_tbl,
                              -- OUT variables
                              x_header_rec => l_header_rec_out,
                              x_header_val_rec => l_header_val_rec_out,
                              x_header_adj_tbl => l_header_adj_tbl_out,
                              x_header_adj_val_tbl => l_header_adj_val_tbl_out,
                              x_header_price_att_tbl => l_header_price_att_tbl_out,
                              x_header_adj_att_tbl => l_header_adj_att_tbl_out,
                              x_header_adj_assoc_tbl => l_header_adj_assoc_tbl_out,
                              x_header_scredit_tbl => l_header_scredit_tbl_out,
                              x_header_scredit_val_tbl => l_header_scredit_val_tbl_out,
                              x_line_tbl => l_line_tbl_out,
                              x_line_val_tbl => l_line_val_tbl_out,
                              x_line_adj_tbl => l_line_adj_tbl_out,
                              x_line_adj_val_tbl => l_line_adj_val_tbl_out,
                              x_line_price_att_tbl => l_line_price_att_tbl_out,
                              x_line_adj_att_tbl => l_line_adj_att_tbl_out,
                              x_line_adj_assoc_tbl => l_line_adj_assoc_tbl_out,
                              x_line_scredit_tbl => l_line_scredit_tbl_out,
                              x_line_scredit_val_tbl => l_line_scredit_val_tbl_out,
                              x_lot_serial_tbl => l_lot_serial_tbl_out,
                              x_lot_serial_val_tbl => l_lot_serial_val_tbl_out,
                              x_action_request_tbl => l_action_request_tbl_out,
                              x_return_status => l_return_status,
                              x_msg_count => l_msg_count,
                              x_msg_data => l_msg_data);
   -- CHECK RETURN STATUS
   IF l_return_status = FND_API.G_RET_STS_SUCCESS THEN
      IF (l_debug_level > 0) THEN
         DBMS_OUTPUT.PUT_LINE('Sales Order Successfully Created '||l_header_rec_out.header_id);
      END IF;
      P_ORDER_NUMBER := l_header_rec_out.order_number;
      P_ORDER_ID := l_header_rec_out.header_id; --MYJIRATEST-4507 Ravi S 18-NOV-2014
      P_STATUS := 'Y';
      P_MSG := NULL;
      --l_order_success := 'Y';
      COMMIT;
   ELSE
      IF (l_debug_level > 0) THEN
         DBMS_OUTPUT.PUT_LINE('Failed to Create Sales Order');
      END IF;
      P_STATUS := 'N';
      FOR i IN 1 .. l_msg_count LOOP
         oe_msg_pub.get(
          p_msg_index => i
         ,p_encoded => Fnd_Api.G_FALSE
         ,p_data => l_data
         ,p_msg_index_out => l_msg_index);
         DBMS_OUTPUT.PUT_LINE('message is:'||l_data);
         DBMS_OUTPUT.PUT_LINE('message index is:'||l_msg_index);
         --MYJIRATEST-4806 Ravi S 15-DEC-2014
         IF l_data NOT LIKE '%PO Number is referenced by another order%' AND l_data NOT LIKE '%Error messages from Order Management%' AND l_data NOT LIKE '%There is an error in order submission%' THEN
            IF l_data LIKE '%The item specified is invalid or does not exist in the warehouse you specified. Please enter a valid item-warehouse combination.%' THEN
               IF NVL(P_MSG,'#') NOT LIKE '%8139%' THEN
                  P_MSG := P_MSG||GET_ERR_MSG(8139)||'|';
               END IF;
            ELSIF l_data LIKE '%Invalid unit of measure for this item.%' THEN
               IF NVL(P_MSG,'#') NOT LIKE '%8140%' THEN
                  P_MSG := P_MSG||GET_ERR_MSG(8140)||'|';
               END IF;
            ELSIF l_data LIKE '%The desired date%falls outside of the project effective dates.%' THEN
               IF NVL(P_MSG,'#') NOT LIKE '%8159%' THEN
                  P_MSG := P_MSG||GET_ERR_MSG(8159)||'|';
               END IF;
            ELSIF l_data LIKE '%Quantity should be multiple of UPQ%' OR l_data LIKE '%Ordered Quantity is not a multiple of Unit Pack Quantity%' THEN
               IF NVL(P_MSG,'#') NOT LIKE '%8142%' THEN
                  P_MSG := P_MSG||GET_ERR_MSG(8142)||'|';
               END IF;
            ELSIF l_data LIKE '%PTO KIT quantity should be 1%' THEN
               IF NVL(P_MSG,'#') NOT LIKE '%8143%' THEN
                  P_MSG := P_MSG||GET_ERR_MSG(8143)||'|';
               END IF;
            ELSIF l_data LIKE '%SPR price list not present , order cannot be booked%' THEN
               IF NVL(P_MSG,'#') NOT LIKE '%8144%' THEN
                  P_MSG := P_MSG||GET_ERR_MSG(8144)||'|';
               END IF;
            ELSIF l_data LIKE '%Kit price check failed.  Please check the kit header and component list prices%' THEN
               IF NVL(P_MSG,'#') NOT LIKE '%8145%' THEN
                  P_MSG := P_MSG||GET_ERR_MSG(8145)||'|';
               END IF;
            ELSIF l_data LIKE '%ADN Validation Failed%' THEN
               IF NVL(P_MSG,'#') NOT LIKE '%8146%' THEN
                  P_MSG := P_MSG||GET_ERR_MSG(8146)||'|';
               END IF;
            ELSIF l_data LIKE '%No Project Code Please Check Customer set Up%' THEN
               IF NVL(P_MSG,'#') NOT LIKE '%8147%' THEN
                  P_MSG := P_MSG||GET_ERR_MSG(8147)||'|';
               END IF;
            ELSIF l_data LIKE '%Warehouse on this order line is invalid for this Operating Unit.%' THEN
               IF NVL(P_MSG,'#') NOT LIKE '%8148%' THEN
                  P_MSG := P_MSG||GET_ERR_MSG(8148)||'|';
               END IF;
            ELSIF l_data LIKE '%Part Value Code is not assigned to Item%' THEN
               IF NVL(P_MSG,'#') NOT LIKE '%8149%' THEN
                  P_MSG := P_MSG||GET_ERR_MSG(8149)||'|';
               END IF;
            ELSIF l_data LIKE '%Same planning priority value cannot be assigned for a given part within a Warehouse%' THEN
               IF NVL(P_MSG,'#') NOT LIKE '%8150%' THEN
                  P_MSG := P_MSG||GET_ERR_MSG(8150)||'|';
               END IF;
            ELSIF l_data LIKE '%Ship To and Deliver To Mapping is not valid combination%' THEN
               IF NVL(P_MSG,'#') NOT LIKE '%8151%' THEN
                  P_MSG := P_MSG||GET_ERR_MSG(8151)||'|';
               END IF;
            ELSIF l_data LIKE '%AOG Validation Failed Item Request Cannot Be Later Than SYSDATE%' THEN
               IF NVL(P_MSG,'#') NOT LIKE '%8152%' THEN
                  P_MSG := P_MSG||GET_ERR_MSG(8152)||'|';
               END IF;
            ELSIF l_data LIKE '%Configuration Validation fail for this item%' THEN
               IF NVL(P_MSG,'#') NOT LIKE '%8154%' THEN
                  P_MSG := P_MSG||GET_ERR_MSG(8154)||'|';
               END IF;
            ELSIF l_data LIKE '%Configuration Validation - Model Applicability Error%' THEN
               IF NVL(P_MSG,'#') NOT LIKE '%8154%' THEN
                  P_MSG := P_MSG||GET_ERR_MSG(8154)||'|';
               END IF;
            ELSIF l_data LIKE '%Please note%you cannot place%order with an invalid configuration%' THEN
               IF NVL(P_MSG,'#') NOT LIKE '%8169%' THEN
                  P_MSG := P_MSG||GET_ERR_MSG(8169)||'|';
               END IF;
            ELSIF l_data LIKE '%Last_Update_Date%must%exist%missing column%' THEN
               IF NVL(P_MSG,'#') NOT LIKE '%8155%' THEN
                  P_MSG := P_MSG||GET_ERR_MSG(8155)||'|';
               END IF;
            ELSIF l_data LIKE '%GTA%' THEN
               IF NVL(P_MSG,'#') NOT LIKE '%8157%' THEN
                  P_MSG := P_MSG||GET_ERR_MSG(8157)||'|';
               END IF;
            ELSIF l_data LIKE '%Validation failed for the field - Shipment Priority%' THEN
               IF NVL(P_MSG,'#') NOT LIKE '%8158%' THEN
                  P_MSG := P_MSG||GET_ERR_MSG(8158)||'|';
               END IF;
            ELSIF l_data LIKE '%Review Required for this Order. Check the Order Lines%' THEN
               IF NVL(P_MSG,'#') NOT LIKE '%8160%' THEN
                  P_MSG := P_MSG||GET_ERR_MSG(8160)||'|';
               END IF;
            ELSIF l_data LIKE '%This is Buy ATO item%' THEN
               IF NVL(P_MSG,'#') NOT LIKE '%8161%' THEN
                  P_MSG := P_MSG||GET_ERR_MSG(8161)||'|';
               END IF;
            ELSIF l_data LIKE '%order with an invalid configuration%' THEN
               IF NVL(P_MSG,'#') NOT LIKE '%8169%' THEN
                  P_MSG := P_MSG||GET_ERR_MSG(8169)||'|';
               END IF;
            ELSIF l_data LIKE '%Customer PO is required on a booked order%' THEN
               IF NVL(P_MSG,'#') NOT LIKE '%8162%' THEN
                  P_MSG := P_MSG||GET_ERR_MSG(8162)||'|';
               END IF;
            ELSIF l_data LIKE '%Payment Term is required on a booked order%' THEN
               IF NVL(P_MSG,'#') NOT LIKE '%8163%' THEN
                  P_MSG := P_MSG||GET_ERR_MSG(8163)||'|';
               END IF;
            ELSIF l_data LIKE '%Please specify the tax code%The line type requires tax calculation%' THEN
               IF NVL(P_MSG,'#') NOT LIKE '%8164%' THEN
                  P_MSG := P_MSG||GET_ERR_MSG(8164)||'|';
               END IF;
            ELSIF l_data LIKE '%User-Defined Exception in Package MSC_ATP_PUB Procedure Call_ATP_No_Commit%' THEN
               IF NVL(P_MSG,'#') NOT LIKE '%8165%' THEN
                  P_MSG := P_MSG||GET_ERR_MSG(8165)||'|';
               END IF;
            ELSIF l_data LIKE '%Scheduling action (SCHEDULE) is invalid for the transaction type%' THEN
               IF NVL(P_MSG,'#') NOT LIKE '%8063%' THEN
                  P_MSG := P_MSG||GET_ERR_MSG(8063)||'|';
               END IF;
            ELSIF l_data LIKE '%Validation failed for the field - Deliver To Org%' THEN
               IF NVL(P_MSG,'#') NOT LIKE '%8064%' THEN
                  P_MSG := P_MSG||GET_ERR_MSG(8064)||'|';
               END IF;
            ELSIF l_data LIKE '%User-Defined Exception in Package Oe_Config_Util Procedure Process_Included_Items%' THEN
               IF NVL(P_MSG,'#') NOT LIKE '%8065%' THEN
                  P_MSG := P_MSG||GET_ERR_MSG(8065)||'|';
               END IF;
            ELSE
               P_MSG := P_MSG||'8300:'||l_data||'|';
            END IF;
         END IF;
      END LOOP;
      --IF P_MSG LIKE '%Validation failed for the field - Order Type|Validation failed for the field - Salesperson|%' THEN
         --l_order_success := 'N';
         --IF i < 10 THEN
            --P_MSG := NULL;
         --END IF;
      --ELSE
         --l_order_success := 'Y';
      --END IF;
      ROLLBACK;
   END IF;
   --IF l_order_success = 'Y' THEN
      --EXIT;
   --END IF;
   --END LOOP;
   IF P_STATUS = 'N' THEN
      GOTO end_proc;
   END IF;
   IF P_BB_REQ_BY IS NOT NULL AND P_DISPUTE = 'Buyback' THEN
      ADD_ATTACHMENT(l_header_rec_out.header_id,NULL,P_BB_REQ_BY,'REQUESTED_BY',NULL,V_USER_ID,l_return_status);
      IF l_return_status <> 'Y' THEN
         P_MSG := P_MSG||GET_ERR_MSG(8035)||'|';
         GOTO end_proc;
      END IF;
   END IF;
   IF P_ATT_COMMENTS IS NOT NULL THEN
    --  ADD_ATTACHMENT(l_header_rec_out.header_id,NULL,P_ATT_COMMENTS,'COMMENTS',NULL,V_USER_ID,l_return_status); --Commented as part of MYJIRATEST-4775 Neelima Y 28-OCT-2015
      ADD_ATTACHMENT(l_line_tbl_out(1).line_id,NULL,P_ATT_COMMENTS,'COMMENTS',NULL,V_USER_ID,l_return_status); --MYJIRATEST-4775 Neelima Y 28-OCT-2015
      IF l_return_status <> 'Y' THEN
         P_MSG := P_MSG||GET_ERR_MSG(8035)||'|';
         GOTO end_proc;
      END IF;
   END IF;
   IF P_SND_ATT_SLLST IS NOT NULL THEN
      ADD_ATTACHMENT(l_header_rec_out.header_id,NULL,P_SND_ATT_SLLST,'SELECTED_SNO',NULL,V_USER_ID,l_return_status);
      IF l_return_status <> 'Y' THEN
         P_MSG := P_MSG||GET_ERR_MSG(8037)||'|';
         GOTO end_proc;
      END IF;
   END IF;
   IF P_SND_ATT_RCLST IS NOT NULL THEN
      ADD_ATTACHMENT(l_header_rec_out.header_id,NULL,P_SND_ATT_RCLST,'RECEIVED_SNO',NULL,V_USER_ID,l_return_status);
      IF l_return_status <> 'Y' THEN
         P_MSG := P_MSG||GET_ERR_MSG(8038)||'|';
         GOTO end_proc;
      END IF;
   END IF;
   IF P_SND_ATT_FILE IS NOT NULL AND P_SND_ATT_FNAME IS NOT NULL THEN
      ADD_ATTACHMENT(l_header_rec_out.header_id,P_SND_ATT_FILE,NULL,'FILE',P_SND_ATT_FNAME,V_USER_ID,l_return_status);
      IF l_return_status <> 'Y' THEN
         P_MSG := P_MSG||'8036:File '||P_SND_ATT_FNAME||' could not be attached'||'|';
         GOTO end_proc;
      END IF;
   END IF;
   --MYJIRATEST-4646 Ravi S 28-NOV-2014
   SELECT booked_flag
     INTO l_booked_flag
     FROM oe_order_headers_all
    WHERE header_id = l_header_rec_out.header_id;
   IF l_booked_flag = 'Y' THEN
      BEGIN
         SELECT SUM(unit_selling_price*ordered_quantity*DECODE(line_category_code,'RETURN',-1,1))
           INTO P_ORDER_VALUE
           FROM oe_order_lines_all
          WHERE header_id = l_header_rec_out.header_id;
      EXCEPTION
         WHEN OTHERS THEN
            P_ORDER_VALUE := NULL;
      END;
   ELSE
      P_ORDER_VALUE := NULL;
   END IF;

   <<end_proc>>
   NULL;
EXCEPTION
   WHEN OTHERS THEN
      P_MSG := '8300:'||SUBSTR(SQLERRM,1,100);
END CREATE_DISPUTE_ORDER;

PROCEDURE LOAD_SERIAL_DISPUTE_OBJ (
                                P_OU_ID         NUMBER,
                                P_ORIG_ORDER_ID NUMBER,
                                P_ORIG_LINE_ID  NUMBER,
                                P_HEADER_REC    OUT NOCOPY oe_order_pub.header_rec_type,
                                P_LINE_TBL      OUT NOCOPY oe_order_pub.line_tbl_type,
                                P_MSG           OUT VARCHAR2
                                )
AS
   -- CURSOR FOR HEADER DETAILS OF ORIGINAL ORDER
   CURSOR C_HDR(P_ORDER_ID NUMBER) IS
      SELECT *
        FROM oe_order_headers_all
       WHERE header_id = P_ORDER_ID;
   -- CURSOR FOR LINE DETAILS OF ORIGINAL ORDER LINE
   CURSOR C_LINE(P_ORDER_ID NUMBER, P_LINE_ID NUMBER) IS
      SELECT *
        FROM oe_order_lines_all
       WHERE header_id = P_ORDER_ID
         AND line_id = P_LINE_ID;
BEGIN
   -- INITIALIZE HEADER RECORD
   P_HEADER_REC := OE_ORDER_PUB.G_MISS_HEADER_REC;
   -- INITIALIZE LINE RECORD(S)
--   P_LINE_TBL.EXTEND;
   P_LINE_TBL(1) := OE_ORDER_PUB.G_MISS_LINE_REC;
   -- POPULATE REQUIRED HEADER DATA
   P_HEADER_REC.operation := OE_GLOBALS.G_OPR_CREATE;
   -- GET ORDER TYPE
   SELECT tag
     INTO P_HEADER_REC.order_type_id
     FROM fnd_lookup_values
    WHERE lookup_type = 'GEAE_MYGE_DISPUTE_ORDER_TYPES'
      AND lookup_code = P_OU_ID||'-OSND';
   -- GET ORDER SOURCE
   --MYJIRATEST-5845 Ravi S 10-FEB-2015
   BEGIN
      SELECT oos.order_source_id
        INTO P_HEADER_REC.order_source_id
        FROM oe_order_sources oos, fnd_lookup_values flv
       WHERE oos.name = flv.description
         AND flv.lookup_type = 'GEAE_MYGE_ORDER_SOURCE'
         AND flv.lookup_code = P_OU_ID;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         P_MSG := GET_ERR_MSG(8059);
   END;
   FOR r_hdr IN C_HDR(P_ORIG_ORDER_ID) LOOP
      P_HEADER_REC.cust_po_number := r_hdr.cust_po_number;
      P_HEADER_REC.sold_to_org_id := r_hdr.sold_to_org_id;
      P_HEADER_REC.price_list_id := r_hdr.price_list_id;
      P_HEADER_REC.sold_from_org_id := r_hdr.sold_from_org_id;
      P_HEADER_REC.ship_from_org_id := r_hdr.ship_from_org_id;
  --    P_HEADER_REC.ship_to_org_id := r_hdr.ship_to_org_id;
      P_HEADER_REC.salesrep_id := r_hdr.salesrep_id;
      P_HEADER_REC.context := r_hdr.context;
      P_HEADER_REC.attribute1 := r_hdr.attribute1;
      P_HEADER_REC.attribute3 := r_hdr.attribute3;
   END LOOP;
   P_HEADER_REC.ordered_date := SYSDATE;
   P_HEADER_REC.flow_status_code:='ENTERED';
   -- POPULATE REQUIRED LINE DATA
   P_LINE_TBL(1).operation := OE_GLOBALS.G_OPR_CREATE;
   -- GET LINE TYPE
   SELECT tag
     INTO P_LINE_TBL(1).line_type_id
     FROM fnd_lookup_values
    WHERE lookup_type = 'GEAE_MYGE_DISPUTE_LINE_TYPES'
      AND lookup_code = P_OU_ID||'-CAPTURE ONLY';
   FOR r_line IN C_LINE(P_ORIG_ORDER_ID,P_ORIG_LINE_ID) LOOP
      P_LINE_TBL(1).inventory_item_id := r_line.inventory_item_id;
      P_LINE_TBL(1).ordered_quantity := r_line.ordered_quantity;
      P_LINE_TBL(1).price_list_id := r_line.price_list_id;
      P_LINE_TBL(1).context := r_line.context;
      P_LINE_TBL(1).attribute1 := r_line.attribute1;
      P_LINE_TBL(1).ship_from_org_id := GET_RETURN_WAREHOUSE(r_line.ship_from_org_id);
      P_LINE_TBL(1).calculate_price_flag := g_calc_price;
      P_LINE_TBL(1).customer_line_number := r_line.customer_line_number;
      -- GET COUNTRY OF ORIGIN
      --MYJIRATEST-4756 Ravi S 11-FEB-2015
      BEGIN
         SELECT DISTINCT wdd.attribute6
           INTO P_LINE_TBL(1).return_attribute3
           FROM wsh_delivery_details wdd, oe_order_lines_all ool
          WHERE wdd.source_header_id = P_ORIG_ORDER_ID
            AND wdd.source_line_id = ool.line_id
            AND DECODE(r_line.item_type_code,'MODEL',ool.top_model_line_id,ool.line_id) = P_ORIG_LINE_ID;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            P_MSG := GET_ERR_MSG(8039);
         WHEN TOO_MANY_ROWS THEN
            P_LINE_TBL(1).return_attribute3 := NULL;
            /*P_MSG := GET_ERR_MSG(8040);*/
      END;
   END LOOP;
   SELECT cmr.lookup_code
     INTO P_LINE_TBL(1).return_reason_code
     FROM fnd_lookup_values cmr, fnd_lookup_values drr
    WHERE cmr.lookup_type = 'CREDIT_MEMO_REASON'
      AND drr.lookup_type = 'GEAE_MYGE_DISPUTE_RET_REASON'
      AND cmr.meaning = drr.description
      AND drr.lookup_code = P_OU_ID||'-SERIAL';
   P_LINE_TBL(1).return_attribute1 := P_ORIG_ORDER_ID;
   P_LINE_TBL(1).return_attribute2 := P_ORIG_LINE_ID;
   P_LINE_TBL(1).return_context := 'ORDER';
   P_LINE_TBL(1).reference_header_id := P_ORIG_ORDER_ID;
   P_LINE_TBL(1).reference_line_id := P_ORIG_LINE_ID;
   P_LINE_TBL(1).line_category_code := 'RETURN';
END LOAD_SERIAL_DISPUTE_OBJ;

PROCEDURE LOAD_DISCREPANCY_OBJ  (
                                P_OU_ID         NUMBER,
                                P_ORIG_ORDER_ID NUMBER,
                                P_ORIG_LINE_ID  NUMBER,
                                P_DD_ITEM_ID    NUMBER,
                                P_DD_QTY        NUMBER,
                                P_TYPE          VARCHAR2,
                                P_REPLACE       VARCHAR2,
                                P_HEADER_REC    OUT NOCOPY oe_order_pub.header_rec_type,
                                P_LINE_TBL      OUT NOCOPY oe_order_pub.line_tbl_type,
                                P_MSG           OUT VARCHAR2
                                )
AS
   -- CURSOR FOR HEADER DETAILS OF ORIGINAL ORDER
   CURSOR C_HDR(P_ORDER_ID NUMBER) IS
      SELECT *
        FROM oe_order_headers_all
       WHERE header_id = P_ORDER_ID;
   -- CURSOR FOR LINE DETAILS OF ORIGINAL ORDER LINE
   CURSOR C_LINE(P_ORDER_ID NUMBER, P_LINE_ID NUMBER) IS
      SELECT *
        FROM oe_order_lines_all
       WHERE header_id = P_ORDER_ID
         AND line_id = P_LINE_ID;
   l_line_num      NUMBER;
BEGIN
   -- INITIALIZE HEADER RECORD
   P_HEADER_REC := OE_ORDER_PUB.G_MISS_HEADER_REC;
   -- POPULATE REQUIRED HEADER DATA
   P_HEADER_REC.operation := OE_GLOBALS.G_OPR_CREATE;
   -- GET ORDER TYPE
   SELECT tag
     INTO P_HEADER_REC.order_type_id
     FROM fnd_lookup_values
    WHERE lookup_type = 'GEAE_MYGE_DISPUTE_ORDER_TYPES'
      AND lookup_code = P_OU_ID||'-OSND';
   -- GET ORDER SOURCE
   --MYJIRATEST-5845 Ravi S 10-FEB-2015
   BEGIN
      SELECT oos.order_source_id
        INTO P_HEADER_REC.order_source_id
        FROM oe_order_sources oos, fnd_lookup_values flv
       WHERE oos.name = flv.description
         AND flv.lookup_type = 'GEAE_MYGE_ORDER_SOURCE'
         AND flv.lookup_code = P_OU_ID;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         P_MSG := GET_ERR_MSG(8059);
   END;
   FOR r_hdr IN C_HDR(P_ORIG_ORDER_ID) LOOP
      P_HEADER_REC.cust_po_number := r_hdr.cust_po_number;
      P_HEADER_REC.sold_to_org_id := r_hdr.sold_to_org_id;
      P_HEADER_REC.price_list_id := r_hdr.price_list_id;
      P_HEADER_REC.sold_from_org_id := r_hdr.sold_from_org_id;
      P_HEADER_REC.ship_from_org_id := r_hdr.ship_from_org_id;
     -- P_HEADER_REC.ship_to_org_id := r_hdr.ship_to_org_id;
      P_HEADER_REC.salesrep_id := r_hdr.salesrep_id;
      P_HEADER_REC.context := r_hdr.context;
      P_HEADER_REC.attribute1 := r_hdr.attribute1;
      P_HEADER_REC.attribute3 := r_hdr.attribute3;
   END LOOP;
   P_HEADER_REC.ordered_date := SYSDATE;
   P_HEADER_REC.flow_status_code:='ENTERED';
   --SHORTAGE CREDIT LINE
   l_line_num := 1;
--   P_LINE_TBL.EXTEND(1);
   P_LINE_TBL(l_line_num) := OE_ORDER_PUB.G_MISS_LINE_REC;
   P_LINE_TBL(l_line_num).operation := OE_GLOBALS.G_OPR_CREATE;
   SELECT tag
     INTO P_LINE_TBL(l_line_num).line_type_id
     FROM fnd_lookup_values
    WHERE lookup_type = 'GEAE_MYGE_DISPUTE_LINE_TYPES'
      AND lookup_code = P_OU_ID||'-SHORTAGE CREDIT';
   FOR r_line IN C_LINE(P_ORIG_ORDER_ID,P_ORIG_LINE_ID) LOOP
      P_LINE_TBL(l_line_num).inventory_item_id := r_line.inventory_item_id;
      P_LINE_TBL(l_line_num).ship_from_org_id := GET_RETURN_WAREHOUSE(r_line.ship_from_org_id);
      P_LINE_TBL(l_line_num).calculate_price_flag := g_calc_price;
      P_LINE_TBL(l_line_num).attribute1 := r_line.attribute1;
   --   P_LINE_TBL(l_line_num).ordered_quantity := P_DD_QTY; --MYJIRATEST-4532 Ravi S 18-NOV-2014
      P_LINE_TBL(l_line_num).ordered_quantity := r_line.ORDERED_QUANTITY;  --MYJIRATEST-4765 Neelima Y 28-AUG-2015
      P_LINE_TBL(l_line_num).customer_line_number := r_line.customer_line_number;
      -- GET COUNTRY OF ORIGIN
      --MYJIRATEST-4756 Ravi S 11-FEB-2015
      BEGIN
         SELECT DISTINCT wdd.attribute6
           INTO P_LINE_TBL(l_line_num).return_attribute3
           FROM wsh_delivery_details wdd, oe_order_lines_all ool
          WHERE wdd.source_header_id = P_ORIG_ORDER_ID
            AND wdd.source_line_id = ool.line_id
            AND DECODE(r_line.item_type_code,'MODEL',ool.top_model_line_id,ool.line_id) = P_ORIG_LINE_ID;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            P_MSG := GET_ERR_MSG(8039);
         WHEN TOO_MANY_ROWS THEN
            P_LINE_TBL(l_line_num).return_attribute3 := NULL;
            /*P_MSG := GET_ERR_MSG(8040);*/
      END;
   END LOOP;
   SELECT cmr.lookup_code
     INTO P_LINE_TBL(l_line_num).return_reason_code
     FROM fnd_lookup_values cmr, fnd_lookup_values drr
    WHERE cmr.lookup_type = 'CREDIT_MEMO_REASON'
      AND drr.lookup_type = 'GEAE_MYGE_DISPUTE_RET_REASON'
      AND cmr.meaning = drr.description
      AND drr.lookup_code = P_OU_ID||'-DISCREPANCY';
   --P_LINE_TBL(l_line_num).return_reason_code := '008'; --from lookup
   P_LINE_TBL(l_line_num).return_attribute1 := P_ORIG_ORDER_ID;
   P_LINE_TBL(l_line_num).return_attribute2 := P_ORIG_LINE_ID;
   P_LINE_TBL(l_line_num).return_context := 'ORDER';
   P_LINE_TBL(l_line_num).reference_header_id := P_ORIG_ORDER_ID;
   P_LINE_TBL(l_line_num).reference_line_id := P_ORIG_LINE_ID;
   P_LINE_TBL(l_line_num).line_category_code := 'RETURN';
   --SHIP AND BILL LINE IF NEEDED
   IF P_REPLACE = 'Y' THEN
      l_line_num := l_line_num + 1;
--      P_LINE_TBL.EXTEND(1);
      P_LINE_TBL(l_line_num) := OE_ORDER_PUB.G_MISS_LINE_REC;
      P_LINE_TBL(l_line_num).operation := OE_GLOBALS.G_OPR_CREATE;
      SELECT tag
        INTO P_LINE_TBL(l_line_num).line_type_id
        FROM fnd_lookup_values
       WHERE lookup_type = 'GEAE_MYGE_DISPUTE_LINE_TYPES'
         AND lookup_code = P_OU_ID||'-SHIP AND BILL';
      FOR r_line IN C_LINE(P_ORIG_ORDER_ID,P_ORIG_LINE_ID) LOOP
         P_LINE_TBL(l_line_num).inventory_item_id := r_line.inventory_item_id;
         P_LINE_TBL(l_line_num).ship_from_org_id := r_line.ship_from_org_id;
         P_LINE_TBL(l_line_num).ship_to_org_id := r_line.ship_to_org_id;
         P_LINE_TBL(l_line_num).invoice_to_org_id := r_line.invoice_to_org_id;
         P_LINE_TBL(l_line_num).deliver_to_org_id := r_line.deliver_to_org_id;
         P_LINE_TBL(l_line_num).sold_to_org_id := r_line.sold_to_org_id;
         P_LINE_TBL(l_line_num).calculate_price_flag := g_calc_price;
         P_LINE_TBL(l_line_num).attribute1 := r_line.attribute1;
         P_LINE_TBL(l_line_num).attribute5 := r_line.attribute5;
        -- P_LINE_TBL(l_line_num).ordered_quantity := P_DD_QTY; --MYJIRATEST-4532 Ravi S 18-NOV-2014
         P_LINE_TBL(l_line_num).ordered_quantity := r_line.ORDERED_QUANTITY;  --MYJIRATEST-4765 Neelima Y 28-AUG-2015
         P_LINE_TBL(l_line_num).customer_line_number := r_line.customer_line_number;
         P_LINE_TBL(l_line_num).pricing_date := r_line.pricing_date;
      END LOOP;
   END IF;
   --OVERAGE LINE
   l_line_num := l_line_num + 1;
--   P_LINE_TBL.EXTEND(1);
   P_LINE_TBL(l_line_num) := OE_ORDER_PUB.G_MISS_LINE_REC;
   P_LINE_TBL(l_line_num).operation := OE_GLOBALS.G_OPR_CREATE;
   SELECT tag
     INTO P_LINE_TBL(l_line_num).line_type_id
     FROM fnd_lookup_values
    WHERE lookup_type = 'GEAE_MYGE_DISPUTE_LINE_TYPES'
      AND lookup_code = P_OU_ID||P_TYPE;
   FOR r_line IN C_LINE(P_ORIG_ORDER_ID,P_ORIG_LINE_ID) LOOP
      P_LINE_TBL(l_line_num).inventory_item_id := P_DD_ITEM_ID;
     -- P_LINE_TBL(l_line_num).ship_from_org_id := r_line.ship_from_org_id; --MYJIRATEST-4659 Neelima Y 28-AUG-2015
      P_LINE_TBL(l_line_num).calculate_price_flag := g_calc_price;
--      P_LINE_TBL(l_line_num).attribute1 := r_line.attribute1;
      P_LINE_TBL(l_line_num).ordered_quantity := P_DD_QTY;
      P_LINE_TBL(l_line_num).customer_line_number := r_line.customer_line_number;
      IF P_TYPE = '-OVERAGE RETURN' THEN
         -- GET COUNTRY OF ORIGIN
         --MYJIRATEST-4756 Ravi S 11-FEB-2015
         BEGIN
            SELECT DISTINCT wdd.attribute6
              INTO P_LINE_TBL(l_line_num).return_attribute3
              FROM wsh_delivery_details wdd, oe_order_lines_all ool
             WHERE wdd.source_header_id = P_ORIG_ORDER_ID
               AND wdd.source_line_id = ool.line_id
               AND DECODE(r_line.item_type_code,'MODEL',ool.top_model_line_id,ool.line_id) = P_ORIG_LINE_ID;
         EXCEPTION
            WHEN NO_DATA_FOUND THEN
               P_MSG := GET_ERR_MSG(8039);
            WHEN TOO_MANY_ROWS THEN
               P_LINE_TBL(l_line_num).return_attribute3 := NULL;
               /*P_MSG := GET_ERR_MSG(8040);*/
         END;
         P_LINE_TBL(l_line_num).ship_from_org_id := GET_RETURN_WAREHOUSE(r_line.ship_from_org_id);
         SELECT cmr.lookup_code
           INTO P_LINE_TBL(l_line_num).return_reason_code
           FROM fnd_lookup_values cmr, fnd_lookup_values drr
          WHERE cmr.lookup_type = 'CREDIT_MEMO_REASON'
            AND drr.lookup_type = 'GEAE_MYGE_DISPUTE_RET_REASON'
            AND cmr.meaning = drr.description
            AND drr.lookup_code = P_OU_ID||'-DISCREPANCY';
      --Commented below for MYJIRATEST-4580 Ravi S 20-NOV-2014
      /*
         --P_LINE_TBL(l_line_num).return_reason_code := '001'; --from lookup
         P_LINE_TBL(l_line_num).return_attribute1 := P_ORIG_ORDER_ID;
         P_LINE_TBL(l_line_num).return_attribute2 := P_ORIG_LINE_ID;
         P_LINE_TBL(l_line_num).return_context := 'ORDER';
         P_LINE_TBL(l_line_num).line_category_code := 'RETURN';
         P_LINE_TBL(l_line_num).reference_header_id := P_ORIG_ORDER_ID;
         P_LINE_TBL(l_line_num).reference_line_id := P_ORIG_LINE_ID;
      */
      END IF;
   END LOOP;
END LOAD_DISCREPANCY_OBJ;

PROCEDURE LOAD_SHORTAGE_OBJ     (
                                P_OU_ID         NUMBER,
                                P_ORIG_ORDER_ID NUMBER,
                                P_ORIG_LINE_ID  NUMBER,
                                P_SD_QTY        NUMBER,
                                P_REPLACE       VARCHAR2,
                                P_HEADER_REC    OUT NOCOPY oe_order_pub.header_rec_type,
                                P_LINE_TBL      OUT NOCOPY oe_order_pub.line_tbl_type,
                                P_MSG           OUT VARCHAR2
                                )
AS
   -- CURSOR FOR HEADER DETAILS OF ORIGINAL ORDER
   CURSOR C_HDR(P_ORDER_ID NUMBER) IS
      SELECT *
        FROM oe_order_headers_all
       WHERE header_id = P_ORDER_ID;
   -- CURSOR FOR LINE DETAILS OF ORIGINAL ORDER LINE
   CURSOR C_LINE(P_ORDER_ID NUMBER, P_LINE_ID NUMBER) IS
      SELECT *
        FROM oe_order_lines_all
       WHERE header_id = P_ORDER_ID
         AND line_id = P_LINE_ID;
   l_hdr_loop VARCHAR2(1) := 'N';
   l_ln_loop VARCHAR2(1) := 'N';
BEGIN
   -- INITIALIZE HEADER RECORD
   P_HEADER_REC := OE_ORDER_PUB.G_MISS_HEADER_REC;
   -- INITIALIZE LINE RECORD(S)
--   P_LINE_TBL.EXTEND(1);
   P_LINE_TBL(1) := OE_ORDER_PUB.G_MISS_LINE_REC;
   -- POPULATE REQUIRED HEADER DATA
   P_HEADER_REC.operation := OE_GLOBALS.G_OPR_CREATE;
   -- GET ORDER TYPE
   SELECT tag
     INTO P_HEADER_REC.order_type_id
     FROM fnd_lookup_values
    WHERE lookup_type = 'GEAE_MYGE_DISPUTE_ORDER_TYPES'
      AND lookup_code = P_OU_ID||'-OSND';
   -- GET ORDER SOURCE
   --MYJIRATEST-5845 Ravi S 10-FEB-2015
   BEGIN
      SELECT oos.order_source_id
        INTO P_HEADER_REC.order_source_id
        FROM oe_order_sources oos, fnd_lookup_values flv
       WHERE oos.name = flv.description
         AND flv.lookup_type = 'GEAE_MYGE_ORDER_SOURCE'
         AND flv.lookup_code = P_OU_ID;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         P_MSG := GET_ERR_MSG(8059);
   END;
   FOR r_hdr IN C_HDR(P_ORIG_ORDER_ID) LOOP
      l_hdr_loop := 'Y';
      P_HEADER_REC.cust_po_number := r_hdr.cust_po_number;
      P_HEADER_REC.sold_to_org_id := r_hdr.sold_to_org_id;
      P_HEADER_REC.price_list_id := r_hdr.price_list_id;
      P_HEADER_REC.sold_from_org_id := r_hdr.sold_from_org_id;
      P_HEADER_REC.ship_from_org_id := r_hdr.ship_from_org_id;
    --  P_HEADER_REC.ship_to_org_id := r_hdr.ship_to_org_id;
      P_HEADER_REC.salesrep_id := r_hdr.salesrep_id;
      P_HEADER_REC.context := r_hdr.context;
      P_HEADER_REC.attribute1 := r_hdr.attribute1;
      P_HEADER_REC.attribute3 := r_hdr.attribute3;
   END LOOP;
   IF l_hdr_loop <> 'Y' THEN
      P_MSG := P_MSG||'Original Order not found|';
   END IF;
   P_HEADER_REC.ordered_date := SYSDATE;
   P_HEADER_REC.flow_status_code:='ENTERED';
   -- POPULATE REQUIRED LINE DATA
   P_LINE_TBL(1).operation := OE_GLOBALS.G_OPR_CREATE;
   -- GET LINE TYPE
   SELECT tag
     INTO P_LINE_TBL(1).line_type_id
     FROM fnd_lookup_values
    WHERE lookup_type = 'GEAE_MYGE_DISPUTE_LINE_TYPES'
      AND lookup_code = P_OU_ID||'-SHORTAGE CREDIT';
   FOR r_line IN C_LINE(P_ORIG_ORDER_ID,P_ORIG_LINE_ID) LOOP
      l_ln_loop := 'Y';
      P_LINE_TBL(1).inventory_item_id := r_line.inventory_item_id;
      P_LINE_TBL(1).ship_from_org_id := GET_RETURN_WAREHOUSE(r_line.ship_from_org_id);
      P_LINE_TBL(1).calculate_price_flag := g_calc_price;
      P_LINE_TBL(1).attribute1 := r_line.attribute1;
      P_LINE_TBL(1).ordered_quantity := P_SD_QTY; --MYJIRATEST-4532 Ravi S 18-NOV-2014
      P_LINE_TBL(1).customer_line_number := r_line.customer_line_number;
      -- GET COUNTRY OF ORIGIN
      --MYJIRATEST-4756 Ravi S 11-FEB-2015
      BEGIN
         SELECT DISTINCT wdd.attribute6
           INTO P_LINE_TBL(1).return_attribute3
           FROM wsh_delivery_details wdd, oe_order_lines_all ool
          WHERE wdd.source_header_id = P_ORIG_ORDER_ID
            AND wdd.source_line_id = ool.line_id
            AND DECODE(r_line.item_type_code,'MODEL',ool.top_model_line_id,ool.line_id) = P_ORIG_LINE_ID;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            P_MSG := GET_ERR_MSG(8039);
         WHEN TOO_MANY_ROWS THEN
            P_LINE_TBL(1).return_attribute3 := NULL;
            /*P_MSG := GET_ERR_MSG(8040);*/
      END;
   END LOOP;
   IF l_ln_loop <> 'Y' THEN
      P_MSG := P_MSG||'Original Order Line not found|';
   END IF;
   SELECT cmr.lookup_code
     INTO P_LINE_TBL(1).return_reason_code
     FROM fnd_lookup_values cmr, fnd_lookup_values drr
    WHERE cmr.lookup_type = 'CREDIT_MEMO_REASON'
      AND drr.lookup_type = 'GEAE_MYGE_DISPUTE_RET_REASON'
      AND cmr.meaning = drr.description
      AND drr.lookup_code = P_OU_ID||'-SHORTAGE';
   --P_LINE_TBL(1).return_reason_code := '008'; --from lookup
   P_LINE_TBL(1).return_attribute1 := P_ORIG_ORDER_ID;
   P_LINE_TBL(1).return_attribute2 := P_ORIG_LINE_ID;
   P_LINE_TBL(1).return_context := 'ORDER';
   P_LINE_TBL(1).reference_header_id := P_ORIG_ORDER_ID;
   P_LINE_TBL(1).reference_line_id := P_ORIG_LINE_ID;
   P_LINE_TBL(1).line_category_code := 'RETURN';
   IF P_REPLACE = 'Y' THEN
      -- INITIALIZE LINE RECORD(S)
--      P_LINE_TBL.EXTEND(1);
      P_LINE_TBL(2) := OE_ORDER_PUB.G_MISS_LINE_REC;
      -- POPULATE REQUIRED LINE DATA
      P_LINE_TBL(2).operation := OE_GLOBALS.G_OPR_CREATE;
      -- GET LINE TYPE
      SELECT tag
        INTO P_LINE_TBL(2).line_type_id
        FROM fnd_lookup_values
       WHERE lookup_type = 'GEAE_MYGE_DISPUTE_LINE_TYPES'
         AND lookup_code = P_OU_ID||'-SHIP AND BILL';
      FOR r_line IN C_LINE(P_ORIG_ORDER_ID,P_ORIG_LINE_ID) LOOP
         P_LINE_TBL(2).inventory_item_id := r_line.inventory_item_id;
         P_LINE_TBL(2).ship_from_org_id := r_line.ship_from_org_id;
         P_LINE_TBL(2).ship_to_org_id := r_line.ship_to_org_id;
         P_LINE_TBL(2).invoice_to_org_id := r_line.invoice_to_org_id;
         P_LINE_TBL(2).deliver_to_org_id := r_line.deliver_to_org_id;
         P_LINE_TBL(2).sold_to_org_id := r_line.sold_to_org_id;
         P_LINE_TBL(2).calculate_price_flag := g_calc_price;
         P_LINE_TBL(2).attribute1 := r_line.attribute1;
         P_LINE_TBL(2).attribute5 := r_line.attribute5;
         P_LINE_TBL(2).ordered_quantity := P_SD_QTY; --MYJIRATEST-4532 Ravi S 18-NOV-2014
         P_LINE_TBL(2).customer_line_number := r_line.customer_line_number;
         P_LINE_TBL(2).pricing_date := r_line.pricing_date;
      END LOOP;
   END IF;
EXCEPTION
   WHEN OTHERS THEN
      P_MSG := P_MSG||SUBSTR(SQLERRM,1,100)||'|';
END LOAD_SHORTAGE_OBJ;

PROCEDURE LOAD_OVRG_RET_OBJ     (
                                P_OU_ID         NUMBER,
                                P_ORIG_ORDER_ID NUMBER,
                                P_ORIG_LINE_ID  NUMBER,
                                P_OR_QTY        NUMBER,
                                P_TYPE          VARCHAR2,
                                P_HEADER_REC    OUT NOCOPY oe_order_pub.header_rec_type,
                                P_LINE_TBL      OUT NOCOPY oe_order_pub.line_tbl_type,
                                P_MSG           OUT VARCHAR2
                                )
AS
   -- CURSOR FOR HEADER DETAILS OF ORIGINAL ORDER
   CURSOR C_HDR(P_ORDER_ID NUMBER) IS
      SELECT *
        FROM oe_order_headers_all
       WHERE header_id = P_ORDER_ID;
   -- CURSOR FOR LINE DETAILS OF ORIGINAL ORDER LINE
   CURSOR C_LINE(P_ORDER_ID NUMBER, P_LINE_ID NUMBER) IS
      SELECT *
        FROM oe_order_lines_all
       WHERE header_id = P_ORDER_ID
         AND line_id = P_LINE_ID;
BEGIN
   -- INITIALIZE HEADER RECORD
   P_HEADER_REC := OE_ORDER_PUB.G_MISS_HEADER_REC;
   -- INITIALIZE LINE RECORD(S)
--   P_LINE_TBL.EXTEND(1);
   P_LINE_TBL(1) := OE_ORDER_PUB.G_MISS_LINE_REC;
   -- POPULATE REQUIRED HEADER DATA
   P_HEADER_REC.operation := OE_GLOBALS.G_OPR_CREATE;
   -- GET ORDER TYPE
   SELECT tag
     INTO P_HEADER_REC.order_type_id
     FROM fnd_lookup_values
    WHERE lookup_type = 'GEAE_MYGE_DISPUTE_ORDER_TYPES'
      AND lookup_code = P_OU_ID||'-OSND';
   -- GET ORDER SOURCE
   --MYJIRATEST-5845 Ravi S 10-FEB-2015
   BEGIN
      SELECT oos.order_source_id
        INTO P_HEADER_REC.order_source_id
        FROM oe_order_sources oos, fnd_lookup_values flv
       WHERE oos.name = flv.description
         AND flv.lookup_type = 'GEAE_MYGE_ORDER_SOURCE'
         AND flv.lookup_code = P_OU_ID;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         P_MSG := GET_ERR_MSG(8059);
   END;
   FOR r_hdr IN C_HDR(P_ORIG_ORDER_ID) LOOP
      P_HEADER_REC.cust_po_number := r_hdr.cust_po_number;
      P_HEADER_REC.sold_to_org_id := r_hdr.sold_to_org_id;
      P_HEADER_REC.price_list_id := r_hdr.price_list_id;
      P_HEADER_REC.sold_from_org_id := r_hdr.sold_from_org_id;
      P_HEADER_REC.ship_from_org_id := r_hdr.ship_from_org_id;
    --  P_HEADER_REC.ship_to_org_id := r_hdr.ship_to_org_id;
      P_HEADER_REC.salesrep_id := r_hdr.salesrep_id;
      P_HEADER_REC.context := r_hdr.context;
      P_HEADER_REC.attribute1 := r_hdr.attribute1;
      P_HEADER_REC.attribute3 := r_hdr.attribute3;
   END LOOP;
   P_HEADER_REC.ordered_date := SYSDATE;
   P_HEADER_REC.flow_status_code:='ENTERED';
   -- POPULATE REQUIRED LINE DATA
   P_LINE_TBL(1).operation := OE_GLOBALS.G_OPR_CREATE;
   -- GET LINE TYPE
   SELECT tag
     INTO P_LINE_TBL(1).line_type_id
     FROM fnd_lookup_values
    WHERE lookup_type = 'GEAE_MYGE_DISPUTE_LINE_TYPES'
      AND lookup_code = P_OU_ID||P_TYPE;
   FOR r_line IN C_LINE(P_ORIG_ORDER_ID,P_ORIG_LINE_ID) LOOP
      P_LINE_TBL(1).inventory_item_id := r_line.inventory_item_id;
      P_LINE_TBL(1).ship_from_org_id := r_line.ship_from_org_id;
      P_LINE_TBL(1).calculate_price_flag := g_calc_price;
      P_LINE_TBL(1).attribute1 := r_line.attribute1;
      P_LINE_TBL(1).ordered_quantity := P_OR_QTY; --MYJIRATEST-4532 Ravi S 18-NOV-2014
      P_LINE_TBL(1).customer_line_number := r_line.customer_line_number;
      IF P_TYPE = '-OVERAGE RETURN' THEN
         P_LINE_TBL(1).ship_from_org_id := GET_RETURN_WAREHOUSE(r_line.ship_from_org_id);
         -- GET COUNTRY OF ORIGIN
         --MYJIRATEST-4756 Ravi S 11-FEB-2015
         BEGIN
            SELECT DISTINCT wdd.attribute6
              INTO P_LINE_TBL(1).return_attribute3
              FROM wsh_delivery_details wdd, oe_order_lines_all ool
             WHERE wdd.source_header_id = P_ORIG_ORDER_ID
               AND wdd.source_line_id = ool.line_id
               AND DECODE(r_line.item_type_code,'MODEL',ool.top_model_line_id,ool.line_id) = P_ORIG_LINE_ID;
         EXCEPTION
            WHEN NO_DATA_FOUND THEN
               P_MSG := GET_ERR_MSG(8039);
            WHEN TOO_MANY_ROWS THEN
               P_LINE_TBL(1).return_attribute3 := NULL;
               /*P_MSG := GET_ERR_MSG(8040);*/
         END;
         SELECT cmr.lookup_code
           INTO P_LINE_TBL(1).return_reason_code
           FROM fnd_lookup_values cmr, fnd_lookup_values drr
          WHERE cmr.lookup_type = 'CREDIT_MEMO_REASON'
            AND drr.lookup_type = 'GEAE_MYGE_DISPUTE_RET_REASON'
            AND cmr.meaning = drr.description
            AND drr.lookup_code = P_OU_ID||'-OVERAGE';
         --P_LINE_TBL(1).return_reason_code := '001'; --from lookup
         P_LINE_TBL(1).return_attribute1 := P_ORIG_ORDER_ID;
         P_LINE_TBL(1).return_attribute2 := P_ORIG_LINE_ID;
         P_LINE_TBL(1).return_context := 'ORDER';
         P_LINE_TBL(1).reference_header_id := P_ORIG_ORDER_ID;
         P_LINE_TBL(1).reference_line_id := P_ORIG_LINE_ID;
         P_LINE_TBL(1).line_category_code := 'RETURN';
      END IF;
   END LOOP;
END LOAD_OVRG_RET_OBJ;

PROCEDURE LOAD_BUYBACK_OBJ     (
                                P_OU_ID         NUMBER,
                                P_ORIG_ORDER_ID NUMBER,
                                P_ORIG_LINE_ID  NUMBER,
                                P_BB_QTY        NUMBER,
                                P_HEADER_REC    OUT NOCOPY oe_order_pub.header_rec_type,
                                P_LINE_TBL      OUT NOCOPY oe_order_pub.line_tbl_type,
                                P_MSG           OUT VARCHAR2
                                )
AS
   -- CURSOR FOR HEADER DETAILS OF ORIGINAL ORDER
   CURSOR C_HDR(P_ORDER_ID NUMBER) IS
      SELECT *
        FROM oe_order_headers_all
       WHERE header_id = P_ORDER_ID;
   -- CURSOR FOR LINE DETAILS OF ORIGINAL ORDER LINE
   CURSOR C_LINE(P_ORDER_ID NUMBER, P_LINE_ID NUMBER) IS
      SELECT *
        FROM oe_order_lines_all
       WHERE header_id = P_ORDER_ID
         AND line_id = P_LINE_ID;
BEGIN
   -- INITIALIZE HEADER RECORD
   P_HEADER_REC := OE_ORDER_PUB.G_MISS_HEADER_REC;
   -- INITIALIZE LINE RECORD(S)
--   P_LINE_TBL.EXTEND(1);
   P_LINE_TBL(1) := OE_ORDER_PUB.G_MISS_LINE_REC;
   -- POPULATE REQUIRED HEADER DATA
   P_HEADER_REC.operation := OE_GLOBALS.G_OPR_CREATE;
   -- GET ORDER TYPE
   SELECT tag
     INTO P_HEADER_REC.order_type_id
     FROM fnd_lookup_values
    WHERE lookup_type = 'GEAE_MYGE_DISPUTE_ORDER_TYPES'
      AND lookup_code = P_OU_ID||'-CUSTOMER RETURN';
   -- GET ORDER SOURCE
   --MYJIRATEST-5845 Ravi S 10-FEB-2015
   BEGIN
      SELECT oos.order_source_id
        INTO P_HEADER_REC.order_source_id
        FROM oe_order_sources oos, fnd_lookup_values flv
       WHERE oos.name = flv.description
         AND flv.lookup_type = 'GEAE_MYGE_ORDER_SOURCE'
         AND flv.lookup_code = P_OU_ID;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         P_MSG := GET_ERR_MSG(8059);
   END;
   FOR r_hdr IN C_HDR(P_ORIG_ORDER_ID) LOOP
      P_HEADER_REC.cust_po_number := r_hdr.cust_po_number;
      P_HEADER_REC.sold_to_org_id := r_hdr.sold_to_org_id;
      P_HEADER_REC.price_list_id := r_hdr.price_list_id;
      P_HEADER_REC.sold_from_org_id := r_hdr.sold_from_org_id;
      P_HEADER_REC.ship_from_org_id := GET_RETURN_WAREHOUSE(r_hdr.ship_from_org_id);
      P_HEADER_REC.ship_to_org_id := r_hdr.ship_to_org_id;
      P_HEADER_REC.salesrep_id := r_hdr.salesrep_id;
      P_HEADER_REC.context := r_hdr.context;
      P_HEADER_REC.attribute1 := r_hdr.attribute1;
      P_HEADER_REC.attribute3 := r_hdr.attribute3;
   END LOOP;
   P_HEADER_REC.source_document_id := P_ORIG_ORDER_ID;
   P_HEADER_REC.ordered_date := SYSDATE;
   P_HEADER_REC.flow_status_code:='ENTERED';
   -- POPULATE REQUIRED LINE DATA
   P_LINE_TBL(1).operation := OE_GLOBALS.G_OPR_CREATE;
   -- GET LINE TYPE
   SELECT tag
     INTO P_LINE_TBL(1).line_type_id
     FROM fnd_lookup_values
    WHERE lookup_type = 'GEAE_MYGE_DISPUTE_LINE_TYPES'
      AND lookup_code = P_OU_ID||'-RECEIVE AND CREDIT';
   FOR r_line IN C_LINE(P_ORIG_ORDER_ID,P_ORIG_LINE_ID) LOOP
      P_LINE_TBL(1).inventory_item_id := r_line.inventory_item_id;
      P_LINE_TBL(1).ship_from_org_id := GET_RETURN_WAREHOUSE(r_line.ship_from_org_id);
      P_LINE_TBL(1).calculate_price_flag := g_calc_price;
      P_LINE_TBL(1).attribute1 := r_line.attribute1;
      P_LINE_TBL(1).ordered_quantity := P_BB_QTY;
      P_LINE_TBL(1).customer_line_number := r_line.customer_line_number;
      P_LINE_TBL(1).context := r_line.context;
      -- GET COUNTRY OF ORIGIN
      --MYJIRATEST-4756 Ravi S 11-FEB-2015
      BEGIN
         SELECT DISTINCT wdd.attribute6
           INTO P_LINE_TBL(1).return_attribute3
           FROM wsh_delivery_details wdd, oe_order_lines_all ool
          WHERE wdd.source_header_id = P_ORIG_ORDER_ID
            AND wdd.source_line_id = ool.line_id
            AND DECODE(r_line.item_type_code,'MODEL',ool.top_model_line_id,ool.line_id) = P_ORIG_LINE_ID;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            P_MSG := GET_ERR_MSG(8039);
         WHEN TOO_MANY_ROWS THEN
            P_LINE_TBL(1).return_attribute3 := NULL;
            /*P_MSG := GET_ERR_MSG(8040);*/
      END;
   END LOOP;
   SELECT cmr.lookup_code
     INTO P_LINE_TBL(1).return_reason_code
     FROM fnd_lookup_values cmr, fnd_lookup_values drr
    WHERE cmr.lookup_type = 'CREDIT_MEMO_REASON'
      AND drr.lookup_type = 'GEAE_MYGE_DISPUTE_RET_REASON'
      AND cmr.meaning = drr.description
      AND drr.lookup_code = P_OU_ID||'-BUYBACK';
   --P_LINE_TBL(1).return_reason_code := '001'; --from lookup
   P_LINE_TBL(1).return_attribute1 := P_ORIG_ORDER_ID;
   P_LINE_TBL(1).return_attribute2 := P_ORIG_LINE_ID;
   P_LINE_TBL(1).return_context := 'ORDER';
   P_LINE_TBL(1).reference_header_id := P_ORIG_ORDER_ID;
   P_LINE_TBL(1).reference_line_id := P_ORIG_LINE_ID;
   P_LINE_TBL(1).line_category_code := 'RETURN';
   P_LINE_TBL(1).source_document_line_id := P_ORIG_LINE_ID;
END LOAD_BUYBACK_OBJ;

PROCEDURE LOAD_PRICING_ERR_OBJ  (
                                P_OU_ID         NUMBER,
                                P_ORIG_ORDER_ID NUMBER,
                                P_ORIG_LINE_ID  NUMBER,
                                P_PE_EXP_PRICE  NUMBER,
                                P_HEADER_REC    OUT NOCOPY oe_order_pub.header_rec_type,
                                P_LINE_TBL      OUT NOCOPY oe_order_pub.line_tbl_type,
                                P_MSG           OUT VARCHAR2
                                )
AS
   -- CURSOR FOR HEADER DETAILS OF ORIGINAL ORDER
   CURSOR C_HDR(P_ORDER_ID NUMBER) IS
      SELECT *
        FROM oe_order_headers_all
       WHERE header_id = P_ORDER_ID;
   -- CURSOR FOR LINE DETAILS OF ORIGINAL ORDER LINE
   CURSOR C_LINE(P_ORDER_ID NUMBER, P_LINE_ID NUMBER) IS
      SELECT *
        FROM oe_order_lines_all
       WHERE header_id = P_ORDER_ID
         AND line_id = P_LINE_ID;
BEGIN
   -- INITIALIZE HEADER RECORD
   P_HEADER_REC := OE_ORDER_PUB.G_MISS_HEADER_REC;
   -- INITIALIZE LINE RECORD(S)
--   P_LINE_TBL.EXTEND(2);
   P_LINE_TBL(1) := OE_ORDER_PUB.G_MISS_LINE_REC;
   P_LINE_TBL(2) := OE_ORDER_PUB.G_MISS_LINE_REC;
   -- POPULATE REQUIRED HEADER DATA
   P_HEADER_REC.operation := OE_GLOBALS.G_OPR_CREATE;
   -- GET ORDER TYPE
   SELECT tag
     INTO P_HEADER_REC.order_type_id
     FROM fnd_lookup_values
    WHERE lookup_type = 'GEAE_MYGE_DISPUTE_ORDER_TYPES'
      AND lookup_code = P_OU_ID||'-CREDIT AND BILL';
   -- GET ORDER SOURCE
   --MYJIRATEST-5845 Ravi S 10-FEB-2015
   BEGIN
      SELECT oos.order_source_id
        INTO P_HEADER_REC.order_source_id
        FROM oe_order_sources oos, fnd_lookup_values flv
       WHERE oos.name = flv.description
         AND flv.lookup_type = 'GEAE_MYGE_ORDER_SOURCE'
         AND flv.lookup_code = P_OU_ID;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         P_MSG := GET_ERR_MSG(8059);
   END;
   FOR r_hdr IN C_HDR(P_ORIG_ORDER_ID) LOOP
      P_HEADER_REC.cust_po_number := r_hdr.cust_po_number;
      P_HEADER_REC.sold_to_org_id := r_hdr.sold_to_org_id;
      P_HEADER_REC.price_list_id := r_hdr.price_list_id;
      P_HEADER_REC.sold_from_org_id := r_hdr.sold_from_org_id;
      P_HEADER_REC.ship_from_org_id := r_hdr.ship_from_org_id;
      P_HEADER_REC.ship_to_org_id := r_hdr.ship_to_org_id;
      P_HEADER_REC.salesrep_id := r_hdr.salesrep_id;
      P_HEADER_REC.context := r_hdr.context;
      P_HEADER_REC.attribute1 := r_hdr.attribute1;
      P_HEADER_REC.attribute3 := r_hdr.attribute3;
   END LOOP;
   P_HEADER_REC.ordered_date := SYSDATE;
   P_HEADER_REC.flow_status_code := 'ENTERED';
   -- POPULATE REQUIRED LINE DATA
   P_LINE_TBL(1).operation := OE_GLOBALS.G_OPR_CREATE;
   P_LINE_TBL(2).operation := OE_GLOBALS.G_OPR_CREATE;
   -- GET LINE TYPE
   SELECT tag
     INTO P_LINE_TBL(1).line_type_id
     FROM fnd_lookup_values
    WHERE lookup_type = 'GEAE_MYGE_DISPUTE_LINE_TYPES'
      AND lookup_code = P_OU_ID||'-CREDIT ONLY';
   SELECT tag
     INTO P_LINE_TBL(2).line_type_id
     FROM fnd_lookup_values
    WHERE lookup_type = 'GEAE_MYGE_DISPUTE_LINE_TYPES'
      AND lookup_code = P_OU_ID||'-BILL ONLY';
   FOR r_line IN C_LINE(P_ORIG_ORDER_ID,P_ORIG_LINE_ID) LOOP
      P_LINE_TBL(1).inventory_item_id := r_line.inventory_item_id;
--      P_LINE_TBL(1).ship_from_org_id := r_line.ship_from_org_id;
      P_LINE_TBL(1).calculate_price_flag := g_calc_price;
      P_LINE_TBL(1).attribute1 := r_line.attribute1;
      P_LINE_TBL(1).ordered_quantity := r_line.ordered_quantity;
      P_LINE_TBL(1).customer_line_number := r_line.customer_line_number;
      -- GET COUNTRY OF ORIGIN
      --MYJIRATEST-4756 Ravi S 11-FEB-2015
      BEGIN
         SELECT DISTINCT wdd.attribute6
           INTO P_LINE_TBL(1).return_attribute3
           FROM wsh_delivery_details wdd, oe_order_lines_all ool
          WHERE wdd.source_header_id = P_ORIG_ORDER_ID
            AND wdd.source_line_id = ool.line_id
            AND DECODE(r_line.item_type_code,'MODEL',ool.top_model_line_id,ool.line_id) = P_ORIG_LINE_ID;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            P_MSG := GET_ERR_MSG(8039);
         WHEN TOO_MANY_ROWS THEN
            P_LINE_TBL(1).return_attribute3 := NULL;
            /*P_MSG := GET_ERR_MSG(8040);*/
      END;
      P_LINE_TBL(2).inventory_item_id := r_line.inventory_item_id;
      P_LINE_TBL(2).ship_from_org_id := GET_RETURN_WAREHOUSE(r_line.ship_from_org_id);
      P_LINE_TBL(2).calculate_price_flag := g_freeze_price;
      P_LINE_TBL(2).attribute1 := r_line.attribute1;
      P_LINE_TBL(2).ordered_quantity := r_line.ordered_quantity;
      P_LINE_TBL(2).customer_line_number := r_line.customer_line_number;
      P_LINE_TBL(2).unit_selling_price := P_PE_EXP_PRICE;
   END LOOP;
   SELECT cmr.lookup_code
     INTO P_LINE_TBL(1).return_reason_code
     FROM fnd_lookup_values cmr, fnd_lookup_values drr
    WHERE cmr.lookup_type = 'CREDIT_MEMO_REASON'
      AND drr.lookup_type = 'GEAE_MYGE_DISPUTE_RET_REASON'
      AND cmr.meaning = drr.description
      AND drr.lookup_code = P_OU_ID||'-PRICE';
   --P_LINE_TBL(1).return_reason_code := '001'; --from lookup
   P_LINE_TBL(1).return_attribute1 := P_ORIG_ORDER_ID;
   P_LINE_TBL(1).return_attribute2 := P_ORIG_LINE_ID;
   P_LINE_TBL(1).return_context := 'ORDER';
   P_LINE_TBL(1).reference_header_id := P_ORIG_ORDER_ID;
   P_LINE_TBL(1).reference_line_id := P_ORIG_LINE_ID;
   P_LINE_TBL(1).line_category_code := 'RETURN';
END LOAD_PRICING_ERR_OBJ;


PROCEDURE ADD_ATTACHMENT        (
                                --Input Parameters
                                P_ORDER_ID IN NUMBER,
                                P_FILE IN BLOB,
                                P_TEXT IN VARCHAR2,
                                P_TYPE IN VARCHAR2,
                                P_FNAME IN VARCHAR2,
                                P_USER_ID IN NUMBER,
                                --Output Parameters
                                P_STATUS OUT VARCHAR2
                                )
AS
   l_name              VARCHAR2 (100);
   l_doc_size          NUMBER;
   x_access_id         NUMBER;
   x_file_id           NUMBER;
   l_file_name         VARCHAR2 (100);
   l_blob_data         BLOB;
   l_len               NUMBER;
   l_error             VARCHAR2 (2000);
   x_errbuf            VARCHAR2 (200);
   l_datatype_id       NUMBER;
   l_text              VARCHAR2(500);
   l_blob_sample       BLOB;
   l_attach_count      NUMBER;
   l_seq_num           NUMBER;
   l_file_type         VARCHAR2(200);
   l_file_format       VARCHAR2(100);
   l_file_id           NUMBER;
   l_entity_name       VARCHAR2(100); --MYJIRATEST-4775 Neelima Y 28-OCT-2015
BEGIN

   --Fetching Sequence Number
   SELECT NVL(MAX(SEQ_NUM),0)+10
     INTO l_seq_num
     FROM FND_ATTACHED_DOCUMENTS
    WHERE PK1_VALUE=P_ORDER_ID;

   --According to the type of data attachment datatype_id will be assigned
   IF P_TYPE='FILE' THEN
      l_file_name := P_FNAME;
      BEGIN
         SELECT description
           INTO l_file_type
           FROM fnd_lookup_values
          WHERE lookup_type = 'GEAE_MYGE_DSPT_FILE_TYPE'
            AND lookup_code = upper(substr(P_FNAME,INSTR(P_FNAME,'.',-1)));
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            l_file_type := 'application/octet-stream';
      END;
      SELECT fnd_lobs_s.nextval INTO l_file_id FROM DUAL;
      SELECT fnd_gfm.set_file_format(l_file_type) INTO l_file_format FROM DUAL;
      INSERT INTO fnd_lobs (file_id,file_name,file_content_type,file_data,upload_date,file_format)
                     VALUES(l_file_id,l_file_name,l_file_type,P_FILE,sysdate,l_file_format);
      l_datatype_id := 6;
      l_text:=NULL;
      l_entity_name:='OE_ORDER_HEADERS';
   ELSIF P_TYPE='SELECTED_SNO' THEN
      l_file_name := 'Selected Serial Number List';
      l_datatype_id:=2;
      l_text:=P_TEXT;
      l_entity_name:='OE_ORDER_HEADERS';
   ELSIF P_TYPE='RECEIVED_SNO' THEN
      l_file_name := 'Received Serial Number List';
      l_datatype_id:=2;
      l_text:=P_TEXT;
      l_entity_name:='OE_ORDER_HEADERS';
   ELSIF P_TYPE='COMMENTS' THEN
      l_file_name := 'Return Comments';
      l_datatype_id:=2;
      l_text:=P_TEXT;
      l_entity_name:='OE_ORDER_LINES'; --MYJIRATEST-4775 Neelima Y 28-OCT-2015
   ELSIF P_TYPE='REQUESTED_BY' THEN
      l_file_name := 'Requested By';
      l_datatype_id:=2;
      l_text:=P_TEXT;
      l_entity_name:='OE_ORDER_HEADERS';
   END IF;

   --Creating accessID and fileID
   BEGIN
      x_access_id := fnd_gfm.authorize(l_file_id);
      DBMS_OUTPUT.put_line ('Access id :' || x_access_id);
      -- The function fnd_gfm.confirm_upload return the file id
      x_file_id :=
        fnd_gfm.confirm_upload (access_id            => x_access_id
                              , file_name            => l_file_name
                              , program_name         => 'TEST'
                              , program_tag          => 'TEST'
                              , expiration_date      => NULL
                              , LANGUAGE             => 'US'
                              , wakeup               => TRUE
                               );
      DBMS_OUTPUT.put_line ('File id :' || x_file_id);
   EXCEPTION
      WHEN OTHERS THEN
         x_errbuf := 'Procedure upload_file errored out with the following error : ' || SQLERRM;
         DBMS_OUTPUT.put_line (x_errbuf);
   END;

   --Calling API to attach file to order
   fnd_webattch.add_attachment (      seq_num                   => l_seq_num
                                     ,category_id               => 1000503
                                     ,document_description      => l_file_name
                                     ,datatype_id               => l_datatype_id
                                     ,text                      => l_text
                                     ,file_name                 => l_file_name
                                     ,url                       => NULL
                                     ,function_name             => 'OEXOEORD'
                                     ,entity_name               => l_entity_name--'OE_ORDER_HEADERS' MYJIRATEST-4775 Neelima Y 28-OCT-2015
                                     ,pk1_value                 => P_ORDER_ID
                                     ,pk2_value                 => NULL
                                     ,pk3_value                 => NULL
                                     ,pk4_value                 => NULL
                                     ,pk5_value                 => NULL
                                     ,media_id                  => l_file_id
                                     ,user_id                   => P_USER_ID
                                     ,usage_type                => 'O'
                                     );

   SELECT COUNT (1) INTO l_attach_count
     FROM FND_ATTACHED_DOCUMENTS
    WHERE SEQ_NUM=l_seq_num AND PK1_VALUE=P_ORDER_ID;
   --Check if the file is attached
   IF l_attach_count = 0 THEN
      DBMS_OUTPUT.put_line ('error in loading the attachement');
      P_STATUS:='N';
   ELSE
      DBMS_OUTPUT.put_line ('File Attached!');
      P_STATUS:='Y';
   END IF;

END ADD_ATTACHMENT;

FUNCTION GET_ERR_MSG            (P_ERR_CODE IN NUMBER)
    RETURN VARCHAR2
AS
   V_MSG VARCHAR2(2000);
BEGIN
   SELECT LOOKUP_CODE
            || ':'
            || DESCRIPTION
     INTO V_MSG
     FROM FND_LOOKUP_VALUES
    WHERE LOOKUP_TYPE = 'GEAE_MYGE_ERROR_CODES'
      AND UPPER(LOOKUP_CODE) = UPPER(P_ERR_CODE);
    RETURN V_MSG;
EXCEPTION
   WHEN NO_DATA_FOUND THEN
      RETURN NULL;
END GET_ERR_MSG;

PROCEDURE CREATE_DISPUTE_ORDER_WS(
                                --Standard Parameters
                                P_SSO           VARCHAR2,
                                P_IACO_CODE     VARCHAR2,
                                P_CUST_ID       V_CUST_ID_ARRAY,
                                P_ROLE          VARCHAR2,
                                P_OU_ID         VARCHAR2,
                                --Input Parameters
                                P_ORIG_ORDER_ID NUMBER,
                                P_ORIG_LINE_ID  NUMBER,
                                P_DISPUTE       VARCHAR2,
                                P_SND_ATT_SLLST VARCHAR2,
                                P_SND_ATT_RCLST VARCHAR2,
                                P_SND_ATT_FNAME VARCHAR2,
                                P_SND_ATT_FILE  BLOB,
                                P_DD_PN_RCVD    VARCHAR2,
                                P_DD_QTY_RCVD   NUMBER,
                                P_REPLACE       VARCHAR2,
                                P_UD_QTY_RCVD   NUMBER,
                                P_OD_QTY_RCVD   NUMBER,
                                P_BB_REQ_BY     VARCHAR2,
                                P_BB_QTY        NUMBER,
                                P_PE_EXP_PRICE  NUMBER,
                                P_ATT_COMMENTS  VARCHAR2,
                                --Output Parameters
                                P_ORDER_NUMBER  OUT NUMBER,
                                P_ORDER_TYPE    OUT VARCHAR2,
                                P_MSG           OUT VARCHAR2,
                                P_STATUS        OUT VARCHAR2,
                                P_ORIG_PO_NUM   OUT VARCHAR2,
                                P_ORIG_PO_LNUM  OUT VARCHAR2,
                                P_ORDER_VALUE   OUT NUMBER,
                                P_ORDER_ID      OUT NUMBER --MYJIRATEST-4507 Ravi S 18-NOV-2014
                                )
AS
  l_try_count NUMBER := 5;
  l_count NUMBER := 1;
BEGIN
   WHILE l_count < l_try_count LOOP
      CREATE_DISPUTE_ORDER(P_SSO,P_IACO_CODE,P_CUST_ID,P_ROLE,P_OU_ID,
                           P_ORIG_ORDER_ID,P_ORIG_LINE_ID,P_DISPUTE,
                           P_SND_ATT_SLLST,P_SND_ATT_RCLST,P_SND_ATT_FNAME,P_SND_ATT_FILE,
                           P_DD_PN_RCVD,P_DD_QTY_RCVD,
                           P_REPLACE,
                           P_UD_QTY_RCVD,
                           P_OD_QTY_RCVD,
                           P_BB_REQ_BY,P_BB_QTY,
                           P_PE_EXP_PRICE,P_ATT_COMMENTS,
                           P_ORDER_NUMBER,P_ORDER_TYPE,
                           P_MSG,P_STATUS,
                           P_ORIG_PO_NUM,P_ORIG_PO_LNUM,
                           P_ORDER_VALUE,P_ORDER_ID);
      IF P_MSG LIKE '%Validation failed for the field - Order Type%'
      OR P_MSG LIKE '%Validation failed for the field - Salesperson%'
      OR P_MSG LIKE '%Validation failed for the field - Line Type%' THEN
         l_count := l_count + 1;
      ELSE
         l_count := 6;
      END IF;
   END LOOP;
END CREATE_DISPUTE_ORDER_WS;

FUNCTION GET_RETURN_WAREHOUSE (P_IN_WAREHOUSE IN NUMBER) RETURN NUMBER
AS
   l_out_warehouse NUMBER;
BEGIN
   BEGIN
      SELECT mpo.organization_id
        INTO l_out_warehouse
        FROM mtl_parameters mpo, mtl_parameters mpi, fnd_lookup_values wh_trans
       WHERE mpi.organization_code = wh_trans.lookup_code
         AND mpo.organization_code = wh_trans.tag
         AND mpi.organization_id = P_IN_WAREHOUSE
         AND wh_trans.lookup_type = 'GEAE_WSH_ACPT_RTRNS_LKP'
         AND wh_trans.enabled_flag = 'Y'
         AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(wh_trans.start_date_active,SYSDATE)) AND TRUNC(NVL(wh_trans.end_date_active,SYSDATE));
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         l_out_warehouse := P_IN_WAREHOUSE;
   END;
   RETURN l_out_warehouse;
END GET_RETURN_WAREHOUSE;


-------------------------------------------------------------------------------------------------------------------


PROCEDURE GET_LABEL_INFORMATION (
                                 --Standard Parameters
                                 P_SSO           VARCHAR2,
                                 P_IACO_CODE     VARCHAR2,
                                 P_CUST_ID       V_CUST_ID_ARRAY,
                                 P_ROLE          VARCHAR2,
                                 P_OU_ID         VARCHAR2,
                                 --Input Parameters
                                 P_ORDER_ID      NUMBER,
                                 --Output Parameters
                                 P_RMA_NUMBER    OUT NUMBER,
                                 P_PO_NUMBER     OUT VARCHAR2,
                                 P_PART_NUMBER   OUT VARCHAR2,
                                 P_QUANTITY      OUT NUMBER,
                                 P_REASON        OUT VARCHAR2,
                                 P_COO           OUT VARCHAR2,
                                 P_MSG           OUT VARCHAR2
                                 )
AS
   l_cust_id NUMBER;
   l_authorized VARCHAR2(1);
   l_ret_reason VARCHAR2(50);
   v_OU_ID      VARCHAR2(50);  --US230170; Manisha K; 26-Nov; Added the variable to save OU_ID
   
   
BEGIN

/********************************************************
  US230170; Manisha K. 11-NOV-2018 Passport Requirements. Two OU_ID will be passed for input parameter P_OU_ID
  Added below code to find OU_ID using dispute_header_id
  ********************************************************/
  
IF P_OU_ID like '%~%' THEN
      BEGIN
      SELECT ooh.org_Id
      INTO v_OU_ID
      FROM oe_order_headers_all ooh
      WHERE ooh.header_id = P_ORDER_ID;
      EXCEPTION
      WHEN OTHERS THEN
      P_MSG := 'Error while fetching the OU_ID: '||SQLCODE||SQLERRM;
      GOTO end_proc;
      END;
  ELSE
    v_OU_ID := P_OU_ID;
  END IF;

   IF v_ou_id IS NULL THEN
      P_MSG := GET_ERR_MSG(8503);
         GOTO end_proc;

    END IF;


   -- CHECK IF ORDER EXISTS AND AUTHORIZATION
   
   BEGIN
      SELECT sold_to_org_id, order_number, cust_po_number
        INTO l_cust_id, P_RMA_NUMBER, P_PO_NUMBER
        FROM oe_order_headers_all
       WHERE header_id = P_ORDER_ID
         AND org_id = v_OU_ID; ---P_OU_ID;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         P_MSG := 'Order does not exist';
         GOTO end_proc;
   END;
   l_authorized := 'N';
   FOR i IN 1..P_CUST_ID.COUNT LOOP
      IF P_CUST_ID(i) = l_cust_id THEN
         l_authorized := 'Y';
      END IF;
   END LOOP;
   IF l_authorized = 'N' THEN
      p_MSG:=GET_ERR_MSG(8180);
      P_RMA_NUMBER := NULL;
      P_PO_NUMBER := NULL;
      goto end_proc;
   END IF;
   
   --START LOGIC TO DETERMINE TYPE OF DISPUTE
   BEGIN
      SELECT DISTINCT(SUBSTR(ret.lookup_code,INSTR(ret.lookup_code,'-')+1))
        INTO l_ret_reason
        FROM fnd_lookup_values ret, oe_order_lines_all ool, fnd_lookup_values cmr
       WHERE ool.header_id = P_ORDER_ID
         AND ool.return_reason_code = cmr.lookup_code
         AND ret.description = cmr.meaning
         AND cmr.lookup_type = 'CREDIT_MEMO_REASON'
         AND ret.lookup_type = 'GEAE_MYGE_DISPUTE_RET_REASON'
         AND SUBSTR(ret.lookup_code,1,INSTR(ret.lookup_code,'-')-1) = v_OU_ID   --P_OU_ID
         AND ret.enabled_flag = 'Y'
         AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(ret.start_date_active,SYSDATE)) AND TRUNC(NVL(ret.end_date_active,SYSDATE))
         AND cmr.enabled_flag = 'Y'
         AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(cmr.start_date_active,SYSDATE)) AND TRUNC(NVL(cmr.end_date_active,SYSDATE))
         AND rownum = 1;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         l_ret_reason := NULL;
   END;
   IF l_ret_reason IS NULL THEN
      P_RMA_NUMBER := NULL;
      P_PO_NUMBER := NULL;
      goto end_ret;
   END IF;
   IF l_ret_reason = 'OVERAGE' OR l_ret_reason = 'DISCREPANCY' OR l_ret_reason = 'BUYBACK' THEN
      P_REASON := l_ret_reason;
   ELSE
      P_RMA_NUMBER := NULL;
      P_PO_NUMBER := NULL;
      goto end_ret;
   END IF;
   
   --GET PART NUMBER, QUANTITY AND COO
   BEGIN
      SELECT ool.ordered_item, ool.ordered_quantity, ool.return_attribute3
        INTO P_PART_NUMBER, P_QUANTITY, P_COO
        FROM oe_order_lines_all ool, fnd_lookup_values ln_tp
       WHERE ool.header_id = P_ORDER_ID
         AND ool.org_id = v_OU_ID --P_OU_ID
         AND ool.line_type_id = ln_tp.tag
        -- AND ln_tp.lookup_code = P_OU_ID||DECODE(l_ret_reason,'BUYBACK','-RECEIVE AND CREDIT','-OVERAGE RETURN')
        AND ln_tp.lookup_code = v_OU_ID||DECODE(l_ret_reason,'BUYBACK','-RECEIVE AND CREDIT','-OVERAGE RETURN')
         AND ln_tp.lookup_type = 'GEAE_MYGE_DISPUTE_LINE_TYPES'
         AND ln_tp.enabled_flag = 'Y'
         AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(ln_tp.start_date_active,SYSDATE)) AND TRUNC(NVL(ln_tp.end_date_active,SYSDATE))
         AND rownum = 1;
      goto end_proc;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         P_RMA_NUMBER := NULL;
         P_PO_NUMBER := NULL;
         P_REASON := NULL;
         goto end_ret;
   END;
   <<end_ret>>
   BEGIN
      SELECT ool.ordered_item, ool.ordered_quantity, ool.return_attribute3
        INTO P_PART_NUMBER, P_QUANTITY, P_COO
        FROM oe_order_lines_all ool, fnd_lookup_values ln_tp
       WHERE ool.header_id = P_ORDER_ID
         AND ool.org_id = v_OU_ID --P_OU_ID
         AND ool.line_type_id = ln_tp.tag
         AND ln_tp.lookup_code = v_OU_ID||'-OVERAGE SCRAP' --P_OU_ID||'-OVERAGE SCRAP'
         AND ln_tp.lookup_type = 'GEAE_MYGE_DISPUTE_LINE_TYPES'
         AND ln_tp.enabled_flag = 'Y'
         AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(ln_tp.start_date_active,SYSDATE)) AND TRUNC(NVL(ln_tp.end_date_active,SYSDATE))
         AND rownum = 1;
      P_REASON := 'SCRAP';
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         P_MSG:='Not valid return or scrap scenario';
         P_RMA_NUMBER := NULL;
         P_PO_NUMBER := NULL;
         P_REASON := NULL;
         goto end_proc;
   END;
   <<end_proc>>
   NULL;
EXCEPTION
   WHEN OTHERS THEN
      P_MSG := SUBSTR(SQLERRM,1,100);
END GET_LABEL_INFORMATION;




END GEAE_MYGE_SHIPMENT_DISPUTE_PKG;






