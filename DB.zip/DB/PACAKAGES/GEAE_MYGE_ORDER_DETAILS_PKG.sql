

GEAE_MYGE_ORDER_DETAILS_PKG

create or replace PACKAGE        "GEAE_MYGE_ORDER_DETAILS_PKG" AS

	TYPE V_HDR_ARRAY IS VARRAY(250) OF V_ORDER_HDR_ARRAY;
	TYPE V_LINE_ARRAY IS VARRAY(250) OF V_ORDER_LINE_ARRAY;

FUNCTION GET_CANCEL_FLAG(P_HEADER_ID	NUMBER
	                        ,P_LINE_ID	number ) return varchar2;

	PROCEDURE GET_ORDER_DETAILS(p_SSO VARCHAR2
	                           ,P_IACO_CODE VARCHAR2
                             ,p_CUST_ID	VARCHAR2
                             ,P_ROLE	VARCHAR2
                             ,P_OU_ID	VARCHAR2
                             ,P_headerId	VARCHAR2
                             ,P_OUT_ODR_HDR  OUT	V_ORDER_HDR_ARRAY
                             --,P_OUT_ODR_LINE OUT	V_ORDER_LINE_ARRAY
                             ,p_message	   OUT VARCHAR2
				   );

 	PROCEDURE GET_ORDER_LINE_DETAILS(p_SSO VARCHAR2
	                           ,P_IACO_CODE VARCHAR2
                             ,p_CUST_ID	VARCHAR2
                             ,P_ROLE	VARCHAR2
                             ,P_OU_ID	VARCHAR2
                             ,P_HEADERID	VARCHAR2
                            -- ,P_OUT_ODR_HDR  OUT	V_ORDER_HDR_ARRAY
                             ,P_OUT_ODR_LINE OUT	V_ORDER_LINE_ARRAY
                             ,P_MESSAGE	   OUT VARCHAR2
				   );
END GEAE_MYGE_ORDER_DETAILS_PKG;