






create or replace PACKAGE BODY "GEAE_MYGE_CUST_DETAILS_PKG" AS

/*----------Change Log--------------
Date         Name              Description
03-SEP-2014  Ravi Saxena       MYJIRATEST-3173 In case of no delivery location mapped, still send mapping data with null delivery location
03-SEP-2014  Ravi Saxena       MYJIRATEST-3056 If mapping as DL as Y, dont show same mapping with DL as N
13-OCT-2014  Ravi Saxena       MYJIRATEST-3834 Mapping to include only valid ship to and deliver to addresses
16-OCT-2014  Ravi Saxena       Show mapping address if the deliver to address is null for local customers
07-NOV-2014  Ravi Saxena       Added procedure to get CAM email address based on cust id list
27-APR-2015  Ankita Shetty     Changed code to add PRIMARY FLAG for default ship_to for MYJIRATEST-7431
27-MAY-2015  Abhinav Srivastava MYJIRATEST-8449 Changes to add Ship to Address where Deliver-To is Null and a Ship-Deliver Mapping Exists
30-JUL-2015  Neelima Y         MYJIRA#6856 All customer details for global enquiry
28-NOV-2018  Manisha K         US217871; Passport Requirement; Modified the proc GET_CUSTOMER_DETAILS
                               to fetch the customer details in case of two OU_ID's passed in the input parameter P_OU_ID.
28-NOV-2018  Manisha K         US230168:Passport Requirement; Modified the proc GET_GLOBAL_CUST_DETAILS
                               to fetch the customer details in case of two OU_ID's passed in the input parameter P_OU_ID.
*/



--GET_CUSTOMER_DETAILS
--GET_CAM_EMAIL
--GET_GLOBAL_CUST_DETAILS



  PROCEDURE GET_CUSTOMER_DETAILS(p_SSO    VARCHAR2
                             ,p_IACO_CODE    VARCHAR2
           ,p_CUST_ID    V_CUST_ID_ARRAY
           ,p_ROLE    VARCHAR2
           ,p_OU_ID    VARCHAR2
           ,P_headerId    VARCHAR2
           ,p_cust_SHIP_add  OUT V_CUST_SHIPPING_ARRAY
           ,p_cust_del_add  OUT V_CUST_DELIVER_ARRAY
           ,p_cust_map_add  OUT V_CUST_MAPPING_ARRAY
           ,p_cust_gta    OUT V_CUSTOMER_GTA_ARRAY
           ,p_cust_admin  OUT V_CUSTOMER_ADMIN_ARRAY
           ,p_message     OUT VARCHAR2
           ) AS
    L_SHIP_ADD  BOOLEAN := TRUE;
    L_DEL_ADD  BOOLEAN := TRUE;
    L_MAP_ADD  BOOLEAN := TRUE;
    L_GTA_ADD  BOOLEAN := TRUE;
    L_ADMIN_ADD  BOOLEAN := TRUE;
    l_cust_Ids  VARCHAR2(32000) := NULL;


    l_ship_cnt  NUMBER := 0;
    l_del_cnt  NUMBER := 0;
    l_map_cnt  NUMBER := 0;
    l_gta_cnt  NUMBER := 0;
    l_admin_cnt  NUMBER := 0;
    v_not_match_flag BOOLEAN;

    l_cust_SHIP_add  V_CUST_SHIPPING_ARRAY := V_CUST_SHIPPING_ARRAY();
    l_cust_del_add  V_CUST_DELIVER_ARRAY := V_CUST_DELIVER_ARRAY();
    l_cust_map_add  V_CUST_MAPPING_ARRAY := V_CUST_MAPPING_ARRAY();
    l_cust_gta  V_CUSTOMER_GTA_ARRAY :=V_CUSTOMER_GTA_ARRAY();
    l_cust_admin  V_CUSTOMER_ADMIN_ARRAY:=V_CUSTOMER_ADMIN_ARRAY();

    l_shp_exists VARCHAR2(1);
    l_del_exists VARCHAR2(1);
  v_ou_id                      VARCHAR2(100)   := NULL; --US217871; Added By Manisha;05-NOV-18;Passport requirement to save the OU_ID separated by comma
  v_ou_id1                     VARCHAR2(100)   := NULL;
  v_ou_id2                     VARCHAR2(100)   := NULL;
  j_ou_id                      VARCHAr2(100)   := NULL;

  BEGIN
    p_cust_SHIP_add  := V_CUST_SHIPPING_ARRAY();
    p_cust_del_add  := V_CUST_DELIVER_ARRAY();
    p_cust_map_add  := V_CUST_MAPPING_ARRAY();
    p_cust_gta  := V_CUSTOMER_GTA_ARRAY();
    p_cust_admin  := V_CUSTOMER_ADMIN_ARRAY();

--IF p_ROLE <> 'Global Enquiry' and p_ROLE <> 'Cust Enquiry' THEN
dbms_output.put_line(p_CUST_ID.COUNT);
    IF p_CUST_ID.COUNT > 0 THEN
    l_admin_cnt        := 0;
      FOR var IN 1 .. p_CUST_ID.COUNT LOOP
           -- to fetch the customer shipping address
           dbms_output.put_line('inside');
--US217871;Manisha K. Added the below change to find the OU_ID using customer id value
IF P_OU_ID like '%~%' THEN
 v_ou_id := P_OU_ID;
 v_ou_id1 := REGEXP_SUBSTR(v_ou_id, '[^~]+', 1,1);
 v_ou_id2 :=  REGEXP_SUBSTR (v_ou_id, '[^~]+', 1, 2);

    BEGIN

    SELECT distinct hcasa.org_id
    INTO j_ou_id
    FROM  HZ_CUST_ACCOUNTS hca, HZ_CUST_ACCT_SITES_ALL HCASA
    WHERE (hcasa.org_id = to_number(v_ou_id1) or  hcasa.org_id = to_number(v_ou_id2))
    AND  NVL(HCASA.STATUS, 'I') = 'A'
    AND NVL(hca.status, 'I') = 'A'
    AND hcasa.cust_account_id = hca.cust_account_id
    and hca.cust_Account_id = to_number(p_cust_id(var));

    EXCEPTION
    WHEN OTHERS THEN
    dbms_output.put_line('Error while fetching the OU_ID: '||SQLCODE||SQLERRM);
    goto END_PROC;
    END;
IF j_ou_id IS NULL THEN
       SELECT LOOKUP_CODE || ': ' || DESCRIPTION
                INTO p_message
                FROM fnd_lookup_values
               where LOOKUP_TYPE = 'GEAE_MYGE_ERROR_CODES'
                 and UPPER(LOOKUP_CODE) = UPPER('8503');
    END IF;

ELSE
    j_ou_id :=P_OU_ID;

END IF;

      BEGIN
        SELECT V_SHIPPING_ADDRESS_LIST_BO
                     (hl.location_id --SHIP_ADDRESS_ID
                     ,HP.PARTY_NAME --ADDRESS_NAME
                     ,hcsua2.location  --ADDRESS_CODE
                     ,HL.ADDRESS1     -- address1
                     ,hl.address2    -- address2
                     ,hl.city         --city
                     ,hl.STATE       -- STATE
                     ,hl.postal_code -- ZIP
                     ,hl.COUNTRY      --COUNTRY
                     ,(SELECT DFLT_LOC FROM GEAE_ONT_CUST_SHIP_DEL_MAP
                  WHERE CUST_ACCOUNT_ID=hca.cust_account_id
                  AND SHP_TO_ST_USE_ID=hcasa2.cust_acct_site_id)-- DEFAULTIND
                     ,hca.cust_account_id
                     ,hl.address3    -- address3 AD
                     ,hl.address4    -- address4 AD
                     ,hcsua2.PRIMARY_FLAG --MYJIRATEST-7431 Ankita.S 27-APR-2015
)
         BULK COLLECT INTO l_cust_SHIP_add
        FROM hz_parties hp,
             hz_party_sites hps,
             hz_cust_accounts hca,
             hz_locations hl,
             hz_cust_acct_sites_all hcasa2,
             hz_cust_site_uses_all hcsua2
        WHERE hp.party_id = hps.party_id(+)
          AND hp.party_id = hca.party_id(+)
          AND HCASA2.PARTY_SITE_ID(+) = HPS.PARTY_SITE_ID
          and hcasa2.org_id = to_number(j_ou_id)   --to_number(p_OU_ID)
          AND hcsua2.cust_acct_site_id(+) = hcasa2.cust_acct_site_id
          AND hcsua2.site_use_code = 'SHIP_TO'   -- DELIVER_TO
          AND hps.location_id = hl.location_id
          AND NVL(hcasa2.status, 'I') = 'A'        ----Added NVL
          AND NVL(hca.status, 'I') = 'A'           ----Added NVL
          AND NVL(hcsua2.STATUS, 'I') = 'A'        ----Added NVL
          AND NVL(hps.STATUS, 'I') ='A'            ----Added NVL
          AND NVL(hp.STATUS, 'I') ='A'             ----Added NVL
           AND hca.cust_account_id=to_number(p_cust_id(var))
        order by hca.cust_account_id;
           dbms_output.put_line('C');
       EXCEPTION
         when NO_DATA_FOUND then
           NULL;
           dbms_output.put_line('A');
         WHEN OTHERS THEN
           dbms_output.put_line('An error was encountered - '|| SQLCODE ||' -ERROR- '||SQLERRM);
           NULL;
        END;

        --
        IF sql%rowcount  > 0 THEN
          for I in 1 .. L_CUST_SHIP_ADD.COUNT LOOP
            L_SHIP_CNT := L_SHIP_CNT +1;
           -- l_cust_SHIP_add.
            p_cust_SHIP_add.extend();
            p_cust_SHIP_add(l_ship_cnt) := l_cust_SHIP_add(i);
          END LOOP ;
        end if ;

           -- to fetch the customer deliver address
        SELECT V_DELIVER_ADDRESS_LIST_BO(hl.location_id --SHIP_ADDRESS_ID
                     ,HP.PARTY_NAME --ADDRESS_NAME
                     ,hcsua2.location  --ADDRESS_CODE
                     ,HL.ADDRESS1     -- address1
                     ,hl.address2    -- address2
                     ,hl.city         --city
                     ,hl.STATE       -- STATE
                     ,hl.postal_code -- ZIP
                     ,hl.COUNTRY      --COUNTRY
                     ,(SELECT DFLT_LOC FROM GEAE_ONT_CUST_SHIP_DEL_MAP
                  WHERE CUST_ACCOUNT_ID=hca.cust_account_id
                  AND SHP_TO_ST_USE_ID=hcasa2.cust_acct_site_id)-- DEFAULTIND
                     ,hca.cust_account_id
                     ,hl.address3    -- address3 AD
                     ,hl.address4    -- address4 AD
                     )
         BULK COLLECT INTO l_cust_del_add
        FROM hz_parties hp,
             hz_party_sites hps,
             hz_cust_accounts hca,
             hz_locations hl,
             hz_cust_acct_sites_all hcasa2,
             hz_cust_site_uses_all hcsua2
        WHERE hp.party_id = hps.party_id(+)
          AND hp.party_id = hca.party_id(+)
          AND HCASA2.PARTY_SITE_ID(+) = HPS.PARTY_SITE_ID
          and hcasa2.org_id = to_number(j_ou_id)  --to_number(p_OU_ID)
          AND hcsua2.cust_acct_site_id(+) = hcasa2.cust_acct_site_id
          AND hcsua2.site_use_code = 'DELIVER_TO'
          AND hps.location_id = hl.location_id
          AND NVL(hcasa2.status,'I') = 'A'      ----Added NVL
          AND NVL(hca.status, 'I') = 'A'        ----Added NVL
          AND NVL(hcsua2.STATUS, 'I') = 'A'     ----Added NVL
          AND NVL(hps.STATUS, 'I') ='A'         ----Added NVL
          AND NVL(hp.STATUS, 'I') ='A'          ----Added NVL
          AND hca.cust_account_id =p_cust_id(var)
        order by HCA.CUST_ACCOUNT_ID;

        IF sql%rowcount  > 0 THEN
          FOR i IN 1 .. l_cust_del_add.count LOOP
            l_del_cnt := l_del_cnt +1;
            p_cust_del_add.extend();
            p_cust_del_add(l_del_cnt) := l_cust_del_add(i);
          END LOOP ;
        END IF ;
           -- to fetch the mapping address
           --
        SELECT V_MAPPING_ADDRESS_LIST_BO(SHIP_LOC_ID
                  ,SHIP_LOC
                  ,SHIP_ADD --SHIP_ADDRESS1
                  ,DEL_LOC_ID
                  ,DEL_LOC
                  ,DEL_ADD --DEL_ADDRESS1
                  ,DL --DEFAULT_IND
                  ,CUST_ID)
         BULK COLLECT INTO l_cust_map_add
        FROM (
              SELECT Distinct STG.SHP_TO_LOC_ID AS SHIP_LOC_ID
                        ,STG.SHP_TO_LOC AS SHIP_LOC
                        ,SHIP_LOC.address1 AS SHIP_ADD--SHIP_ADDRESS1
                        ,STG.DEL_TO_LOC_ID AS DEL_LOC_ID
                        ,STG.DEL_TO_LOC AS DEL_LOC
                        ,DEL_LOC.address1 AS DEL_ADD --DEL_ADDRESS1
                        ,STG.DFLT_LOC AS DL--DEFAULT_IND
                        ,STG.CUST_ACCOUNT_ID AS CUST_ID
              FROM GEAE_ONT_CUST_SHIP_DEL_MAP STG
                  ,HZ_LOCATIONS SHIP_LOC
                  ,HZ_LOCATIONS DEL_LOC
              WHERE STG.SHP_TO_LOC_ID= SHIP_LOC.location_id(+)
                and STG.DEL_TO_LOC_ID= DEL_LOC.LOCATION_ID(+)
                and EXISTS (SELECT 1 FROM hz_cust_site_uses_all
                      WHERE SITE_USE_ID =STG.SHP_TO_ST_USE_ID AND Nvl(STATUS,'I')='A')
                and EXISTS (SELECT 1 FROM hz_cust_site_uses_all
                  WHERE SITE_USE_ID =NVL(STG.DEL_TO_ST_USG_ID,STG.SHP_TO_ST_USE_ID) AND Nvl(STATUS,'I')='A')
                AND STG.CUST_ACCOUNT_ID=P_CUST_ID(VAR)
                and stg.org_id = to_number(j_ou_id)  --to_number(p_OU_ID)
              --MYJIRATEST-3056 Ravi S 03-SEP-2014
              MINUS
              SELECT SHIP_LOC_ID, SHIP_LOC, SHIP_ADD, DEL_LOC_ID, DEL_LOC, DEL_ADD, 'N' DL, CUST_ID
                FROM (SELECT COUNT(1) cnt, SHIP_LOC_ID, SHIP_LOC, SHIP_ADD, DEL_LOC_ID, DEL_LOC, DEL_ADD, CUST_ID
                        FROM (SELECT Distinct
                                     STG.SHP_TO_LOC_ID AS SHIP_LOC_ID
                                    ,STG.SHP_TO_LOC AS SHIP_LOC
                                    ,SHIP_LOC.address1 AS SHIP_ADD--SHIP_ADDRESS1
                                    ,STG.DEL_TO_LOC_ID AS DEL_LOC_ID
                                    ,STG.DEL_TO_LOC AS DEL_LOC
                                    ,DEL_LOC.address1 AS DEL_ADD --DEL_ADDRESS1
                                    ,STG.DFLT_LOC AS DL--DEFAULT_IND
                                    ,STG.CUST_ACCOUNT_ID AS CUST_ID
                          FROM GEAE_ONT_CUST_SHIP_DEL_MAP STG
                              ,HZ_LOCATIONS SHIP_LOC
                              ,HZ_LOCATIONS DEL_LOC
                          WHERE STG.SHP_TO_LOC_ID= SHIP_LOC.location_id(+)
                            and STG.DEL_TO_LOC_ID= DEL_LOC.LOCATION_ID(+)
                            and EXISTS (SELECT 1 FROM hz_cust_site_uses_all
                                  WHERE SITE_USE_ID =STG.SHP_TO_ST_USE_ID AND Nvl(STATUS,'I')='A')
                            and EXISTS (SELECT 1 FROM hz_cust_site_uses_all
                              WHERE SITE_USE_ID =NVL(STG.DEL_TO_ST_USG_ID,STG.SHP_TO_ST_USE_ID) AND Nvl(STATUS,'I')='A')
                            AND STG.CUST_ACCOUNT_ID=P_CUST_ID(VAR)
                            and stg.org_id =to_number(j_ou_id) -- to_number(p_OU_ID)
                             )
                      GROUP BY SHIP_LOC_ID, SHIP_LOC, SHIP_ADD, DEL_LOC_ID, DEL_LOC, DEL_ADD, CUST_ID
                     ) WHERE cnt = 2
                );
       --
        IF sql%rowcount  > 0 THEN
          FOR i IN 1 .. l_cust_map_add.count LOOP
            --MYJIRATEST-3834 Ravi S 13-OCT-2014
            l_shp_exists := 'N';
            FOR j IN 1..p_cust_SHIP_add.COUNT LOOP
              IF l_cust_map_add(i).SHIP_ADDRESS_CODE = p_cust_SHIP_add(j).ADDRESS_CODE THEN
                l_shp_exists := 'Y';
              END IF;
            END LOOP;
      --Ravi S 16-OCT-2014
            IF l_cust_map_add(i).DEL_ADDRESS_CODE IS NULL THEN
              l_del_exists := 'Y';
      ELSE
              l_del_exists := 'N';
        FOR j IN 1..p_cust_del_add.COUNT LOOP
                IF l_cust_map_add(i).DEL_ADDRESS_CODE = p_cust_del_add(j).ADDRESS_CODE THEN
                  l_del_exists := 'Y';
                END IF;
              END LOOP;
      END IF;
            IF l_shp_exists = 'Y' AND l_del_exists = 'Y' THEN
              l_map_cnt := l_map_cnt +1;
              p_cust_map_add.extend();
              p_cust_map_add(l_map_cnt) := l_cust_map_add(i);
            END IF;
          END LOOP ;

-- Commented for MYJIRATEST-8449 Abhinav S 27-MAY-2015 Starts
       /* else
           --MYJIRATEST-3173 Ravi S 03-SEP-2014
           SELECT V_MAPPING_ADDRESS_LIST_BO(SHIP_LOC_ID
                 ,SHIP_LOC
                 ,SHIP_ADD --SHIP_ADDRESS1
                 ,DEL_LOC_ID
                 ,DEL_LOC
                 ,DEL_ADD --DEL_ADDRESS1
                 ,DL --DEFAULT_IND
                 ,CUST_ID)
            BULK COLLECT INTO l_cust_map_add
           FROM (
              SELECT Distinct STG.SHP_TO_LOC_ID AS SHIP_LOC_ID
                        ,STG.SHP_TO_LOC AS SHIP_LOC
                        ,SHIP_LOC.address1 AS SHIP_ADD--SHIP_ADDRESS1
                        ,STG.DEL_TO_LOC_ID AS DEL_LOC_ID
                        ,STG.DEL_TO_LOC AS DEL_LOC
                        ,DEL_LOC.address1 AS DEL_ADD --DEL_ADDRESS1
                        ,STG.DFLT_LOC AS DL--DEFAULT_IND
                        ,STG.CUST_ACCOUNT_ID AS CUST_ID
              FROM GEAE_ONT_CUST_SHIP_DEL_MAP STG
                  ,HZ_LOCATIONS SHIP_LOC
                  ,HZ_LOCATIONS DEL_LOC
              WHERE STG.SHP_TO_LOC_ID= SHIP_LOC.location_id(+)
                and STG.DEL_TO_LOC_ID= DEL_LOC.LOCATION_ID(+)
                and EXISTS (SELECT 1 FROM hz_cust_site_uses_all
                      WHERE SITE_USE_ID =STG.SHP_TO_ST_USE_ID AND Nvl(STATUS,'I')='A')
                AND STG.CUST_ACCOUNT_ID=P_CUST_ID(VAR)
                and stg.org_id = to_number(p_OU_ID)
              --MYJIRATEST-3056 Ravi S 03-SEP-2014
              MINUS
              SELECT SHIP_LOC_ID, SHIP_LOC, SHIP_ADD, DEL_LOC_ID, DEL_LOC, DEL_ADD, 'N' DL, CUST_ID
                FROM (SELECT COUNT(1) cnt, SHIP_LOC_ID, SHIP_LOC, SHIP_ADD, DEL_LOC_ID, DEL_LOC, DEL_ADD, CUST_ID
                        FROM (SELECT Distinct
                                     STG.SHP_TO_LOC_ID AS SHIP_LOC_ID
                                    ,STG.SHP_TO_LOC AS SHIP_LOC
                                    ,SHIP_LOC.address1 AS SHIP_ADD--SHIP_ADDRESS1
                                    ,STG.DEL_TO_LOC_ID AS DEL_LOC_ID
                                    ,STG.DEL_TO_LOC AS DEL_LOC
                                    ,DEL_LOC.address1 AS DEL_ADD --DEL_ADDRESS1
                                    ,STG.DFLT_LOC AS DL--DEFAULT_IND
                                    ,STG.CUST_ACCOUNT_ID AS CUST_ID
                          FROM GEAE_ONT_CUST_SHIP_DEL_MAP STG
                              ,HZ_LOCATIONS SHIP_LOC
                              ,HZ_LOCATIONS DEL_LOC
                          WHERE STG.SHP_TO_LOC_ID= SHIP_LOC.location_id(+)
                            and STG.DEL_TO_LOC_ID= DEL_LOC.LOCATION_ID(+)
                            and EXISTS (SELECT 1 FROM hz_cust_site_uses_all
                                  WHERE SITE_USE_ID =STG.SHP_TO_ST_USE_ID AND Nvl(STATUS,'I')='A')
                            AND STG.CUST_ACCOUNT_ID=P_CUST_ID(VAR)
                            and stg.org_id = to_number(p_OU_ID)
                             )
                      GROUP BY SHIP_LOC_ID, SHIP_LOC, SHIP_ADD, DEL_LOC_ID, DEL_LOC, DEL_ADD, CUST_ID
                     ) WHERE cnt = 2
                );
           IF sql%rowcount  > 0 THEN
             FOR i IN 1 .. l_cust_map_add.count LOOP
               --MYJIRATEST-3834 Ravi S 13-OCT-2014
               l_shp_exists := 'N';
               FOR j IN 1..p_cust_SHIP_add.COUNT LOOP
                 IF l_cust_map_add(i).SHIP_ADDRESS_CODE = p_cust_SHIP_add(j).ADDRESS_CODE THEN
                   l_shp_exists := 'Y';
                 END IF;
               END LOOP;
         --Ravi S 16-OCT-2014
               IF l_cust_map_add(i).DEL_ADDRESS_CODE IS NULL THEN
                 l_del_exists := 'Y';
         ELSE
                 l_del_exists := 'N';
           FOR j IN 1..p_cust_del_add.COUNT LOOP
                   IF l_cust_map_add(i).DEL_ADDRESS_CODE = p_cust_del_add(j).ADDRESS_CODE THEN
                     l_del_exists := 'Y';
                   END IF;
                 END LOOP;
         END IF;
               IF l_shp_exists = 'Y' AND l_del_exists = 'Y' THEN
                  l_map_cnt := l_map_cnt +1;
                  p_cust_map_add.extend();
               p_cust_map_add(l_map_cnt) := l_cust_map_add(i);
               END IF;
             END LOOP ;
           END IF;*/
-- Commented for MYJIRATEST-8449 Abhinav S 27-MAY-2015 Ends
        end if ;
        --
           -- to fetch the customer GTA details
        SELECT V_CUST_GTA_LIST_BO(GOCG.gta_number-- GTA_NUMBER
               ,hca.ACCOUNT_NUMBER --CUST_ACCOUNT
               ,GOCG.start_date --START_DATE
               ,GOCG.end_date --EXP_DATE
               ,gogm.ENTY_CD  -- CONTRACT_PRODUCT
               ,hca.CUST_ACCOUNT_ID) -- CUSTID
         BULK COLLECT INTO l_cust_gta
        FROM hz_cust_accounts hca
            ,GEAE_ONT_CUST_GTA_INFO GOCG
            ,geae_ont_gta_model gogm
        WHERE hca.CUST_ACCOUNT_ID = GOCG.CUSTOMER_ID(+)
          AND GOGM.GEAE_ONT_CUST_GTA_INFO_SEQ_ID= GOCG.GEAE_ONT_CUST_GTA_INFO_SEQ_ID
          and GOCG.org_id =  to_number(j_ou_id)  --to_number(p_OU_ID)
          and NVL(GOCG.END_DATE,sysdate +1) >= sysdate
          AND nvl(gocg.start_date,sysdate) <= SYSDATE
          and CUST_ACCOUNT_ID = P_CUST_ID(VAR);
      --
        IF sql%rowcount  > 0 THEN
          FOR i IN 1 .. l_cust_gta.count LOOP
            l_gta_cnt := l_gta_cnt +1;
            p_cust_gta.extend();
            p_cust_gta(l_gta_cnt) := l_cust_gta(i);
          END LOOP ;
        END IF ;
           -- to fetch the customer admin details
           --
        /*SELECT V_CUST_ADMIN_LIST_BO(hp.party_name --customer_name
              ,hcp.EMAIL_ADDRESS
              ,hcp.phone_number
              ,cust.cust_account_id)
          BULK COLLECT INTO l_cust_admin
        FROM hz_parties hp
            ,hz_relationships hr
            ,hz_parties h_contact
            ,hz_contact_points hcp
            ,hz_cust_accounts cust
        WHERE 1=1
          and hr.subject_id = h_contact.PARTY_ID
          and hr.object_id = hp.party_id
          and hcp.owner_table_id = hr.party_id
          and cust.party_id = hp.party_id
          --and hcp.CONTACT_POINT_TYPE ='EMAIL'
          and NVL(hcp.STATUS, 'I') = 'A'         ----Added NVL
          and CUST.CUST_ACCOUNT_ID =P_CUST_ID(VAR);*/

        l_cust_admin := V_CUSTOMER_ADMIN_ARRAY();

        SELECT V_CUST_ADMIN_LIST_BO((SELECT max(RESOURCE_NAME) FROM JTF_RS_DEFRESOURCES_VL WHERE RESOURCE_ID=SR.RESOURCE_ID)
                                    ,Nvl((SELECT max(SOURCE_EMAIL) FROM JTF_RS_DEFRESOURCES_VL WHERE RESOURCE_ID=SR.RESOURCE_ID),SR.EMAIL_ADDRESS) --SOURCE_EMAIL
                                    ,(SELECT max(SOURCE_PHONE) FROM JTF_RS_DEFRESOURCES_VL WHERE RESOURCE_ID=SR.RESOURCE_ID)                       --SOURCE_PHONE
                                    ,hca.cust_account_id)
              BULK COLLECT INTO l_cust_admin
        FROM hz_parties hp,
             hz_party_sites hps,
             hz_cust_accounts hca,
             hz_locations hl,
             hz_cust_acct_sites_all hcasa2,
             hz_cust_site_uses_all hcsua2,
             JTF_RS_SALESREPS SR
        WHERE hp.party_id = hps.party_id(+)
          AND hp.party_id = hca.party_id(+)
          AND HCASA2.PARTY_SITE_ID(+) = HPS.PARTY_SITE_ID
          and hcasa2.org_id = to_number(j_ou_id) --to_number(p_OU_ID)
          AND hcsua2.cust_acct_site_id(+) = hcasa2.cust_acct_site_id
          AND hcsua2.site_use_code = 'SHIP_TO'   -- DELIVER_TO
          AND hps.location_id = hl.location_id
          AND NVL(hcasa2.status, 'I') = 'A'        ----Added NVL
          AND NVL(hca.status, 'I') = 'A'           ----Added NVL
          AND NVL(hcsua2.STATUS, 'I') = 'A'        ----Added NVL
          AND NVL(hps.STATUS, 'I') ='A'            ----Added NVL
          AND NVL(hp.STATUS, 'I') ='A'             ----Added NVL
           AND hca.cust_account_id=to_number(p_cust_id(var))
         --AND hca.account_number='KLM'
          and hca.cust_account_id is not null
         and hcsua2.PRIMARY_SALESREP_ID is not null
         AND hcsua2.PRIMARY_SALESREP_ID = SR.SALESREP_ID (+)
        order by HCA.CUST_ACCOUNT_ID;

      --
          IF sql%rowcount  > 0 and l_cust_admin.count > 0 THEN
           l_admin_cnt  := l_admin_cnt + 1;
           p_cust_admin.extend();
           p_cust_admin(l_admin_cnt) := l_cust_admin(1);
           FOR var IN 1 .. l_cust_admin.COUNT LOOP
            v_not_match_flag := TRUE;

            FOR dup IN 1 .. p_cust_admin.COUNT LOOP
              IF NVL(l_cust_admin(var).CUSTID,'-1') = NVL(p_cust_admin(dup).CUSTID,'-1') AND
                 NVL(l_cust_admin(var).CUST_NAME,'-X') = NVL(p_cust_admin(dup).CUST_NAME,'-X') AND
                 NVL(l_cust_admin(var).CUST_EMAIL,'-X') = NVL(p_cust_admin(dup).CUST_EMAIL,'-X') AND
                 NVL(l_cust_admin(var).CUST_PHONE,'-1') = NVL(p_cust_admin(dup).CUST_PHONE,'-1') THEN
                v_not_match_flag := FALSE ;
                EXIT WHEN  l_cust_admin(var).CUSTID = p_cust_admin(dup).CUSTID;
              END IF ;
            END LOOP ;
            IF v_not_match_flag THEN
               l_admin_cnt  := l_admin_cnt+ 1;
               p_cust_admin.extend();
               p_cust_admin(l_admin_cnt) := l_cust_admin(var);
            END IF;
           END LOOP;
        END IF ;
      END LOOP ;
    else
      --p_message := 'No customer passed.';
      SELECT LOOKUP_CODE || ': ' || DESCRIPTION
                INTO p_message
                FROM fnd_lookup_values
               where LOOKUP_TYPE = 'GEAE_MYGE_ERROR_CODES'
                 and UPPER(LOOKUP_CODE) = UPPER('8101');
    end if ;
 /* ELSE
    IF  p_ROLE = 'Global Enquiry' THEN
       SELECT LOOKUP_CODE || ': ' || DESCRIPTION
                INTO p_message
                FROM fnd_lookup_values
               where LOOKUP_TYPE = 'GEAE_MYGE_ERROR_CODES'
                 AND UPPER(LOOKUP_CODE) = UPPER('8055');
     END IF;

     IF P_ROLE = 'Cust Enquiry' THEN
       SELECT LOOKUP_CODE || ': ' || DESCRIPTION
                INTO p_message
                FROM fnd_lookup_values
               WHERE LOOKUP_TYPE = 'GEAE_MYGE_ERROR_CODES'
                 AND UPPER(LOOKUP_CODE) = UPPER('8057');
      END IF;
--
  END IF;*/

  <<END_PROC>>  --05-DEC-2018 Manisha introduced this to exit the proc in case of error while fetching OU_ID
  NULL;
  EXCEPTION
    WHEN OTHERS THEN
      SELECT LOOKUP_CODE || ': ' || DESCRIPTION
                INTO p_message
                FROM fnd_lookup_values
               where LOOKUP_TYPE = 'GEAE_MYGE_ERROR_CODES'
                 and UPPER(LOOKUP_CODE) = UPPER('8000');
  END GET_CUSTOMER_DETAILS;

PROCEDURE GET_CAM_EMAIL(P_SSO    VARCHAR2
                       ,P_IACO_CODE    VARCHAR2
                       ,P_CUST_ID    V_CUST_ID_ARRAY
                       ,P_ROLE    VARCHAR2
                       ,P_OU_ID    VARCHAR2
                       ,P_CAM_EMAIL_ADD  OUT VARCHAR2
                       ) AS
-- Passport Changes start to save the OU_ID separated by comma -11-14-2018 suguna
  v_ou_id                      VARCHAR2(100)   := NULL;
  v_ou_id1                     VARCHAR2(100)   := NULL;
  v_ou_id2                     VARCHAR2(100)   := NULL;
  j_ou_id                      VARCHAr2(100)   := NULL;
--end
   CURSOR C_EMAIL(P_CUSTOMER_ID NUMBER,P_OU_ID NUMBER) IS
      SELECT DISTINCT NVL((SELECT max(SOURCE_EMAIL) FROM JTF_RS_DEFRESOURCES_VL WHERE RESOURCE_ID=SR.RESOURCE_ID),SR.EMAIL_ADDRESS) SOURCE_EMAIL
        FROM hz_parties hp,
             hz_party_sites hps,
             hz_cust_accounts hca,
             hz_locations hl,
             hz_cust_acct_sites_all hcasa2,
             hz_cust_site_uses_all hcsua2,
             JTF_RS_SALESREPS SR
        WHERE hp.party_id = hps.party_id(+)
          AND hp.party_id = hca.party_id(+)
          AND HCASA2.PARTY_SITE_ID(+) = HPS.PARTY_SITE_ID
          and hcasa2.org_id = P_OU_ID
          AND hcsua2.cust_acct_site_id(+) = hcasa2.cust_acct_site_id
          AND hcsua2.site_use_code = 'SHIP_TO'   -- DELIVER_TO
          AND hps.location_id = hl.location_id
          AND NVL(hcasa2.status, 'I') = 'A'        ----Added NVL
          AND NVL(hca.status, 'I') = 'A'           ----Added NVL
          AND NVL(hcsua2.STATUS, 'I') = 'A'        ----Added NVL
          AND NVL(hps.STATUS, 'I') ='A'            ----Added NVL
          AND NVL(hp.STATUS, 'I') ='A'             ----Added NVL
           AND hca.cust_account_id=P_CUSTOMER_ID
         --AND hca.account_number='KLM'
          AND hca.cust_account_id is not null
          AND hcsua2.PRIMARY_SALESREP_ID is not null
          AND hcsua2.PRIMARY_SALESREP_ID = SR.SALESREP_ID(+);
BEGIN

/******************************************************
Passport changes start - US230167 - start
Suguna Added below to fetch the OU_ID based on the customer code
*******************************************************/

     v_ou_id := P_OU_ID;
     v_ou_id1 := REGEXP_SUBSTR(v_ou_id, '[^~]+', 1,1);
     v_ou_id2 :=  REGEXP_SUBSTR (v_ou_id, '[^~]+', 1, 2);


   FOR i IN 1..P_CUST_ID.COUNT LOOP

   --fetch the OU_ID based on the customer code -- pasport change
      IF P_OU_ID like '%~%' THEN

             BEGIN
                SELECT distinct HCASA.org_id
                INTO j_ou_id
                FROM  HZ_CUST_ACCOUNTS hca, HZ_CUST_ACCT_SITES_ALL HCASA
                WHERE (HCASA.org_id = to_number(v_ou_id1) or  HCASA.org_id = to_number(v_ou_id2))
                AND  NVL(HCASA.STATUS, 'I') = 'A'
                AND NVL(hca.status, 'I') = 'A'
                AND hcasa.cust_account_id = hca.cust_account_id
                and hca.cust_Account_id = P_CUST_ID(i);

            END;
    ELSE
     j_ou_id := TO_NUMBER(P_OU_ID);

    END IF;
    --passport changes end
    FOR r_email IN C_EMAIL(TO_NUMBER(P_CUST_ID(i)),j_ou_id) LOOP
         IF r_email.source_email IS NOT NULL THEN
            P_CAM_EMAIL_ADD := P_CAM_EMAIL_ADD||r_email.source_email||';';
         END IF;
      END LOOP;
   END LOOP;
EXCEPTION
   WHEN OTHERS THEN
      P_CAM_EMAIL_ADD := NULL;
END GET_CAM_EMAIL;
--30-JUL-2015  Neelima Y         MYJIRA#6856 All customer details for global enquiry
PROCEDURE GET_GLOBAL_CUST_DETAILS(P_SSO               VARCHAR2
                                 ,P_OU_ID            VARCHAR2
                                 ,p_IACO_CODE        VARCHAR2
                                 ,P_ROLE             VARCHAR2
                                 ,P_CUST_DETAIL_LIST OUT V_CUST_LIST_ARRAY
                                 ,P_MESSAGE          OUT VARCHAR2
                                 ) AS
-- Passport Changes start to save the OU_ID separated by comma -11-14-2018 suguna Passport Requirement US230168
  v_ou_id                      VARCHAR2(100)   := NULL;
  v_ou_id1                     VARCHAR2(100)   := NULL;
  v_ou_id2                     VARCHAR2(100)   := NULL;
--end
  CURSOR C_CUST_DET(v_ou_id1 VARCHAR2,v_ou_id2 VARCHAR2) IS -- added by Suguna for Passport Requirement US230168
  SELECT DISTINCT REPLACE(par.party_name,',','') customer_name
         ,act.account_number customer_number
    FROM hz_parties par
        ,hz_cust_accounts act
        ,hz_cust_acct_sites_all sit
        ,hz_cust_site_uses_all use
   WHERE par.party_id             = act.party_id
     AND act.cust_account_id      = sit.cust_account_id(+)
     AND sit.cust_acct_site_id    = use.cust_acct_site_id(+)
     AND act.status(+)            = 'A'
     AND use.status(+)            = 'A'
     AND use.site_use_code        <> 'BILL_TO'
     AND NVL (use.LOCATION, '-1') <> '-1'
     AND (sit.org_id = v_ou_id1 or sit.org_id  = v_ou_id2);--passport change
    -- AND sit.org_id               = P_OU_ID;--commented for passport change

BEGIN

  P_CUST_DETAIL_LIST   :=   V_CUST_LIST_ARRAY();

  IF P_OU_ID IS NULL THEN
     P_MESSAGE:='OU ID cannot be NULL';
     goto end_proc;
  END IF;

  IF p_ROLE    = 'Global Enquiry' THEN

/******************************************************
Passport changes start US230168
Suguna Added below to fetch the OU_ID based on the customer code
*******************************************************/
     v_ou_id := P_OU_ID;
     v_ou_id1 := REGEXP_SUBSTR(v_ou_id, '[^~]+', 1,1);
     v_ou_id2 :=  REGEXP_SUBSTR (v_ou_id, '[^~]+', 1, 2);

/** Modified the cusrsor to send both ou id inputs
  to get both CSO and PASSPORT customers details**/
  FOR CUST_REC IN C_CUST_DET(v_ou_id1,v_ou_id2)
  LOOP
--end
    P_CUST_DETAIL_LIST.extend(1);
    P_CUST_DETAIL_LIST(P_CUST_DETAIL_LIST.last):=V_GLOBAL_ENQ_CUST_LIST_BO( CUST_REC.CUSTOMER_NAME , CUST_REC.CUSTOMER_NUMBER);

  END LOOP;
    P_MESSAGE :='TRUE';
  ELSE
    P_MESSAGE :='FALSE';
    goto end_proc;
  END IF;
  <<end_proc>>
  null;
END GET_GLOBAL_CUST_DETAILS;
END GEAE_MYGE_CUST_DETAILS_PKG;