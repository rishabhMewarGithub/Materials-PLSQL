

GEAE_MYGE_UPDATE_ORDER_PKG

create or replace PACKAGE BODY "GEAE_MYGE_UPDATE_ORDER_PKG" AS
  /*---------------------------Change Log---------------------------------------

  31/10/2014_Ankita.S: Changed the reason code to 'GE INITIATED' for cancel_order_line
  04/11/2014_Ankita.S: Added authentication logic
  12/11/2014_Ankita.S: Changed reason code to 'Admin Error'
  14/11/2014_Ankita.S: Added error handling for 'Interfaced to WMS'
  14/11/2014_Ankita.S: Added su.SITE_USE_CODE='SHIP_TO/DELIVER_TO' filter to query in UPDATE_ORDER
  18/11/2014_Ankita.S: Added Request_Date <> Holiday logic
  19/11/2014_Ankita.S: Added Kitting priority code error handling
  26/11/2014_Ravi.S  : If part is Kit, dont update Shipment priority
  25/06/2016_Amita.B : added <<update_order_api>> label to error handling for JIRA GESQY-92
  25/06/2016_Amita.B : added <<cancel_order_api>> label to error handling for JIRA GESQY-92
  ----------------------------------------------------------------------------*/
  PROCEDURE UPDATE_ORDER(
                         --Standard Parameters
                         p_SSO       VARCHAR2,
                         p_IACO_CODE VARCHAR2,
                         p_CUST_ID   V_CUST_ID_ARRAY,
                         p_ROLE      VARCHAR2,
                         p_OU_ID     VARCHAR2,
                         --Input Parameters
                         p_ORDER_LINE_DTL IN V_ORDER_LINE_UPD_ARRAY,
                         --Output Parameters
                         p_ORDER_LN_STATUS OUT V_ORD_LN_UPD_STS_ARRAY,
                         p_msg             OUT VARCHAR2) AS
    v_goapi_version_number   NUMBER;
    x_gop_return_status      VARCHAR2(2);
    x_gomsg_count            NUMBER;
    x_gomsg_data             VARCHAR2(2000);
    v_poapi_version_number   NUMBER;
    x_pop_return_status      VARCHAR2(2);
    x_pomsg_count            NUMBER;
    x_pomsg_data             VARCHAR2(2000);
    v_goheader               VARCHAR2(10);
    v_msg_data               VARCHAR2(8000) := null;
    v_msg_index_out          NUMBER(10) := 0;
    v_poheader_rec           OE_ORDER_PUB.Header_Rec_Type;
    x_header_rec             OE_ORDER_PUB.Header_Rec_Type;
    x_header_upd_rec         OE_ORDER_PUB.Header_Rec_Type;
    x_header_val_rec         OE_ORDER_PUB.Header_Val_Rec_Type;
    x_Header_Adj_tbl         OE_ORDER_PUB.Header_Adj_Tbl_Type;
    x_Header_Adj_val_tbl     OE_ORDER_PUB.Header_Adj_Val_Tbl_Type;
    x_Header_price_Att_tbl   OE_ORDER_PUB.Header_Price_Att_Tbl_Type;
    x_Header_Adj_Att_tbl     OE_ORDER_PUB.Header_Adj_Att_Tbl_Type;
    x_Header_Adj_Assoc_tbl   OE_ORDER_PUB.Header_Adj_Assoc_Tbl_Type;
    x_Header_Scredit_tbl     OE_ORDER_PUB.Header_Scredit_Tbl_Type;
    x_Header_Scredit_val_tbl OE_ORDER_PUB.Header_Scredit_Val_Tbl_Type;
    x_line_tbl               OE_ORDER_PUB.Line_Tbl_Type;
    x_line_update_tbl        OE_ORDER_PUB.Line_Tbl_Type;
    x_line_upd_tbl           OE_ORDER_PUB.Line_Tbl_Type;
    x_line_val_tbl           OE_ORDER_PUB.Line_Val_Tbl_Type;
    x_Line_Adj_tbl           OE_ORDER_PUB.Line_Adj_Tbl_Type;
    x_Line_Adj_val_tbl       OE_ORDER_PUB.Line_Adj_Val_Tbl_Type;
    x_Line_price_Att_tbl     OE_ORDER_PUB.Line_Price_Att_Tbl_Type;
    x_Line_Adj_Att_tbl       OE_ORDER_PUB.Line_Adj_Att_Tbl_Type;
    x_Line_Adj_Assoc_tbl     OE_ORDER_PUB.Line_Adj_Assoc_Tbl_Type;
    x_Line_Scredit_tbl       OE_ORDER_PUB.Line_Scredit_Tbl_Type;
    x_Line_Scredit_val_tbl   OE_ORDER_PUB.Line_Scredit_Val_Tbl_Type;
    x_Lot_Serial_tbl         OE_ORDER_PUB.Lot_Serial_Tbl_Type;
    x_Lot_Serial_val_tbl     OE_ORDER_PUB.Lot_Serial_Val_Tbl_Type;
    x_action_request_tbl     OE_ORDER_PUB.Request_Tbl_Type;
    p_action_request_tbl     OE_ORDER_PUB.Request_Tbl_Type;
    v_rtrim_data             Varchar2(1);
    v_validate_desc_flex     VARCHAR2(1);
    v_reason_code            VARCHAR2(30);
    v_lcount                 NUMBER;
    l_header_id              VARCHAR(50);
    l_line_id                VARCHAR(50);
    l_cust_line_num          VARCHAR(50);
    l_ord_qty                VARCHAR(50);
    l_ship_priority_code     VARCHAR(50);
    l_ship_to_loc            VARCHAR(50);
    l_del_to_loc             VARCHAR(50);
    l_req_date               DATE;
    l_success                VARCHAR(10);
    l_status_msg             VARCHAR(1000);
    l_ship_to_org_id         NUMBER;
    l_deliver_to_org_id      NUMBER;
    V_USER_ID                FND_USER.USER_ID%TYPE;
    V_RESP_ID                FND_RESPONSIBILITY_TL.RESPONSIBILITY_ID%TYPE;
    V_APP_ID                 FND_RESPONSIBILITY_TL.APPLICATION_ID%TYPE;
    l_authorized             VARCHAR(10);
    l_cust_id                NUMBER;
    l_cust_acc_num           VARCHAR(30);
    l_supp_code              VARCHAR(30);
    l_next_working_date      VARCHAR(50);
    l_item_type_code         VARCHAR(20);
    l_mygea_esn              VARCHAR2(6); --Neelima Y MYJIRATEST-8723
    l_esn_flag               VARCHAR2(1); --Neelima Y MYJIRATEST-8723
    l_esn_msg                VARCHAR2(100); --Neelima Y MYJIRATEST-8723
    l_counter                NUMBER := 0;
    l_wrkstp_date            DATE;       --MANISHA
    l_wrkstp_qty             NUMBER;       --MANISHA
    l_workstop_date_char     VARCHAR2(20); -- added by suguna for workstop changes
    v_OU_ID                  VARCHAR2(20);  --04-OCT Manisha K Added to save the OU_ID
  BEGIN
    <<update_order_api>> --Amita.B JIRA GESQY-92

 /***********************************************************************
Manisha K. 04-OCT-2018 Commented the below code and have added
this piece of code below after finding the OU_ID
*************************************************************************/
    --Fetching responsibilityID and appID
--    BEGIN
--      SELECT RESP.RESPONSIBILITY_ID, RESP.APPLICATION_ID
--        INTO V_RESP_ID, V_APP_ID
--        FROM FND_RESPONSIBILITY_TL RESP,
--             FND_LOOKUP_VALUES     FLV,
--             HR_OPERATING_UNITS    HOU
--       WHERE HOU.NAME = FLV.MEANING
--         AND RESP.RESPONSIBILITY_NAME = FLV.DESCRIPTION
--         AND HOU.ORGANIZATION_ID = p_OU_ID
--         AND FLV.LOOKUP_TYPE = 'GEAE_MYGE_ORDER_RESPONSIBILITY';
--    EXCEPTION
--      WHEN no_data_found THEN
--        P_MSG := GET_ERR_MSG(8026);
--        GOTO end_proc;
--    END;

    --Fetching userID
    SELECT USER_ID INTO V_USER_ID FROM FND_USER WHERE USER_NAME = p_SSO;

    p_ORDER_LN_STATUS      := V_ORD_LN_UPD_STS_ARRAY();
    v_goapi_version_number := 1.0;
    v_goheader             := FND_API.G_MISS_CHAR;

    /***********************************************************************
Manisha K. 04-OCT-2018 Commented the below code and have added
this piece of code below after finding the OU_ID
*************************************************************************/

--    mo_global.set_policy_context('S', P_OU_ID);
--    mo_global.init('ONT');
--    FND_GLOBAL.APPS_INITIALIZE(V_USER_ID, V_RESP_ID, V_APP_ID);

    --Main Loop starts
    FOR i in 1 .. p_ORDER_LINE_DTL.count LOOP
      l_header_id          := p_ORDER_LINE_DTL(i).HEADER_ID;
      l_line_id            := p_ORDER_LINE_DTL(i).LINE_ID;
      l_cust_line_num      := p_ORDER_LINE_DTL(i).CUSTOMER_LINE_NUMBER;
      l_ord_qty            := p_ORDER_LINE_DTL(i).ORDERED_QUANTITY;
      --
      SELECT DECODE(p_ORDER_LINE_DTL(i).SHIPMENT_PRIORITY_CODE,'NORMAL','50_NORMAL','WSP','40_WKSTP',p_ORDER_LINE_DTL(i).SHIPMENT_PRIORITY_CODE)
      INTO l_ship_priority_code
      FROM DUAL;
      --
      l_ship_to_loc        := p_ORDER_LINE_DTL(i).SHIP_TO_LOCATION_ID;
      l_del_to_loc         := p_ORDER_LINE_DTL(i).DLVR_TO_LOCATION_ID;
      l_req_date           := p_ORDER_LINE_DTL(i).REQUEST_DATE;
      l_mygea_esn          := p_ORDER_LINE_DTL(i).MYGEA_ESN; --Neelima Y MYJIRATEST-8723
      l_wrkstp_date        := p_ORDER_LINE_DTL(i).WORKSTP_DATE;
      l_wrkstp_qty         := p_ORDER_LINE_DTL(i).WORKSTP_QTY;

      l_status_msg := NULL;
      p_ORDER_LN_STATUS.extend;

/********************************************************
  Manisha K. 4-OCT-2018 Passport Requirements.
  Earlier responsibility ,  used to call outside the loop using P_OU_ID.
  Now, OU_ID is fetched using header so placed the below code inside the header loop
  ********************************************************/

  IF P_OU_ID like '%~%' THEN
      BEGIN
      SELECT org_Id
      INTO v_OU_ID FROM oe_order_headers_all
      WHERE HEADER_ID =l_header_id ;
      EXCEPTION
      WHEN OTHERS THEN
      P_MSG := 'Error while fetching the OU_ID: '||SQLCODE||SQLERRM;
      goto end_proc;
      END;
  ELSE
    v_OU_ID := P_OU_ID;
  END IF;

  IF v_ou_id IS NULL THEN
        p_MSG:=GET_ERR_MSG(8503);
        goto end_proc;
    END IF;
   --Fetching responsibilityID and appID
    BEGIN
      SELECT RESP.RESPONSIBILITY_ID, RESP.APPLICATION_ID
        INTO V_RESP_ID, V_APP_ID
        FROM FND_RESPONSIBILITY_TL RESP,
             FND_LOOKUP_VALUES     FLV,
             HR_OPERATING_UNITS    HOU
       WHERE HOU.NAME = FLV.MEANING
         AND RESP.RESPONSIBILITY_NAME = FLV.DESCRIPTION
         AND HOU.ORGANIZATION_ID = v_OU_ID
         AND FLV.LOOKUP_TYPE = 'GEAE_MYGE_ORDER_RESPONSIBILITY';
    EXCEPTION
      WHEN no_data_found THEN
        P_MSG := GET_ERR_MSG(8026);
        GOTO end_proc;
    END;

DBMS_OUTPUT.PUT_LINE('V_RESP_ID = ' || V_RESP_ID);
DBMS_OUTPUT.PUT_LINE('V_APP_ID = ' || V_APP_ID);


    mo_global.set_policy_context('S', v_OU_ID);
    mo_global.init('ONT');
    FND_GLOBAL.APPS_INITIALIZE(V_USER_ID, V_RESP_ID, V_APP_ID);

      --Error handling for shipment priority of a KIT item
      SELECT ITEM_TYPE_CODE
        INTO l_item_type_code
        FROM oe_order_lines_all
       WHERE LINE_ID = l_line_id;

      IF l_item_type_code = 'MODEL' THEN
        l_ship_priority_code := NULL; -- Ravi S 26/11/2014
      END IF;

      --Logic for request_date <> Holiday
      IF l_req_date IS NOT NULL THEN
        --Get account number
        SELECT hca.account_number
          INTO l_cust_acc_num
          FROM oe_order_headers_all ooh, hz_cust_accounts hca
         WHERE hca.cust_account_id = ooh.sold_to_org_id
           AND ooh.header_id = l_header_id;
        --DBMS_OUTPUT.PUT_LINE('acc no: '||l_cust_acc_num);
        --Get Shipment priority code
        IF l_ship_priority_code IS NULL THEN
          SELECT DECODE(SHIPMENT_PRIORITY_CODE,'NORMAL','50_NORMAL','WSP','40_WKSTP',SHIPMENT_PRIORITY_CODE)
            INTO l_ship_priority_code
            FROM oe_order_lines_all
           WHERE LINE_ID = l_line_id;
        END IF;
        -- DBMS_OUTPUT.PUT_LINE('Prio code: '||l_ship_priority_code);
        -- Fetching Site_Use_Id from location_id for SHIP_TO_ORG_ID
        IF l_ship_to_loc IS NOT NULL THEN
          BEGIN
            SELECT su.site_use_id
              INTO l_ship_to_org_id
              FROM hz_cust_site_uses_all  su,
                   hz_locations           loc,
                   hz_party_sites         ps,
                   hz_cust_acct_sites_all cas
             WHERE loc.location_id = to_number(l_ship_to_loc)
               AND loc.location_id(+) = ps.location_id
                  --AND ps.PARTY_SITE_NUMBER=su.LOCATION
               AND ps.party_site_id(+) = cas.party_site_id
               AND cas.cust_acct_site_id(+) = su.cust_acct_site_id
               AND su.SITE_USE_CODE = 'SHIP_TO'
               AND su.org_id = v_OU_ID  --P_OU_ID
               AND Rownum = 1;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              l_status_msg := l_status_msg || GET_ERR_MSG(8171) || '|';
              l_success    := 'N';
              goto end_auth;
          END;
        ELSIF l_ship_to_loc IS NULL THEN
          SELECT SHIP_TO_ORG_ID
            INTO l_ship_to_org_id
            FROM oe_order_lines_all
           WHERE LINE_ID = l_line_id;
        END IF;
        --DBMS_OUTPUT.PUT_LINE('Shipment id: '||l_ship_to_org_id);
        --Get supplier code
        SELECT ATTRIBUTE1
          INTO l_supp_code
          FROM oe_order_headers_all
         WHERE HEADER_ID = l_header_id;
        --DBMS_OUTPUT.PUT_LINE('supp code: '||l_supp_code);

        GEAE_ONT_SALES_ORDER_PKG.GET_REQUEST_DATE(P_SHIP_PRIORITY    => l_ship_priority_code,
                                                  P_REQUEST_DATE_IN  => to_char(to_date(l_req_date,
                                                                                        'DD-MON-YY'),
                                                                                'RRRRMMDD'),
                                                  P_REQUEST_DATE_OUT => l_next_working_date,
                                                  P_ACCOUNT_NUMBER   => l_cust_acc_num,
                                                  P_ORG_ID           => v_OU_ID, -- p_OU_ID,
                                                  P_SHIP_TO_ORG_ID   => l_ship_to_org_id,
                                                  P_PRICELIST_ID     => NULL,
                                                  P_PART_NUMBER      => NULL,
                                                  P_SUPPLIER_CODE    => l_supp_code);

        IF TO_CHAR(TO_DATE(l_next_working_date, 'YYYY-MM-DD'), 'RRRRMMDD') <>
           to_char(to_date(l_req_date, 'DD-MON-YY'), 'RRRRMMDD') THEN
          l_status_msg := l_status_msg || GET_ERR_MSG(8167) || ' ' ||
                          l_next_working_date || '|';
          l_success    := 'N';
          goto end_auth;
        END IF;
      END IF;

      --Get the order details

      oe_order_pub.get_order(p_api_version_number     => v_goapi_version_number,
                             p_init_msg_list          => FND_API.G_FALSE,
                             p_return_values          => FND_API.G_FALSE,
                             x_return_status          => x_gop_return_status,
                             x_msg_count              => x_gomsg_count,
                             x_msg_data               => x_gomsg_data,
                             p_header_id              => to_number(l_header_id),
                             p_header                 => v_goheader,
                             x_header_rec             => x_header_rec,
                             x_header_val_rec         => x_header_val_rec,
                             x_Header_Adj_tbl         => x_Header_Adj_tbl,
                             x_Header_Adj_val_tbl     => x_Header_Adj_val_tbl,
                             x_Header_price_Att_tbl   => x_Header_price_Att_tbl,
                             x_Header_Adj_Att_tbl     => x_Header_Adj_Att_tbl,
                             x_Header_Adj_Assoc_tbl   => x_Header_Adj_Assoc_tbl,
                             x_Header_Scredit_tbl     => x_Header_Scredit_tbl,
                             x_Header_Scredit_val_tbl => x_Header_Scredit_val_tbl,
                             x_line_tbl               => x_line_tbl,
                             x_line_val_tbl           => x_line_val_tbl,
                             x_Line_Adj_tbl           => x_Line_Adj_tbl,
                             x_Line_Adj_val_tbl       => x_Line_Adj_val_tbl,
                             x_Line_price_Att_tbl     => x_Line_price_Att_tbl,
                             x_Line_Adj_Att_tbl       => x_Line_Adj_Att_tbl,
                             x_Line_Adj_Assoc_tbl     => x_Line_Adj_Assoc_tbl,
                             x_Line_Scredit_tbl       => x_Line_Scredit_tbl,
                             x_Line_Scredit_val_tbl   => x_Line_Scredit_val_tbl,
                             x_Lot_Serial_tbl         => x_Lot_Serial_tbl,
                             x_Lot_Serial_val_tbl     => x_Lot_Serial_val_tbl);

      --DBMS_OUTPUT.PUT_LINE('ret data: '||x_gomsg_data);

      -- If there is any error it will list down in this below loop.
      IF (x_gop_return_status != FND_API.G_RET_STS_SUCCESS) THEN
        IF TO_NUMBER(x_gomsg_count) > 0 THEN
          FOR Cur_I IN 1 .. x_gomsg_count LOOP
            Oe_Msg_Pub.get(p_msg_index     => Cur_I,
                           p_encoded       => Fnd_Api.G_FALSE,
                           p_data          => x_gomsg_data,
                           p_msg_index_out => v_msg_index_out);
            --Changes made for API Message
            fnd_file.put_line(fnd_file.OUTPUT, 'ERROR: ' || x_gomsg_data);
            fnd_file.put_line(fnd_file.LOG,
                              'Order Number ==== ' ||
                               x_header_rec.order_number ||
                               ' Line Number ==== ' || x_line_upd_tbl(v_lcount)
                              .line_number || '.' || x_line_upd_tbl(v_lcount)
                              .Shipment_number);
            --DBMS_OUTPUT.PUT_LINE('ERROR: ' || x_gomsg_data); -- To display error if any

          END LOOP;
        END IF;
      ELSE
        fnd_file.put_line(fnd_file.LOG,
                          'Return Status   = ' ||
                          SUBSTR(x_gop_return_status, 1, 255));
        fnd_file.put_line(fnd_file.LOG,
                          'Order Number    = ' || x_header_rec.order_number);
        fnd_file.put_line(fnd_file.LOG,
                          'Order Number ==== ' || x_header_rec.order_number ||
                           ' Line Number ==== ' || x_line_tbl(i).line_number || '.' || x_line_tbl(i)
                          .Shipment_number);
        fnd_file.put_line(fnd_file.LOG,
                          'Ordered Item    = ' || x_line_tbl(i)
                          .ordered_item);
        fnd_file.put_line(fnd_file.LOG,
                          'Ordered Quantity= ' || x_line_tbl(i)
                          .ordered_quantity);
        fnd_file.put_line(fnd_file.LOG,
                          'Order Quantity uom=' || x_line_tbl(i)
                          .order_quantity_uom);
        fnd_file.put_line(fnd_file.LOG, 'Data is succesfully retrived. ');
        -- DBMS_OUTPUT.PUT_LINE('Data is succesfully retrived. ');
      END IF;
      --Authorization logic
      IF l_header_id IS NOT NULL THEN
        l_authorized := 'N';
        BEGIN
          SELECT sold_to_org_id
            INTO l_cust_id
            FROM oe_order_headers_all
           WHERE header_id = l_header_id;
          --DBMS_OUTPUT.PUT_LINE('Cust id : ' || l_cust_id);
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            l_status_msg := l_status_msg || GET_ERR_MSG(8010) || '|';
            l_success    := 'N';
            goto end_auth;
        END;
        FOR i IN 1 .. P_CUST_ID.COUNT LOOP
          IF P_CUST_ID(i) = l_cust_id THEN
            l_authorized := 'Y';
            --   DBMS_OUTPUT.PUT_LINE('l_authorized := yes ');
          END IF;
        END LOOP;
        IF l_authorized = 'N' THEN
          l_status_msg := l_status_msg || GET_ERR_MSG(8180) || '|';
          l_success    := 'N';
          goto end_auth;
        END IF;
      END IF;
      --
      --ONLY WHEN OE_ORDER_PUB.GET_ORDER API IS SUCCESSFUL CALL to PROCESS_ORDER

      IF (x_gop_return_status = FND_API.G_RET_STS_SUCCESS) THEN
        --DBMS_OUTPUT.PUT_LINE('return status success ');
        v_poapi_version_number   := 1.0;
        v_rtrim_data             := 'N';
        v_validate_desc_flex     := 'Y';
        v_poheader_rec           := OE_ORDER_PUB.G_MISS_HEADER_REC;
        v_poheader_rec.header_id := x_header_rec.header_id;
        v_lcount                 := 0;
        -- For getting the line in the table.
        FOR cur_i in 1 .. x_line_tbl.count LOOP
          IF x_line_tbl(CUR_i).line_id = to_number(l_line_id) THEN
            v_lcount := cur_i;
            --DBMS_OUTPUT.PUT_LINE('v_count : ' || v_lcount);
          END IF;
        END LOOP;

        IF v_lcount > 0 then
          x_line_update_tbl := x_line_tbl;

          IF l_ship_to_loc IS NOT NULL THEN
            BEGIN
              SELECT su.site_use_id
                INTO l_ship_to_org_id
                FROM hz_cust_site_uses_all  su,
                     hz_locations           loc,
                     hz_party_sites         ps,
                     hz_cust_acct_sites_all cas
               WHERE loc.location_id = to_number(l_ship_to_loc)
                 AND loc.location_id(+) = ps.location_id
                    --AND ps.PARTY_SITE_NUMBER=su.LOCATION
                 AND ps.party_site_id(+) = cas.party_site_id
                 AND cas.cust_acct_site_id(+) = su.cust_acct_site_id
                 AND su.SITE_USE_CODE = 'SHIP_TO'
                 AND su.org_id = v_OU_ID --P_OU_ID
                 AND Rownum = 1;
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                l_status_msg := l_status_msg || GET_ERR_MSG(8171) || '|';
                l_success    := 'N';
                goto end_loop;
            END;
          END IF;
          -- Fetching Site_Use_Id from location_id for DELIVER_TO_ORG_ID
          IF l_del_to_loc IS NOT NULL THEN
            BEGIN
              SELECT su.site_use_id
                INTO l_deliver_to_org_id
                FROM hz_cust_site_uses_all  su,
                     hz_locations           loc,
                     hz_party_sites         ps,
                     hz_cust_acct_sites_all cas
               WHERE loc.location_id = to_number(l_del_to_loc)
                 AND loc.location_id(+) = ps.location_id
                    --AND ps.PARTY_SITE_NUMBER=su.LOCATION
                 AND ps.party_site_id(+) = cas.party_site_id
                 AND cas.cust_acct_site_id(+) = su.cust_acct_site_id
                 AND su.SITE_USE_CODE = 'DELIVER_TO'
                 AND su.org_id = v_OU_ID --P_OU_ID
                 AND Rownum = 1;
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                l_status_msg := l_status_msg || GET_ERR_MSG(8172) || '|';
                l_success    := 'N';
                goto end_loop;
            END;
          END IF;
        --Removed ESn Validation since service team is taking care of it  Suguna 20-May-2018
               l_esn_flag := 'Y';
               l_esn_msg  := NULL;
          --Assigning new values to the Line_rec fields for updation
          IF l_cust_line_num IS NOT NULL THEN
            x_line_update_tbl(v_lcount).customer_line_number := l_cust_line_num;
            fnd_file.put_line(fnd_file.LOG,
                              'Customer Order Number:' || x_line_update_tbl(v_lcount)
                              .customer_line_number);
          END IF;

          IF l_ship_to_org_id IS NOT NULL THEN
            x_line_update_tbl(v_lcount).ship_to_org_id := l_ship_to_org_id;
            fnd_file.put_line(fnd_file.LOG,
                              'Ship to Location:' || x_line_update_tbl(v_lcount)
                              .ship_to_org_id);
          END IF;

          IF l_deliver_to_org_id IS NOT NULL THEN
            x_line_update_tbl(v_lcount).deliver_to_org_id := l_deliver_to_org_id;
            fnd_file.put_line(fnd_file.LOG,
                              'Deliver to Location:' || x_line_update_tbl(v_lcount)
                              .deliver_to_org_id);
          END IF;

          IF l_ord_qty IS NOT NULL THEN
            x_line_update_tbl(v_lcount).ordered_quantity := to_number(l_ord_qty);
            fnd_file.put_line(fnd_file.LOG,
                              'Ordered Quantity:' || x_line_update_tbl(v_lcount)
                              .ordered_quantity);
          END IF;

          IF l_req_date IS NOT NULL THEN
            x_line_update_tbl(v_lcount).request_date := l_req_date;
            fnd_file.put_line(fnd_file.LOG,
                              'Request Date:' || x_line_update_tbl(v_lcount)
                              .request_date);
          END IF;

          IF l_ship_priority_code IS NOT NULL THEN
            x_line_update_tbl(v_lcount).SHIPMENT_PRIORITY_CODE := l_ship_priority_code;
            fnd_file.put_line(fnd_file.LOG,
                              'Shipment Priority:' || x_line_update_tbl(v_lcount)
                              .SHIPMENT_PRIORITY_CODE);
          END IF;

          IF l_mygea_esn IS NOT NULL THEN
            --Neelima Y MYJIRATEST-8723
            IF UPPER(l_ship_priority_code) IN ('NORMAL','50_NORMAL') THEN
            x_line_update_tbl(v_lcount).ATTRIBUTE7 := l_mygea_esn;
            ELSIF UPPER(l_ship_priority_code) IN ('WSP','40_WKSTP') THEN

              IF (l_wrkstp_date IS NULL) OR (l_wrkstp_qty IS NULL) THEN
                l_status_msg := l_status_msg || GET_ERR_MSG(8205) || '|';
                l_success    := 'N';
                goto end_auth;
              END IF;
            l_workstop_date_char:= to_char(l_wrkstp_date,'YYYY/MM/DD hh24:mi:ss'); -- added by suguna because Date is not showing correctly in APMS
			 -- "~~~~ " added by Suguna since the workstop date is not showing in AMPS workstop report 21-May-2018
            x_line_update_tbl(v_lcount).ATTRIBUTE7 := l_mygea_esn||'~'||l_workstop_date_char||'~'||l_wrkstp_qty||'~'||'~'||'~'||'~'; --MANISHA

            END IF;
            fnd_file.put_line(fnd_file.LOG,
                              'MYGEA_ESN ~ wrkstp_date ~ wrkstp_qty:' || x_line_update_tbl(v_lcount) --MANISHA
                              .attribute7);
            ELSE

              x_line_update_tbl(v_lcount).ATTRIBUTE7 := l_mygea_esn;

          END IF;

          x_line_update_tbl(v_lcount).operation := OE_GLOBALS.G_OPR_UPDATE;
          fnd_file.put_line(fnd_file.LOG,
                            'Operation:' || x_line_update_tbl(v_lcount)
                            .operation);

          --The below select statement brings the reason for the change.
          BEGIN
            SELECT lookup_code
              INTO v_reason_code
              FROM oe_lookups
             WHERE lookup_type = 'CANCEL_CODE'
               AND enabled_flag = 'Y'
               AND SYSDATE BETWEEN NVL(start_date_active, SYSDATE) AND
                   NVL(end_date_active, SYSDATE)
               AND lookup_code = 'Not provided';
            --DBMS_OUTPUT.PUT_LINE('v_reason_code ' || v_reason_code);
            fnd_file.put_line(fnd_file.LOG,
                              'L_Change reason:' || v_reason_code);
          EXCEPTION
            WHEN no_data_found THEN
              oe_debug_pub.ADD('geae_proc_order_api:reason code:not found ');
            WHEN OTHERS THEN
              oe_debug_pub.ADD('geae_proc_order_api:reason code:others ');
          END;
          x_line_update_tbl(v_lcount).change_reason := v_reason_code;

          fnd_file.put_line(fnd_file.LOG,
                            'Change reason:' || x_line_update_tbl(v_lcount)
                            .change_reason);
          p_action_request_tbl := oe_order_pub.g_miss_request_tbl;

          --DBMS_OUTPUT.PUT_LINE('call to process order');
          -- Call to PROCESS_ORDER
          oe_order_pub.process_order(p_api_version_number     => v_poapi_version_number,
                                     p_init_msg_list          => fnd_api.g_true,
                                     p_return_values          => fnd_api.g_false,
                                     p_action_commit          => fnd_api.g_false,
                                     x_return_status          => x_pop_return_status,
                                     x_msg_count              => x_pomsg_count,
                                     x_msg_data               => x_pomsg_data,
                                     p_header_rec             => x_header_rec,
                                     p_line_tbl               => x_line_update_tbl,
                                     p_action_request_tbl     => p_action_request_tbl,
                                     x_header_rec             => x_header_rec,
                                     x_header_val_rec         => x_header_val_rec,
                                     x_header_adj_tbl         => x_header_adj_tbl,
                                     x_header_adj_val_tbl     => x_header_adj_val_tbl,
                                     x_header_price_att_tbl   => x_header_price_att_tbl,
                                     x_header_adj_att_tbl     => x_header_adj_att_tbl,
                                     x_header_adj_assoc_tbl   => x_header_adj_assoc_tbl,
                                     x_header_scredit_tbl     => x_header_scredit_tbl,
                                     x_header_scredit_val_tbl => x_header_scredit_val_tbl,
                                     x_line_tbl               => x_line_upd_tbl,
                                     x_line_val_tbl           => x_line_val_tbl,
                                     x_line_adj_tbl           => x_line_adj_tbl,
                                     x_line_adj_val_tbl       => x_line_adj_val_tbl,
                                     x_line_price_att_tbl     => x_line_price_att_tbl,
                                     x_line_adj_att_tbl       => x_line_adj_att_tbl,
                                     x_line_adj_assoc_tbl     => x_line_adj_assoc_tbl,
                                     x_line_scredit_tbl       => x_line_scredit_tbl,
                                     x_line_scredit_val_tbl   => x_line_scredit_val_tbl,
                                     x_lot_serial_tbl         => x_lot_serial_tbl,
                                     x_lot_serial_val_tbl     => x_lot_serial_val_tbl,
                                     x_action_request_tbl     => x_action_request_tbl,
                                     p_rtrim_data             => v_rtrim_data,
                                     p_validate_desc_flex     => v_validate_desc_flex);

          --DBMS_OUTPUT.PUT_LINE('Data: ' || x_pomsg_data);
          --DBMS_OUTPUT.PUT_LINE('Count: ' || x_pomsg_count);
          IF (x_pop_return_status = FND_API.G_RET_STS_SUCCESS) THEN
            fnd_file.put_line(fnd_file.LOG,
                              'Request Status - ' ||
                              SUBSTR(x_pop_return_status, 1, 255));
            fnd_file.put_line(fnd_file.LOG,
                              '------------------------------------');
            fnd_file.put_line(fnd_file.LOG,
                              'Order Number ==== ' ||
                              x_header_rec.order_number);
            fnd_file.put_line(fnd_file.LOG,
                              'Order Number ==== ' ||
                               x_header_rec.order_number ||
                               ' Line Number ==== ' || x_line_upd_tbl(v_lcount)
                              .line_number || '.' || x_line_upd_tbl(v_lcount)
                              .Shipment_number);
            fnd_file.put_line(fnd_file.LOG,
                              'Data is succesfully updated. ');
            --DBMS_OUTPUT.PUT_LINE('Data is succesfully updated. ');
            --populating the output varray for success
            p_msg        := NULL;
            l_success    := 'Y';
            l_status_msg := NULL;
          ELSE
            --DBMS_OUTPUT.PUT_LINE('return status unsuccess');
            fnd_file.put_line(fnd_file.OUTPUT,
                              'Order Number ==== ' ||
                              x_header_rec.order_number);
            fnd_file.put_line(fnd_file.LOG,
                              'Order Number ==== ' ||
                               x_header_rec.order_number ||
                               ' Line Number ==== ' || x_line_upd_tbl(v_lcount)
                              .line_number || '.' || x_line_upd_tbl(v_lcount)
                              .Shipment_number);
            -- If there is any error it will list  down in this below loop.
            --DBMS_OUTPUT.PUT_LINE('x_pomsg_count: ' || x_pomsg_count);
            IF TO_NUMBER(x_pomsg_count) > 0 THEN
              FOR Cur_I IN 1 .. x_pomsg_count LOOP
                Oe_Msg_Pub.get(p_msg_index     => 1,
                               p_encoded       => Fnd_Api.G_FALSE,
                               p_data          => x_pomsg_data,
                               p_msg_index_out => v_msg_index_out);
                -- DBMS_OUTPUT.PUT_LINE('x_pomsg_data : ' || x_pomsg_data);

                --Amita.B JIRA GESQY-92
                LOOP
                  l_counter := l_counter + 1;
                --  DBMS_OUTPUT.PUT_LINE(l_counter); Manisha 14 Dec commented as proc was running continously in some scenarios
                  IF x_pomsg_data LIKE
                     '%ORA-01403: no data found in Package OE_Line_Security Procedure Attributes%' THEN
                    goto update_order_api;
                  ELSIF x_pomsg_data LIKE
                        '%ORA-01403: no data found in Package OE_Order_Cache Procedure get_tax_calculation_flag|%' THEN
                    goto update_order_api;
                  ELSIF x_pomsg_data LIKE '%ORA-01403: no data found%' THEN
                    goto update_order_api;
                  END IF;
                  IF l_counter = 1 THEN
                    EXIT;
                  END IF;
                END LOOP;
                ---END JIRA GESQY-92

                fnd_file.put_line(fnd_file.OUTPUT,
                                  'ERROR: ' || x_pomsg_data);
                fnd_file.put_line(fnd_file.LOG,
                                  'Order Number ==== ' ||
                                   x_header_rec.order_number ||
                                   ' Line Number ==== ' || x_line_upd_tbl(v_lcount)
                                  .line_number || '.' || x_line_upd_tbl(v_lcount)
                                  .Shipment_number);
                l_success := 'N';

                IF x_pomsg_data LIKE '%Deliver To Org%' THEN
                  --Ravi--
                  l_status_msg := l_status_msg || GET_ERR_MSG(8172) || '|'; --Ravi
                ELSIF x_pomsg_data LIKE 'You are not allowed to update Order Line because:
Order line has been closed.' THEN
                  l_status_msg := l_status_msg || GET_ERR_MSG(8173) || '|';
                ELSIF x_pomsg_data LIKE 'You are not allowed to update Ordered Quantity because:
Line is cancelled' THEN
                  l_status_msg := l_status_msg || GET_ERR_MSG(8174) || '|';
                ELSIF x_pomsg_data LIKE 'You are not allowed to update Ordered Quantity because:
PTO KIT quantity should be 1' THEN
                  l_status_msg := l_status_msg || GET_ERR_MSG(8175) || '|';
                ELSIF x_pomsg_data LIKE
                      'Quantity should be multiple of UPQ%' THEN
                  l_status_msg := l_status_msg || GET_ERR_MSG(8176) || '|';
                ELSIF x_pomsg_data LIKE 'You are not allowed to update Ordered Quantity because:
Update Ordered Quantity Not Allowed.Line Interfaced to WMS
' THEN
                  l_status_msg := l_status_msg || GET_ERR_MSG(8187) || '|';
                ELSIF x_pomsg_data LIKE 'You are not allowed to update Order Line because:
SPR price list not present , order cannot be booked
' THEN
                  l_status_msg := l_status_msg || GET_ERR_MSG(8144) || '|';
                ELSE
                  l_status_msg := l_status_msg || x_pomsg_data || '|';
                END IF;

              END LOOP;
            END IF;
            fnd_file.put_line(fnd_file.LOG,
                              'Request Status = ' || x_pop_return_status);
          END IF;
          <<end_loop>>
          null;
        ELSE
          --In case incorrect Line ID
          l_success    := 'N';
          l_status_msg := l_status_msg || GET_ERR_MSG(8177) || '|';
          --DBMS_OUTPUT.PUT_LINE('l_status_msg : ' || l_status_msg);
          goto end_proc;

        END IF;
      ELSE
        --In case no orders fetched
        l_success    := 'N';
        l_status_msg := l_status_msg || GET_ERR_MSG(8177) || '|';
        goto end_proc;
      END IF; -- GET ORDER API CALL Status Check IF

      <<end_auth>>
      null;
      p_ORDER_LN_STATUS(i) := V_ORD_LN_UPD_STS_BO(l_header_id,
                                                  l_line_id,
                                                  l_success,
                                                  l_status_msg,
                                                  l_esn_flag,
                                                  l_esn_msg);
    END LOOP; --Main loop ends

    <<end_proc>>
    null;
    COMMIT;
  END UPDATE_ORDER;
  
  
  
  

  FUNCTION GET_ERR_MSG(P_ERR_CODE IN NUMBER) RETURN VARCHAR2 AS
    V_MSG VARCHAR2(2000);
  BEGIN
    SELECT LOOKUP_CODE || ':' || DESCRIPTION
      INTO V_MSG
      FROM FND_LOOKUP_VALUES
     WHERE LOOKUP_TYPE = 'GEAE_MYGE_ERROR_CODES'
       AND UPPER(LOOKUP_CODE) = UPPER(P_ERR_CODE);
    RETURN V_MSG;
  EXCEPTION
    WHEN no_data_found THEN
      RETURN NULL;
  END GET_ERR_MSG;

  --CANCEL_ORDER_LINE Starts here

  PROCEDURE CANCEL_ORDER_LINE(
                              --Standard Parameters
                              p_SSO       VARCHAR2,
                              p_IACO_CODE VARCHAR2,
                              p_CUST_ID   V_CUST_ID_ARRAY,
                              p_ROLE      VARCHAR2,
                              p_OU_ID     VARCHAR2,
                              --Input Parameters
                              p_HEADER_ID IN NUMBER,
                              p_LINE_ID   IN NUMBER,
                              --Output Parameters
                              p_msg OUT VARCHAR2) AS

    v_goapi_version_number   NUMBER;
    x_gop_return_status      VARCHAR2(2);
    x_gomsg_count            NUMBER;
    x_gomsg_data             VARCHAR2(2000);
    v_poapi_version_number   NUMBER;
    x_pop_return_status      VARCHAR2(2);
    x_pomsg_count            NUMBER;
    x_pomsg_data             VARCHAR2(2000);
    v_goheader               VARCHAR2(10);
    v_msg_data               VARCHAR2(8000) := null;
    v_msg_index_out          NUMBER(10) := 0;
    v_poheader_rec           OE_ORDER_PUB.Header_Rec_Type;
    x_header_rec             OE_ORDER_PUB.Header_Rec_Type;
    x_header_upd_rec         OE_ORDER_PUB.Header_Rec_Type;
    x_header_val_rec         OE_ORDER_PUB.Header_Val_Rec_Type;
    x_Header_Adj_tbl         OE_ORDER_PUB.Header_Adj_Tbl_Type;
    x_Header_Adj_val_tbl     OE_ORDER_PUB.Header_Adj_Val_Tbl_Type;
    x_Header_price_Att_tbl   OE_ORDER_PUB.Header_Price_Att_Tbl_Type;
    x_Header_Adj_Att_tbl     OE_ORDER_PUB.Header_Adj_Att_Tbl_Type;
    x_Header_Adj_Assoc_tbl   OE_ORDER_PUB.Header_Adj_Assoc_Tbl_Type;
    x_Header_Scredit_tbl     OE_ORDER_PUB.Header_Scredit_Tbl_Type;
    x_Header_Scredit_val_tbl OE_ORDER_PUB.Header_Scredit_Val_Tbl_Type;
    x_line_tbl               OE_ORDER_PUB.Line_Tbl_Type;
    x_line_update_tbl        OE_ORDER_PUB.Line_Tbl_Type;
    x_line_upd_tbl           OE_ORDER_PUB.Line_Tbl_Type;
    x_line_val_tbl           OE_ORDER_PUB.Line_Val_Tbl_Type;
    x_Line_Adj_tbl           OE_ORDER_PUB.Line_Adj_Tbl_Type;
    x_Line_Adj_val_tbl       OE_ORDER_PUB.Line_Adj_Val_Tbl_Type;
    x_Line_price_Att_tbl     OE_ORDER_PUB.Line_Price_Att_Tbl_Type;
    x_Line_Adj_Att_tbl       OE_ORDER_PUB.Line_Adj_Att_Tbl_Type;
    x_Line_Adj_Assoc_tbl     OE_ORDER_PUB.Line_Adj_Assoc_Tbl_Type;
    x_Line_Scredit_tbl       OE_ORDER_PUB.Line_Scredit_Tbl_Type;
    x_Line_Scredit_val_tbl   OE_ORDER_PUB.Line_Scredit_Val_Tbl_Type;
    x_Lot_Serial_tbl         OE_ORDER_PUB.Lot_Serial_Tbl_Type;
    x_Lot_Serial_val_tbl     OE_ORDER_PUB.Lot_Serial_Val_Tbl_Type;
    x_action_request_tbl     OE_ORDER_PUB.Request_Tbl_Type;
    p_action_request_tbl     OE_ORDER_PUB.Request_Tbl_Type;
    v_lcount                 NUMBER;
    v_rtrim_data             VARCHAR2(1);
    v_validate_desc_flex     VARCHAR2(1);
    v_reason_code            VARCHAR2(30);
    V_USER_ID                FND_USER.USER_ID%TYPE;
    V_RESP_ID                FND_RESPONSIBILITY_TL.RESPONSIBILITY_ID%TYPE;
    V_APP_ID                 FND_RESPONSIBILITY_TL.APPLICATION_ID%TYPE;
    l_authorized             VARCHAR(10);
    l_cust_id                NUMBER;
    l_cancel_reason          VARCHAR(100);
    l_status                 VARCHAR(50);
    l_flag                   VARCHAR(5);
    l_counter                NUMBER := 0;
    v_OU_ID                 VARCHAR2(20);  --30-OCT Manisha K Added to save the OU_ID
  BEGIN
    <<cancel_order_api>> -- Amita.B JIRA GESQY-92
 /********************************************************
  Manisha K. 4-OCT-2018 Passport Requirements.
  Earlier responsibility ,  used to call outside the loop using P_OU_ID.
  Now, OU_ID is fetched using header so placed the below code inside the header loop
  ********************************************************/

  IF P_OU_ID like '%~%' THEN
      BEGIN
      SELECT org_Id
      INTO v_OU_ID FROM oe_order_headers_all
      WHERE HEADER_ID =p_HEADER_ID ;
      EXCEPTION
      WHEN OTHERS THEN
      P_MSG := 'Error while fetching the OU_ID: '||SQLCODE||SQLERRM;
      goto end_proc;
      END;
  ELSE
    v_OU_ID := P_OU_ID;
  END IF;

  IF v_ou_id IS NULL THEN
        p_MSG:=GET_ERR_MSG(8503);
        goto end_proc;
    END IF;

    -- get ResponsibilityID/AppID/UserID
    BEGIN
      SELECT RESP.RESPONSIBILITY_ID, RESP.APPLICATION_ID
        INTO V_RESP_ID, V_APP_ID
        FROM FND_RESPONSIBILITY_TL RESP,
             FND_LOOKUP_VALUES     FLV,
             HR_OPERATING_UNITS    HOU
       WHERE HOU.NAME = FLV.MEANING
         AND RESP.RESPONSIBILITY_NAME = FLV.DESCRIPTION
         AND HOU.ORGANIZATION_ID = v_OU_ID  --p_OU_ID
         AND FLV.LOOKUP_TYPE = 'GEAE_MYGE_ORDER_RESPONSIBILITY';
    EXCEPTION
      WHEN no_data_found THEN
        P_MSG := GET_ERR_MSG(8026);
        GOTO end_proc;
    END;

    -- Get user ID
    SELECT USER_ID INTO V_USER_ID FROM FND_USER WHERE USER_NAME = p_SSO;

    -- Get cancel reason
    SELECT DESCRIPTION
      INTO l_cancel_reason
      FROM FND_LOOKUP_VALUES
     WHERE LOOKUP_TYPE = 'GEAE_MYGE_ORD_LN_CANCEL_REASON'
       AND LOOKUP_CODE = v_OU_ID ; --p_OU_ID;

    --If order already cancelled
    SELECT FLOW_STATUS_CODE, CANCELLED_FLAG
      INTO l_status, l_flag
      FROM oe_order_lines_all
     WHERE line_id = p_LINE_ID;

    IF l_status = 'CANCELLED' AND l_flag = 'Y' THEN
      P_MSG := GET_ERR_MSG(8186);
      GOTO end_proc;
    END IF;

    v_goapi_version_number := 1.0;
    v_goheader             := FND_API.G_MISS_CHAR;
    mo_global.init('ONT');
    FND_GLOBAL.APPS_INITIALIZE(V_USER_ID, V_RESP_ID, V_APP_ID);
    mo_global.set_policy_context('S', v_OU_ID);

    -- Get order details
    oe_order_pub.get_order(p_api_version_number     => v_goapi_version_number,
                           p_init_msg_list          => FND_API.G_FALSE,
                           p_return_values          => FND_API.G_FALSE,
                           x_return_status          => x_gop_return_status,
                           x_msg_count              => x_gomsg_count,
                           x_msg_data               => x_gomsg_data,
                           p_header_id              => p_HEADER_ID,
                           p_header                 => v_goheader,
                           x_header_rec             => x_header_rec,
                           x_header_val_rec         => x_header_val_rec,
                           x_Header_Adj_tbl         => x_Header_Adj_tbl,
                           x_Header_Adj_val_tbl     => x_Header_Adj_val_tbl,
                           x_Header_price_Att_tbl   => x_Header_price_Att_tbl,
                           x_Header_Adj_Att_tbl     => x_Header_Adj_Att_tbl,
                           x_Header_Adj_Assoc_tbl   => x_Header_Adj_Assoc_tbl,
                           x_Header_Scredit_tbl     => x_Header_Scredit_tbl,
                           x_Header_Scredit_val_tbl => x_Header_Scredit_val_tbl,
                           x_line_tbl               => x_line_tbl,
                           x_line_val_tbl           => x_line_val_tbl,
                           x_Line_Adj_tbl           => x_Line_Adj_tbl,
                           x_Line_Adj_val_tbl       => x_Line_Adj_val_tbl,
                           x_Line_price_Att_tbl     => x_Line_price_Att_tbl,
                           x_Line_Adj_Att_tbl       => x_Line_Adj_Att_tbl,
                           x_Line_Adj_Assoc_tbl     => x_Line_Adj_Assoc_tbl,
                           x_Line_Scredit_tbl       => x_Line_Scredit_tbl,
                           x_Line_Scredit_val_tbl   => x_Line_Scredit_val_tbl,
                           x_Lot_Serial_tbl         => x_Lot_Serial_tbl,
                           x_Lot_Serial_val_tbl     => x_Lot_Serial_val_tbl);

    -- If there is any error it will list down in this below loop.

    IF (x_gop_return_status != FND_API.G_RET_STS_SUCCESS) THEN
      IF TO_NUMBER(x_gomsg_count) > 0 THEN
        FOR Cur_I IN 1 .. x_gomsg_count LOOP
          Oe_Msg_Pub.get(p_msg_index     => Cur_I,
                         p_encoded       => Fnd_Api.G_FALSE,
                         p_data          => x_gomsg_data,
                         p_msg_index_out => v_msg_index_out);
          --Changes made for API Message
          fnd_file.put_line(fnd_file.OUTPUT, 'ERROR: ' || x_gomsg_data);
          fnd_file.put_line(fnd_file.LOG,
                            'Order Number ==== ' ||
                             x_header_rec.order_number ||
                             ' Line Number ==== ' || x_line_upd_tbl(1)
                            .line_number || '.' || x_line_upd_tbl(1)
                            .Shipment_number);
          --DBMS_OUTPUT.PUT_LINE('ERROR: ' || x_gomsg_data); -- To display error if any

        END LOOP;
      END IF;
    ELSE
      fnd_file.put_line(fnd_file.LOG,
                        'Return Status   = ' ||
                        SUBSTR(x_gop_return_status, 1, 255));
      fnd_file.put_line(fnd_file.LOG,
                        'Order Number    = ' || x_header_rec.order_number);
      fnd_file.put_line(fnd_file.LOG,
                        'Order Number ==== ' || x_header_rec.order_number ||
                         ' Line Number ==== ' || x_line_tbl(1).line_number || '.' || x_line_tbl(1)
                        .Shipment_number);
      fnd_file.put_line(fnd_file.LOG,
                        'Ordered Item    = ' || x_line_tbl(1).ordered_item);
      fnd_file.put_line(fnd_file.LOG,
                        'Ordered Quantity= ' || x_line_tbl(1)
                        .ordered_quantity);
      fnd_file.put_line(fnd_file.LOG,
                        'Order Quantity uom=' || x_line_tbl(1)
                        .order_quantity_uom);
      fnd_file.put_line(fnd_file.LOG, 'Data is succesfully retrived. ');
      --DBMS_OUTPUT.PUT_LINE('Data is succesfully retrived. ');
    END IF;

    --Authorization logic
    IF p_HEADER_ID IS NOT NULL THEN
      l_authorized := 'N';
      BEGIN
        SELECT sold_to_org_id
          INTO l_cust_id
          FROM oe_order_headers_all
         WHERE header_id = p_HEADER_ID;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          p_msg := GET_ERR_MSG(8010) || '|';
          goto end_proc;
      END;
      FOR i IN 1 .. P_CUST_ID.COUNT LOOP
        IF P_CUST_ID(i) = l_cust_id THEN
          l_authorized := 'Y';
        END IF;
      END LOOP;
      IF l_authorized = 'N' THEN
        p_msg := GET_ERR_MSG(8180) || '|';
        goto end_proc;
      END IF;
    END IF;

    --ONLY WHEN OE_ORDER_PUB.GET_ORDER API IS SUCCESSFUL CALL to PROCESS_ORDER
    IF (x_gop_return_status = FND_API.G_RET_STS_SUCCESS) THEN
      v_poapi_version_number   := 1.0;
      v_rtrim_data             := 'N';
      v_validate_desc_flex     := 'Y';
      v_poheader_rec           := OE_ORDER_PUB.G_MISS_HEADER_REC;
      v_poheader_rec.header_id := x_header_rec.header_id;
      v_lcount                 := 0;
      -- For getting the line in the table.
      FOR cur_i in 1 .. x_line_tbl.count LOOP
        IF x_line_tbl(CUR_i).line_id = p_LINE_ID THEN
          v_lcount := cur_i;
        END IF;
      END LOOP;

      IF v_lcount > 0 then
        x_line_update_tbl := x_line_tbl;
        --Assigning new values to the Line_rec fields for Cancellation
        x_line_update_tbl(v_lcount).header_id := p_HEADER_ID;
        x_line_update_tbl(v_lcount).line_id := p_LINE_ID;
        x_line_update_tbl(v_lcount).ordered_quantity := 0;
        x_line_update_tbl(v_lcount).cancelled_quantity := 0;
        x_line_update_tbl(v_lcount).change_reason := l_cancel_reason;
        x_line_update_tbl(v_lcount).cancelled_flag := 'Y';
        x_line_update_tbl(v_lcount).open_flag := 'N';
        x_line_update_tbl(v_lcount).operation := OE_GLOBALS.G_OPR_UPDATE;

        oe_order_pub.process_order(p_api_version_number     => v_poapi_version_number,
                                   p_init_msg_list          => fnd_api.g_true,
                                   p_return_values          => fnd_api.g_false,
                                   p_action_commit          => fnd_api.g_false,
                                   x_return_status          => x_pop_return_status,
                                   x_msg_count              => x_pomsg_count,
                                   x_msg_data               => x_pomsg_data,
                                   p_header_rec             => x_header_rec,
                                   p_line_tbl               => x_line_update_tbl,
                                   p_action_request_tbl     => p_action_request_tbl,
                                   x_header_rec             => x_header_rec,
                                   x_header_val_rec         => x_header_val_rec,
                                   x_header_adj_tbl         => x_header_adj_tbl,
                                   x_header_adj_val_tbl     => x_header_adj_val_tbl,
                                   x_header_price_att_tbl   => x_header_price_att_tbl,
                                   x_header_adj_att_tbl     => x_header_adj_att_tbl,
                                   x_header_adj_assoc_tbl   => x_header_adj_assoc_tbl,
                                   x_header_scredit_tbl     => x_header_scredit_tbl,
                                   x_header_scredit_val_tbl => x_header_scredit_val_tbl,
                                   x_line_tbl               => x_line_upd_tbl,
                                   x_line_val_tbl           => x_line_val_tbl,
                                   x_line_adj_tbl           => x_line_adj_tbl,
                                   x_line_adj_val_tbl       => x_line_adj_val_tbl,
                                   x_line_price_att_tbl     => x_line_price_att_tbl,
                                   x_line_adj_att_tbl       => x_line_adj_att_tbl,
                                   x_line_adj_assoc_tbl     => x_line_adj_assoc_tbl,
                                   x_line_scredit_tbl       => x_line_scredit_tbl,
                                   x_line_scredit_val_tbl   => x_line_scredit_val_tbl,
                                   x_lot_serial_tbl         => x_lot_serial_tbl,
                                   x_lot_serial_val_tbl     => x_lot_serial_val_tbl,
                                   x_action_request_tbl     => x_action_request_tbl,
                                   p_rtrim_data             => v_rtrim_data,
                                   p_validate_desc_flex     => v_validate_desc_flex);

        --DBMS_OUTPUT.PUT_LINE('stsus '||x_pop_return_status);
        IF (x_pop_return_status = FND_API.G_RET_STS_SUCCESS) THEN
          fnd_file.put_line(fnd_file.LOG,
                            'Request Status - ' ||
                            SUBSTR(x_pop_return_status, 1, 255));
          fnd_file.put_line(fnd_file.LOG,
                            '------------------------------------');
          fnd_file.put_line(fnd_file.LOG,
                            'Order Number ==== ' ||
                            x_header_rec.order_number);
          fnd_file.put_line(fnd_file.LOG,
                            'Order Number ==== ' ||
                             x_header_rec.order_number ||
                             ' Line Number ==== ' || x_line_upd_tbl(v_lcount)
                            .line_number || '.' || x_line_upd_tbl(v_lcount)
                            .Shipment_number);
          fnd_file.put_line(fnd_file.LOG, 'Line cancelled successfully. ');
          --DBMS_OUTPUT.PUT_LINE('Line cancelled successfully. ');
          p_msg := NULL;

        ELSE
          IF TO_NUMBER(x_pomsg_count) > 0 THEN
            FOR Cur_I IN 1 .. x_pomsg_count LOOP
              Oe_Msg_Pub.get(p_msg_index     => 1,
                             p_encoded       => Fnd_Api.G_FALSE,
                             p_data          => x_pomsg_data,
                             p_msg_index_out => v_msg_index_out);
              --Amita.B JIRA GESQY-92
              LOOP
                l_counter := l_counter + 1;
                DBMS_OUTPUT.PUT_LINE(l_counter);
                IF x_pomsg_data LIKE
                   '%ORA-01403: no data found in Package OE_Line_Security Procedure Attributes%' THEN
                  goto cancel_order_api;
                ELSIF x_pomsg_data LIKE
                      '%ORA-01403: no data found in Package OE_Order_Cache Procedure get_tax_calculation_flag|%' THEN
                  goto cancel_order_api;
                ELSIF x_pomsg_data LIKE '%ORA-01403: no data found%' THEN
                  goto cancel_order_api;
                END IF;
                IF l_counter = 1 THEN
                  EXIT;
                END IF;
              END LOOP;
              --END JIRA GESQY-92
              IF x_pomsg_data LIKE
                 'Validation failed for the field - Change Reas%' THEN
                p_msg := GET_ERR_MSG(8181);
              ELSIF x_pomsg_data LIKE 'You are not allowed to update Ordered Quantity because:
Line is cancelled' THEN
                p_msg := GET_ERR_MSG(8182);
              ELSIF x_pomsg_data LIKE 'You are not allowed to cancel Order Line because:
You can not cancel an Included Item.' THEN
                p_msg := GET_ERR_MSG(8184);
              ELSIF x_pomsg_data LIKE
                    'You are not allowed to cancel Order Line because:
Cancellation Not Allowed.Line Interfaced to WMS' THEN
                p_msg := GET_ERR_MSG(8185);
              ELSIF x_pomsg_data LIKE '%Line Interfaced to WMS' THEN
                p_msg := GET_ERR_MSG(8187);
              ELSIF x_pomsg_data LIKE 'Scheduling failed.

ATP Processing error' THEN
                p_msg := GET_ERR_MSG(8183);
              ELSE
                p_msg := '8300:' || SUBSTR(x_pomsg_data, 1, 100);
              END IF;

            END LOOP;
          END IF;
        END IF;
      ELSE
        p_msg := GET_ERR_MSG(8177);
        goto end_proc;
      END IF; -- v_count if

    END IF; --Get_order if

    <<end_proc>>
    NULL;
    COMMIT;
  END CANCEL_ORDER_LINE;
END GEAE_MYGE_UPDATE_ORDER_PKG;