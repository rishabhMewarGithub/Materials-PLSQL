
      SELECT distinct cmr.lookup_code,cmr.description,  (SUBSTR(ret.lookup_code,INSTR(ret.lookup_code,'-')+1))
        FROM apps.fnd_lookup_values ret, apps.oe_order_lines_all ool, apps.fnd_lookup_values cmr
       WHERE 1=1--ool.header_id = P_ORDER_ID
       --  AND ool.return_reason_code = cmr.lookup_code
         AND ret.description = cmr.meaning
         AND cmr.lookup_type = 'CREDIT_MEMO_REASON'
         AND ret.lookup_type = 'GEAE_MYGE_DISPUTE_RET_REASON'
        -- AND SUBSTR(ret.lookup_code,1,INSTR(ret.lookup_code,'-')-1) = v_OU_ID   --P_OU_ID
         AND ret.enabled_flag = 'Y'
         AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(ret.start_date_active,SYSDATE)) AND TRUNC(NVL(ret.end_date_active,SYSDATE))
         AND cmr.enabled_flag = 'Y'
         AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(cmr.start_date_active,SYSDATE)) AND TRUNC(NVL(cmr.end_date_active,SYSDATE))
         AND (SUBSTR(ret.lookup_code,INSTR(ret.lookup_code,'-')+1)) in (
          'OVERAGE','DISCREPANCY' , 'BUYBACK')
         ;
        
         
    ----------------------------------------------------------------------------------------------------------------
         
            SELECT ln_tp.tag, ln_tp.MEANING, ln_tp.DESCRIPTION --1095
       -- INTO P_PART_NUMBER, P_QUANTITY, P_COO
        FROM  apps.fnd_lookup_values ln_tp
       WHERE 1=1--ool.header_id = P_ORDER_ID
       --  AND ool.org_id = v_OU_ID --P_OU_ID
        -- AND ool.line_type_id = ln_tp.tag
        -- AND ln_tp.lookup_code = P_OU_ID||DECODE(l_ret_reason,'BUYBACK','-RECEIVE AND CREDIT','-OVERAGE RETURN')
        AND ln_tp.lookup_code = 98757||DECODE('OVERAGE','DISCREPANCY','-RECEIVE AND CREDIT','-OVERAGE RETURN')
         AND ln_tp.lookup_type = 'GEAE_MYGE_DISPUTE_LINE_TYPES'
         AND ln_tp.enabled_flag = 'Y'
         AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(ln_tp.start_date_active,SYSDATE)) AND TRUNC(NVL(ln_tp.end_date_active,SYSDATE))
         ;
         
    -------------------------------------------------------------------------------------------------------------------------
        
    -------------------------------------------------------------------------------------------------------------------------
    
         select header_id, CUST_PO_NUMBER from apps.oe_order_headers_all where header_id in
         (select header_id from apps.oe_order_lines_all where return_reason_code='001' and line_type_id=1171
         and org_id =98757);
         
         
         
         
         
    --------------------------------------------------------------------------------------------------------------------
         
            --    Dicrepancy and Overage,   Overage Return
         
        ----------------------------------------------------------------------------------------------------------------

         
         
         select CUST_ACCOUNT_ID, ATTRIBUTE11 from apps.hz_cust_accounts where account_number ='G9S';
         
         
    
         
    -----------------------------------------------------------------------
    
    
    
    
    --REQUEST_LOGIN 
	DECLARE
	  P_OPERATING_UNIT_ID VARCHAR2(200);
	  P_ICAO_CODE VARCHAR2(200);
	  P_USER_NAME VARCHAR2(200);
	  P_IMPERSONATION_FLAG VARCHAR2(200);
	  P_ROLES VARCHAR2(200);
	  P_CUST_ARRAY APPS.V_CUST_ARRAY := NEW V_CUST_ARRAY() ;
	  P_MESSAGE VARCHAR2(200);
	BEGIN
	  P_OPERATING_UNIT_ID := '98757';
	  P_ICAO_CODE := 'MMFF';
	  P_USER_NAME := '502299002';
	  P_IMPERSONATION_FLAG := 'No';

	  GEAE_MYGE_LOGIN.REQUEST_LOGIN(
		P_OPERATING_UNIT_ID => P_OPERATING_UNIT_ID,
		P_ICAO_CODE => P_ICAO_CODE,
		P_USER_NAME => P_USER_NAME,
		P_IMPERSONATION_FLAG => P_IMPERSONATION_FLAG,
		P_ROLES => P_ROLES,
		P_CUST_ARRAY => P_CUST_ARRAY,
		P_MESSAGE => P_MESSAGE
	  );

	DBMS_OUTPUT.PUT_LINE('P_ROLES = ' || P_ROLES);
	for i in 1..P_CUST_ARRAY.COUNT LOOP
	DBMS_OUTPUT.PUT_LINE('P_CUST_ARRAY = ' || P_CUST_ARRAY(i).CUST_ID);
	END LOOP;

	DBMS_OUTPUT.PUT_LINE('P_MESSAGE = ' || P_MESSAGE);

	END;
	/
    
    
    
    -----------------------------------------------------------------------------------
    
    
    
    ---GET_LABEL_INFORMATION
DECLARE
  P_SSO VARCHAR2(200);
  P_IACO_CODE VARCHAR2(200);
  P_CUST_ID APPS.V_CUST_ID_ARRAY :=NEW apps.V_CUST_ID_ARRAY();
  P_ROLE VARCHAR2(200);
  P_OU_ID VARCHAR2(200);
  P_ORDER_ID NUMBER;
  P_RMA_NUMBER NUMBER;
  P_PO_NUMBER VARCHAR2(200);
  P_PART_NUMBER VARCHAR2(200);
  P_QUANTITY NUMBER;
  P_REASON VARCHAR2(200);
  P_COO VARCHAR2(200);
  P_MSG VARCHAR2(200);
BEGIN
  P_SSO := '502299002';
  P_IACO_CODE := 'GLO';
  P_CUST_ID.EXTEND(1);
  p_cust_id(1):=400688;
  P_ROLE := 'Buyer';
  P_OU_ID := '98757';
  P_ORDER_ID := 349722;

  apps.GEAE_MYGE_SHIPMENT_DISPUTE_PKG.GET_LABEL_INFORMATION(
    P_SSO => P_SSO,
    P_IACO_CODE => P_IACO_CODE,
    P_CUST_ID => P_CUST_ID,
    P_ROLE => P_ROLE,
    P_OU_ID => P_OU_ID,
    P_ORDER_ID => P_ORDER_ID,
    P_RMA_NUMBER => P_RMA_NUMBER,
    P_PO_NUMBER => P_PO_NUMBER,
    P_PART_NUMBER => P_PART_NUMBER,
    P_QUANTITY => P_QUANTITY,
    P_REASON => P_REASON,
    P_COO => P_COO,
    P_MSG => P_MSG
  );

DBMS_OUTPUT.PUT_LINE('P_RMA_NUMBER = ' || P_RMA_NUMBER);

DBMS_OUTPUT.PUT_LINE('P_PO_NUMBER = ' || P_PO_NUMBER);

DBMS_OUTPUT.PUT_LINE('P_PART_NUMBER = ' || P_PART_NUMBER);

DBMS_OUTPUT.PUT_LINE('P_QUANTITY = ' || P_QUANTITY);

DBMS_OUTPUT.PUT_LINE('P_REASON = ' || P_REASON);

DBMS_OUTPUT.PUT_LINE('P_COO = ' || P_COO);

DBMS_OUTPUT.PUT_LINE('P_MSG = ' || P_MSG);

END;
/