


CREATE OR REPLACE PROCEDURE CRD_OTR_TAB_REFRESH AS


BEGIN
	DELETE FROM CRD.MV_CRD_OTR_VIEW ;
	COMMIT;


	INSERT INTO 
		CRD.MV_CRD_OTR_VIEW

	SELECT 	"SHOP NAME",
			"PURCHASE ORDER NO",
			"PO LINE NO",
			"SHOP ORDER",
			"CUSTOMER NAME",
			"BILL TO NAME",
			"GEAE CUSTOMER NO",
			"SUB CUSTOMER NAME",
			"ESN",
			"ENG_MDL_NUMBER",
			"ENGINE MODEL",
			"PART NUMBER IN",
			"PART NUMBER OUT",
			"PART DESCRIPTION",
			"PART KEYWORD NEW",
			"PART SERIAL NUMBER",
			"ORIG QTY",
			"QTY REJECTED",
			"QTY REPAIRED",
			"QTY REPLACED",
			"BAL QTY",
			"DOCK DATE",
			"REQD DATE",
			"SCHEDULE DELIVERY DATE",
			"FORECAST TAT",
			"MS#",
			"MS CREATE DATE",
			"PROMISED DATE",
			"SHIP DATE",
			"RPR CLS CODE",
			"QTY SHIPD",
			"AWB#",
			"CARIER CODE",
			"CSM ID#",
			"SO CREATE DATE",
			"SHOP ORDER AGE",
			"COMPONENT CODE",
			"REPORT INDICATOR",
			"INITIAL QUOTE",
			"DAYS TO QUOTE",
			"RFQA Y/N",
			"DATE OF QUOTE APPROVAL",
			"QUOTED PRICE",
			"CONTRACT TAT",
			"TAT",
			"UNIT PRICE",
			"EXTENDED PRICE",
			"ROTABLE CODE",
			"SCHEDULE CUSTOM COMMENTS",
			"CSM_FIRST_NAME",
			"CSM_LAST_NAME",
			"REPORT CODE DESCR",
			"ENGINE FAMILY",
			"CUSTOMER NUMBER",
			"PO LINE STATUS"
		
	FROM
		(
			SELECT 	DISTINCT 	DECODE(coli.location_id,'EV','ACSC')	AS 	"SHOP NAME",
								xref.CUST_PO_NUMBER                    	AS	"PURCHASE ORDER NO",
								xref.cust_po_li_num                     AS 	"PO LINE NO",
								so.intell_so_number                     AS 	"SHOP ORDER",
								NULL                                   	AS 	"SHIPG DOC LI NBR",
								CRD_APP.CRD_COMMON_FUNCT_PKG.get_Customer_name_grp_New
																(
																	coli.location_id,
																	so.cust_id_num,
																	so.bill_to_seq_num,
																	CRD_APP.CRD_COMMON_FUNCT_PKG.get_BILL_TO_NAME
																									(
																										coli.location_id,
																										so.cust_id_num,
																										so.bill_to_seq_num
																									)
																) 		AS 	"CUSTOMER NAME",
								CRD_APP.CRD_COMMON_FUNCT_PKG.get_BILL_TO_NAME
																(
																	coli.location_id,
																	so.cust_id_num, 
																	so.bill_to_seq_num
																)       AS 	"BILL TO NAME",
								CRD_APP.CRD_COMMON_FUNCT_PKG.get_GEAE_CUST_NUMBER
																(
																	coli.location_id,
																	so.cust_id_num, 
																	so.bill_to_seq_num 
																)      AS 	"GEAE CUSTOMER NO",
								CRD_APP.CRD_COMMON_FUNCT_PKG.get_SUB_BILL_TO_NAME
																(
																	coli.location_id,
																	so.sub_cust_id_num, 
																	so.sub_cust_bill_to_seq_num
																)     	AS 	"SUB CUSTOMER NAME",
								DECODE(SUBSTR(so.esn_number,1,1),'0','`'	||	so.esn_number,so.esn_number) 												AS 	ESN,
								DECODE(coli.location_id, 'EV',DECODE(so.eng_mdl_number, '100','43', '107','45', '108','12', '109','29', '110','30', '112','31', '150','6', '214','27', '373','20', '386','51', '101','4C', '370','49', '289','9B', '123','T7', '379','M0', '374','9X', '375','9Z', '376','98', '116','F8', '121','P6', '361','X1', '112','31', '111','32', '356','14', '354','LG', '360','F2', 'T58','58', '129','F9', '124','44',so.eng_mdl_number))	ENG_MDL_NUMBER,
								DECODE(so.eng_mdl_number, 'X1','GENX-1B','X2','GENX-2B',CRD_APP.CRD_COMMON_FUNCT_PKG.get_ENG_PL_NEW(coli.ENG_MDL_NUMBER)) 	AS "ENGINE MODEL",
								coli.part_number                       	AS 	"PART NUMBER IN",
								NULL                                    AS 	"PART NUMBER OUT",
								( 
									SELECT DISTINCT 	org_part_desc
									FROM 	crd_org_part
									WHERE 	part_number 	= coli.part_number
									AND 	org_id_num    	= 12
									AND 	location_id   	= 'EV'
								)                                       AS "PART DESCRIPTION",
								CRD_APP.CRD_COMMON_FUNCT_PKG.get_PART_KEYWORD_HEADER_NEW
																(
																	coli.part_number, 
																	CRD_APP.CRD_COMMON_FUNCT_PKG.get_ENG_PL_NEW(so.ENG_MDL_NUMBER), 
																	coli.CMPNT_CD,
																	coli.location_id
																) 		AS 	"PART KEYWORD NEW",
								srl.srl_number                          AS 	"PART SERIAL NUMBER",
								coli.part_qty                           AS 	"ORIG QTY",
								NULL                                    AS 	"QTY REJECTED",
								NULL                                   	AS 	"QTY REPAIRED",
								NULL                                                                                                                                                                       AS "QTY REPLACED",
								so.bal_due_qty                                                                                                                                                             AS "BAL QTY",
								TO_CHAR(coli.dock_date,'DD-MON-YYYY')                                                                                                                                      AS "DOCK DATE",
									CASE
										WHEN 	coli.reqd_date	> 	to_date('31-DEC-2022','DD-MON-RRRR')
											THEN 	'`'	||	TO_CHAR(coli.reqd_date,'DD-MON-YYYY')
										ELSE 
											TO_CHAR(coli.reqd_date,'DD-MON-YYYY')
									END AS "REQD DATE",
									CASE
										WHEN 	rlsesch.schd_dlvry_date > to_date('31-DEC-2022','DD-MON-RRRR')
											THEN 	'`'	||	TO_CHAR(rlsesch.schd_dlvry_date,'DD-MON-YYYY')
										ELSE 
											TO_CHAR(rlsesch.schd_dlvry_date,'DD-MON-YYYY')
									END AS "SCHEDULE DELIVERY DATE",
									CASE
										WHEN 	rlsesch.schd_dlvry_date >= to_date('01-JAN-2100','DD-MON-YYYY')
											THEN 	NULL
										ELSE 	( rlsesch.schd_dlvry_date-coli.dock_date)
									END  AS "FORECAST TAT",
								NULL 									AS 	"MS#",
								NULL 									AS 	"MS CREATE DATE" ,
								CASE
									WHEN 	(so.prmsd_date) > to_date('31-DEC-2022','DD-MON-RRRR')
										THEN 	'`'	||	TO_CHAR(so.prmsd_date,'DD-MON-YYYY')
									ELSE 	TO_CHAR(so.prmsd_date ,'DD-MON-YYYY')
								END  	AS "PROMISED DATE",
								NULL 									AS 	"SHIP DATE",
								NULL 									AS 	"RPR CLS CODE",
								NULL 									AS 	"QTY SHIPD",
								NULL 									AWB#,
								NULL                                    AS 	"CARIER CODE",
								TO_CHAR(co.csm_user_id_num)             AS 	"CSM ID#", -- added by suvarna
								TO_CHAR(so.create_date ,'DD-MON-YYYY')  AS 	"SO CREATE DATE",
								ROUND( ( sysdate-coli.dock_date),0)     AS 	"SHOP ORDER AGE",
								coli.cmpnt_cd                           AS 	"COMPONENT CODE" ,
								so.so_rpt_cd                            AS 	"REPORT INDICATOR",
								TO_CHAR(rfqa.quote_date,'DD-MON-YYYY')  AS 	"INITIAL QUOTE",
								rfqa.days_to_quote                      AS 	"DAYS TO QUOTE",
								so.rfqa_reqd_flg                        AS 	"RFQA Y/N",
								DECODE(so.rfqa_reqd_flg,'Y',TO_CHAR(rfqa.rfqa_rcv_date,'DD-MON-YYYY')) AS "DATE OF QUOTE APPROVAL",
								rfqa.TOTAL_PRICE                                                       AS "QUOTED PRICE",
								CASE
									WHEN 	coli.reqd_date >= to_date('01-JAN-2100','DD-MON-YYYY')
										THEN 	NULL
									ELSE	(coli.reqd_date	-	coli.dock_date)
								END 			AS "CONTRACT TAT",
								NULL 			TAT,
								NULL          	AS "UNIT PRICE",
								NULL          	AS "EXTENDED PRICE",
								coli.rtbl_cd  	AS "ROTABLE CODE",
								cmnt.cmnt_txt 	AS "SCHEDULE CUSTOM COMMENTS",
								
								/* BELOW COLUMNS ARE ADDED BY MURARI  BAIKADY ON 9/22/2016 -START */
								
								up.FIRST_NAME                   AS 	CSM_FIRST_NAME,
								up.LAST_NAME                    AS 	CSM_LAST_NAME,
								esd.lookup_descr                AS 	"REPORT CODE DESCR",
								CRD_APP.CRD_COMMON_FUNCT_PKG.REPAIR_OTR_ENGINE_FAMILY_FUN(coli.ENG_MDL_NUMBER) 		AS 	"ENGINE FAMILY",  ---------- added by suvarna
								CRD_APP.CRD_COMMON_FUNCT_PKG.REPAIR_OTR_CUSTOMER_NUMBER_FUN(coli.location_id,so.cust_id_num, so.bill_to_seq_num ) AS "CUSTOMER NUMBER",  ------------- added by suvarna
								DECODE(so.BAL_DUE_QTY,0,'CLOSED','OPEN') AS "PO LINE STATUS"
								
								/*END*/
			FROM 	CRD_SO 						so,
					CRD_CO 						co,
					crd_so_rfqa 				rfqa,
					CRD_CO_LI 					coli,
					CRD_PO_LI_ORDCMPNT_XREF 	xref,
					(
						SELECT 	srl_number,
								ORD_CMPNT_ID,
								part_number ,
								ord_cmpnt_amdmt_num
						FROM 	crd_ord_cmpnt_srl
						WHERE 	(ORD_CMPNT_ID,ord_comp_seq_num) IN
									(
										SELECT 	ORD_CMPNT_ID,
												MAX(ord_comp_seq_num)
										FROM 	crd_ord_cmpnt_srl
										WHERE 	location_id       		=	'EV'
										AND 	ord_cmpnt_cd        	=	'L'
										AND 	ord_cmpnt_srl_sts_cd	=	'A'
										GROUP BY ORD_CMPNT_ID
									)
						AND 	location_id         	=	'EV'
						AND 	ord_cmpnt_cd        	=	'L'
						AND 	ord_cmpnt_srl_sts_cd	=	'A'
					)	srl,
					crd_co_li_rlse_schd 	rlsesch,
					(
						SELECT 	cmnt_txt,
								ORD_CMPNT_ID,
								ord_cmpnt_cstm_cmnt_sts_cd
						FROM 	CRD_ORD_CMPNT_CSTM_CMNT
						WHERE 	(ORD_CMPNT_ID,cmnt_seq_num) IN
									(
										SELECT 	ORD_CMPNT_ID,
												MAX(cmnt_seq_num)
										FROM 	CRD_ORD_CMPNT_CSTM_CMNT
										WHERE 	location_id	=	'EV'
										GROUP BY ORD_CMPNT_ID
									)
						AND location_id	=	'EV'
					)	cmnt,
					
					/* BELOW COLUMNS ARE ADDED BY MURARI  BAIKADY ON 9/22/2016 -START */
					(
						SELECT 	*
						FROM 	crd_user_prfl
						WHERE 	location_id	=	'EV'
					) 	up,
					( 
						SELECT 	* 
						FROM 	esd_lookup 
						WHERE 	lookup_nbr	=	1950 
						AND 	location_id	=	'EV'
					) 	esd
					
					/*END*/
			WHERE 	coli.CO_NUMBER                    	= so.ASM_CO_NUMBER
			AND 	coli.CO_LI_NUM                      = so.ASM_CO_LI_NUM
			AND 	coli.AMDMT_NUM                      = so.ASM_CO_AMDMT_NUM
			AND 	co.CO_NUMBER                        = coli.CO_NUMBER
			AND 	co.AMDMT_NUM                        = coli.AMDMT_NUM
			AND 	coli.location_id                    = 'EV'
			AND 	so.location_id                      = 'EV'
			AND 	co.location_id                      = 'EV'
			AND 	xref.location_id                    = 'EV'
			AND 	cmnt.ord_cmpnt_id (+)               = coli.REF_ID
			AND 	ord_cmpnt_cstm_cmnt_sts_cd(+)       = 'A'
			AND 	coli.ref_id                         = xref.ord_cmpnt_id(+)
			AND 	XREF.po_li_ord_cmpnt_xref_sts_cd(+) = 'A'
			AND 	coli.ORG_ID_NUM                     = 12
			AND 	so.ORG_ID_NUM                       = 12
			AND 	so.AMDMT_STS_CD                     = 'A'
			AND 	so.so_amdmt_num                     =
															(
																SELECT 	MAX(so_amdmt_num)
																FROM 	crd_so so1
																WHERE 	so1.asm_co_number IS NOT NULL
																AND 	so1.AMDMT_STS_CD     = 'A'
																AND 	so1.ORG_ID_NUM       = 12
																AND 	so1.location_id      = 'EV'
																AND 	so1.so_number        = so.so_number
															)
			AND 	so.bal_due_qty               >	0
			AND 	coli.ref_id                  =	srl.ord_cmpnt_id(+)
			AND 	coli.part_number             =	srl.part_number(+)
			AND 	srl.ord_cmpnt_amdmt_num(+)   =	coli.amdmt_num
			AND 	rlsesch.co_number(+)         =	coli.co_number
			AND 	rlsesch.co_li_num(+)         =	coli.co_li_num
			AND 	rlsesch.location_id(+)       =	'EV'
			AND 	rlse_sts_cd_num              = 	5
			AND 	so.create_date              <= SYSDATE
			AND 	rfqa.so_number(+)            =	so.so_number
			AND 	rfqa.location_id(+)          =	'EV'
			AND 	rfqa.rfqa_sts_cd(+)          =	'A'
			AND 	coli.part_number 			NOT IN ('UNKNOWN' , 'UNK' , 'MISC')
			AND 	cmnt.ord_cmpnt_id (+)        = 	coli.REF_ID
			AND 	ord_cmpnt_cstm_cmnt_sts_cd(+)=	'A'
			AND 	(
						SELECT 	geae_cust_number
						FROM 	crd_cust_bill_to 	cb
						WHERE 	cb.cust_id_num       	=	coli.cust_id_num
						AND 	cb.bill_to_seq_num     	=	coli.bill_to_seq_num
						AND 	cb.location_id         	=	'EV'	
					)	
					NOT IN	
					(	
						'56576','9573B', '9200M','9526B','9524B','9570B','9200A','9571B'
					)
			AND 	coli.eng_mdl_number 		NOT IN
												(	
													SELECT 	eng_mdl_number 
													FROM 	crd_eng_mdl 
													WHERE 	eng_prod_ln_scrubbed = 'APU'
												)
			AND 	coli.cmpnt_cd <>'UNK'
			
			/* BELOW COLUMNS ARE ADDED BY MURARI  BAIKADY ON 9/22/2016 -START */
			AND 	co.CSM_USER_ID_NUM	=	up.user_id_num(+)
			AND 	so.so_rpt_cd      	=	esd.lookup_code(+)
			/*END */

			
			
			
			
			
			
			
			UNION ALL

			
			
			
			
			
			
			SELECT	DISTINCT 	DECODE(coli.location_id,'EV','ACSC')        AS "SHOP NAME",
								xref.CUST_PO_NUMBER                         AS "PURCHASE ORDER NO",
								xref.cust_po_li_num                         AS "PO LINE NO",
								so.intell_so_number                         AS "SHOP ORDER",
								SDL.SHIPG_DOC_LI_NUM                        AS "SHIPG DOC LI NBR",
								CRD_APP.CRD_COMMON_FUNCT_PKG.get_Customer_name_grp_New
																(
																	coli.location_id,
																	so.cust_id_num,
																	so.bill_to_seq_num,
																	CRD_APP.CRD_COMMON_FUNCT_PKG.get_BILL_TO_NAME
																									(
																										coli.location_id,
																										so.cust_id_num,
																										so.bill_to_seq_num
																									)
																) 			AS "CUSTOMER NAME",
								CRD_APP.CRD_COMMON_FUNCT_PKG.get_BILL_TO_NAME(coli.location_id,so.cust_id_num, so.bill_to_seq_num)                   AS "BILL TO NAME",
								CRD_APP.CRD_COMMON_FUNCT_PKG.get_GEAE_CUST_NUMBER(coli.location_id,so.cust_id_num, so.bill_to_seq_num )              AS "GEAE CUSTOMER NO",
								CRD_APP.CRD_COMMON_FUNCT_PKG.get_SUB_BILL_TO_NAME(coli.location_id,so.sub_cust_id_num, so.sub_cust_bill_to_seq_num)  AS "SUB CUSTOMER NAME",
								DECODE(SUBSTR(so.esn_number,1,1),'0','`'	||	so.esn_number,so.esn_number) 										 AS ESN,
								DECODE(coli.location_id, 'EV',DECODE(so.eng_mdl_number, '100','43', '107','45', '108','12', '109','29', '110','30', '112','31', '150','6', '214','27', '373','20', '386','51', '101','4C', '370','49', '289','9B', '123','T7', '379','M0', '374','9X', '375','9Z', '376','98', '116','F8', '121','P6', '361','X1', '112','31', '111','32', '356','14', '354','LG', '360','F2', 'T58','58', '129','F9', '124','44',so.eng_mdl_number))ENG_MDL_NUMBER,
								DECODE(so.eng_mdl_number, 'X1','GENX-1B','X2','GENX-2B',CRD_APP.CRD_COMMON_FUNCT_PKG.get_ENG_PL_NEW(coli.ENG_MDL_NUMBER)) AS "ENGINE MODEL",
								coli.part_number                            AS "PART NUMBER IN",
								SDL.PART_NUMBER                             AS "PART NUMBER OUT",
								( 
									SELECT 	DISTINCT org_part_desc
									FROM 	crd_org_part
									WHERE 	part_number 	= coli.part_number
									AND 	org_id_num    	= 12
									AND 	location_id   	= 'EV'
								)                                       	AS "PART DESCRIPTION" ,
								CRD_APP.CRD_COMMON_FUNCT_PKG.get_PART_KEYWORD_NEW
																(
																	SDL.PART_NUMBER, 
																	SDL.SHIPG_PART_DESC, 
																	CRD_APP.CRD_COMMON_FUNCT_PKG.get_ENG_PL_NEW(SDL.ENG_MDL_NUMBER), 
																	SDL.CMPNT_CD,coli.location_id) AS "PART KEYWORD NEW",
    srl.srl_number                                                                                                                                                          AS "PART SERIAL NUMBER",
    coli.part_qty                                                                                                                                                           AS "ORIG QTY",
    DECODE(sdl.rpr_cls_cd,'NSMR', SDL.SHIPG_QTY,'NSERV',SDL.SHIPG_QTY,'DCRNSM',SDL.SHIPG_QTY,'DCNSCR',SDL.SHIPG_QTY,'DCNNSM',SDL.SHIPG_QTY,NULL)                            AS "QTY REJECTED",
    DECODE(sdl.rpr_cls_cd,'1LEREP',SDL.SHIPG_QTY,'2LEREP', SDL.SHIPG_QTY,'3LEEXC', SDL.SHIPG_QTY,'LEREP', SDL.SHIPG_QTY,'ABVEXC', SDL.SHIPG_QTY,'ABVREP', SDL.SHIPG_QTY, 'ADEREP',SDL.SHIPG_QTY,'ADHREP',SDL.SHIPG_QTY,'ADPREP',SDL.SHIPG_QTY,'AFTEXC',SDL.SHIPG_QTY,'AFTREP',SDL.SHIPG_QTY,'ANTREP',SDL.SHIPG_QTY,'ARBREP',SDL.SHIPG_QTY, 'EP TR',SDL.SHIPG_QTY,'EPRP',SDL.SHIPG_QTY,'EPTES',SDL.SHIPG_QTY,'ERTBC',SDL.SHIPG_QTY,'EX REP',SDL.SHIPG_QTY,'FULLQ',SDL.SHIPG_QTY,'GFP',SDL.SHIPG_QTY,'High',SDL.SHIPG_QTY, 'Med',SDL.SHIPG_QTY,'MPR',SDL.SHIPG_QTY,'MPRA',SDL.SHIPG_QTY,'MPRAT',SDL.SHIPG_QTY,'MPRT',SDL.SHIPG_QTY,'N5REP',SDL.SHIPG_QTY,'PR',SDL.SHIPG_QTY,'PRA',SDL.SHIPG_QTY,'PRREP',SDL.SHIPG_QTY, 'PRT',SDL.SHIPG_QTY,'PTSTRP',SDL.SHIPG_QTY,'R142',SDL.SHIPG_QTY,'RADCF',SDL.SHIPG_QTY,'RADCFX',SDL.SHIPG_QTY,'RALMD',SDL.SHIPG_QTY,'RALMDX',SDL.SHIPG_QTY,'REJUV',SDL.SHIPG_QTY, 'REPPA',SDL.SHIPG_QTY,'REPPR',SDL.SHIPG_QTY,'REPRA',SDL.SHIPG_QTY,'REPRP',SDL.SHIPG_QTY,'RPLATE',SDL.SHIPG_QTY,'SALV',
    SDL.SHIPG_QTY,'SB-102',SDL.SHIPG_QTY,'SB-118',SDL.SHIPG_QTY, 'SLOT15',SDL.SHIPG_QTY,'SPADT',SDL.SHIPG_QTY,'SW EP',SDL.SHIPG_QTY,'SW SB',SDL.SHIPG_QTY,'SW+PA',SDL.SHIPG_QTY,'SW1EP',SDL.SHIPG_QTY,'SWET',SDL.SHIPG_QTY,'SWET1',SDL.SHIPG_QTY, 'SWET1P',SDL.SHIPG_QTY,'SWETTE',SDL.SHIPG_QTY,'SWP SB',SDL.SHIPG_QTY,'SWVS',SDL.SHIPG_QTY,'TERPL',SDL.SHIPG_QTY,'VPAREP',SDL.SHIPG_QTY,'VPREP1',SDL.SHIPG_QTY,'VPREP2',SDL.SHIPG_QTY, 'VPREP3',SDL.SHIPG_QTY,'VPREP4',SDL.SHIPG_QTY,'VPREP5',SDL.SHIPG_QTY,'VPREP6',SDL.SHIPG_QTY,'VPREP7',SDL.SHIPG_QTY,'VPREP8',SDL.SHIPG_QTY,'VPREP9',SDL.SHIPG_QTY,'VPREPA',SDL.SHIPG_QTY, 'VPREPB',SDL.SHIPG_QTY,'VPREP10',SDL.SHIPG_QTY,'AFREPL',SDL.SHIPG_QTY,'DCEXC',SDL.SHIPG_QTY,'EXC',SDL.SHIPG_QTY,'FULL',SDL.SHIPG_QTY,'REP',SDL.SHIPG_QTY,'STRIP',SDL.SHIPG_QTY,'STRP',SDL.SHIPG_QTY, 'TBC',SDL.SHIPG_QTY,'1010',SDL.SHIPG_QTY,'AFR',SDL.SHIPG_QTY,'DER',SDL.SHIPG_QTY,'Low',SDL.SHIPG_QTY,'MINI',SDL.SHIPG_QTY,'REPDEV',SDL.SHIPG_QTY,'RJVTBC',SDL.SHIPG_QTY,'SPADL',SDL.SHIPG_QTY,
    'SVREP',SDL.SHIPG_QTY,'SWETPA',SDL.SHIPG_QTY,'SWPTBC',SDL.SHIPG_QTY,'TACK',SDL.SHIPG_QTY,'TR',SDL.SHIPG_QTY,'DCUSED',SDL.SHIPG_QTY,NULL)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              AS "QTY REPAIRED",
    DECODE(sdl.rpr_cls_cd,'1LEEXC', SDL.SHIPG_QTY,'2LEEXC', SDL.SHIPG_QTY,'ADEEXC', SDL.SHIPG_QTY,'ADHEXC', SDL.SHIPG_QTY,'ADPEXC', SDL.SHIPG_QTY,'ANTEXC', SDL.SHIPG_QTY,'ARBEXC', SDL.SHIPG_QTY, 'DEREXC', SDL.SHIPG_QTY,'ER EXC', SDL.SHIPG_QTY,'MINIEX', SDL.SHIPG_QTY,'N5EXC', SDL.SHIPG_QTY,'NEW/MK', SDL.SHIPG_QTY,'OTIME', SDL.SHIPG_QTY,'PRAT', SDL.SHIPG_QTY,'TL', SDL.SHIPG_QTY, 'VPAEXC', SDL.SHIPG_QTY,'DCNEW', SDL.SHIPG_QTY,'NEW', SDL.SHIPG_QTY,'QPR', SDL.SHIPG_QTY,'SERV', SDL.SHIPG_QTY,'SPEC', SDL.SHIPG_QTY,'SPECNC', SDL.SHIPG_QTY,'LEASE', SDL.SHIPG_QTY, 'SCRPLC', SDL.SHIPG_QTY,'TEST', SDL.SHIPG_QTY,'RES', SDL.SHIPG_QTY,NULL) AS "QTY REPLACED",
    so.bal_due_qty                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        AS "BAL QTY",
    TO_CHAR(coli.dock_date,'DD-MON-YYYY')                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 AS "DOCK DATE",
    CASE
      WHEN coli.reqd_date> to_date('31-DEC-2022','DD-MON-RRRR')
      THEN '`'
        ||TO_CHAR(coli.reqd_date,'DD-MON-YYYY')
      ELSE TO_CHAR(coli.reqd_date,'DD-MON-YYYY')
    END AS "REQD DATE",
    CASE
      WHEN rlsesch.schd_dlvry_date > to_date('31-DEC-2022','DD-MON-RRRR')
      THEN '`'
        ||TO_CHAR(rlsesch.schd_dlvry_date,'DD-MON-YYYY')
      ELSE TO_CHAR(rlsesch.schd_dlvry_date,'DD-MON-YYYY')
    END                                 AS "SCHEDULE DELIVERY DATE",
    NULL                                AS "FORECAST TAT",
    to_char(SDL.shipg_doc_num)                  AS "MS#",  -- added by suvarna
    TO_CHAR(shd.initd_ts,'DD-MON-YYYY') AS "MS CREATE DATE" ,
    CASE
      WHEN (so.prmsd_date) > to_date('31-DEC-2022','DD-MON-RRRR')
      THEN '`'
        ||TO_CHAR(so.prmsd_date,'DD-MON-YYYY')
      ELSE TO_CHAR(so.prmsd_date ,'DD-MON-YYYY')
    END                                   AS "PROMISED DATE" ,
    TO_CHAR(SHD.shipd_date,'DD-MON-YYYY') AS "SHIP DATE",
    SDL.RPR_CLS_CD                        AS "RPR CLS CODE",
    SDL.SHIPG_QTY                         AS "QTY SHIPD",
    '`'
    || SHD.WAYBILL_NUMBER AWB#,
    shd.carier_cd                                                          AS "CARIER CODE",
    to_char(co.csm_user_id_num)                                                     AS "CSM ID#",  -- added by suvarna
    TO_CHAR(so.create_date,'DD-MON-YYYY')                                  AS "SO CREATE DATE",
    ROUND((SYSDATE - coli.dock_date),0)                                    AS "SHOP ORDER AGE",
    sdl.cmpnt_cd                                                           AS "COMPONENT CODE" ,
    so.so_rpt_cd                                                           AS "REPORT INDICATOR",
    TO_CHAR(rfqa.quote_date,'DD-MON-YYYY')                                 AS "INITIAL QUOTE",
    rfqa.days_to_quote                                                     AS "DAYS TO QUOTE",
    so.rfqa_reqd_flg                                                       AS "RFQA Y/N",
    DECODE(so.rfqa_reqd_flg,'Y',TO_CHAR(rfqa.rfqa_rcv_date,'DD-MON-YYYY')) AS "DATE OF QUOTE APPROVAL",
    rfqa.TOTAL_PRICE                                                       AS "QUOTED PRICE",
    CASE
      WHEN coli.reqd_date >= TO_DATE('01-JAN-2100','DD-MON-YYYY')
      THEN NULL
      ELSE (coli.reqd_date-coli.dock_date)
    END AS "CONTRACT TAT",
    (shd.shipd_date-coli.dock_date) TAT,
    sdl.unt_price_amt                   AS "UNIT PRICE",
    (sdl.shipg_QTY * sdl.unt_price_amt) AS "EXTENDED PRICE",
    coli.rtbl_cd                        AS "ROTABLE CODE",
    cmnt.cmnt_txt                       AS "SCHEDULE CUSTOM COMMENTS",
         /* below columns are added by Murari  Baikady on 9/22/2016 -START */
  up.FIRST_NAME                                                          AS CSM_FIRST_NAME,
  up.LAST_NAME                                                           AS CSM_LAST_NAME,
  esd.lookup_descr                                                       AS "REPORT CODE DESCR",
  CRD_APP.CRD_COMMON_FUNCT_PKG.REPAIR_OTR_ENGINE_FAMILY_FUN(coli.ENG_MDL_NUMBER) AS "ENGINE FAMILY",
  CRD_APP.CRD_COMMON_FUNCT_PKG.REPAIR_OTR_CUSTOMER_NUMBER_FUN(coli.location_id,so.cust_id_num, so.bill_to_seq_num ) AS "CUSTOMER NUMBER",
  decode(so.BAL_DUE_QTY,0,'CLOSED','OPEN') AS "PO LINE STATUS"
  /*END*/
  FROM CRD_SO so,
    CRD_CO co,
    CRD_SHIPG_DOC_LI SDL,
    CRD_SHIPG_DOC SHD,
    crd_so_rfqa rfqa,
    CRD_CO_LI coli,
    CRD_PO_LI_ORDCMPNT_XREF xref,
    (SELECT srl_number,
      ORD_CMPNT_ID,
      part_number ,
      ord_cmpnt_amdmt_num
    FROM crd_ord_cmpnt_srl
    WHERE (ORD_CMPNT_ID,ord_comp_seq_num) IN
      (SELECT ORD_CMPNT_ID,
        MAX(ord_comp_seq_num)
      FROM crd_ord_cmpnt_srl
      WHERE location_id       ='EV'
      AND ord_cmpnt_cd        ='L'
      AND ord_cmpnt_srl_sts_cd='A'
      GROUP BY ORD_CMPNT_ID
      )
    AND location_id         ='EV'
    AND ord_cmpnt_cd        ='L'
    AND ord_cmpnt_srl_sts_cd='A'
    )srl,
    crd_co_li_rlse_schd rlsesch,
    CRD_shipg_li_ordcmpnt_rls sdlocr,
    (SELECT cmnt_txt,
      ORD_CMPNT_ID,
      ord_cmpnt_cstm_cmnt_sts_cd
    FROM CRD_ORD_CMPNT_CSTM_CMNT
    WHERE (ORD_CMPNT_ID,cmnt_seq_num) IN
      (SELECT ORD_CMPNT_ID,
        MAX(cmnt_seq_num)
      FROM CRD_ORD_CMPNT_CSTM_CMNT
      WHERE location_id='EV'
      GROUP BY ORD_CMPNT_ID
      )
    AND location_id='EV'
    )cmnt,

/* below columns are added by Murari  Baikady on 9/22/2016 -START */
   (select  *  from crd_user_prfl  where location_id='EV') up,
  ( SELECT * FROM esd_lookup WHERE lookup_nbr=1950 AND location_id='EV'
  ) esd
  /*END*/

  WHERE coli.CO_NUMBER                = so.ASM_CO_NUMBER
  AND coli.CO_LI_NUM                  = so.ASM_CO_LI_NUM
  AND coli.AMDMT_NUM                  = so.ASM_CO_AMDMT_NUM
  AND co.CO_NUMBER                    = coli.CO_NUMBER
  AND co.AMDMT_NUM                    = coli.AMDMT_NUM
  AND rfqa.so_number(+)               =so.so_number
  AND sdlocr.ord_cmpnt_id             = coli.REF_ID
  AND cmnt.ord_cmpnt_id (+)           = coli.REF_ID
  AND ord_cmpnt_cstm_cmnt_sts_cd(+)   ='A'
  AND sdl.shipg_doc_num               = sdlocr.shipg_doc_num
  AND sdl.shipg_doc_li_NUM            = sdlocr.shipg_doc_li_nUM
  AND sdl.shipg_doc_cls_CD            = sdlocr.shipg_doc_cls_CD
  AND SDL.SHIPG_DOC_NUM               =SHD.SHIPG_DOC_NUM
  AND SDL.SHIPG_DOC_CLS_CD            = SHD.SHIPG_DOC_CLS_CD
  AND SDL.SHIPG_DOC_AMDMT_NUM         = SHD.SHIPG_DOC_AMDMT_NUM
  AND rlsesch.co_number               =coli.co_number
  AND rlsesch.co_li_num               =coli.co_li_num
  AND rlsesch.location_id             ='EV'
  AND rlsesch.rlse_seq_num            =sdlocr.rlse_seq_num
  AND rlsesch.rlse_qty                = sdl.shipg_qty
  AND coli.location_id                = 'EV'
  AND so.location_id                  = 'EV'
  AND co.location_id                  = 'EV'
  AND SDL.location_id                 ='EV'
  AND shd.location_id                 ='EV'
  AND sdlocr.location_id              = 'EV'
  AND rfqa.location_id(+)             ='EV'
  AND xref.location_id                = 'EV'
  AND coli.ref_id                     =srl.ord_cmpnt_id (+)
  AND coli.part_number                =srl.part_number (+)
  AND srl.ord_cmpnt_amdmt_num(+)      =coli.amdmt_num
  AND rfqa.rfqa_sts_cd(+)             ='A'
  AND coli.ref_id                     =xref.ord_cmpnt_id
  AND XREF.po_li_ord_cmpnt_xref_sts_cd= 'A'
  AND coli.ORG_ID_NUM                 = 12
  AND SDL.ORG_ID_NUM                  = 12
  AND so.ORG_ID_NUM                   = 12
  AND so.AMDMT_STS_CD                 = 'A'
  AND (SHD.AMDMT_STS_CD               = 'A'
  OR shd.amdmt_sts_cd                IS NULL)
  AND shd.shipg_sts_cd               <> 65
  AND sdlocr.ord_Cmpnt_cd             = 'L'
  AND SDL.SHIPG_DOC_CLS_CD            = 'MS'
  AND ((shd.shipd_date BETWEEN (SYSDATE- 365) AND SYSDATE)
  OR (shd.shipd_date       IS NULL
  AND shd.initd_ts         IS NOT NULL))
  AND coli.part_number NOT IN ('UNKNOWN' , 'UNK' , 'MISC')
  AND sdl.part_number NOT  IN ('UNKNOWN' , 'UNK' , 'MISC')
  AND (SELECT geae_cust_number
    FROM crd_cust_bill_to cb
    WHERE cb.cust_id_num       =coli.cust_id_num
    AND cb.bill_to_seq_num     =coli.bill_to_seq_num
    AND cb.location_id         ='EV')NOT IN('56576','9573B', '9200M','9526B','9524B','9570B','9200A','9571B')
  AND coli.eng_mdl_number NOT            IN
    (SELECT eng_mdl_number FROM crd_eng_mdl WHERE eng_prod_ln_scrubbed = 'APU'
    )
  AND coli.cmpnt_cd <>'UNK'
    /* below columns are added by Murari  Baikady on 9/22/2016 -START */
AND co.CSM_USER_ID_NUM=up.user_id_num(+)
AND so.so_rpt_cd      =esd.lookup_code(+)
/*END */

  )
  
  
  

UNION ALL





SELECT 
	  "SHOP NAME",
	  "PURCHASE ORDER NO",
	  "PO LINE NO",
	  "SHOP ORDER",
	  "CUSTOMER NAME",
	  "BILL TO NAME",
	  "GEAE CUSTOMER NO",
	  "SUB CUSTOMER NAME",
	  "ESN",
	  "ENG_MDL_NUMBER",
	  "ENGINE MODEL",
	  "PART NUMBER IN",
	  "PART NUMBER OUT",
	  "PART DESCRIPTION",
	  "PART KEYWORD NEW",
	  "PART SERIAL NUMBER",
	  "ORIG QTY",
	  "QTY REJECTED",
	  "QTY REPAIRED",
	  "QTY REPLACED",
	  "BAL QTY",
	  "DOCK DATE",
	  "REQD DATE",
	  "SCHEDULE DELIVERY DATE",
	  "FORECAST TAT",
	  "MS#",
	  "MS CREATE DATE",
	  "PROMISED DATE",
	  "SHIP DATE",
	  "RPR CLS CODE",
	  "QTY SHIPD",
	  "AWB#",
	  "CARIER CODE",
	  "CSM ID#",
	  "SO CREATE DATE",
	  "SHOP ORDER AGE",
	  "COMPONENT CODE",
	  "REPORT INDICATOR",
	  "INITIAL QUOTE",
	  "DAYS TO QUOTE",
	  "RFQA Y/N",
	  "DATE OF QUOTE APPROVAL",
	  "QUOTED PRICE",
	  "CONTRACT TAT",
	  "TAT",
	  "UNIT PRICE",
	  "EXTENDED PRICE",
	  "ROTABLE CODE",
	  "SCHEDULE CUSTOM COMMENTS",
	  "CSM_FIRST_NAME",
	  "CSM_LAST_NAME",
	  "REPORT CODE DESCR",
	  "ENGINE FAMILY",
	  "CUSTOMER NUMBER",
	  "PO LINE STATUS"
	  
	  
FROM


  (
	SELECT DISTINCT DECODE(coli.location_id,'SI','GEASO')                                                                                                                                                          AS "SHOP NAME",
					  xref.CUST_PO_NUMBER                                                                                                                                                                                          AS "PURCHASE ORDER NO",
					  xref.cust_po_li_num                                                                                                                                                                                          AS "PO LINE NO",
					  so.intell_so_number                                                                                                                                                                                          AS "SHOP ORDER",
					NULL                                                                                                                                                                                                         AS "SHIPG DOC LI NBR",
				  CRD_APP.CRD_COMMON_FUNCT_PKG.get_Customer_name_grp_New(coli.location_id,so.cust_id_num,so.bill_to_seq_num,CRD_APP.CRD_COMMON_FUNCT_PKG.get_BILL_TO_NAME(coli.location_id,so.cust_id_num,so.bill_to_seq_num)) AS "CUSTOMER NAME",
				  CRD_APP.CRD_COMMON_FUNCT_PKG.get_BILL_TO_NAME(coli.location_id,so.cust_id_num, so.bill_to_seq_num)                                                                                                           AS "BILL TO NAME",
				  CRD_APP.CRD_COMMON_FUNCT_PKG.get_GEAE_CUST_NUMBER(coli.location_id,so.cust_id_num, so.bill_to_seq_num )                                                                                                      AS "GEAE CUSTOMER NO",
				  CRD_APP.CRD_COMMON_FUNCT_PKG.get_SUB_BILL_TO_NAME(coli.location_id,so.sub_cust_id_num, so.sub_cust_bill_to_seq_num)                                                                                          AS "SUB CUSTOMER NAME",
				DECODE(SUBSTR(so.esn_number,1,1),'0','`' ||so.esn_number,so.esn_number) AS ESN,
			  DECODE(coli.location_id, 'SI',DECODE(so.eng_mdl_number, '100','43', '107','45', '108','12', '109','29', '110','30', '112','31', '150','6', '214','27', '373','20', '386','51', '101','4C', '370','49', '289','9B', '123','T7', '379','M0', '374','9X', '375','9Z', '376','98', '116','F8', '121','P6', '361','X1', '112','31', '111','32', '356','14', '354','LG', '360','F2', 'T58','58', '129','F9', '124','44',so.eng_mdl_number))ENG_MDL_NUMBER,
			  CRD_APP.CRD_COMMON_FUNCT_PKG.get_ENG_PL_NEW(coli.ENG_MDL_NUMBER) AS "ENGINE MODEL",
			  coli.part_number                                                 AS "PART NUMBER IN",
				NULL                                                             AS "PART NUMBER OUT",
			  ( 	SELECT DISTINCT org_part_desc
				  FROM crd_org_part
				  WHERE part_number = coli.part_number
				  AND org_id_num    = 12
				  AND location_id   = 'SI'
			  )                                                                                                                                                                          AS "PART DESCRIPTION",
			  CRD_APP.CRD_COMMON_FUNCT_PKG.get_PART_KEYWORD_HEADER_NEW(coli.part_number, CRD_APP.CRD_COMMON_FUNCT_PKG.get_ENG_PL_NEW(so.ENG_MDL_NUMBER), coli.CMPNT_CD,coli.location_id) AS "PART KEYWORD NEW",
			  srl.srl_number                                                                                                                                                             AS "PART SERIAL NUMBER",
			  coli.part_qty                                                                                                                                                              AS "ORIG QTY",
			  NULL                                                                                                                                                                       AS "QTY REJECTED",
			  NULL                                                                                                                                                                       AS "QTY REPAIRED",
			  NULL                                                                                                                                                                       AS "QTY REPLACED",
			  so.bal_due_qty                                                                                                                                                             AS "BAL QTY",
			
			TO_CHAR(coli.dock_date,'DD-MON-YYYY')                                                                                                                                      AS "DOCK DATE",
			  CASE
				WHEN coli.reqd_date> to_date('31-DEC-2022','DD-MON-RRRR')
				THEN '`'
				  ||TO_CHAR(coli.reqd_date,'DD-MON-YYYY')
				ELSE TO_CHAR(coli.reqd_date,'DD-MON-YYYY')
			  END AS "REQD DATE",
			  
			  CASE
				WHEN rlsesch.schd_dlvry_date > to_date('31-DEC-2022','DD-MON-RRRR')
				THEN '`'
				  ||TO_CHAR(rlsesch.schd_dlvry_date,'DD-MON-YYYY')
				ELSE TO_CHAR(rlsesch.schd_dlvry_date,'DD-MON-YYYY')
			  END AS "SCHEDULE DELIVERY DATE",
			  
			  CASE
				WHEN rlsesch.schd_dlvry_date >= TO_DATE('01-JAN-2100','DD-MON-YYYY')
				THEN NULL
				ELSE ( rlsesch.schd_dlvry_date-coli.dock_date)
			  END  AS "FORECAST TAT",
			  
			  NULL AS "MS#",
			  NULL AS "MS CREATE DATE" ,
			  
			  CASE
				WHEN (so.prmsd_date) > to_date('31-DEC-2022','DD-MON-RRRR')
				THEN '`'
				  ||TO_CHAR(so.prmsd_date,'DD-MON-YYYY')
				ELSE TO_CHAR(so.prmsd_date ,'DD-MON-YYYY')
			  END  AS "PROMISED DATE",
			  
			  NULL AS "SHIP DATE",
			  NULL AS "RPR CLS CODE",
			  NULL AS "QTY SHIPD",
			  NULL AWB#,
			  NULL               AS "CARIER CODE",
			  to_char(co.csm_user_id_num) AS "CSM ID#",  -- added by suvarna
			  TO_CHAR(so.create_date ,'DD-MON-YYYY') AS "SO CREATE DATE",
			  ROUND( ( SYSDATE-coli.dock_date),0)    AS "SHOP ORDER AGE",
			  coli.cmpnt_cd                          AS "COMPONENT CODE" ,
			  so.so_rpt_cd                           AS "REPORT INDICATOR",
			  TO_CHAR(rfqa.quote_date,'DD-MON-YYYY')                                 AS "INITIAL QUOTE",
			  rfqa.days_to_quote                                                     AS "DAYS TO QUOTE",
			  so.rfqa_reqd_flg                                                       AS "RFQA Y/N",
			  DECODE(so.rfqa_reqd_flg,'Y',TO_CHAR(rfqa.rfqa_rcv_date,'DD-MON-YYYY')) AS "DATE OF QUOTE APPROVAL",
			  rfqa.TOTAL_PRICE   AS "QUOTED PRICE",
			  
			  CASE
				WHEN coli.reqd_date >= TO_DATE('01-JAN-2100','DD-MON-YYYY')
				THEN NULL
				ELSE (coli.reqd_date-coli.dock_date)
			  END AS "CONTRACT TAT",
			  
			  NULL TAT,
			  NULL          AS "UNIT PRICE",
			  NULL          AS "EXTENDED PRICE",
			  coli.rtbl_cd  AS "ROTABLE CODE",
			  cmnt.cmnt_txt AS "SCHEDULE CUSTOM COMMENTS",
				/* below columns are added by Murari  Baikady on 9/22/2016 -START */
			  up.FIRST_NAME                                                          AS CSM_FIRST_NAME,
			  up.LAST_NAME                                                           AS CSM_LAST_NAME,
			  esd.lookup_descr                                                       AS "REPORT CODE DESCR",
			  CRD_APP.CRD_COMMON_FUNCT_PKG.REPAIR_OTR_ENGINE_FAMILY_FUN(coli.ENG_MDL_NUMBER) AS "ENGINE FAMILY",
			  CRD_APP.CRD_COMMON_FUNCT_PKG.REPAIR_OTR_CUSTOMER_NUMBER_FUN(coli.location_id,so.cust_id_num, so.bill_to_seq_num ) AS "CUSTOMER NUMBER",
			  decode(so.BAL_DUE_QTY,0,'CLOSED','OPEN') AS "PO LINE STATUS"
			/*END*/
			
	FROM 	CRD_SO so,
			CRD_CO co,
			crd_so_rfqa rfqa,
			CRD_CO_LI coli,
			CRD_PO_LI_ORDCMPNT_XREF xref,
			(		SELECT srl_number,
						ORD_CMPNT_ID,
						part_number ,
						ord_cmpnt_amdmt_num
					FROM 	crd_ord_cmpnt_srl
					WHERE (ORD_CMPNT_ID,ord_comp_seq_num) IN
						(	SELECT ORD_CMPNT_ID,
									MAX(ord_comp_seq_num)
							FROM crd_ord_cmpnt_srl
							WHERE location_id       ='SI'
							AND ord_cmpnt_cd        ='L'
							AND ord_cmpnt_srl_sts_cd='A'
							GROUP BY ORD_CMPNT_ID
						)
					AND location_id         ='SI'
					AND ord_cmpnt_cd        ='L'
					AND ord_cmpnt_srl_sts_cd='A'
			)srl,
			
			crd_co_li_rlse_schd rlsesch,
		
			(			SELECT cmnt_txt,
							ORD_CMPNT_ID,
										ord_cmpnt_cstm_cmnt_sts_cd
					FROM CRD_ORD_CMPNT_CSTM_CMNT
					WHERE (ORD_CMPNT_ID,cmnt_seq_num) IN
								(	SELECT ORD_CMPNT_ID,
											MAX(cmnt_seq_num)
									FROM CRD_ORD_CMPNT_CSTM_CMNT
									WHERE location_id='SI'
									GROUP BY ORD_CMPNT_ID
								)
					AND location_id='SI'
			)cmnt,
	
	/* below columns are added by Murari  Baikady on 9/22/2016 -START */
			(
				  SELECT *
				  FROM crd_user_prfl
				  WHERE location_id='SI'
			) up,
			
			( 
				SELECT * FROM esd_lookup WHERE lookup_nbr=1950 AND location_id='SI'
			) esd
			
  /*END*/
  
  
  
	WHERE coli.CO_NUMBER                    = so.ASM_CO_NUMBER
	AND coli.CO_LI_NUM                      = so.ASM_CO_LI_NUM
	AND coli.AMDMT_NUM                      = so.ASM_CO_AMDMT_NUM
	AND co.CO_NUMBER                        = coli.CO_NUMBER
	AND co.AMDMT_NUM                        = coli.AMDMT_NUM
	AND coli.location_id                    = 'SI'
	AND so.location_id                      = 'SI'
	AND co.location_id                      = 'SI'
	AND xref.location_id                    = 'SI'
	AND cmnt.ord_cmpnt_id (+)               = coli.REF_ID
	AND ord_cmpnt_cstm_cmnt_sts_cd(+)       ='A'
	AND coli.ref_id                         =xref.ord_cmpnt_id(+)
	AND XREF.po_li_ord_cmpnt_xref_sts_cd(+) = 'A'
	AND coli.ORG_ID_NUM                     = 12
	AND so.ORG_ID_NUM                       = 12
	AND so.AMDMT_STS_CD                     = 'A'
	AND so.so_amdmt_num                     =
											  (		SELECT MAX(so_amdmt_num)
												  FROM crd_so so1
												  WHERE so1.asm_co_number IS NOT NULL
												  AND so1.AMDMT_STS_CD     = 'A'
												  AND so1.ORG_ID_NUM       = 12
												  AND so1.location_id      ='SI'
												  AND so1.so_number        =so.so_number
											  )
	AND so.bal_due_qty            >0
	AND coli.ref_id               =srl.ord_cmpnt_id(+)
	AND coli.part_number          =srl.part_number(+)
	AND srl.ord_cmpnt_amdmt_num(+)=coli.amdmt_num
	AND rlsesch.co_number(+)      = coli.co_number
	AND rlsesch.co_li_num(+)      = coli.co_li_num
	AND rlsesch.location_id(+)    ='SI'
	AND rlse_sts_cd_num           = 5
	AND so.create_date           <= SYSDATE
	AND rfqa.so_number(+)         =so.so_number
	AND rfqa.location_id(+)       ='SI'
	AND rfqa.rfqa_sts_cd(+)       ='A'
	AND cmnt.ord_cmpnt_id(+)      = coli.REF_ID
	AND coli.part_number NOT LIKE 'SET%'
	AND ord_cmpnt_cstm_cmnt_sts_cd(+)='A'
	AND coli.eng_mdl_number NOT     IN
			(
				SELECT eng_mdl_number FROM crd_eng_mdl WHERE eng_prod_ln_scrubbed = 'APU'
			)
	AND coli.cmpnt_cd <>'UNK'
	  /* below columns are added by Murari  Baikady on 9/22/2016 -START */
	AND co.CSM_USER_ID_NUM=up.user_id_num(+)
	AND so.so_rpt_cd      =esd.lookup_code(+)
	
  /*END */
  
  
  
    UNION ALL

	

	
	SELECT	DISTINCT 
	DECODE(coli.location_id,'SI','GEASO')                                                                                                                                               AS "SHOP NAME",
    xref.CUST_PO_NUMBER                                                                                                                                                                          AS "PURCHASE ORDER NO",
    xref.cust_po_li_num                                                                                                                                                                          AS "PO LINE NO",
    so.intell_so_number                                                                                                                                                                          AS "SHOP ORDER",
    SDL.SHIPG_DOC_LI_NUM                                                                                                                                                                         AS "SHIPG DOC LI NBR",
    CRD_APP.CRD_COMMON_FUNCT_PKG.get_Customer_name_grp_New(coli.location_id,so.cust_id_num,so.bill_to_seq_num,CRD_APP.CRD_COMMON_FUNCT_PKG.get_BILL_TO_NAME(coli.location_id,so.cust_id_num,so.bill_to_seq_num)) AS "CUSTOMER NAME",
    CRD_APP.CRD_COMMON_FUNCT_PKG.get_BILL_TO_NAME(coli.location_id,so.cust_id_num, so.bill_to_seq_num)                                                                                                   AS "BILL TO NAME",
    CRD_APP.CRD_COMMON_FUNCT_PKG.get_GEAE_CUST_NUMBER(coli.location_id,so.cust_id_num, so.bill_to_seq_num )                                                                                              AS "GEAE CUSTOMER NO",
    CRD_APP.CRD_COMMON_FUNCT_PKG.get_SUB_BILL_TO_NAME(coli.location_id,so.sub_cust_id_num, so.sub_cust_bill_to_seq_num)                                                                                  AS "SUB CUSTOMER NAME",
    DECODE(SUBSTR(so.esn_number,1,1),'0','`'	||so.esn_number,so.esn_number) AS ESN,
    DECODE(coli.location_id, 'SI',DECODE(so.eng_mdl_number, '100','43', '107','45', '108','12', '109','29', '110','30', '112','31', '150','6', '214','27', '373','20', '386','51', '101','4C', '370','49', '289','9B', '123','T7', '379','M0', '374','9X', '375','9Z', '376','98', '116','F8', '121','P6', '361','X1', '112','31', '111','32', '356','14', '354','LG', '360','F2', 'T58','58', '129','F9', '124','44',so.eng_mdl_number))ENG_MDL_NUMBER,
    CRD_APP.CRD_COMMON_FUNCT_PKG.get_ENG_PL_NEW(SDL.ENG_MDL_NUMBER) AS "ENGINE MODEL",
    coli.part_number                                        AS "PART NUMBER IN",
    SDL.PART_NUMBER                                         AS "PART NUMBER OUT",
		( 	SELECT DISTINCT org_part_desc
			FROM crd_org_part
			WHERE part_number = coli.part_number
			AND org_id_num    = 12
			AND location_id   = 'SI'
		)                                                                                                                                                                                                                                                                                                AS "PART DESCRIPTION" ,
    CRD_APP.CRD_COMMON_FUNCT_PKG.get_PART_KEYWORD_NEW(SDL.PART_NUMBER, SDL.SHIPG_PART_DESC, CRD_APP.CRD_COMMON_FUNCT_PKG.get_ENG_PL_NEW(SDL.ENG_MDL_NUMBER), SDL.CMPNT_CD,coli.location_id)                                                                                                                          AS "PART KEYWORD NEW",
    srl.srl_number                                                                                                                                                                                                                                                                                   AS "PART SERIAL NUMBER",
    coli.part_qty                                                                                                                                                                                                                                                                                    AS "ORIG QTY",
    DECODE(sdl.rpr_cls_cd,'NSMR', SDL.SHIPG_QTY,'NSERV',SDL.SHIPG_QTY,'CNI',SDL.SHIPG_QTY,'CNIR',SDL.SHIPG_QTY,NULL)                                                                                                                                                                                 AS "QTY REJECTED",
    DECODE(sdl.rpr_cls_cd,'NEWC',SDL.SHIPG_QTY,'REPC', SDL.SHIPG_QTY,'QPRCN', SDL.SHIPG_QTY,'QPRCR', SDL.SHIPG_QTY,'NEW', SDL.SHIPG_QTY,'REP', SDL.SHIPG_QTY, 'REPEXO',SDL.SHIPG_QTY,'QPRN',SDL.SHIPG_QTY,'QPRR',SDL.SHIPG_QTY,'QPRRZ',SDL.SHIPG_QTY,'SERV',SDL.SHIPG_QTY,'REPD',SDL.SHIPG_QTY,NULL) AS "QTY REPAIRED",
    DECODE(sdl.rpr_cls_cd,'SHELFN', SDL.SHIPG_QTY,'SHELFR', SDL.SHIPG_QTY,'BUYN', SDL.SHIPG_QTY,'BUYR', SDL.SHIPG_QTY,'ROTDN', SDL.SHIPG_QTY,'ROTDR', SDL.SHIPG_QTY,'SPECN', SDL.SHIPG_QTY, 'SPECR', SDL.SHIPG_QTY,'NEWA', SDL.SHIPG_QTY,'REPA', SDL.SHIPG_QTY,'REPS', SDL.SHIPG_QTY,NULL)           AS "QTY REPLACED",
    so.bal_due_qty         
                                                                                                                                                                                                                                                                          AS "BAL QTY",
    TO_CHAR(coli.dock_date,'DD-MON-YYYY')    
                                                                                                                                                                                                                                                        AS "DOCK DATE",
    CASE
      WHEN coli.reqd_date> to_date('31-DEC-2022','DD-MON-RRRR')
      THEN '`'
        ||TO_CHAR(coli.reqd_date,'DD-MON-YYYY')
      ELSE TO_CHAR(coli.reqd_date,'DD-MON-YYYY')
    END AS "REQD DATE",
	
    CASE
      WHEN rlsesch.schd_dlvry_date > to_date('31-DEC-2022','DD-MON-RRRR')
      THEN '`'
        ||TO_CHAR(rlsesch.schd_dlvry_date,'DD-MON-YYYY')
      ELSE TO_CHAR(rlsesch.schd_dlvry_date,'DD-MON-YYYY')
    END                                 AS "SCHEDULE DELIVERY DATE",
	
    NULL                                AS "FORECAST TAT",
	
    to_char(SDL.shipg_doc_num)                   AS "MS#",  -- added by suvarna
    TO_CHAR(shd.initd_ts,'DD-MON-YYYY') AS "MS CREATE DATE" ,
	
    CASE
      WHEN (so.prmsd_date) > to_date('31-DEC-2022','DD-MON-RRRR')
      THEN '`'
        ||TO_CHAR(so.prmsd_date,'DD-MON-YYYY')
      ELSE TO_CHAR(so.prmsd_date ,'DD-MON-YYYY')
    END                                   AS "PROMISED DATE",
	
    TO_CHAR(SHD.shipd_date,'DD-MON-YYYY') AS "SHIP DATE",
    SDL.RPR_CLS_CD                        AS "RPR CLS CODE",
    SDL.SHIPG_QTY                         AS "QTY SHIPD",
    '`'	|| SHD.WAYBILL_NUMBER AWB#,
    shd.carier_cd                                                          AS "CARIER CODE",
    to_char(co.csm_user_id_num)                                                   AS "CSM ID#",  -- added by suvarna
    TO_CHAR(so.create_date ,'DD-MON-YYYY')                                 AS "SO CREATE DATE",
    ROUND( ( SYSDATE -coli.dock_date),0)                                   AS "SHOP ORDER AGE",
    sdl.cmpnt_cd                                                           AS "COMPONENT CODE" ,
    so.so_rpt_cd                                                           AS "REPORT INDICATOR",
    TO_CHAR(rfqa.quote_date,'DD-MON-YYYY')                                 AS "INITIAL QUOTE",
    rfqa.days_to_quote                                                     AS "DAYS TO QUOTE",
    so.rfqa_reqd_flg                                                       AS "RFQA Y/N",
    DECODE(so.rfqa_reqd_flg,'Y',TO_CHAR(rfqa.rfqa_rcv_date,'DD-MON-YYYY')) AS "DATE OF QUOTE APPROVAL",
    
	rfqa.TOTAL_PRICE                                                       AS "QUOTED PRICE",
    
	CASE
      WHEN coli.reqd_date >= TO_DATE('01-JAN-2100','DD-MON-YYYY')
      THEN NULL
      ELSE (coli.reqd_date-coli.dock_date)
    END AS "CONTRACT TAT",
	
    (shd.shipd_date-coli.dock_date) TAT,
    sdl.unt_price_amt                   AS "UNIT PRICE",
    (sdl.shipg_QTY * sdl.unt_price_amt) AS "EXTENDED PRICE",
    coli.rtbl_cd                        AS "ROTABLE CODE",
    cmnt.cmnt_txt                       AS "SCHEDULE CUSTOM COMMENTS",
       /* below columns are added by Murari  Baikady on 9/22/2016 -START */
	up.FIRST_NAME                                                          AS CSM_FIRST_NAME,
	up.LAST_NAME                                                           AS CSM_LAST_NAME,
	esd.lookup_descr                                                       AS "REPORT CODE DESCR",
	CRD_APP.CRD_COMMON_FUNCT_PKG.REPAIR_OTR_ENGINE_FAMILY_FUN(coli.ENG_MDL_NUMBER) AS "ENGINE FAMILY",
	CRD_APP.CRD_COMMON_FUNCT_PKG.REPAIR_OTR_CUSTOMER_NUMBER_FUN(coli.location_id,so.cust_id_num, so.bill_to_seq_num ) AS "CUSTOMER NUMBER",
	decode(so.BAL_DUE_QTY,0,'CLOSED','OPEN') AS "PO LINE STATUS"
	
  /*END*/
  
  
	FROM 
	CRD_SO so,
    CRD_CO co,
    CRD_SHIPG_DOC_LI SDL,
    CRD_SHIPG_DOC SHD,
    crd_so_rfqa rfqa,
    CRD_CO_LI coli,
    CRD_PO_LI_ORDCMPNT_XREF xref,
    (	SELECT 	srl_number,
				ORD_CMPNT_ID,
				part_number ,
				ord_cmpnt_amdmt_num
		FROM crd_ord_cmpnt_srl
		WHERE (ORD_CMPNT_ID,ord_comp_seq_num) IN
				  (	SELECT 	ORD_CMPNT_ID,
							MAX(ord_comp_seq_num)
					  FROM crd_ord_cmpnt_srl
					  WHERE location_id       ='SI'
					  AND ord_cmpnt_cd        ='L'
					  AND ord_cmpnt_srl_sts_cd='A'
					  GROUP BY ORD_CMPNT_ID
				  )
		AND location_id         ='SI'
		AND ord_cmpnt_cd        ='L'
		AND ord_cmpnt_srl_sts_cd='A'
    )srl,
	
    crd_co_li_rlse_schd rlsesch,
    CRD_shipg_li_ordcmpnt_rls sdlocr,
	
    (	SELECT 	cmnt_txt,
				  ORD_CMPNT_ID,
				  ord_cmpnt_cstm_cmnt_sts_cd
		FROM 	CRD_ORD_CMPNT_CSTM_CMNT
		WHERE (ORD_CMPNT_ID,cmnt_seq_num) IN
				  (	SELECT 	ORD_CMPNT_ID,
							MAX(cmnt_seq_num)
					  FROM CRD_ORD_CMPNT_CSTM_CMNT
					  WHERE location_id='SI'
					  GROUP BY ORD_CMPNT_ID
				  )
		AND location_id='SI'
    )cmnt,

    /* below columns are added by Murari  Baikady on 9/22/2016 -START */
	(select  *  from crd_user_prfl  where location_id='SI') up,
	( 
		SELECT * FROM esd_lookup WHERE lookup_nbr=1950 AND location_id='SI'
	) esd
  /*END*/
  
  
  WHERE coli.CO_NUMBER                = so.ASM_CO_NUMBER
  AND coli.CO_LI_NUM                  = so.ASM_CO_LI_NUM
  AND coli.AMDMT_NUM                  = so.ASM_CO_AMDMT_NUM
  AND co.CO_NUMBER                    = coli.CO_NUMBER
  AND co.AMDMT_NUM                    = coli.AMDMT_NUM
  AND rfqa.so_number(+)               =so.so_number
  AND sdlocr.ord_cmpnt_id             = coli.REF_ID
  AND cmnt.ord_cmpnt_id(+)            = coli.REF_ID
  AND ord_cmpnt_cstm_cmnt_sts_cd(+)   ='A'
  AND sdl.shipg_doc_num               = sdlocr.shipg_doc_num
  AND sdl.shipg_doc_li_NUM            = sdlocr.shipg_doc_li_num
  AND sdl.shipg_doc_cls_CD            = sdlocr.shipg_doc_cls_CD
  AND SDL.SHIPG_DOC_NUM               =SHD.SHIPG_DOC_NUM
  AND SDL.SHIPG_DOC_CLS_CD            = SHD.SHIPG_DOC_CLS_CD
  AND SDL.SHIPG_DOC_AMDMT_NUM         = SHD.SHIPG_DOC_AMDMT_NUM
  AND rlsesch.co_number               =coli.co_number
  AND rlsesch.co_li_num               =coli.co_li_num
  AND rlsesch.location_id             ='SI'
  AND rlsesch.rlse_seq_num            =sdlocr.rlse_seq_num
  AND rlsesch.rlse_qty                = sdl.shipg_qty
  AND coli.location_id                = 'SI'
  AND so.location_id                  = 'SI'
  AND co.location_id                  = 'SI'
  AND SDL.location_id                 ='SI'
  AND shd.location_id                 ='SI'
  AND sdlocr.location_id              = 'SI'
  AND rfqa.location_id(+)             ='SI'
  AND xref.location_id                = 'SI'
  AND coli.ref_id                     =srl.ord_cmpnt_id(+)
  AND coli.part_number                =srl.part_number(+)
  AND srl.ord_cmpnt_amdmt_num(+)      =coli.amdmt_num
  AND rfqa.rfqa_sts_cd(+)             ='A'
  AND coli.ref_id                     =xref.ord_cmpnt_id
  AND XREF.po_li_ord_cmpnt_xref_sts_cd= 'A'
  AND coli.ORG_ID_NUM                 = 12
  AND SDL.ORG_ID_NUM                  = 12
  AND so.ORG_ID_NUM                   = 12
  AND so.AMDMT_STS_CD                 = 'A'
  AND(SHD.AMDMT_STS_CD                = 'A'		OR 		shd.amdmt_sts_cd IS NULL)
  AND shd.shipg_sts_cd               <> 65
  AND sdlocr.ord_Cmpnt_cd             = 'L'
  AND SDL.SHIPG_DOC_CLS_CD            = 'MS'
  AND (		(shd.shipd_date BETWEEN (SYSDATE - 365) AND SYSDATE)	OR 	(shd.shipd_date IS NULL	AND shd.initd_ts   IS NOT NULL)		)
  AND coli.part_number NOT LIKE 'SET%'
  AND (		(sdl.rpr_cls_cd NOT IN ('SPADS' , 'SHPC' , 'QPRN' , 'NEW0')		) 	OR 	(sdl.rpr_cls_cd IS NULL)		)
  AND coli.eng_mdl_number NOT IN(SELECT eng_mdl_number FROM crd_eng_mdl WHERE eng_prod_ln_scrubbed = 'APU')
  AND COLI.CMPNT_CD <>'UNK'
  /* below columns are added by Murari  Baikady on 9/22/2016 -START */
  AND co.CSM_USER_ID_NUM=up.user_id_num(+)
  AND so.so_rpt_cd      =esd.lookup_code(+)
  /*END */

  )
  
  
  
  
  
  
  UNION ALL
  
  
  
  
  
  SELECT "SHOP NAME",
  "PURCHASE ORDER NO",
  "PO LINE NO",
  "SHOP ORDER",
  "CUSTOMER NAME",
  "BILL TO NAME",
  "GEAE CUSTOMER NO",
  "SUB CUSTOMER NAME",
  "ESN",
  "ENG_MDL_NUMBER",
  "ENGINE MODEL",
  "PART NUMBER IN",
  "PART NUMBER OUT",
  "PART DESCRIPTION",
  "PART KEYWORD NEW",
  "PART SERIAL NUMBER",
  "ORIG QTY",
  "QTY REJECTED",
  "QTY REPAIRED",
  "QTY REPLACED",
  "BAL QTY",
  "DOCK DATE",
  "REQD DATE",
  "SCHEDULE DELIVERY DATE",
  "FORECAST TAT",
  "MS#",
  "MS CREATE DATE",
  "PROMISED DATE",
  "SHIP DATE",
  "RPR CLS CODE",
  "QTY SHIPD",
  "AWB#",
  "CARIER CODE",
  "CSM ID#",
  "SO CREATE DATE",
  "SHOP ORDER AGE",
  "COMPONENT CODE",
  "REPORT INDICATOR",
  "INITIAL QUOTE",
  "DAYS TO QUOTE",
  "RFQA Y/N",
  "DATE OF QUOTE APPROVAL",
  "QUOTED PRICE",
  "CONTRACT TAT",
  "TAT",
  "UNIT PRICE",
  "EXTENDED PRICE",
  "ROTABLE CODE",
  "SCHEDULE CUSTOM COMMENTS",
 "CSM_FIRST_NAME",
  "CSM_LAST_NAME",
  "REPORT CODE DESCR",
  "ENGINE FAMILY",
  "CUSTOMER NUMBER",
  "PO LINE STATUS"
FROM
  (SELECT DISTINCT DECODE(coli.location_id,'MC','MCALLEN')                                                                                                                                                           AS "SHOP NAME",
  xref.CUST_PO_NUMBER                                                                                                                                                                                          AS "PURCHASE ORDER NO",
  xref.cust_po_li_num                                                                                                                                                                                          AS "PO LINE NO",
  so.intell_so_number                                                                                                                                                                                          AS "SHOP ORDER",
  NULL                                                                                                                                                                                                         AS "SHIPG DOC LI NBR",
  CRD_APP.CRD_COMMON_FUNCT_PKG.get_Customer_name_grp_New(coli.location_id,so.cust_id_num,so.bill_to_seq_num,CRD_APP.CRD_COMMON_FUNCT_PKG.get_BILL_TO_NAME(coli.location_id,so.cust_id_num,so.bill_to_seq_num)) AS "CUSTOMER NAME",
  CRD_APP.CRD_COMMON_FUNCT_PKG.get_BILL_TO_NAME(coli.location_id,so.cust_id_num, so.bill_to_seq_num)                                                                                                           AS "BILL TO NAME",
  CRD_APP.CRD_COMMON_FUNCT_PKG.get_GEAE_CUST_NUMBER(coli.location_id,so.cust_id_num, so.bill_to_seq_num )                                                                                                      AS "GEAE CUSTOMER NO",
  CRD_APP.CRD_COMMON_FUNCT_PKG.get_SUB_BILL_TO_NAME(coli.location_id,so.sub_cust_id_num, so.sub_cust_bill_to_seq_num)                                                                                          AS "SUB CUSTOMER NAME",
  DECODE(SUBSTR(so.esn_number,1,1),'0','`'
  ||so.esn_number,so.esn_number) AS ESN,
  DECODE(coli.location_id, 'MC',DECODE(so.eng_mdl_number, '100','43', '107','45', '108','12', '109','29', '110','30', '112','31', '150','6', '214','27', '373','20', '386','51', '101','4C', '370','49', '289','9B', '123','T7', '379','M0', '374','9X', '375','9Z', '376','98', '116','F8', '121','P6', '361','X1', '112','31', '111','32', '356','14', '354','LG', '360','F2', 'T58','58', '129','F9', '124','44',so.eng_mdl_number))ENG_MDL_NUMBER,
  DECODE(so.eng_mdl_number, 'X1','GENX-1B','X2','GENX-2B',CRD_APP.CRD_COMMON_FUNCT_PKG.get_ENG_PL_NEW(coli.ENG_MDL_NUMBER)) AS "ENGINE MODEL",
  coli.part_number                                                                                                          AS "PART NUMBER IN",
  NULL                                                                                                                      AS "PART NUMBER OUT",
  ( SELECT DISTINCT org_part_desc
  FROM crd_org_part
  WHERE part_number = coli.part_number
  AND org_id_num    = 12
  AND location_id   = 'MC'
  )                                                                                                                                                                          AS "PART DESCRIPTION",
  CRD_APP.CRD_COMMON_FUNCT_PKG.get_PART_KEYWORD_HEADER_NEW(coli.part_number, CRD_APP.CRD_COMMON_FUNCT_PKG.get_ENG_PL_NEW(so.ENG_MDL_NUMBER), coli.CMPNT_CD,coli.location_id) AS "PART KEYWORD NEW",
  srl.srl_number                                                                                                                                                             AS "PART SERIAL NUMBER",
  coli.part_qty                                                                                                                                                              AS "ORIG QTY",
  NULL                                                                                                                                                                       AS "QTY REJECTED",
  NULL                                                                                                                                                                       AS "QTY REPAIRED",
  NULL                                                                                                                                                                       AS "QTY REPLACED",
  so.bal_due_qty                                                                                                                                                             AS "BAL QTY",
  TO_CHAR(coli.dock_date,'DD-MON-YYYY')                                                                                                                                      AS "DOCK DATE",
  CASE
    WHEN coli.reqd_date> to_date('31-DEC-2022','DD-MON-RRRR')
    THEN '`'
      ||TO_CHAR(coli.reqd_date,'DD-MON-YYYY')
    ELSE TO_CHAR(coli.reqd_date,'DD-MON-YYYY')
  END AS "REQD DATE",
  CASE
    WHEN rlsesch.schd_dlvry_date > to_date('31-DEC-2022','DD-MON-RRRR')
    THEN '`'
      ||TO_CHAR(rlsesch.schd_dlvry_date,'DD-MON-YYYY')
    ELSE TO_CHAR(rlsesch.schd_dlvry_date,'DD-MON-YYYY')
  END AS "SCHEDULE DELIVERY DATE",
  CASE
    WHEN rlsesch.schd_dlvry_date >= to_date('01-JAN-2100','DD-MON-YYYY')
    THEN NULL
    ELSE ( rlsesch.schd_dlvry_date-coli.dock_date)
  END  AS "FORECAST TAT",
  NULL AS "MS#",
  NULL AS "MS CREATE DATE" ,
  CASE
    WHEN (so.prmsd_date) > to_date('31-DEC-2022','DD-MON-RRRR')
    THEN '`'
      ||TO_CHAR(so.prmsd_date,'DD-MON-YYYY')
    ELSE TO_CHAR(so.prmsd_date ,'DD-MON-YYYY')
  END  AS "PROMISED DATE",
  NULL AS "SHIP DATE",
  NULL AS "RPR CLS CODE",
  NULL AS "QTY SHIPD",
  NULL AWB#,
  NULL                                                                   AS "CARIER CODE",
  TO_CHAR(co.csm_user_id_num)                                            AS "CSM ID#",
  TO_CHAR(so.create_date ,'DD-MON-YYYY')                                 AS "SO CREATE DATE",
  ROUND( ( sysdate-coli.dock_date),0)                                    AS "SHOP ORDER AGE",
  coli.cmpnt_cd                                                          AS "COMPONENT CODE" ,
  so.so_rpt_cd                                                           AS "REPORT INDICATOR",
  TO_CHAR(rfqa.quote_date,'DD-MON-YYYY')                                 AS "INITIAL QUOTE",
  rfqa.days_to_quote                                                     AS "DAYS TO QUOTE",
  so.rfqa_reqd_flg                                                       AS "RFQA Y/N",
  DECODE(so.rfqa_reqd_flg,'Y',TO_CHAR(rfqa.rfqa_rcv_date,'DD-MON-YYYY')) AS "DATE OF QUOTE APPROVAL",
  rfqa.TOTAL_PRICE                                                       AS "QUOTED PRICE",
  CASE
    WHEN coli.reqd_date >= to_date('01-JAN-2100','DD-MON-YYYY')
    THEN NULL
    ELSE(coli.reqd_date-coli.dock_date)
  END AS "CONTRACT TAT",
  NULL TAT,
  NULL          AS "UNIT PRICE",
  NULL          AS "EXTENDED PRICE",
  coli.rtbl_cd  AS "ROTABLE CODE",
  cmnt.cmnt_txt AS "SCHEDULE CUSTOM COMMENTS",
    /* below columns are added by Murari  Baikady on 9/22/2016 -START */
  up.FIRST_NAME                                                          AS CSM_FIRST_NAME,
  up.LAST_NAME                                                           AS CSM_LAST_NAME,
  esd.lookup_descr                                                       AS "REPORT CODE DESCR",
  CRD_APP.CRD_COMMON_FUNCT_PKG.REPAIR_OTR_ENGINE_FAMILY_FUN(coli.ENG_MDL_NUMBER) AS "ENGINE FAMILY",  ---------- added by suvarna
  CRD_APP.CRD_COMMON_FUNCT_PKG.REPAIR_OTR_CUSTOMER_NUMBER_FUN(coli.location_id,so.cust_id_num, so.bill_to_seq_num ) AS "CUSTOMER NUMBER" , ------------- added by suvarna
  decode(so.BAL_DUE_QTY,0,'CLOSED','OPEN') AS "PO LINE STATUS"
  /*END*/
FROM CRD_SO so,
  CRD_CO co,
  crd_so_rfqa rfqa,
  CRD_CO_LI coli,
  CRD_PO_LI_ORDCMPNT_XREF xref,
  (SELECT srl_number,
    ORD_CMPNT_ID,
    part_number ,
    ord_cmpnt_amdmt_num
  FROM crd_ord_cmpnt_srl
  WHERE (ORD_CMPNT_ID,ord_comp_seq_num) IN
    (SELECT ORD_CMPNT_ID,
      MAX(ord_comp_seq_num)
    FROM crd_ord_cmpnt_srl
    WHERE location_id       ='MC'
    AND ord_cmpnt_cd        ='L'
    AND ord_cmpnt_srl_sts_cd='A'
    GROUP BY ORD_CMPNT_ID
    )
  AND location_id         ='MC'
  AND ord_cmpnt_cd        ='L'
  AND ord_cmpnt_srl_sts_cd='A'
  )srl,
  crd_co_li_rlse_schd rlsesch,
  (SELECT cmnt_txt,
    ORD_CMPNT_ID,
    ord_cmpnt_cstm_cmnt_sts_cd
  FROM CRD_ORD_CMPNT_CSTM_CMNT
  WHERE (ORD_CMPNT_ID,cmnt_seq_num) IN
    (SELECT ORD_CMPNT_ID,
      MAX(cmnt_seq_num)
    FROM CRD_ORD_CMPNT_CSTM_CMNT
    WHERE location_id='MC'
    GROUP BY ORD_CMPNT_ID
    )
  AND location_id='MC'
  )cmnt,
  /* below columns are added by Murari  Baikady on 9/22/2016 -START */
  (
  SELECT *
  FROM crd_user_prfl
  WHERE location_id='MC'
  ) up,
  ( SELECT * FROM esd_lookup WHERE lookup_nbr=1950 AND location_id='MC'
  ) esd
  /*END*/
WHERE coli.CO_NUMBER                    = so.ASM_CO_NUMBER
AND coli.CO_LI_NUM                      = so.ASM_CO_LI_NUM
AND coli.AMDMT_NUM                      = so.ASM_CO_AMDMT_NUM
AND co.CO_NUMBER                        = coli.CO_NUMBER
AND co.AMDMT_NUM                        = coli.AMDMT_NUM
AND coli.location_id                    = 'MC'
AND so.location_id                      = 'MC'
AND co.location_id                      = 'MC'
AND xref.location_id                    = 'MC'
AND cmnt.ord_cmpnt_id (+)               = coli.REF_ID
AND ord_cmpnt_cstm_cmnt_sts_cd(+)       ='A'
AND coli.ref_id                         =xref.ord_cmpnt_id(+)
AND XREF.po_li_ord_cmpnt_xref_sts_cd(+) = 'A'
AND coli.ORG_ID_NUM                     = 12
AND so.ORG_ID_NUM                       = 12
AND so.AMDMT_STS_CD                     = 'A'
AND so.so_amdmt_num                     =
  (SELECT MAX(so_amdmt_num)
  FROM crd_so so1
  WHERE so1.asm_co_number IS NOT NULL
  AND so1.AMDMT_STS_CD     = 'A'
  AND so1.ORG_ID_NUM       = 12
  AND so1.location_id      ='MC'
  AND so1.so_number        =so.so_number
  )
AND so.bal_due_qty               >0
AND coli.ref_id                  =srl.ord_cmpnt_id(+)
AND coli.part_number             =srl.part_number(+)
AND srl.ord_cmpnt_amdmt_num(+)   =coli.amdmt_num
AND rlsesch.co_number(+)         =coli.co_number
AND rlsesch.co_li_num(+)         =coli.co_li_num
AND rlsesch.location_id(+)       ='MC'
AND rlse_sts_cd_num              = 5
AND so.create_date              <= SYSDATE
AND rfqa.so_number(+)            =so.so_number
AND rfqa.location_id(+)          ='MC'
AND rfqa.rfqa_sts_cd(+)          ='A'
AND coli.part_number NOT        IN ('UNKNOWN' , 'UNK' , 'MISC')
AND cmnt.ord_cmpnt_id (+)        = coli.REF_ID
AND ord_cmpnt_cstm_cmnt_sts_cd(+)='A'
AND (SELECT geae_cust_number
  FROM crd_cust_bill_to cb
  WHERE cb.cust_id_num       =coli.cust_id_num
  AND cb.bill_to_seq_num     =coli.bill_to_seq_num
  AND cb.location_id         ='MC')NOT IN('56576','9573B', '9200M','9526B','9524B','9570B','9200A','9571B')
AND coli.eng_mdl_number NOT            IN
  (SELECT eng_mdl_number FROM crd_eng_mdl WHERE eng_prod_ln_scrubbed = 'APU'
  )
AND coli.cmpnt_cd <>'UNK'
  /* below columns are added by Murari  Baikady on 9/22/2016 -START */
AND co.CSM_USER_ID_NUM=up.user_id_num(+)
AND so.so_rpt_cd      =esd.lookup_code(+)
/*END */

  UNION ALL

  SELECT
          DISTINCT DECODE(coli.location_id,'MC','MCALLEN')                                                                                                                                                AS "SHOP NAME",
    xref.CUST_PO_NUMBER                                                                                                                                                                          AS "PURCHASE ORDER NO",
    xref.cust_po_li_num                                                                                                                                                                          AS "PO LINE NO",
    so.intell_so_number                                                                                                                                                                          AS "SHOP ORDER",
    SDL.SHIPG_DOC_LI_NUM                                                                                                                                                                         AS "SHIPG DOC LI NBR",
    CRD_APP.CRD_COMMON_FUNCT_PKG.get_Customer_name_grp_New(coli.location_id,so.cust_id_num,so.bill_to_seq_num,CRD_APP.CRD_COMMON_FUNCT_PKG.get_BILL_TO_NAME(coli.location_id,so.cust_id_num,so.bill_to_seq_num)) AS "CUSTOMER NAME",
    CRD_APP.CRD_COMMON_FUNCT_PKG.get_BILL_TO_NAME(coli.location_id,so.cust_id_num, so.bill_to_seq_num)                                                                                                   AS "BILL TO NAME",
    CRD_APP.CRD_COMMON_FUNCT_PKG.get_GEAE_CUST_NUMBER(coli.location_id,so.cust_id_num, so.bill_to_seq_num )                                                                                              AS "GEAE CUSTOMER NO",
    CRD_APP.CRD_COMMON_FUNCT_PKG.get_SUB_BILL_TO_NAME(coli.location_id,so.sub_cust_id_num, so.sub_cust_bill_to_seq_num)                                                                                  AS "SUB CUSTOMER NAME",
    DECODE(SUBSTR(so.esn_number,1,1),'0','`'
    ||so.esn_number,so.esn_number) AS ESN,
    DECODE(coli.location_id, 'MC',DECODE(so.eng_mdl_number, '100','43', '107','45', '108','12', '109','29', '110','30', '112','31', '150','6', '214','27', '373','20', '386','51', '101','4C', '370','49', '289','9B', '123','T7', '379','M0', '374','9X', '375','9Z', '376','98', '116','F8', '121','P6', '361','X1', '112','31', '111','32', '356','14', '354','LG', '360','F2', 'T58','58', '129','F9', '124','44',so.eng_mdl_number))ENG_MDL_NUMBER,
    DECODE(so.eng_mdl_number, 'X1','GENX-1B','X2','GENX-2B',CRD_APP.CRD_COMMON_FUNCT_PKG.get_ENG_PL_NEW(coli.ENG_MDL_NUMBER)) AS "ENGINE MODEL",
    coli.part_number                                                                                                  AS "PART NUMBER IN",
    SDL.PART_NUMBER                                                                                                   AS "PART NUMBER OUT",
    ( SELECT DISTINCT org_part_desc
    FROM crd_org_part
    WHERE part_number = coli.part_number
    AND org_id_num    = 12
    AND location_id   = 'MC'
    )                                                                                                                                                                       AS "PART DESCRIPTION" ,
    CRD_APP.CRD_COMMON_FUNCT_PKG.get_PART_KEYWORD_NEW(SDL.PART_NUMBER, SDL.SHIPG_PART_DESC, CRD_APP.CRD_COMMON_FUNCT_PKG.get_ENG_PL_NEW(SDL.ENG_MDL_NUMBER), SDL.CMPNT_CD,coli.location_id) AS "PART KEYWORD NEW",
    srl.srl_number                                                                                                                                                          AS "PART SERIAL NUMBER",
    coli.part_qty                                                                                                                                                           AS "ORIG QTY",
    DECODE(sdl.rpr_cls_cd,'ASIS',SDL.SHIPG_QTY,'NSERV',SDL.SHIPG_QTY,'NSMR',SDL.SHIPG_QTY,NULL)                                                                             AS "QTY REJECTED",
    DECODE(sdl.rpr_cls_cd,'EREP',SDL.SHIPG_QTY,
                          'EXCN',SDL.SHIPG_QTY,
                          'EXCR',SDL.SHIPG_QTY,
					                'LOSTNE',SDL.SHIPG_QTY,
					                'LOSTRE',SDL.SHIPG_QTY,
					                'PAREP',SDL.SHIPG_QTY,
					                'QPRR',SDL.SHIPG_QTY,
					                'REP',SDL.SHIPG_QTY,
					                'REPOOL',SDL.SHIPG_QTY,
					                'SDMGNE',SDL.SHIPG_QTY,
					                'SDMGRE',SDL.SHIPG_QTY,
					                'SERV',SDL.SHIPG_QTY,
					                'SPECNC',SDL.SHIPG_QTY,
                          'R4P',SDL.SHIPG_QTY,
					                 NULL)  AS "QTY REPAIRED",
    DECODE(sdl.rpr_cls_cd,'DRSHP', SDL.SHIPG_QTY,
                          'NEWA', SDL.SHIPG_QTY,
					                'NEWC', SDL.SHIPG_QTY,
					                'QPRCN', SDL.SHIPG_QTY,
					                'QPRCR', SDL.SHIPG_QTY,
                          'REPA', SDL.SHIPG_QTY,
					                'REPC', SDL.SHIPG_QTY,
					                'REPNP', SDL.SHIPG_QTY,
					                'SHELFN', SDL.SHIPG_QTY,
					                'SHELFR', SDL.SHIPG_QTY,
					                'SPECN', SDL.SHIPG_QTY,
                          'SPECR', SDL.SHIPG_QTY,
					                 NULL)  AS "QTY REPLACED",
    so.bal_due_qty                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        AS "BAL QTY",
    TO_CHAR(coli.dock_date,'DD-MON-YYYY')                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 AS "DOCK DATE",
    CASE
      WHEN coli.reqd_date> to_date('31-DEC-2022','DD-MON-RRRR')
      THEN '`'
        ||TO_CHAR(coli.reqd_date,'DD-MON-YYYY')
      ELSE TO_CHAR(coli.reqd_date,'DD-MON-YYYY')
    END AS "REQD DATE",
    CASE
      WHEN rlsesch.schd_dlvry_date > to_date('31-DEC-2022','DD-MON-RRRR')
      THEN '`'
        ||TO_CHAR(rlsesch.schd_dlvry_date,'DD-MON-YYYY')
      ELSE TO_CHAR(rlsesch.schd_dlvry_date,'DD-MON-YYYY')
    END                                 AS "SCHEDULE DELIVERY DATE",
    NULL                                AS "FORECAST TAT",
    TO_CHAR(SDL.shipg_doc_num)          AS "MS#",
    TO_CHAR(shd.initd_ts,'DD-MON-YYYY') AS "MS CREATE DATE" ,
    CASE
      WHEN (so.prmsd_date) > to_date('31-DEC-2022','DD-MON-RRRR')
      THEN '`'
        ||TO_CHAR(so.prmsd_date,'DD-MON-YYYY')
      ELSE TO_CHAR(so.prmsd_date ,'DD-MON-YYYY')
    END                                   AS "PROMISED DATE" ,
    TO_CHAR(SHD.shipd_date,'DD-MON-YYYY') AS "SHIP DATE",
    SDL.RPR_CLS_CD                        AS "RPR CLS CODE",
    SDL.SHIPG_QTY                         AS "QTY SHIPD",
    '`'
    || SHD.WAYBILL_NUMBER AWB#,
    shd.carier_cd                                                          AS "CARIER CODE",
    TO_CHAR(co.csm_user_id_num)                                            AS "CSM ID#",
    TO_CHAR(so.create_date,'DD-MON-YYYY')                                  AS "SO CREATE DATE",
    ROUND((SYSDATE - coli.dock_date),0)                                    AS "SHOP ORDER AGE",
    sdl.cmpnt_cd                                                           AS "COMPONENT CODE" ,
    so.so_rpt_cd                                                           AS "REPORT INDICATOR",
    TO_CHAR(rfqa.quote_date,'DD-MON-YYYY')                                 AS "INITIAL QUOTE",
    rfqa.days_to_quote                                                     AS "DAYS TO QUOTE",
    so.rfqa_reqd_flg                                                       AS "RFQA Y/N",
    DECODE(so.rfqa_reqd_flg,'Y',TO_CHAR(rfqa.rfqa_rcv_date,'DD-MON-YYYY')) AS "DATE OF QUOTE APPROVAL",
    rfqa.TOTAL_PRICE                                                       AS "QUOTED PRICE",
    CASE
      WHEN coli.reqd_date >= TO_DATE('01-JAN-2100','DD-MON-YYYY')
      THEN NULL
      ELSE (coli.reqd_date-coli.dock_date)
    END AS "CONTRACT TAT",
    (shd.shipd_date-coli.dock_date) TAT,
    sdl.unt_price_amt                   AS "UNIT PRICE",
    (sdl.shipg_QTY * sdl.unt_price_amt) AS "EXTENDED PRICE",
    coli.rtbl_cd                        AS "ROTABLE CODE",
    cmnt.cmnt_txt                       AS "SCHEDULE CUSTOM COMMENTS",
         /* below columns are added by Murari  Baikady on 9/22/2016 -START */
  up.FIRST_NAME                                                          AS CSM_FIRST_NAME,
  up.LAST_NAME                                                           AS CSM_LAST_NAME,
  esd.lookup_descr                                                       AS "REPORT CODE DESCR",
  CRD_APP.CRD_COMMON_FUNCT_PKG.REPAIR_OTR_ENGINE_FAMILY_FUN(coli.ENG_MDL_NUMBER) AS "ENGINE FAMILY",
  CRD_APP.CRD_COMMON_FUNCT_PKG.REPAIR_OTR_CUSTOMER_NUMBER_FUN(coli.location_id,so.cust_id_num, so.bill_to_seq_num ) AS "CUSTOMER NUMBER",
  decode(so.BAL_DUE_QTY,0,'CLOSED','OPEN') AS "PO LINE STATUS"
   /*END*/
  FROM CRD_SO so,
    CRD_CO co,
    CRD_SHIPG_DOC_LI SDL,
    CRD_SHIPG_DOC SHD,
    crd_so_rfqa rfqa,
    CRD_CO_LI coli,
    CRD_PO_LI_ORDCMPNT_XREF xref,
    (SELECT srl_number,
      ORD_CMPNT_ID,
      part_number ,
      ord_cmpnt_amdmt_num
    FROM crd_ord_cmpnt_srl
    WHERE (ORD_CMPNT_ID,ord_comp_seq_num) IN
      (SELECT ORD_CMPNT_ID,
        MAX(ord_comp_seq_num)
      FROM crd_ord_cmpnt_srl
      WHERE location_id       ='MC'
      AND ord_cmpnt_cd        ='L'
      AND ord_cmpnt_srl_sts_cd='A'
      GROUP BY ORD_CMPNT_ID
      )
    AND location_id         ='MC'
    AND ord_cmpnt_cd        ='L'
    AND ord_cmpnt_srl_sts_cd='A'
    )srl,
    crd_co_li_rlse_schd rlsesch,
    CRD_shipg_li_ordcmpnt_rls sdlocr,
    (SELECT cmnt_txt,
      ORD_CMPNT_ID,
      ord_cmpnt_cstm_cmnt_sts_cd
    FROM CRD_ORD_CMPNT_CSTM_CMNT
    WHERE (ORD_CMPNT_ID,cmnt_seq_num) IN
      (SELECT ORD_CMPNT_ID,
        MAX(cmnt_seq_num)
      FROM CRD_ORD_CMPNT_CSTM_CMNT
      WHERE location_id='MC'
      GROUP BY ORD_CMPNT_ID
      )
    AND location_id='MC'
    )cmnt,

/* below columns are added by Murari  Baikady on 9/22/2016 -START */
   (select  *  from crd_user_prfl  where location_id='MC') up,
  ( SELECT * FROM esd_lookup WHERE lookup_nbr=1950 AND location_id='MC'
  ) esd
  /*END*/

  WHERE coli.CO_NUMBER                = so.ASM_CO_NUMBER
  AND coli.CO_LI_NUM                  = so.ASM_CO_LI_NUM
  AND coli.AMDMT_NUM                  = so.ASM_CO_AMDMT_NUM
  AND co.CO_NUMBER                    = coli.CO_NUMBER
  AND co.AMDMT_NUM                    = coli.AMDMT_NUM
  AND rfqa.so_number(+)               =so.so_number
  AND sdlocr.ord_cmpnt_id             = coli.REF_ID
  AND cmnt.ord_cmpnt_id (+)           = coli.REF_ID
  AND ord_cmpnt_cstm_cmnt_sts_cd(+)   ='A'
  AND sdl.shipg_doc_num               = sdlocr.shipg_doc_num
  AND sdl.shipg_doc_li_NUM            = sdlocr.shipg_doc_li_nUM
  AND sdl.shipg_doc_cls_CD            = sdlocr.shipg_doc_cls_CD
  AND SDL.SHIPG_DOC_NUM               =SHD.SHIPG_DOC_NUM
  AND SDL.SHIPG_DOC_CLS_CD            = SHD.SHIPG_DOC_CLS_CD
  AND SDL.SHIPG_DOC_AMDMT_NUM         = SHD.SHIPG_DOC_AMDMT_NUM
  AND rlsesch.co_number               =coli.co_number
  AND rlsesch.co_li_num               =coli.co_li_num
  AND rlsesch.location_id             ='MC'
  AND rlsesch.rlse_seq_num            =sdlocr.rlse_seq_num
  AND rlsesch.rlse_qty                = sdl.shipg_qty
  AND coli.location_id                = 'MC'
  AND so.location_id                  = 'MC'
  AND co.location_id                  = 'MC'
  AND SDL.location_id                 ='MC'
  AND shd.location_id                 ='MC'
  AND sdlocr.location_id              = 'MC'
  AND rfqa.location_id(+)             ='MC'
  AND xref.location_id                = 'MC'
  AND coli.ref_id                     =srl.ord_cmpnt_id (+)
  AND coli.part_number                =srl.part_number (+)
  AND srl.ord_cmpnt_amdmt_num(+)      =coli.amdmt_num
  AND rfqa.rfqa_sts_cd(+)             ='A'
  AND coli.ref_id                     =xref.ord_cmpnt_id
  AND XREF.po_li_ord_cmpnt_xref_sts_cd= 'A'
  AND coli.ORG_ID_NUM                 = 12
  AND SDL.ORG_ID_NUM                  = 12
  AND so.ORG_ID_NUM                   = 12
  AND so.AMDMT_STS_CD                 = 'A'
  AND (SHD.AMDMT_STS_CD               = 'A'
  OR shd.amdmt_sts_cd                IS NULL)
  AND shd.shipg_sts_cd               <> 65
  AND sdlocr.ord_Cmpnt_cd             = 'L'
  AND SDL.SHIPG_DOC_CLS_CD            = 'MS'
  AND ((shd.shipd_date BETWEEN (SYSDATE- 365) AND SYSDATE)
  OR (shd.shipd_date       IS NULL
  AND shd.initd_ts         IS NOT NULL))
  AND coli.part_number NOT IN ('UNKNOWN' , 'UNK' , 'MISC')
  AND sdl.part_number NOT  IN ('UNKNOWN' , 'UNK' , 'MISC')
  AND (SELECT geae_cust_number
    FROM crd_cust_bill_to cb
    WHERE cb.cust_id_num       =coli.cust_id_num
    AND cb.bill_to_seq_num     =coli.bill_to_seq_num
    AND cb.location_id         ='MC')NOT IN('56576','9573B', '9200M','9526B','9524B','9570B','9200A','9571B')
  AND coli.eng_mdl_number NOT            IN
    (SELECT eng_mdl_number FROM crd_eng_mdl WHERE eng_prod_ln_scrubbed = 'APU'
    )
  AND coli.cmpnt_cd <>'UNK'
    /* below columns are added by Murari  Baikady on 9/22/2016 -START */
AND co.CSM_USER_ID_NUM=up.user_id_num(+)
AND so.so_rpt_cd      =esd.lookup_code(+))
 UNION ALL
  SELECT "SHOP NAME",
  "PURCHASE ORDER NO",
  "PO LINE NO",
  "SHOP ORDER",
  "CUSTOMER NAME",
  "BILL TO NAME",
  "GEAE CUSTOMER NO",
  "SUB CUSTOMER NAME",
  "ESN",
  "ENG_MDL_NUMBER",
  "ENGINE MODEL",
  "PART NUMBER IN",
  "PART NUMBER OUT",
  "PART DESCRIPTION",
  "PART KEYWORD NEW",
  "PART SERIAL NUMBER",
  "ORIG QTY",
  "QTY REJECTED",
  "QTY REPAIRED",
  "QTY REPLACED",
  "BAL QTY",
  "DOCK DATE",
  "REQD DATE",
  "SCHEDULE DELIVERY DATE",
  "FORECAST TAT",
  "MS#",
  "MS CREATE DATE",
  "PROMISED DATE",
  "SHIP DATE",
  "RPR CLS CODE",
  "QTY SHIPD",
  "AWB#",
  "CARIER CODE",
  "CSM ID#",
  "SO CREATE DATE",
  "SHOP ORDER AGE",
  "COMPONENT CODE",
  "REPORT INDICATOR",
  "INITIAL QUOTE",
  "DAYS TO QUOTE",
  "RFQA Y/N",
  "DATE OF QUOTE APPROVAL",
  "QUOTED PRICE",
  "CONTRACT TAT",
  "TAT",
  "UNIT PRICE",
  "EXTENDED PRICE",
  "ROTABLE CODE",
  "SCHEDULE CUSTOM COMMENTS",
  "CSM_FIRST_NAME",
  "CSM_LAST_NAME",
  "REPORT CODE DESCR",
  "ENGINE FAMILY",
  "CUSTOMER NUMBER",
  "PO LINE STATUS"
FROM
(SELECT DISTINCT DECODE(Tri.location_id,'ATI','SINGAPORE P62')"SHOP NAME"
                              ,Tri.CUST_PO_NUMBER "PURCHASE ORDER NO"
                              ,TO_NUMBER(Tri.CUST_PO_LI_NUM) "PO LINE NO"
                              ,Tri.INTELL_SO_NBR "SHOP ORDER"
                              ,Tri.SRC_CUST_NAME "CUSTOMER NAME"
                              ,REPAIR_PO_SUMMARY_DETAILS_PKG.REPAIR_BILL_TO_NAME_FUN(Tri.BILL_TO_GEAE_CUST_NMBR,Tri.location_id) "BILL TO NAME"
                              ,Tri.BILL_TO_GEAE_CUST_NMBR "GEAE CUSTOMER NO"
                              ,Tri.SUB_BILL_TO_NAME "SUB CUSTOMER NAME"
                              ,Tri.ESN_NUMBER "ESN"
                              ,Tri.ENG_MDL_NUMBER "ENG_MDL_NUMBER"
                              ,REPAIR_PO_SUMMARY_DETAILS_PKG.REPAIR_ENG_MODEL_DESC_FUN(Tri.ENG_MDL_NUMBER) "ENGINE MODEL"
                              ,Tri.SHIPG_PART_DESCR_INC "PART NUMBER IN"
                              ,Tri.SHIPG_PART_DESCR_OUT "PART NUMBER OUT"
                              ,Tri.PART_DESCRIPTION "PART DESCRIPTION"
                              ,NULL "PART KEYWORD NEW"
                              ,Tri.PART_SERIAL_NUMBER "PART SERIAL NUMBER"
                              ,Tri.QTY_RCV "ORIG QTY"
                              ,TO_NUMBER(REPAIR_PO_SUMMARY_DETAILS_PKG.REPAIR_ATI_NSMR_QTY_FUN(Tri.cust_po_number,Tri.RPR_CLS_CODE,Tri.location_id,Tri.QTY_SHIPG,Tri.SHIPG_PART_DESCR_INC))"QTY REJECTED"
                              ,NULL "QTY REPAIRED"
                              ,TO_NUMBER(REPAIR_PO_SUMMARY_DETAILS_PKG.REPAIR_ATI_REPLACEMENT_QTY_FUN(Tri.cust_po_number,Tri.RPR_CLS_CODE,Tri.location_id,Tri.QTY_SHIPG,Tri.SHIPG_PART_DESCR_INC)) "QTY REPLACED"
                              ,TO_NUMBER(DECODE(Tri.CO_STS_CD,'CLOSED',0,Tri.QTY_RCV)) "BAL QTY"
                              ,TO_CHAR(Tri.DOCK_DATE,'DD-MON-YYYY') "DOCK DATE"
                              ,TO_CHAR(Tri.reqd_date,'DD-MON-YYYY') "REQD DATE"
                              ,TO_CHAR(Tri.SCHEDULE_SHIP_DATE) "SCHEDULE DELIVERY DATE"
                              ,(Tri.SCHEDULE_SHIP_DATE-Tri.create_date) "FORECAST TAT"
                              ,Tri."MS#" "MS#"
                              ,TO_CHAR(TO_DATE(Tri.MS_CREATE_DATE,'MM-DD-YYYY HH24:MI:SS'),'DD-MON-YYYY') "MS CREATE DATE"
                              ,TO_CHAR(Tri.promised_delivery_date,'DD-MON-YYYY') "PROMISED DATE"
                              ,TO_CHAR(Tri.SHIPD_DATE,'DD-MON-YYYY') "SHIP DATE"
                              ,Tri.RPR_CLS_CODE "RPR CLS CODE"
                              ,Tri.QTY_SHIPG "QTY SHIPD"
                              ,Tri.AWB  "AWB#"
                              ,Tri.CARRIER_CODE "CARIER CODE"
                              ,Tri."CSMID#/NAME" "CSM ID#"
                              ,TO_CHAR(Tri.CREATE_DATE,'DD-MON-YYYY') "SO CREATE DATE"
                              ,ROUND( ( sysdate-Tri.create_date),0)  "SHOP ORDER AGE"
                              ,Tri.cmpnt_cd "COMPONENT CODE"
                              ,NULL "REPORT INDICATOR"
                              ,NULL "INITIAL QUOTE"
                              ,NULL "DAYS TO QUOTE"
                              ,NULL "RFQA Y/N"
                              ,NULL "DATE OF QUOTE APPROVAL"
                              ,Tri.QUOTED_PRICE "QUOTED PRICE"
                              ,(Tri.reqd_date-Tri.create_date) "CONTRACT TAT"
                              ,(Tri.SHIPD_DATE-Tri.create_date) "TAT"
                              ,Tri.UNT_PRICE_AMT "UNIT PRICE"
                              ,NULL "EXTENDED PRICE"
                              ,NULL "ROTABLE CODE"
                              ,NULL "SCHEDULE CUSTOM COMMENTS"
                              ,Tri."CSMID#/NAME" "CSM_FIRST_NAME"
                              ,NULL "CSM_LAST_NAME"
                              ,NULL "REPORT CODE DESCR"
                              ,REPAIR_PO_SUMMARY_DETAILS_PKG.REPAIR_OSB_ENGINE_FAMILY_FUN(Tri.ENG_MDL_NUMBER) "ENGINE FAMILY"
                              ,REPAIR_PO_SUMMARY_DETAILS_PKG.REPAIR_ORACLE_CUST_NUMBER_FUN(Tri.BILL_TO_GEAE_CUST_NMBR,Tri.location_id) "CUSTOMER NUMBER"
							                ,Tri.CO_LI_STS_CD AS "PO LINE STATUS"
                              FROM   CRD_TRI_SHIPMENT Tri
                              where  Tri.location_id='ATI'
                                 AND Tri.create_date BETWEEN SYSDATE - 365 AND SYSDATE)
UNION ALL
  SELECT "SHOP NAME",
  "PURCHASE ORDER NO",
  "PO LINE NO",
  "SHOP ORDER",
  "CUSTOMER NAME",
  "BILL TO NAME",
  "GEAE CUSTOMER NO",
  "SUB CUSTOMER NAME",
  "ESN",
  "ENG_MDL_NUMBER",
  "ENGINE MODEL",
  "PART NUMBER IN",
  "PART NUMBER OUT",
  "PART DESCRIPTION",
  "PART KEYWORD NEW",
  "PART SERIAL NUMBER",
  "ORIG QTY",
  "QTY REJECTED",
  "QTY REPAIRED",
  "QTY REPLACED",
  "BAL QTY",
  "DOCK DATE",
  "REQD DATE",
  "SCHEDULE DELIVERY DATE",
  "FORECAST TAT",
  "MS#",
  "MS CREATE DATE",
  "PROMISED DATE",
  "SHIP DATE",
  "RPR CLS CODE",
  "QTY SHIPD",
  "AWB#",
  "CARIER CODE",
  "CSM ID#",
  "SO CREATE DATE",
  "SHOP ORDER AGE",
  "COMPONENT CODE",
  "REPORT INDICATOR",
  "INITIAL QUOTE",
  "DAYS TO QUOTE",
  "RFQA Y/N",
  "DATE OF QUOTE APPROVAL",
  "QUOTED PRICE",
  "CONTRACT TAT",
  "TAT",
  "UNIT PRICE",
  "EXTENDED PRICE",
  "ROTABLE CODE",
  "SCHEDULE CUSTOM COMMENTS",
  "CSM_FIRST_NAME",
  "CSM_LAST_NAME",
  "REPORT CODE DESCR",
  "ENGINE FAMILY",
  "CUSTOMER NUMBER",
  "PO LINE STATUS"
FROM
(SELECT DISTINCT DECODE(HD.LOCATION_ID,'EHN','HUNGARY')"SHOP NAME"
                              ,HD.PO_NUMBER  "PURCHASE ORDER NO"
                              ,TO_NUMBER(LI.PO_LINE_REFERENCE) "PO LINE NO"
                              ,LI.SO_NUMBER "SHOP ORDER"
                              ,HD.CUSTOMER_NAME "CUSTOMER NAME"
                              ,HD.CUSTOMER_NAME "BILL TO NAME"
                              ,HD.BILL_TO_CODE "GEAE CUSTOMER NO"
                              ,HD.SUB_CUSTOMER_NAME "SUB CUSTOMER NAME"
                              ,HD.ESN  "ESN"
                              ,CRD_APP.CRD_COMMON_FUNCT_PKG.REPAIR_OTR_HG_ENG_MDL_NUM_FUN(HD.ENGINE_MODEL) "ENG_MDL_NUMBER"
                              ,HD.ENGINE_MODEL "ENGINE MODEL"
                              ,LI.PART_NUMBER_IN  "PART NUMBER IN"
                              ,LI.PART_NUMBER_OUT "PART NUMBER OUT"
                              ,LI.PART_DESCRIPTION "PART DESCRIPTION"
                              ,NULL "PART KEYWORD NEW"
                              ,LI.PART_SERIAL_NUMBER "PART SERIAL NUMBER"
                              ,TO_NUMBER(LI.ORIGINAL_QUANTITY) "ORIG QTY"
                              ,TO_NUMBER(LI.SCRAP_QUANTITY) "QTY REJECTED"
                              ,TO_NUMBER(LI.REPAIR_QUANTITY) "QTY REPAIRED"
                              ,TO_NUMBER(LI.REPLACEMENT_QUANTITY) "QTY REPLACED"
                              ,TO_NUMBER(LI.BALANCE_QUANTITY) "BAL QTY"
                              ,TO_CHAR(LI.DOCK_DATE,'DD-MON-YYYY') "DOCK DATE"
                              ,NULL "REQD DATE"
                              ,CASE WHEN LI.SCHEDULE_DELIVERY_DATE LIKE '__.__.____'
										THEN TO_CHAR(TO_DATE(LI.SCHEDULE_DELIVERY_DATE,'DD.MM.YYYY'),'YYYY-MM-DD')
									ELSE LI.SCHEDULE_DELIVERY_DATE
								END "SCHEDULE DELIVERY DATE"
                              ,TO_NUMBER(CRD_APP.REPAIR_PO_SUMMARY_DETAILS_PKG.REPAIR_HG_FORECAST_TAT(LI.SCHEDULE_DELIVERY_DATE,LI.dock_date)) "FORECAST TAT"
                              ,LI.OUTBOUND_DELIVERY_ORDER "MS#"
                              ,TO_CHAR(LI.SHIP_DATE,'DD-MON-YYYY') "MS CREATE DATE"
                              ,TO_CHAR(LI.PROMISE_DATE,'DD-MON-YYYY') "PROMISED DATE"
                              ,TO_CHAR(LI.SHIP_DATE,'DD-MON-YYYY') "SHIP DATE"
                              ,NULL "RPR CLS CODE"
                              ,nvl(REPAIR_QUANTITY,0)+nvl(REPLACEMENT_QUANTITY,0) "QTY SHIPD"
                              ,LI.AIRWAY_BILL_NUMBER "AWB#"
                              ,LI.CARRIER_CODE "CARIER CODE"
                              ,LI.CUSTOMER_SERVICE_REP "CSM ID#"
                              ,TO_CHAR(LI.SO_DATE,'DD-MON-YYYY') "SO CREATE DATE"
                              ,ROUND( ( sysdate-LI.DOCK_DATE),0) "SHOP ORDER AGE"
                              ,LI.COMPONENT_CODE "COMPONENT CODE"
                              ,LI.WORKCENTER_DESC  "REPORT INDICATOR"
                              ,NULL "INITIAL QUOTE"
                              ,TO_NUMBER(HD.DAYS_TO_QUOTE) "DAYS TO QUOTE"
                              ,NULL "RFQA Y/N"
                              ,TO_CHAR(HD.QUOTE_APPROVAL_DATE,'DD-MON-YYYY') "DATE OF QUOTE APPROVAL"
                              ,TO_NUMBER(HD.NET_QUOTE_VALUE) "QUOTED PRICE"
                              ,TO_NUMBER(LI.CONTRACT_TAT) "CONTRACT TAT"
                              ,TO_NUMBER(LI.ACTUAL_TAT) "TAT"
                              ,TO_NUMBER(LI.LINE_PRICE)  "UNIT PRICE"
                              ,TO_NUMBER(nvl(LI.REPAIR_QUANTITY,0)*nvl(LI.LINE_PRICE,0)) "EXTENDED PRICE"
                              ,NULL "ROTABLE CODE"
                              ,NULL "SCHEDULE CUSTOM COMMENTS"
                              ,LI.CUSTOMER_SERVICE_REP "CSM_FIRST_NAME"
                              ,NULL "CSM_LAST_NAME"
                              ,NULL "REPORT CODE DESCR"
                              ,REPAIR_PO_SUMMARY_DETAILS_PKG.REPAIR_HG_ENGINE_FAMILY_FUN(HD.ENGINE_MODEL) "ENGINE FAMILY"
                              ,HD.BILL_TO_CODE "CUSTOMER NUMBER"
                              ,LI.LINE_STATUS AS "PO LINE STATUS"
                              FROM CRD_OASIS_ORDER_HEADER HD,
                                   CRD_OASIS_ORDER_LINES LI
                             where DECODE(HD.LOCATION_ID,'EHN','HG')='HG'
                               AND HD.PO_NUMBER=LI.PO_NUMBER
                               AND HD.location_id=LI.LOCATION_ID
                               AND HD.SVN=LI.SVN
                               AND HD.ORDER_CREATE_DATE BETWEEN SYSDATE - 365 AND SYSDATE);

   COMMIT;
END;