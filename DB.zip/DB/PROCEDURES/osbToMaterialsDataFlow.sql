
                                                     CRD                                                  
  
  
CRD_PO_LI_ORDCMPNT_XREF(CRD_POLIX_PKG--this package will help data load from stage to BASE TABLE ,
CRD_POLIX_SA_PKG--from view to stazing table




=================================================================================================================================




create or replace PACKAGE BODY CRD_POLIX_PKG
IS
    PROCEDURE Process_All_Records(
        P_Shop_Name    IN VARCHAR2,
        P_Process_Date IN DATE)
    IS
        CURSOR LC_SA (P_Shop_Name VARCHAR2) IS
            SELECT
                sa.ROWID
            FROM crd_sa_polix sa
            WHERE sa.location_id = NVL(P_Shop_Name, sa.location_id)
            ORDER BY
                sa.sa_first_processed_date,
                sa.sa_file_shop,
                sa.sa_file_grouping,
                sa.sa_file_index,
                sa.sa_file_line;
    --
        LV_SA_ROWID              ROWID;
        LV_SA_Row  crd_sa_polix%ROWTYPE;
    BEGIN
        OPEN LC_SA (P_Shop_Name);
    --
        LOOP
            FETCH LC_SA INTO LV_SA_ROWID;
    --
            EXIT WHEN LC_SA%NOTFOUND;
    --
            SELECT sa.*
            INTO
                LV_SA_Row
            FROM crd_sa_polix sa
            WHERE
                ROWID = LV_SA_ROWID;
    --
            Process_Record(
                P_Process_Date,
                LV_SA_ROWID,
                LV_SA_Row);
        END LOOP;
    --
        CLOSE LC_SA;
    EXCEPTION
        WHEN OTHERS THEN
            IF LC_SA%ISOPEN THEN
                CLOSE LC_SA;
            END IF;
    --
            RAISE;
    END;
--
--
    PROCEDURE Process_Record(
        P_Process_Date IN     DATE,
        P_SA_ROWID     IN     ROWID,
        P_SA_Row       IN OUT crd_sa_polix%ROWTYPE)
    IS
        LV_Error_Message                   VARCHAR2(2000);
        LV_Master_Value                    VARCHAR2(80);
        LE_Reject_Record                   EXCEPTION;
        LE_Reject_All                      EXCEPTION;
    --
        LV_Count                                NUMBER;
    --
        LV_POLIX_Row   crd_po_li_ordcmpnt_xref %ROWTYPE;
        LV_POLIX_ROWID                          ROWID;
        LV_CSTMR_Row   crd_cust                %ROWTYPE;
        LV_CBILL_Row   crd_cust_bill_to        %ROWTYPE;
        V_CUST_PO_LI_STS_DATE crd_cust_po.cust_po_sts_date %TYPE;
        
    BEGIN
        SAVEPOINT SP_Before_Modifying_SA;
    --
        P_SA_Row.remote_source_id      := CRD_Convert_PKG.TO__CHAR (P_SA_Row.remote_source_id     );
        P_SA_Row.po_li_ordcmpnt_seq_id := CRD_Convert_PKG.TO__CHAR (P_SA_Row.po_li_ordcmpnt_seq_id);
    --
        BEGIN
        -------------------------------------------------------------------------
        --  Delete all old instances of this record from the staging area (if any)
        -------------------------------------------------------------------------
        --
            DELETE  crd_sa_polix sa
            WHERE
                sa.sa_file_shop            = P_SA_Row.sa_file_shop             AND
                sa.sa_first_processed_date < P_SA_Row.sa_first_processed_date  AND
                sa.location_id             = P_SA_Row.location_id              AND
               (sa.remote_source_id        = P_SA_Row.remote_source_id         OR (
                sa.po_li_ordcmpnt_seq_id   = P_SA_Row.po_li_ordcmpnt_seq_id));
        EXCEPTION
            WHEN OTHERS THEN
                RAISE LE_Reject_All;
        END;
    --
    --
        SAVEPOINT SP_Before_Modifying_Target;
    --
    --  ------------------------------------------------------------------------
    --  Validating all mandatory attributes
    --  ------------------------------------------------------------------------
    --
       LV_Error_Message := 'Wrong format of one of the mandatory attributes - location_id, po_li_ordcmpnt_seq_id, ord_cmpnt_cd, ord_cmpnt_seq_num, ord_cmpnt_id (SQLERRM).';
    --
        LV_POLIX_Row.location_id                 := CRD_Convert_PKG.TO__CHAR  (TRIM(P_SA_Row.location_id)         );
        LV_POLIX_Row.po_li_ordcmpnt_xref_seq_id  := CRD_Convert_PKG.TO__NUMBER(P_SA_Row.po_li_ordcmpnt_seq_id      );
        LV_POLIX_Row.ord_cmpnt_cd                := CRD_Convert_PKG.TO__CHAR  (P_SA_Row.ord_cmpnt_cd               );
        LV_POLIX_Row.ord_cmpnt_seq_num           := CRD_Convert_PKG.TO__NUMBER(P_SA_Row.ord_cmpnt_seq_num          );
        LV_POLIX_Row.ord_cmpnt_id                := CRD_Convert_PKG.TO__CHAR  (P_SA_Row.ord_cmpnt_id               );
    --
       LV_Error_Message := 'Wrong format of one of the mandatory attributes - ord_cmpnt_amdmt_num, cust_po_number, cust_po_li_num, po_li_ord_cmpnt_xref_sts_cd (SQLERRM).';
    --
        LV_POLIX_Row.ord_cmpnt_amdmt_num         := CRD_Convert_PKG.TO__NUMBER(P_SA_Row.ord_cmpnt_amdmt_num        );
        LV_POLIX_Row.cust_po_number              := CRD_Convert_PKG.TO__CHAR  (P_SA_Row.cust_po_number             );
    --
        IF P_SA_Row.location_id = 'CEL' THEN
            LV_POLIX_Row.cust_po_li_num          := 1;
        ELSE
            LV_POLIX_Row.cust_po_li_num          := CRD_Convert_PKG.TO__NUMBER(P_SA_Row.cust_po_li_num         );
        END IF;
    --
        LV_POLIX_Row.po_li_ord_cmpnt_xref_sts_cd := CRD_Convert_PKG.TO__CHAR  (P_SA_Row.po_li_ord_cmpnt_xref_sts_cd);
    --
        LV_Error_Message := 'All mandatory attributes location_id, po_li_ordcmpnt_xref_seq_id, ord_cmpnt_cd, ord_cmpnt_seq_num, ord_cmpnt_id have to be specified and can not be "@" (SQLERRM).';
    --
        IF  LV_POLIX_Row.location_id                 IS NULL OR
            LV_POLIX_Row.po_li_ordcmpnt_xref_seq_id  IS NULL OR
            LV_POLIX_Row.ord_cmpnt_cd                IS NULL OR
            LV_POLIX_Row.ord_cmpnt_seq_num           IS NULL OR
            LV_POLIX_Row.ord_cmpnt_id                IS NULL
        THEN
            RAISE LE_Reject_Record;
        END IF;
    --
        LV_Error_Message := 'All mandatory attributes ord_cmpnt_amdmt_num, cust_po_number, cust_po_li_num, po_li_ord_cmpnt_xref_sts_cd have to be specified and can not be "@" (SQLERRM).';
    --
        IF  LV_POLIX_Row.ord_cmpnt_amdmt_num         IS NULL OR
            LV_POLIX_Row.cust_po_number              IS NULL OR
            LV_POLIX_Row.cust_po_li_num              IS NULL OR
            LV_POLIX_Row.po_li_ord_cmpnt_xref_sts_cd IS NULL
        THEN
            RAISE LE_Reject_Record;
        END IF;
    --
    --  ------------------------------------------------------------------------
    --  Validating the non mandatory attributes ("none" allowed)
    --  ------------------------------------------------------------------------
    --
        LV_Error_Message := 'Wrong format of one of teh non mandatory attributes - cust_name, frgn_cntry_cd, cust_sts_cd, geae_cust_number, cust_id_num (SQLERRM).';
    --
        LV_CSTMR_Row.cust_name         := CRD_Convert_PKG.TO__CHAR  (TRIM(P_SA_Row.cust_name)        );
        LV_CSTMR_Row.frgn_cntry_cd     := CRD_Convert_PKG.TO__CHAR  (P_SA_Row.cust_frgn_cntry_cd      );
        LV_CSTMR_Row.cust_sts_cd       := CRD_Convert_PKG.TO__CHAR  (P_SA_Row.cust_sts_cd             );
        LV_CBILL_Row.geae_cust_number  := CRD_Convert_PKG.TO__CHAR  (P_SA_Row.bill_to_geae_cust_number);
        LV_POLIX_Row.cust_id_num       := CRD_Convert_PKG.TO__NUMBER(P_SA_Row.cust_id_num             );
    --
        LV_Error_Message := 'Wrong format of one of the non mandatory attributes - bill_to_seq_num, remote_source_id (SQLERRM).';
    --
        LV_POLIX_Row.bill_to_seq_num   := CRD_Convert_PKG.TO__NUMBER(P_SA_Row.bill_to_seq_num         );
        LV_POLIX_Row.remote_source_id  := CRD_Convert_PKG.TO__CHAR  (P_SA_Row.remote_source_id        );
    --
        IF LV_POLIX_Row.remote_source_id IS NOT NULL THEN
            LV_POLIX_Row.remote_source_id := P_SA_Row.location_id || '-' || P_SA_Row.remote_source_id;
        END IF;
    --
    --  ------------------------------------------------------------------------
    --  Translate some attributes (including some lookups)
    --  ------------------------------------------------------------------------
    --
        LV_Error_Message := 'Can not translate location_id (SQLERRM).';
    --
        CRD_Translate_PKG.Get_Value(
            P_SA_Row.sa_file_shop,
            P_SA_Row.sa_file_grouping,
            CRD_Translate_PKG.GC_AN_Location_Name,
            LV_POLIX_Row.location_id,
            FALSE,
            TRUE,
            LV_POLIX_Row.location_id,
            LV_Master_Value);
    --
        LV_Error_Message := 'Can not find location_id (SQLERRM).';
    --
        SELECT 1
        INTO   LV_Count
        FROM   crd_location
        WHERE  location_id = LV_POLIX_Row.location_id;
    --
    --
        IF LV_POLIX_Row.cust_id_num IS NOT NULL
        THEN
            LV_Error_Message := 'Can not find customer by PKey (SQLERRM).';
    --
            SELECT 1
            INTO   LV_Count
            FROM   crd_cust
            WHERE  cust_id_num = LV_POLIX_Row.cust_id_num AND
                   location_id = LV_POLIX_Row.location_id;
        ELSE
            IF  LV_CSTMR_Row.cust_name      IS NOT NULL AND
                LV_CSTMR_Row.frgn_cntry_cd  IS NOT NULL AND
                LV_CSTMR_Row.cust_sts_cd    IS NOT NULL
            THEN
                --
                LV_Error_Message := 'Can not translate the attribute "cust_name" (SQLERRM).';
                --
                CRD_Translate_PKG.Get_Value(
                    P_SA_Row.sa_file_shop,
                    P_SA_Row.sa_file_grouping,
                    CRD_Translate_PKG.GC_AN_Customer_Name,
                    LV_CSTMR_Row.cust_name,
                    FALSE,
                    TRUE,
                    LV_CSTMR_Row.cust_name,
                    LV_Master_Value);
            --
                LV_Error_Message := 'Can not find the cust_id_num (SQLERRM).';
            --
                SELECT cust_id_num
                INTO   LV_POLIX_Row.cust_id_num
                FROM   crd_cust
                WHERE  cust_name       = LV_CSTMR_Row.cust_name       AND
                       frgn_cntry_cd   = LV_CSTMR_Row.frgn_cntry_cd   AND
                       cust_sts_cd     = LV_CSTMR_Row.cust_sts_cd     AND
                       location_id     = LV_POLIX_Row.location_id;
            END IF;
        END IF;
    --
        CRD_Translate_PKG.Clear_Last_Not_Found_Value;
    --
    --  ------------------------------------------------------------------------
    --  Make lookups
    --  ------------------------------------------------------------------------
    --
        IF  LV_POLIX_Row.bill_to_seq_num IS NOT NULL
        THEN
            LV_Error_Message := 'Can not find Bill To Customer by PKey (SQLERRM).';
    --
            SELECT  1
            INTO    LV_Count
            FROM    crd_cust_bill_to
            WHERE
                bill_to_seq_num = LV_POLIX_Row.bill_to_seq_num AND
                cust_id_num     = LV_POLIX_Row.cust_id_num     AND
                location_id     = LV_POLIX_Row.location_id;
        ELSE
            IF  LV_CBILL_Row.geae_cust_number  IS NOT NULL
            THEN
                LV_Error_Message := 'Can not find Bill To Customer by geae_cust_number (SQLERRM).';
            --
                SELECT cb.bill_to_seq_num
                INTO   LV_POLIX_Row.bill_to_seq_num
                FROM   crd_cust_bill_to cb
                WHERE
                    cb.cust_id_num      = LV_POLIX_Row.cust_id_num   AND
                    cb.location_id      = LV_POLIX_Row.location_id   AND
                    cb.geae_cust_number = LV_CBILL_Row.geae_cust_number;
            END IF;
        END IF;

    --
        IF  LV_POLIX_Row.cust_id_num     IS NOT NULL AND
            LV_POLIX_Row.bill_to_seq_num IS NOT NULL AND
            LV_POLIX_Row.cust_po_number  IS NOT NULL AND
            LV_POLIX_Row.cust_po_li_num  IS NOT NULL
        THEN
           BEGIN
            LV_Error_Message := 'Can not find Customer Purchase Order Line (SQLERRM).';
        
         
            SELECT 1
            INTO   LV_Count
            FROM   crd_cust_po_li cb
            WHERE
                cb.cust_id_num      = LV_POLIX_Row.cust_id_num     AND
                cb.location_id      = LV_POLIX_Row.location_id     AND
                cb.bill_to_seq_num  = LV_POLIX_Row.bill_to_seq_num AND
                cb.cust_po_number   = LV_POLIX_Row.cust_po_number   AND
               cb.cust_po_li_num   = LV_POLIX_Row.cust_po_li_num;
      -------------------------------------------------------------------------------------
      -- Added Code for Inserting into  crd_cust_po_li when no data found
      -- as part of fix production records getting rejected
      -- Changed Date: 1-Apr-2013
      -------------------------------------------------------------------------------------
               
          EXCEPTION
           WHEN NO_DATA_FOUND THEN
              BEGIN
               LV_Error_Message := 'Can not find Cust_PO record in CRD_CUST_PO table(SQLERRM)';
               SELECT cust_po_sts_date  
               INTO V_CUST_PO_LI_STS_DATE  
               FROM crd_cust_po
               WHERE
               cust_id_num   = LV_POLIX_Row.cust_id_num     AND
               location_id      = LV_POLIX_Row.location_id     AND
               bill_to_seq_num  = LV_POLIX_Row.bill_to_seq_num AND
               cust_po_number   = LV_POLIX_Row.cust_po_number;
                
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  NULL;
              END;
               
               IF V_CUST_PO_LI_STS_DATE IS NULL THEN
                 RAISE LE_Reject_Record;
               
               ELSE
                 BEGIN
                  LV_Error_Message := 'Can not Insert in CRD_CUST_PO_LI table(SQLERRM)';
                  INSERT
			              INTO crd_cust_po_li
                    (
			              CUST_PO_NUMBER,
			              BILL_TO_SEQ_NUM,
			              CUST_ID_NUM,
			              CUST_PO_LI_NUM,
                    CUST_PO_LI_STS_CD,
                    LOCATION_ID,
			              LAST_UPDATED_BY,
			              LAST_UPDATE_DATE,
			              CUST_PO_LI_LTXT_CHNG_FLG,
			              CUST_PO_LI_DATE,
			              REMOTE_SOURCE_ID,
			              CUST_PO_LI_STS_DATE
                   )
			            (SELECT DISTINCT CUST_PO_NUMBER,
			                BILL_TO_SEQ_NUM,
			                CUST_ID_NUM,
			                CUST_PO_LI_NUM,
			                PO_LI_ORD_CMPNT_XREF_STS_CD CUST_PO_LI_STS_CD,
			                LV_POLIX_Row.location_id LOCATION_ID,
			                '1' LAST_UPDATED_BY,
			                SYSDATE LAST_UPDATE_DATE,
			                NULL CUST_PO_LI_LTXT_CHNG_FLG,
			                NULL CUST_PO_LI_DATE,
			                NULL REMOTE_SOURCE_ID ,
                      V_CUST_PO_LI_STS_DATE
                    FROM CRD_SA_POLIX
                    WHERE Cust_id_num       = LV_POLIX_Row.cust_id_num
			              AND location_id         = P_SA_Row.location_id
			              AND bill_to_seq_num     = LV_POLIX_Row.bill_to_seq_num
			              AND cust_po_number      = LV_POLIX_Row.cust_po_number
			              AND cust_po_li_num      = LV_POLIX_Row.cust_po_li_num
                    AND po_li_ordcmpnt_seq_id =
			                (SELECT DISTINCT MAX(po_li_ordcmpnt_seq_id)
			                 FROM CRD_SA_POLIX
			                 WHERE cust_id_num   = LV_POLIX_Row.cust_id_num
                       AND location_id     = P_SA_Row.location_id
			                 AND bill_to_seq_num = LV_POLIX_Row.bill_to_seq_num
			                 AND cust_po_number  = LV_POLIX_Row.cust_po_number
			                 AND cust_po_li_num  = LV_POLIX_Row.cust_po_li_num
                       AND ORD_CMPNT_AMDMT_NUM      =
                       (SELECT DISTINCT MAX(ORD_CMPNT_AMDMT_NUM)
                        FROM CRD_SA_POLIX
			                  WHERE cust_id_num   = LV_POLIX_Row.cust_id_num
                        AND location_id     = P_SA_Row.location_id
			                  AND bill_to_seq_num = LV_POLIX_Row.bill_to_seq_num
			                  AND cust_po_number  = LV_POLIX_Row.cust_po_number
			                  AND cust_po_li_num  = LV_POLIX_Row.cust_po_li_num
                       
                )
             )
			  );

              END;
           END IF;
        END;
    END IF;
    --
    --  ------------------------------------------------------------------------
    --  Find the old record (if any)
    --  ------------------------------------------------------------------------
    --
        LV_Error_Message := 'Error finding PO Line Order Component xref record by PKey (SQLERRM).';
    --
        BEGIN
            SELECT ROWID
            INTO   LV_POLIX_ROWID
            FROM   crd_po_li_ordcmpnt_xref
            WHERE
                   po_li_ordcmpnt_xref_seq_id = LV_POLIX_Row.po_li_ordcmpnt_xref_seq_id AND
                   location_id                = LV_POLIX_Row.location_id;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                NULL;
        END;
    --
        IF LV_POLIX_ROWID IS NULL THEN
    --
            IF LV_POLIX_Row.remote_source_id IS NOT NULL THEN
        --
                LV_Error_Message := 'Error finding the PO Line Order Component xref record by "Remote_Source_Id" (SQLERRM).';
        --
                BEGIN
                    SELECT ROWID
                    INTO   LV_POLIX_ROWID
                    FROM   crd_po_li_ordcmpnt_xref
                    WHERE  remote_source_id = LV_POLIX_Row.remote_source_id;
                EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                        NULL;
                END;
            END IF;
        END IF;
    --
        IF  LV_POLIX_ROWID IS NULL THEN
    --
        --  --------------------------------------------------------------------
        --  Inserting new record
        --  --------------------------------------------------------------------
        --
            LV_Error_Message := 'Can not create PO Line Order Component xref record (SQLERRM).';
        --
            INSERT INTO crd_po_li_ordcmpnt_xref(
                location_id,
                po_li_ordcmpnt_xref_seq_id ,
                cust_po_li_num,
                cust_po_number,
                bill_to_seq_num,
                cust_id_num,
                ord_cmpnt_cd,
                ord_cmpnt_id,
                po_li_ord_cmpnt_xref_sts_cd,
                ord_cmpnt_amdmt_num,
                ord_cmpnt_seq_num,
                remote_source_id)
            VALUES (
                LV_POLIX_Row.location_id,
                LV_POLIX_Row.po_li_ordcmpnt_xref_seq_id,
                LV_POLIX_Row.cust_po_li_num,
                LV_POLIX_Row.cust_po_number,
                LV_POLIX_Row.bill_to_seq_num,
                LV_POLIX_Row.cust_id_num,
                LV_POLIX_Row.ord_cmpnt_cd,
                LV_POLIX_Row.ord_cmpnt_id,
                LV_POLIX_Row.po_li_ord_cmpnt_xref_sts_cd,
                LV_POLIX_Row.ord_cmpnt_amdmt_num,
                LV_POLIX_Row.ord_cmpnt_seq_num,
                LV_POLIX_Row.remote_source_id);
        ELSE
        --  --------------------------------------------------------------------
        --  Update the existing record
        --  --------------------------------------------------------------------
        --
            LV_Error_Message := 'Error updating PO Line Order Component xref record (SQLERRM).';
        --
            UPDATE crd_po_li_ordcmpnt_xref o
            SET o.cust_po_li_num              = LV_POLIX_Row.cust_po_li_num,
                o.cust_po_number              = LV_POLIX_Row.cust_po_number,
                o.bill_to_seq_num             = LV_POLIX_Row.bill_to_seq_num,
                o.cust_id_num                 = LV_POLIX_Row.cust_id_num,
                o.ord_cmpnt_cd                = LV_POLIX_Row.ord_cmpnt_cd,
                o.ord_cmpnt_id                = LV_POLIX_Row.ord_cmpnt_id,
                o.po_li_ord_cmpnt_xref_sts_cd = LV_POLIX_Row.po_li_ord_cmpnt_xref_sts_cd,
                o.ord_cmpnt_amdmt_num         = LV_POLIX_Row.ord_cmpnt_amdmt_num,
                o.ord_cmpnt_seq_num           = LV_POLIX_Row.ord_cmpnt_seq_num,
                o.remote_source_id            = LV_POLIX_Row.remote_source_id
            WHERE
                o.ROWID = LV_POLIX_ROWID;
        END IF;
    --
    --  ------------------------------------------------------------------------
    --  Delete the record from the staging area
    --  ------------------------------------------------------------------------
    --
        LV_Error_Message := 'The staging area record was processed but can not be deleted (SQLERRM).';
    --
        DELETE crd_sa_polix sa
        WHERE sa.ROWID = P_SA_ROWID;
    --
        COMMIT;
    --
    EXCEPTION
        WHEN LE_Reject_All THEN
            ROLLBACK TO SAVEPOINT SP_Before_Modifying_SA;
    --
            RAISE;
        WHEN OTHERS THEN
            ROLLBACK TO SAVEPOINT SP_Before_Modifying_Target;
    --
            BEGIN
                LV_Error_Message := NVL(LV_Error_Message, 'Unknown (SQLERRM).');
                LV_Error_Message := REPLACE(LV_Error_Message, 'SQLERRM', REPLACE(SQLERRM, CHR(10), ' / '));
            --
                CRD_Translate_PKG.Put_Last_Not_Found_Value;
            --
            --  ----------------------------------------------------------------
            --  Update staging area table
            --  ----------------------------------------------------------------
            --
                UPDATE crd_sa_polix sa
                SET sa.sa_error_msg           = LV_Error_Message,
                    sa.sa_last_processed_date = P_Process_Date,
                    sa.sa_last_update_date    = SYSDATE
                WHERE sa.ROWID = P_SA_ROWID;
            --
                COMMIT;
            --
            EXCEPTION
                WHEN OTHERS THEN
                    ROLLBACK TO SAVEPOINT SP_Before_Modifying_SA;
            --
                    RAISE;
            END;
    END;
END CRD_POLIX_PKG;




=================================================================================================================================



create or replace PACKAGE BODY CRD_POLIX_SA_PKG
IS
    PROCEDURE Refresh_SA_OSB (P_Shop_Name         IN VARCHAR2,
                              P_Pull_Begin_Date   IN DATE,
                              P_Pull_End_Date     IN DATE,
                              P_Proc_Date         IN DATE,
                              P_Refr_Date_Flag    IN VARCHAR2,
                              P_Rec_Count        OUT NUMBER)
    IS
    BEGIN
        INSERT INTO crd_sa_polix(
            sa_file_date,
            sa_file_shop,
            sa_file_index,
            sa_file_grouping,
            sa_file_line,
            sa_first_processed_date,
            sa_last_processed_date,
            sa_error_msg,
        --
            location_id,
            po_li_ordcmpnt_seq_id,
            ord_cmpnt_seq_num,
            ord_cmpnt_cd,
            ord_cmpnt_id,
            ord_cmpnt_amdmt_num,
            cust_po_number,
            cust_po_li_num,
            cust_id_num,
            cust_name,
            cust_frgn_cntry_cd,
            cust_sts_cd,
            bill_to_seq_num,
            bill_to_geae_cust_number,
            po_li_ord_cmpnt_xref_sts_cd,
            remote_source_id,
        --
            sa_creation_date,
            sa_last_update_date
        )
        SELECT
            p.refresh_date,
            p.location_id,
            NULL,
            GC_IF_Group_Name,
            NULL,
            P_Proc_Date,
            P_Proc_Date,
            NULL,
        --
            p.location_id,
            TO_CHAR(p.seq_id),
            TO_CHAR(p.ord_cmpnt_seq_nbr),
            p.ord_cmpnt_code,
            p.ord_cmpnt_id,
            TO_CHAR(p.amdmt_nbr),
            p.cust_po_nbr,
            TO_CHAR(p.cust_po_li_nbr),
            TO_CHAR(p.cust_id),
            NULL, /* cust_name         */
            NULL, /* frgn_cntry_code   */
            NULL, /* cust_sts_code     */
            TO_CHAR(p.bill_to_seq_nbr),
            NULL, /* bill_to_geae_cust_nbr     */
            p.sts_code,
            TO_CHAR(p.seq_id),
        --
            P_Proc_Date,
            P_Proc_Date
        FROM
            crd_osb_polix_v p /* REF - cust_po_li_ord_cmpnt_xref */
        WHERE
            ((P_Refr_Date_Flag = 'Y'
          AND p.refresh_date >= P_Pull_Begin_Date
          AND p.refresh_date <= P_Pull_End_Date    )
           OR
             (P_Refr_Date_Flag != 'Y'
          AND p.last_update_date >= P_Pull_Begin_Date
          AND p.last_update_date <= P_Pull_End_Date))
    --
          AND p.location_id = NVL(P_Shop_Name, p.location_id);
    --
        COMMIT;
    --
        P_Rec_Count := SQL%ROWCOUNT;
    END;
	
	
	
	
	
	=======================================================================================================================
	
	
                              STAGEING_TABLE
							  ================
	
  CREATE TABLE "CRD"."CRD_SA_POLIX" 
   (	"SA_FILE_DATE" VARCHAR2(4000 BYTE), 
	"SA_FILE_SHOP" VARCHAR2(4000 BYTE), 
	"SA_FILE_INDEX" VARCHAR2(4000 BYTE), 
	"SA_FILE_GROUPING" VARCHAR2(4000 BYTE), 
	"SA_FILE_LINE" VARCHAR2(4000 BYTE), 
	"SA_FIRST_PROCESSED_DATE" DATE, 
	"SA_LAST_PROCESSED_DATE" DATE, 
	"SA_ERROR_MSG" VARCHAR2(4000 BYTE), 
	"LOCATION_ID" VARCHAR2(400 BYTE), 
	"PO_LI_ORDCMPNT_SEQ_ID" VARCHAR2(400 BYTE), 
	"ORD_CMPNT_SEQ_NUM" VARCHAR2(4000 BYTE), 
	"ORD_CMPNT_CD" VARCHAR2(4000 BYTE), 
	"ORD_CMPNT_ID" VARCHAR2(4000 BYTE), 
	"ORD_CMPNT_AMDMT_NUM" VARCHAR2(4000 BYTE), 
	"CUST_PO_NUMBER" VARCHAR2(4000 BYTE), 
	"CUST_PO_LI_NUM" VARCHAR2(4000 BYTE), 
	"BILL_TO_GEAE_CUST_NUMBER" VARCHAR2(4000 BYTE), 
	"CUST_NAME" VARCHAR2(4000 BYTE), 
	"CUST_FRGN_CNTRY_CD" VARCHAR2(4000 BYTE), 
	"CUST_STS_CD" VARCHAR2(4000 BYTE), 
	"PO_LI_ORD_CMPNT_XREF_STS_CD" VARCHAR2(4000 BYTE), 
	"REMOTE_SOURCE_ID" VARCHAR2(400 BYTE), 
	"SA_CREATION_DATE" DATE, 
	"SA_LAST_UPDATE_DATE" DATE, 
	"CUST_ID_NUM" VARCHAR2(4000 BYTE), 
	"BILL_TO_SEQ_NUM" VARCHAR2(4000 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 4194304 NEXT 4194304 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "CRD_SA_TABLES_M_01" ;

 \
Table: CUST_PO_LI_ORDCMPNT_XREF, Column: Bill_To_Seq_Nbr.';
   --COMMENT ON TABLE "CRD"."CRD_SA_POLIX"  This table contains the customer purchase order line and Order component cross reference details and refers to the CRD_PO_LI_ORDCMPNT_XREF.';

   
							  

                                    VIEW
									======
	-- Unable to render VIEW DDL for object CRD.CRD_OSB_POLIX_V with DBMS_METADATA attempting internal generator.
CREATE VIEW CRD.CRD_OSB_POLIX_V
AS SELECT "AMDMT_NBR","BILL_TO_SEQ_NBR","CUST_ID","CUST_PO_NBR","CUST_PO_LI_NBR",
"ORD_CMPNT_CODE","ORD_CMPNT_ID","ORD_CMPNT_SEQ_NBR","SEQ_ID","STS_CODE","STS_DATE","LAST_UPDATED_BY",
"LAST_UPDATE_DATE","LOCATION_ID","REFRESH_DATE" from crd_osb_POLIX_ev_v
UNION ALL
SELECT "AMDMT_NBR","BILL_TO_SEQ_NBR","CUST_ID","CUST_PO_NBR","CUST_PO_LI_NBR",
"ORD_CMPNT_CODE","ORD_CMPNT_ID","ORD_CMPNT_SEQ_NBR","SEQ_ID","STS_CODE","STS_DATE","LAST_UPDATED_BY",
"LAST_UPDATE_DATE","LOCATION_ID","REFRESH_DATE" from crd_osb_POLIX_jp_v
UNION ALL
SELECT "AMDMT_NBR","BILL_TO_SEQ_NBR","CUST_ID","CUST_PO_NBR",
"CUST_PO_LI_NBR","ORD_CMPNT_CODE","ORD_CMPNT_ID","ORD_CMPNT_SEQ_NBR","SEQ_ID","STS_CODE","STS_DATE","LAST_UPDATED_BY",
"LAST_UPDATE_DATE","LOCATION_ID","REFRESH_DATE" from crd_osb_POLIX_mc_v
UNION ALL
SELECT "AMDMT_NBR","BILL_TO_SEQ_NBR","CUST_ID","CUST_PO_NBR","CUST_PO_LI_NBR",
"ORD_CMPNT_CODE","ORD_CMPNT_ID","ORD_CMPNT_SEQ_NBR","SEQ_ID","STS_CODE","STS_DATE","LAST_UPDATED_BY",
"LAST_UPDATE_DATE","LOCATION_ID","REFRESH_DATE" from crd_osb_POLIX_hu_v
UNION ALL
SELECT "AMDMT_NBR","BILL_TO_SEQ_NBR","CUST_ID","CUST_PO_NBR","CUST_PO_LI_NBR",
"ORD_CMPNT_CODE","ORD_CMPNT_ID","ORD_CMPNT_SEQ_NBR","SEQ_ID","STS_CODE","STS_DATE","LAST_UPDATED_BY",
"LAST_UPDATE_DATE","LOCATION_ID","REFRESH_DATE" from crd_osb_POLIX_si_v
								
								

========================================================================================================

                                       SUB_VIEW
									   =======
CREATE VIEW CRD.CRD_OSB_POLIX_SI_V
AS SELECT /*+ RULE */
    p.amdmt_nbr,
    p.bill_to_seq_nbr,
    p.cust_id,
    p.cust_po_nbr,
    p.cust_po_li_nbr,
    p.ord_cmpnt_code,
    p.ord_cmpnt_id,
    p.ord_cmpnt_seq_nbr,
    p.seq_id,
    p.sts_code,
    p.sts_date,
    p.last_updated_by,
    p.last_update_date,
    p.location_id,
    p.refresh_date
FROM
    mv_SI_cust_po                  po,
    mv_SI_ust_po_li_ord_cmpnt_xref p
WHERE
    p.location_id     = po.location_id     AND
    p.cust_id         = po.cust_id         AND
    p.bill_to_seq_nbr = po.bill_to_seq_nbr AND
    p.cust_po_nbr     = po.cust_po_nbr     AND
--
    po.last_update_date >= TO_DATE('01-01-1998', 'DD-MM-YYYY')

	
	                                MATARIALIZED_VIEW 

									
============================================================================================================================================									
									
-- Unable to render MATERIALIZED VIEW DDL for object CRD.MV_SI_UST_PO_LI_ORD_CMPNT_XREF with DBMS_METADATA attempting internal generator.
CREATE MATERIALIZED VIEW CRD.MV_SI_UST_PO_LI_ORD_CMPNT_XREF 
LOGGING 
TABLESPACE CRD_MVIEW_SI_TABLES_M_01 
PCTFREE 10 
PCTUSED 40 
INITRANS 1 
STORAGE 
( 
  INITIAL 4194304 
  NEXT 4194304 
  MINEXTENTS 1 
  MAXEXTENTS UNLIMITED 
  PCTINCREASE 0 
  FREELISTS 1 
  FREELIST GROUPS 1 
  BUFFER_POOL DEFAULT 
) 
NOCOMPRESS 
NOCACHE 
NOPARALLEL AS 
SELECT
amdmt_nbr,
bill_to_seq_nbr,
cust_id,
cust_po_li_nbr,
cust_po_nbr,
ord_cmpnt_code,
ord_cmpnt_id,
ord_cmpnt_seq_nbr,
seq_id,
sts_code,
sts_date,
last_update_date,
last_updated_by,
'SI' "LOCATION_ID",
NVL(NULL,SYSDATE) "REFRESH_DATE"
FROM esdtest.cust_po_li_ord_cmpnt_xref@crd_asiosbp1COMMENT ON MATERIALIZED VIEW CRD.MV_SI_UST_PO_LI_ORD_CMPNT_XREF IS 'snapshot table for snapshot CRD.MV_SI_UST_PO_LI_ORD_CMPNT_XREF'CREATE UNIQUE INDEX CRD.I_SNAP$_MV_SI_UST_PO_LI_OR ON CRD.MV_SI_UST_PO_LI_ORD_CMPNT_XREF (M_ROW$$ ASC) 
LOGGING 



=========================================================================

CREATE MATERIALIZED VIEW CRD.MV_SI_CUST_PO 
LOGGING 
TABLESPACE CRD_MVIEW_SI_TABLES_M_01 
PCTFREE 10 
PCTUSED 40 
INITRANS 1 
STORAGE 
( 
  INITIAL 4194304 
  NEXT 4194304 
  MINEXTENTS 1 
  MAXEXTENTS UNLIMITED 
  PCTINCREASE 0 
  FREELISTS 1 
  FREELIST GROUPS 1 
  BUFFER_POOL DEFAULT 
) 
NOCOMPRESS 
NOCACHE 
NOPARALLEL AS 
SELECT
bill_to_seq_nbr,
cust_id,
cust_po_date,
cust_po_nbr,
sts_code,
sts_date,
last_update_date,
last_updated_by,
'SI' "LOCATION_ID",
NVL(NULL,SYSDATE) "REFRESH_DATE"
FROM esdtest.cust_po@crd_asiosbp1

COMMENT ON MATERIALIZED VIEW CRD.MV_SI_CUST_PO IS 'snapshot table for snapshot CRD.MV_SI_CUST_PO'
CREATE UNIQUE INDEX CRD.I_SNAP$_MV_SI_CUST_PO ON CRD.MV_SI_CUST_PO (M_ROW$$ ASC) 
LOGGING 


====================================================================================================================================

CRD.MV_SI_UST_PO_LI_ORD_CMPNT_XREF  this mv created by-
 FROM esdtest.cust_po_li_ord_cmpnt_xref@crd_asiosbp1 --DATABASE LINK--user schema (name)
 
 
 
 
 