

-------------------------------------------------------------------------GET_CUSTOMER_DETAILS-------------------------------------------------------


DECLARE
  P_SSO VARCHAR2(200);
  P_IACO_CODE VARCHAR2(200);
  P_CUST_ID APPS.V_CUST_ID_ARRAY;
  P_ROLE VARCHAR2(200);
  P_OU_ID VARCHAR2(200);
  P_HEADERID VARCHAR2(200);
  P_CUST_SHIP_ADD APPS.V_CUST_SHIPPING_ARRAY;
  P_CUST_DEL_ADD APPS.V_CUST_DELIVER_ARRAY;
  P_CUST_MAP_ADD APPS.V_CUST_MAPPING_ARRAY;
  P_CUST_GTA APPS.V_CUSTOMER_GTA_ARRAY;
  P_CUST_ADMIN APPS.V_CUSTOMER_ADMIN_ARRAY;
  P_MESSAGE VARCHAR2(200);
  
BEGIN
  P_SSO := NULL;
  P_IACO_CODE := NULL;
  -- Modify the code to initialize the variable
  -- P_CUST_ID := NULL;
  P_ROLE := NULL;
  P_OU_ID := NULL;
  P_HEADERID := NULL;

  GEAE_MYGE_CUST_DETAILS_PKG.GET_CUSTOMER_DETAILS(
    P_SSO => P_SSO,
    P_IACO_CODE => P_IACO_CODE,
    P_CUST_ID => P_CUST_ID,
    P_ROLE => P_ROLE,
    P_OU_ID => P_OU_ID,
    P_HEADERID => P_HEADERID,
    P_CUST_SHIP_ADD => P_CUST_SHIP_ADD,
    P_CUST_DEL_ADD => P_CUST_DEL_ADD,
    P_CUST_MAP_ADD => P_CUST_MAP_ADD,
    P_CUST_GTA => P_CUST_GTA,
    P_CUST_ADMIN => P_CUST_ADMIN,
    P_MESSAGE => P_MESSAGE
  );
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_CUST_SHIP_ADD = ' || P_CUST_SHIP_ADD);
*/ 
  --:P_CUST_SHIP_ADD := P_CUST_SHIP_ADD;
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_CUST_DEL_ADD = ' || P_CUST_DEL_ADD);
*/ 
  --:P_CUST_DEL_ADD := P_CUST_DEL_ADD;
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_CUST_MAP_ADD = ' || P_CUST_MAP_ADD);
*/ 
  --:P_CUST_MAP_ADD := P_CUST_MAP_ADD;
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_CUST_GTA = ' || P_CUST_GTA);
*/ 
  --:P_CUST_GTA := P_CUST_GTA;
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_CUST_ADMIN = ' || P_CUST_ADMIN);
*/ 
  --:P_CUST_ADMIN := P_CUST_ADMIN;
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_MESSAGE = ' || P_MESSAGE);
*/ 
  :P_MESSAGE := P_MESSAGE;
--rollback; 
END;



-----------------------------------------------------------------------------------------------

create or replace TYPE        "V_CUST_SHIPPING_ARRAY" AS VARRAY(1000) OF APPS.V_SHIPPING_ADDRESS_LIST_BO

create or replace TYPE        "V_CUST_DELIVER_ARRAY" AS VARRAY(2250) OF V_DELIVER_ADDRESS_LIST_BO

create or replace TYPE        "V_CUST_MAPPING_ARRAY" AS VARRAY(2250) OF V_MAPPING_ADDRESS_LIST_BO;

create or replace TYPE        "V_CUSTOMER_GTA_ARRAY" AS VARRAY(2250) OF V_CUST_GTA_LIST_BO;

create or replace TYPE        "V_CUSTOMER_ADMIN_ARRAY" AS VARRAY(2250) OF V_CUST_ADMIN_LIST_BO;

-----------------------------------------------------------------------------------------------

create or replace TYPE        "V_SHIPPING_ADDRESS_LIST_BO" AS OBJECT (
                                    SHIP_ADDRESS_ID     NUMBER,
                                    ADDRESS_NAME        VARCHAR2(500),
                                    ADDRESS_CODE        VARCHAR2(500),
                                    ADDRESS1            VARCHAR2(500),
                                    ADDRESS2            VARCHAR2(500),
                                    CITY                VARCHAR2(500),
                                    STATE               VARCHAR2(500),
                                    ZIP                 VARCHAR2(500),
                                    COUNTRY             VARCHAR2(500),
                                    DEFAULTIND          VARCHAR2(500),
                                    CUSTID              VARCHAR2(500),
                                    ADDRESS3            VARCHAR2(500),
                                    ADDRESS4            VARCHAR2(500),
                                    PRIMARY_FLAG        VARCHAR2(10));

									
create or replace TYPE        "V_DELIVER_ADDRESS_LIST_BO" AS OBJECT (
                                    SHIP_ADDRESS_ID     NUMBER,
                                    ADDRESS_NAME        VARCHAR2(500),
                                    ADDRESS_CODE        VARCHAR2(500),
                                    ADDRESS1            VARCHAR2(500),
                                    ADDRESS2            VARCHAR2(500),
                                    CITY                VARCHAR2(500),
                                    STATE               VARCHAR2(500),
                                    ZIP                 VARCHAR2(500),
                                    COUNTRY             VARCHAR2(500),
                                    DEFAULTIND          VARCHAR2(500),
                                    CUSTID              VARCHAR2(500),
                                    ADDRESS3            VARCHAR2(500),
                                    ADDRESS4            VARCHAR2(500));
									
									
create or replace TYPE        "V_MAPPING_ADDRESS_LIST_BO" AS OBJECT (
                                    SHIP_ADDRESS_ID     NUMBER,
                                    SHIP_ADDRESS_CODE   VARCHAR2(500),
                                    SHIP_ADDRESS1       VARCHAR2(500),
                                    DEL_ADDRESS_ID      NUMBER,
                                    DEL_ADDRESS_CODE    VARCHAR2(500),
                                    DEL_ADDRESS1        VARCHAR2(500),
                                    DEFAULTIND          VARCHAR2(500),
                                    CUSTID              VARCHAR2(500));

									
create or replace TYPE        "V_CUST_GTA_LIST_BO" AS OBJECT (
                                    GTA_NUMBER            VARCHAR2(500),
                                    CUST_ACCOUNT          VARCHAR2(500),
                                    START_DATE            DATE,
                                    EXP_DATE              DATE,
                                    CONTRACT_PRODUCT      VARCHAR2(500),
                                    CUSTID                VARCHAR2(500));

									
create or replace TYPE        "V_CUST_ADMIN_LIST_BO" AS OBJECT (
                                    CUST_NAME                  VARCHAR2(500),
                                    CUST_EMAIL                 VARCHAR2(500),
                                    CUST_PHONE                 VARCHAR2(100),
                                    CUSTID                     VARCHAR2(500));

									
-----------------------------------------------------------------------------------------------------------
					

DECLARE
  P_SSO VARCHAR2(200);
  P_IACO_CODE VARCHAR2(200);
  P_CUST_ID APPS.V_CUST_ID_ARRAY;
  P_ROLE VARCHAR2(200);
  P_OU_ID VARCHAR2(200);
  P_HEADERID VARCHAR2(200);
  P_CUST_SHIP_ADD APPS.V_CUST_SHIPPING_ARRAY;
  P_CUST_DEL_ADD APPS.V_CUST_DELIVER_ARRAY;
  P_CUST_MAP_ADD APPS.V_CUST_MAPPING_ARRAY;
  P_CUST_GTA APPS.V_CUSTOMER_GTA_ARRAY;
  P_CUST_ADMIN APPS.V_CUSTOMER_ADMIN_ARRAY;
  P_MESSAGE VARCHAR2(200);
  
BEGIN
  P_SSO := NULL;
  P_IACO_CODE := NULL;
  -- Modify the code to initialize the variable
  -- P_CUST_ID := NULL;
  P_ROLE := NULL;
  P_OU_ID := NULL;
  P_HEADERID := NULL;

  GEAE_MYGE_CUST_DETAILS_PKG.GET_CUSTOMER_DETAILS(
    P_SSO => P_SSO,
    P_IACO_CODE => P_IACO_CODE,
    P_CUST_ID => P_CUST_ID,
    P_ROLE => P_ROLE,
    P_OU_ID => P_OU_ID,
    P_HEADERID => P_HEADERID,
    P_CUST_SHIP_ADD => P_CUST_SHIP_ADD,
    P_CUST_DEL_ADD => P_CUST_DEL_ADD,
    P_CUST_MAP_ADD => P_CUST_MAP_ADD,
    P_CUST_GTA => P_CUST_GTA,
    P_CUST_ADMIN => P_CUST_ADMIN,
    P_MESSAGE => P_MESSAGE
  );
  
  
	For i in 1..P_CUST_SHIP_ADD.COUNT LOOP
		DBMS_OUTPUT.PUT_LINE('P_CUST_SHIP_ADD SHIP_ADDRESS_ID= ' || P_CUST_SHIP_ADD(i).SHIP_ADDRESS_ID);
		DBMS_OUTPUT.PUT_LINE('P_CUST_SHIP_ADD ADDRESS_NAME = ' || P_CUST_SHIP_ADD(i).ADDRESS_NAME);
		DBMS_OUTPUT.PUT_LINE('P_CUST_SHIP_ADD ADDRESS_CODE= ' || P_CUST_SHIP_ADD(i).ADDRESS_CODE);
		DBMS_OUTPUT.PUT_LINE('P_CUST_SHIP_ADD ADDRESS1= ' || P_CUST_SHIP_ADD(i).ADDRESS1);
		DBMS_OUTPUT.PUT_LINE('P_CUST_SHIP_ADD ADDRESS2= ' || P_CUST_SHIP_ADD(i).ADDRESS2);
		DBMS_OUTPUT.PUT_LINE('P_CUST_SHIP_ADD CITY= ' || P_CUST_SHIP_ADD(i).CITY);
		DBMS_OUTPUT.PUT_LINE('P_CUST_SHIP_ADD STATE= ' || P_CUST_SHIP_ADD(i).STATE);
		DBMS_OUTPUT.PUT_LINE('P_CUST_SHIP_ADD ZIP= ' || P_CUST_SHIP_ADD(i).ZIP);
		DBMS_OUTPUT.PUT_LINE('P_CUST_SHIP_ADD COUNTRY= ' || P_CUST_SHIP_ADD(i).COUNTRY);
		DBMS_OUTPUT.PUT_LINE('P_CUST_SHIP_ADD DEFAULTIND= ' || P_CUST_SHIP_ADD(i).DEFAULTIND);
		DBMS_OUTPUT.PUT_LINE('P_CUST_SHIP_ADD CUSTID= ' || P_CUST_SHIP_ADD(i).CUSTID);
		DBMS_OUTPUT.PUT_LINE('P_CUST_SHIP_ADD ADDRESS3= ' || P_CUST_SHIP_ADD(i).ADDRESS3);
		DBMS_OUTPUT.PUT_LINE('P_CUST_SHIP_ADD ADDRESS4= ' || P_CUST_SHIP_ADD(i).ADDRESS4);
		DBMS_OUTPUT.PUT_LINE('P_CUST_SHIP_ADD PRIMARY_FLAG= ' || P_CUST_SHIP_ADD(i).PRIMARY_FLAG);
	END LOOP;

	For i in 1..P_CUST_DEL_ADD.COUNT LOOP
		DBMS_OUTPUT.PUT_LINE('P_CUST_DEL_ADD SHIP_ADDRESS_ID= ' || P_CUST_DEL_ADD(i).SHIP_ADDRESS_ID);
		DBMS_OUTPUT.PUT_LINE('P_CUST_DEL_ADD ADDRESS_NAME = ' || P_CUST_DEL_ADD(i).ADDRESS_NAME);
		DBMS_OUTPUT.PUT_LINE('P_CUST_DEL_ADD ADDRESS_CODE= ' || P_CUST_DEL_ADD(i).ADDRESS_CODE);
		DBMS_OUTPUT.PUT_LINE('P_CUST_DEL_ADD ADDRESS1= ' || P_CUST_DEL_ADD(i).ADDRESS1);
		DBMS_OUTPUT.PUT_LINE('P_CUST_DEL_ADD ADDRESS2= ' || P_CUST_DEL_ADD(i).ADDRESS2);
		DBMS_OUTPUT.PUT_LINE('P_CUST_DEL_ADD CITY= ' || P_CUST_DEL_ADD(i).CITY);
		DBMS_OUTPUT.PUT_LINE('P_CUST_DEL_ADD STATE= ' || P_CUST_DEL_ADD(i).STATE);
		DBMS_OUTPUT.PUT_LINE('P_CUST_DEL_ADD ZIP= ' || P_CUST_DEL_ADD(i).ZIP);
		DBMS_OUTPUT.PUT_LINE('P_CUST_DEL_ADD COUNTRY= ' || P_CUST_DEL_ADD(i).COUNTRY);
		DBMS_OUTPUT.PUT_LINE('P_CUST_DEL_ADD DEFAULTIND= ' || P_CUST_DEL_ADD(i).DEFAULTIND);
		DBMS_OUTPUT.PUT_LINE('P_CUST_DEL_ADD CUSTID= ' || P_CUST_DEL_ADD(i).CUSTID);
		DBMS_OUTPUT.PUT_LINE('P_CUST_DEL_ADD ADDRESS3= ' || P_CUST_DEL_ADD(i).ADDRESS3);
		DBMS_OUTPUT.PUT_LINE('P_CUST_DEL_ADD ADDRESS4= ' || P_CUST_DEL_ADD(i).ADDRESS4);=
	END LOOP;

	For i in 1..P_CUST_MAP_ADD.COUNT LOOP
		DBMS_OUTPUT.PUT_LINE('P_CUST_MAP_ADD SHIP_ADDRESS_ID= ' || P_CUST_MAP_ADD(i).SHIP_ADDRESS_ID);
		DBMS_OUTPUT.PUT_LINE('P_CUST_MAP_ADD SHIP_ADDRESS_CODE = ' || P_CUST_MAP_ADD(i).SHIP_ADDRESS_CODE);
		DBMS_OUTPUT.PUT_LINE('P_CUST_MAP_ADD SHIP_ADDRESS1= ' || P_CUST_MAP_ADD(i).SHIP_ADDRESS1);
		DBMS_OUTPUT.PUT_LINE('P_CUST_MAP_ADD DEL_ADDRESS_ID= ' || P_CUST_MAP_ADD(i).DEL_ADDRESS_ID);
		DBMS_OUTPUT.PUT_LINE('P_CUST_MAP_ADD DEL_ADDRESS_CODE= ' || P_CUST_MAP_ADD(i).DEL_ADDRESS_CODE);
		DBMS_OUTPUT.PUT_LINE('P_CUST_MAP_ADD DEL_ADDRESS1= ' || P_CUST_MAP_ADD(i).DEL_ADDRESS1);
		DBMS_OUTPUT.PUT_LINE('P_CUST_MAP_ADD DEFAULTIND= ' || P_CUST_MAP_ADD(i).DEFAULTIND);
		DBMS_OUTPUT.PUT_LINE('P_CUST_MAP_ADD CUSTID= ' || P_CUST_MAP_ADD(i).CUSTID);
	END LOOP;


	For i in 1..P_CUST_GTA.COUNT LOOP
		DBMS_OUTPUT.PUT_LINE('P_CUST_GTA GTA_NUMBER= ' || P_CUST_GTA(i).GTA_NUMBER);
		DBMS_OUTPUT.PUT_LINE('P_CUST_GTA CUST_ACCOUNT = ' || P_CUST_GTA(i).CUST_ACCOUNT);
		DBMS_OUTPUT.PUT_LINE('P_CUST_GTA START_DATE= ' || P_CUST_GTA(i).START_DATE);
		DBMS_OUTPUT.PUT_LINE('P_CUST_GTA EXP_DATE= ' || P_CUST_GTA(i).EXP_DATE);
		DBMS_OUTPUT.PUT_LINE('P_CUST_GTA CONTRACT_PRODUCT= ' || P_CUST_GTA(i).CONTRACT_PRODUCT);
		DBMS_OUTPUT.PUT_LINE('P_CUST_GTA CUSTID= ' || P_CUST_GTA(i).CUSTID);
	END LOOP;
	
	For i in 1..P_CUST_ADMIN.COUNT LOOP
		DBMS_OUTPUT.PUT_LINE('P_CUST_ADMIN CUST_NAME= ' || P_CUST_ADMIN(i).CUST_NAME);
		DBMS_OUTPUT.PUT_LINE('P_CUST_ADMIN CUST_EMAIL = ' || P_CUST_ADMIN(i).CUST_EMAIL);
		DBMS_OUTPUT.PUT_LINE('P_CUST_ADMIN CUST_PHONE= ' || P_CUST_ADMIN(i).CUST_PHONE);
		DBMS_OUTPUT.PUT_LINE('P_CUST_ADMIN CUSTID= ' || P_CUST_ADMIN(i).CUSTID);
	END LOOP;
	
	DBMS_OUTPUT.PUT_LINE('P_MSG = ' || P_MSG);

END;


--------------------------------------------------------------------------------------------------------------------------------

