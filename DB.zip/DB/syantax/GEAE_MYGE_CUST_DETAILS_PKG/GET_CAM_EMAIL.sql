

-------------------------------------------------------------------------GET_CAM_EMAIL-------------------------------------------------------


DECLARE
  P_SSO VARCHAR2(200);
  P_IACO_CODE VARCHAR2(200);
  P_CUST_ID APPS.V_CUST_ID_ARRAY;
  P_ROLE VARCHAR2(200);
  P_OU_ID VARCHAR2(200);
  P_CAM_EMAIL_ADD VARCHAR2(200);
BEGIN
  P_SSO := NULL;
  P_IACO_CODE := NULL;
  -- Modify the code to initialize the variable
  -- P_CUST_ID := NULL;
  P_ROLE := NULL;
  P_OU_ID := NULL;

  GEAE_MYGE_CUST_DETAILS_PKG.GET_CAM_EMAIL(
    P_SSO => P_SSO,
    P_IACO_CODE => P_IACO_CODE,
    P_CUST_ID => P_CUST_ID,
    P_ROLE => P_ROLE,
    P_OU_ID => P_OU_ID,
    P_CAM_EMAIL_ADD => P_CAM_EMAIL_ADD
  );
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_CAM_EMAIL_ADD = ' || P_CAM_EMAIL_ADD);
*/ 
  :P_CAM_EMAIL_ADD := P_CAM_EMAIL_ADD;
--rollback; 
END;
