

-------------------------------------------------------------------------GET_GLOBAL_CUST_DETAILS-------------------------------------------------------


DECLARE
  P_SSO VARCHAR2(200);
  P_OU_ID VARCHAR2(200);
  P_IACO_CODE VARCHAR2(200);
  P_ROLE VARCHAR2(200);
  P_CUST_DETAIL_LIST APPS.V_CUST_LIST_ARRAY;
  P_MESSAGE VARCHAR2(200);
BEGIN
  P_SSO := NULL;
  P_OU_ID := NULL;
  P_IACO_CODE := NULL;
  P_ROLE := NULL;

  GEAE_MYGE_CUST_DETAILS_PKG.GET_GLOBAL_CUST_DETAILS(
    P_SSO => P_SSO,
    P_OU_ID => P_OU_ID,
    P_IACO_CODE => P_IACO_CODE,
    P_ROLE => P_ROLE,
    P_CUST_DETAIL_LIST => P_CUST_DETAIL_LIST,
    P_MESSAGE => P_MESSAGE
  );
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_CUST_DETAIL_LIST = ' || P_CUST_DETAIL_LIST);
*/ 
  --:P_CUST_DETAIL_LIST := P_CUST_DETAIL_LIST;
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_MESSAGE = ' || P_MESSAGE);
*/ 
  :P_MESSAGE := P_MESSAGE;
--rollback; 
END;

-----------------------------------------------------------------------------------------------------------

create or replace TYPE        "V_CUST_LIST_ARRAY" AS VARRAY(2000) OF V_GLOBAL_ENQ_CUST_LIST_BO

-----------------------------------------------------------------------------------------------------------

create or replace TYPE        "V_GLOBAL_ENQ_CUST_LIST_BO" AS OBJECT (
                                                                           PARTY_NAME     VARCHAR2(300),
                                                                           ACCOUNT_NUMBER VARCHAR2(30)
                                                                           );
																		   
-----------------------------------------------------------------------------------------------------------
							   
DECLARE
  P_SSO VARCHAR2(200);
  P_OU_ID VARCHAR2(200);
  P_IACO_CODE VARCHAR2(200);
  P_ROLE VARCHAR2(200);
  P_CUST_DETAIL_LIST APPS.V_CUST_LIST_ARRAY;
  P_MESSAGE VARCHAR2(200);
BEGIN
  P_SSO := NULL;
  P_OU_ID := NULL;
  P_IACO_CODE := NULL;
  P_ROLE := NULL;

  GEAE_MYGE_CUST_DETAILS_PKG.GET_GLOBAL_CUST_DETAILS(
    P_SSO => P_SSO,
    P_OU_ID => P_OU_ID,
    P_IACO_CODE => P_IACO_CODE,
    P_ROLE => P_ROLE,
    P_CUST_DETAIL_LIST => P_CUST_DETAIL_LIST,
    P_MESSAGE => P_MESSAGE
  );

   For i in 1..P_CUST_DETAIL_LIST.COUNT LOOP
		DBMS_OUTPUT.PUT_LINE('P_CUST_DETAIL_LIST PARTY_NAME= ' || P_CUST_DETAIL_LIST(i).PARTY_NAME);
		DBMS_OUTPUT.PUT_LINE('P_CUST_DETAIL_LIST ACCOUNT_NUMBER = ' || P_CUST_DETAIL_LIST(i).ACCOUNT_NUMBER);
	END LOOP;
	
	DBMS_OUTPUT.PUT_LINE('P_MSG = ' || P_MSG);
  
END;