

-------------------------------------------------------------------------GET_ORDER_DETAILS-------------------------------------------------------


DECLARE
  P_SSO VARCHAR2(200);
  P_IACO_CODE VARCHAR2(200);
  P_CUST_ID VARCHAR2(200);
  P_ROLE VARCHAR2(200);
  P_OU_ID VARCHAR2(200);
  P_HEADERID VARCHAR2(200);
  P_OUT_ODR_HDR APPS.V_ORDER_HDR_ARRAY;
  P_MESSAGE VARCHAR2(200);
BEGIN
  P_SSO := NULL;
  P_IACO_CODE := NULL;
  P_CUST_ID := NULL;
  P_ROLE := NULL;
  P_OU_ID := NULL;
  P_HEADERID := NULL;

  GEAE_MYGE_ORDER_DETAILS_PKG.GET_ORDER_DETAILS(
    P_SSO => P_SSO,
    P_IACO_CODE => P_IACO_CODE,
    P_CUST_ID => P_CUST_ID,
    P_ROLE => P_ROLE,
    P_OU_ID => P_OU_ID,
    P_HEADERID => P_HEADERID,
    P_OUT_ODR_HDR => P_OUT_ODR_HDR,
    P_MESSAGE => P_MESSAGE
  );
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_OUT_ODR_HDR = ' || P_OUT_ODR_HDR);
*/ 
  --:P_OUT_ODR_HDR := P_OUT_ODR_HDR;
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_MESSAGE = ' || P_MESSAGE);
*/ 
  :P_MESSAGE := P_MESSAGE;
--rollback; 
END;


-----------------------------------------------------------------------------------------------

create or replace TYPE        "V_ORDER_HDR_ARRAY" AS VARRAY(250) OF V_ORDER_HDR_DETAILS;


-----------------------------------------------------------------------------------------------

create or replace TYPE        "V_ORDER_HDR_DETAILS" AS OBJECT (
    ORDER_NUMBER            VARCHAR2(500),
    ORDER_DATE              DATE,
    ORDER_STATUS            VARCHAR2(500),
    CUST_CODE               varchar2(500),
    CUST_NAME               varchar2(500),
    CUST_ID                 varchar2(500)
    );


-----------------------------------------------------------------------------------------------

DECLARE
  P_SSO VARCHAR2(200);
  P_IACO_CODE VARCHAR2(200);
  P_CUST_ID VARCHAR2(200);
  P_ROLE VARCHAR2(200);
  P_OU_ID VARCHAR2(200);
  P_HEADERID VARCHAR2(200);
  P_OUT_ODR_HDR APPS.V_ORDER_HDR_ARRAY;
  P_MESSAGE VARCHAR2(200);
BEGIN
  P_SSO := NULL;
  P_IACO_CODE := NULL;
  P_CUST_ID := NULL;
  P_ROLE := NULL;
  P_OU_ID := NULL;
  P_HEADERID := NULL;

  GEAE_MYGE_ORDER_DETAILS_PKG.GET_ORDER_DETAILS(
    P_SSO => P_SSO,
    P_IACO_CODE => P_IACO_CODE,
    P_CUST_ID => P_CUST_ID,
    P_ROLE => P_ROLE,
    P_OU_ID => P_OU_ID,
    P_HEADERID => P_HEADERID,
    P_OUT_ODR_HDR => P_OUT_ODR_HDR,
    P_MESSAGE => P_MESSAGE
  );

  For i in 1..P_OUT_ODR_HDR.COUNT LOOP
		DBMS_OUTPUT.PUT_LINE('P_OUT_ODR_HDR ORDER_NUMBER= ' || P_OUT_ODR_HDR(i).ORDER_NUMBER);
		DBMS_OUTPUT.PUT_LINE('P_OUT_ODR_HDR ORDER_DATE = ' || P_OUT_ODR_HDR(i).ORDER_DATE);
		DBMS_OUTPUT.PUT_LINE('P_OUT_ODR_HDR ORDER_STATUS= ' || P_OUT_ODR_HDR(i).ORDER_STATUS);
		DBMS_OUTPUT.PUT_LINE('P_OUT_ODR_HDR CUST_CODE= ' || P_OUT_ODR_HDR(i).CUST_CODE);
		DBMS_OUTPUT.PUT_LINE('P_OUT_ODR_HDR CUST_NAME= ' || P_OUT_ODR_HDR(i).CUST_NAME);
		DBMS_OUTPUT.PUT_LINE('P_OUT_ODR_HDR CUST_ID= ' || P_OUT_ODR_HDR(i).CUST_ID);
	END LOOP;
	
	DBMS_OUTPUT.PUT_LINE('P_MSG = ' || P_MSG);
  
END;


-----------------------------------------------------------------------------------------------

