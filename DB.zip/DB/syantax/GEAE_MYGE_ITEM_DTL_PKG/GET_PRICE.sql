

-------------------------------------------------------------------------GET_PRICE-------------------------------------------------------


DECLARE
  P_SSO VARCHAR2(200);
  P_OU_ID VARCHAR2(200);
  P_INVENTORY_ITEM_ID NUMBER;
  P_PRICE_LIST_ID NUMBER;
  P_UNIT_PRICE NUMBER;
  P_LIST_LINE_ID NUMBER;
BEGIN
  P_SSO := NULL;
  P_OU_ID := NULL;
  P_INVENTORY_ITEM_ID := NULL;
  P_PRICE_LIST_ID := NULL;

  GEAE_MYGE_ITEM_DTL_PKG.GET_PRICE(
    P_SSO => P_SSO,
    P_OU_ID => P_OU_ID,
    P_INVENTORY_ITEM_ID => P_INVENTORY_ITEM_ID,
    P_PRICE_LIST_ID => P_PRICE_LIST_ID,
    P_UNIT_PRICE => P_UNIT_PRICE,
    P_LIST_LINE_ID => P_LIST_LINE_ID
  );
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_UNIT_PRICE = ' || P_UNIT_PRICE);
*/ 
  :P_UNIT_PRICE := P_UNIT_PRICE;
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_LIST_LINE_ID = ' || P_LIST_LINE_ID);
*/ 
  :P_LIST_LINE_ID := P_LIST_LINE_ID;
--rollback; 
END;
