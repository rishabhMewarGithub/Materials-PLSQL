



-------------------------------------------------------------------------ITEM_DTL_PART_NUM_BULK-------------------------------------------------------


DECLARE
  P_SSO VARCHAR2(200);
  P_IACO_CODE VARCHAR2(200);
  P_CUST_ID APPS.V_CUST_ID_ARRAY;
  P_ROLE VARCHAR2(200);
  P_OU_ID VARCHAR2(200);
  P_PART_NUM APPS.V_PART_NUM_LIST_ARRAY;
  P_BULK_PART_DETAILS APPS.V_BULK_PART_DETAILS;
  P_MESSAGE VARCHAR2(200);
  
BEGIN
  P_SSO := NULL;
  P_IACO_CODE := NULL;
  -- Modify the code to initialize the variable
  -- P_CUST_ID := NULL;
  P_ROLE := NULL;
  P_OU_ID := NULL;
  -- Modify the code to initialize the variable
  -- P_PART_NUM := NULL;

  GEAE_MYGE_ITEM_DTL_PKG.ITEM_DTL_PART_NUM_BULK(
    P_SSO => P_SSO,
    P_IACO_CODE => P_IACO_CODE,
    P_CUST_ID => P_CUST_ID,
    P_ROLE => P_ROLE,
    P_OU_ID => P_OU_ID,
    P_PART_NUM => P_PART_NUM,
    P_BULK_PART_DETAILS => P_BULK_PART_DETAILS,
    P_MESSAGE => P_MESSAGE
  );
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_BULK_PART_DETAILS = ' || P_BULK_PART_DETAILS);
*/ 
  --:P_BULK_PART_DETAILS := P_BULK_PART_DETAILS;
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_MESSAGE = ' || P_MESSAGE);
*/ 
  :P_MESSAGE := P_MESSAGE;
--rollback; 
END;


create or replace TYPE        "V_PART_NUM_LIST_ARRAY" IS VARRAY(2250) OF VARCHAR2(40)

create or replace TYPE        "V_BULK_PART_DETAILS" AS VARRAY(2000) OF V_BULK_PART_DETAILS_LIST_BO


create or replace TYPE        "V_BULK_PART_DETAILS_LIST_BO" AS OBJECT (INVENTORY_ITEM_ID   VARCHAR2(1000),
                                                                      PART_NUMBER         VARCHAR2(1000),
                                                                      PART_DESCRIPTION    VARCHAR2(1000),
                                                                      QUANTITY            VARCHAR2(1000),
                                                                      UNIT_PRICE          VARCHAR2(1000),
                                                                      UPQ                 VARCHAR2(1000),
                                                                      LEAD_TIME           VARCHAR2(1000),
                                                                      DISC_PERCENT        NUMBER,
                                                                    --  DISC_PRICE          NUMBER,
                                                                      DISPLAY_MESSAGE     VARCHAR2(1000),
                                                                      AVAIL_MESSAGE       VARCHAR2(1000),
                                                                      PRICE_MESSAGE       VARCHAR2(1000),
                                                                      DISC_MESSAGE        VARCHAR2(1000),
                                                                      CRITICAL_PART       VARCHAR2(1000));
																	  
																	  
																	  
DECLARE
  P_SSO VARCHAR2(200);
  P_IACO_CODE VARCHAR2(200);
  P_CUST_ID APPS.V_CUST_ID_ARRAY;
  P_ROLE VARCHAR2(200);
  P_OU_ID VARCHAR2(200);
  P_PART_NUM APPS.V_PART_NUM_LIST_ARRAY;
  P_BULK_PART_DETAILS APPS.V_BULK_PART_DETAILS;
  P_MESSAGE VARCHAR2(200);
  
BEGIN
  P_SSO := NULL;
  P_IACO_CODE := NULL;
  -- Modify the code to initialize the variable
  -- P_CUST_ID := NULL;
  P_ROLE := NULL;
  P_OU_ID := NULL;
  -- Modify the code to initialize the variable
  -- P_PART_NUM := NULL;

  GEAE_MYGE_ITEM_DTL_PKG.ITEM_DTL_PART_NUM_BULK(
    P_SSO => P_SSO,
    P_IACO_CODE => P_IACO_CODE,
    P_CUST_ID => P_CUST_ID,
    P_ROLE => P_ROLE,
    P_OU_ID => P_OU_ID,
    P_PART_NUM => P_PART_NUM,
    P_BULK_PART_DETAILS => P_BULK_PART_DETAILS,
    P_MESSAGE => P_MESSAGE
  );
  
	For i in 1..P_BULK_PART_DETAILS.COUNT LOOP
		DBMS_OUTPUT.PUT_LINE('P_BULK_PART_DETAILS INVENTORY_ITEM_ID= ' || P_BULK_PART_DETAILS(i).INVENTORY_ITEM_ID);
		DBMS_OUTPUT.PUT_LINE('P_BULK_PART_DETAILS PART_NUMBER = ' || P_BULK_PART_DETAILS(i).PART_NUMBER);
		DBMS_OUTPUT.PUT_LINE('P_BULK_PART_DETAILS PART_DESCRIPTION= ' || P_BULK_PART_DETAILS(i).PART_DESCRIPTION);
		DBMS_OUTPUT.PUT_LINE('P_BULK_PART_DETAILS QUANTITY= ' || P_BULK_PART_DETAILS(i).QUANTITY);
		DBMS_OUTPUT.PUT_LINE('P_BULK_PART_DETAILS UNIT_PRICE= ' || P_BULK_PART_DETAILS(i).UNIT_PRICE);
		DBMS_OUTPUT.PUT_LINE('P_BULK_PART_DETAILS UPQ= ' || P_BULK_PART_DETAILS(i).UPQ);
		DBMS_OUTPUT.PUT_LINE('P_BULK_PART_DETAILS LEAD_TIME = ' || P_BULK_PART_DETAILS(i).LEAD_TIME);
		DBMS_OUTPUT.PUT_LINE('P_BULK_PART_DETAILS DISC_PERCENT= ' || P_BULK_PART_DETAILS(i).DISC_PERCENT);
		DBMS_OUTPUT.PUT_LINE('P_BULK_PART_DETAILS DISPLAY_MESSAGE= ' || P_BULK_PART_DETAILS(i).DISPLAY_MESSAGE);
		DBMS_OUTPUT.PUT_LINE('P_BULK_PART_DETAILS AVAIL_MESSAGE= ' || P_BULK_PART_DETAILS(i).AVAIL_MESSAGE);
		DBMS_OUTPUT.PUT_LINE('P_BULK_PART_DETAILS PRICE_MESSAGE= ' || P_BULK_PART_DETAILS(i).PRICE_MESSAGE);
		DBMS_OUTPUT.PUT_LINE('P_BULK_PART_DETAILS DISC_MESSAGE = ' || P_BULK_PART_DETAILS(i).DISC_MESSAGE);
		DBMS_OUTPUT.PUT_LINE('P_BULK_PART_DETAILS CRITICAL_PART= ' || P_BULK_PART_DETAILS(i).CRITICAL_PART);
	END LOOP;
	
  DBMS_OUTPUT.PUT_LINE('P_MESSAGE = ' || P_MESSAGE);
  
END;

