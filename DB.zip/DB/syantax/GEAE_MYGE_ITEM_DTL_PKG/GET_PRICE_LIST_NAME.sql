

-------------------------------------------------------------------------GET_PRICE_LIST_NAME-------------------------------------------------------


DECLARE
  P_PRICE_LIST_ID NUMBER;
  v_Return VARCHAR2(200);
BEGIN
  P_PRICE_LIST_ID := NULL;

  v_Return := GEAE_MYGE_ITEM_DTL_PKG.GET_PRICE_LIST_NAME(
    P_PRICE_LIST_ID => P_PRICE_LIST_ID
  );
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('v_Return = ' || v_Return);
*/ 
  :v_Return := v_Return;
--rollback; 
END;

