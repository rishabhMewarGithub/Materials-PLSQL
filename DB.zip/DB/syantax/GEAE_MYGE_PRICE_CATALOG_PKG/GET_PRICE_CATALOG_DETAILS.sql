

-------------------------------------------------------------------------GET_PRICE_CATALOG_DETAILS-------------------------------------------------------


DECLARE
  P_SSO VARCHAR2(200);
  P_IACO_CODE VARCHAR2(200);
  P_CUST_ID APPS.V_CUST_ID_ARRAY;
  P_ROLE VARCHAR2(200);
  P_OU_ID VARCHAR2(200);
  P_PRICE_CATALOG APPS.V_PRICING_CATALOG_ARRAY;
  P_MESSAGE VARCHAR2(200);
  
BEGIN
  P_SSO := NULL;
  P_IACO_CODE := NULL;
  -- Modify the code to initialize the variable
  -- P_CUST_ID := NULL;
  P_ROLE := NULL;
  P_OU_ID := NULL;

  GEAE_MYGE_PRICE_CATALOG_PKG.GET_PRICE_CATALOG_DETAILS(
    P_SSO => P_SSO,
    P_IACO_CODE => P_IACO_CODE,
    P_CUST_ID => P_CUST_ID,
    P_ROLE => P_ROLE,
    P_OU_ID => P_OU_ID,
    P_PRICE_CATALOG => P_PRICE_CATALOG,
    P_MESSAGE => P_MESSAGE
  );
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_PRICE_CATALOG = ' || P_PRICE_CATALOG);
*/ 
  --:P_PRICE_CATALOG := P_PRICE_CATALOG;
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_MESSAGE = ' || P_MESSAGE);
*/ 
  :P_MESSAGE := P_MESSAGE;
--rollback; 
END;

--------------------------------------------------------------------------------------------------------------------------------

create or replace TYPE        "V_PRICING_CATALOG_ARRAY" AS VARRAY(2250) OF V_PRICING_CATALOG;

--------------------------------------------------------------------------------------------------------------------------------


create or replace TYPE        "V_PRICING_CATALOG" AS OBJECT (
        PLATFORM VARCHAR2(1000)
        );

--------------------------------------------------------------------------------------------------------------------------------
		
DECLARE
  P_SSO VARCHAR2(200);
  P_IACO_CODE VARCHAR2(200);
  P_CUST_ID APPS.V_CUST_ID_ARRAY;
  P_ROLE VARCHAR2(200);
  P_OU_ID VARCHAR2(200);
  P_PRICE_CATALOG APPS.V_PRICING_CATALOG_ARRAY;
  P_MESSAGE VARCHAR2(200);
BEGIN
  P_SSO := NULL;
  P_IACO_CODE := NULL;
  -- Modify the code to initialize the variable
  -- P_CUST_ID := NULL;
  P_ROLE := NULL;
  P_OU_ID := NULL;

  GEAE_MYGE_PRICE_CATALOG_PKG.GET_PRICE_CATALOG_DETAILS(
    P_SSO => P_SSO,
    P_IACO_CODE => P_IACO_CODE,
    P_CUST_ID => P_CUST_ID,
    P_ROLE => P_ROLE,
    P_OU_ID => P_OU_ID,
    P_PRICE_CATALOG => P_PRICE_CATALOG,
    P_MESSAGE => P_MESSAGE
  );

	For i in 1..P_PRICE_CATALOG.COUNT LOOP
		DBMS_OUTPUT.PUT_LINE('P_PRICE_CATALOG PLATFORM= ' || P_PRICE_CATALOG(i).PLATFORM);
	END LOOP;
	
	DBMS_OUTPUT.PUT_LINE('P_MSG = ' || P_MSG);
  
END;

