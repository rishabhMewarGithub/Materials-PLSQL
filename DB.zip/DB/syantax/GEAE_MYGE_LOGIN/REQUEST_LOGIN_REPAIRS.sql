

-------------------------------------------------------------------------REQUEST_LOGIN_REPAIRS-------------------------------------------------------


DECLARE
  P_OPERATING_UNIT_ID VARCHAR2(200);
  P_ICAO_CODE VARCHAR2(200);
  P_USER_NAME VARCHAR2(200);
  P_IMPERSONATION_FLAG VARCHAR2(200);
  P_ROLES VARCHAR2(200);
  P_CUST_ARRAY APPS.V_CUST_ARRAY;
  P_MESSAGE VARCHAR2(200);
  
BEGIN
  P_OPERATING_UNIT_ID := NULL;
  P_ICAO_CODE := NULL;
  P_USER_NAME := NULL;
  P_IMPERSONATION_FLAG := NULL;

  GEAE_MYGE_LOGIN.REQUEST_LOGIN_REPAIRS(
    P_OPERATING_UNIT_ID => P_OPERATING_UNIT_ID,
    P_ICAO_CODE => P_ICAO_CODE,
    P_USER_NAME => P_USER_NAME,
    P_IMPERSONATION_FLAG => P_IMPERSONATION_FLAG,
    P_ROLES => P_ROLES,
    P_CUST_ARRAY => P_CUST_ARRAY,
    P_MESSAGE => P_MESSAGE
  );
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_ROLES = ' || P_ROLES);
*/ 
  :P_ROLES := P_ROLES;
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_CUST_ARRAY = ' || P_CUST_ARRAY);
*/ 
  --:P_CUST_ARRAY := P_CUST_ARRAY;
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_MESSAGE = ' || P_MESSAGE);
*/ 
  :P_MESSAGE := P_MESSAGE;
--rollback; 
END;


-----------------------------------------------------------------------------------------------

create or replace TYPE        "V_CUST_ARRAY" AS VARRAY(250) OF v_Cust_Entry;

-----------------------------------------------------------------------------------------------

create or replace TYPE        "V_CUST_ENTRY" AS OBJECT (
															cust_id             number,
															cust_account_number varchar2(500),
															party_name          varchar2(500)
														);
														
-----------------------------------------------------------------------------------------------


DECLARE
  P_OPERATING_UNIT_ID VARCHAR2(200);
  P_ICAO_CODE VARCHAR2(200);
  P_USER_NAME VARCHAR2(200);
  P_IMPERSONATION_FLAG VARCHAR2(200);
  P_ROLES VARCHAR2(200);
  P_CUST_ARRAY APPS.V_CUST_ARRAY;
  P_MESSAGE VARCHAR2(200);
  
BEGIN
  P_OPERATING_UNIT_ID := NULL;
  P_ICAO_CODE := NULL;
  P_USER_NAME := NULL;
  P_IMPERSONATION_FLAG := NULL;

  GEAE_MYGE_LOGIN.REQUEST_LOGIN(
    P_OPERATING_UNIT_ID => P_OPERATING_UNIT_ID,
    P_ICAO_CODE => P_ICAO_CODE,
    P_USER_NAME => P_USER_NAME,
    P_IMPERSONATION_FLAG => P_IMPERSONATION_FLAG,
    P_ROLES => P_ROLES,
    P_CUST_ARRAY => P_CUST_ARRAY,
    P_MESSAGE => P_MESSAGE
  );
  
	For i in 1..P_CUST_ARRAY.COUNT LOOP
		DBMS_OUTPUT.PUT_LINE('P_CUST_ARRAY cust_id= ' || P_CUST_ARRAY(i).cust_id);
		DBMS_OUTPUT.PUT_LINE('P_CUST_ARRAY cust_account_number = ' || P_CUST_ARRAY(i).cust_account_number);
		DBMS_OUTPUT.PUT_LINE('P_CUST_ARRAY party_name= ' || P_CUST_ARRAY(i).party_name);
	END LOOP;

	DBMS_OUTPUT.PUT_LINE('P_MSG = ' || P_MSG);

END;
