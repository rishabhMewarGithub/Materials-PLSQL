
-------------------------------------------------------------------------CHECK_LOGIN-------------------------------------------------------


DECLARE
  P_OPERATING_UNIT_ID VARCHAR2(200);
  P_ICAO_CODE VARCHAR2(200);
  P_USER_ID VARCHAR2(200);
  P_OU_ID VARCHAR2(200);
  P_MESSAGE VARCHAR2(200);
BEGIN
  P_OPERATING_UNIT_ID := NULL;
  P_ICAO_CODE := NULL;
  P_USER_ID := NULL;

  GEAE_MYGE_LOGIN.CHECK_LOGIN(
    P_OPERATING_UNIT_ID => P_OPERATING_UNIT_ID,
    P_ICAO_CODE => P_ICAO_CODE,
    P_USER_ID => P_USER_ID,
    P_OU_ID => P_OU_ID,
    P_MESSAGE => P_MESSAGE
  );
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_OU_ID = ' || P_OU_ID);
*/ 
  :P_OU_ID := P_OU_ID;
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_MESSAGE = ' || P_MESSAGE);
*/ 
  :P_MESSAGE := P_MESSAGE;
--rollback; 
END;
