

-------------------------------------------------------------------------GET_SEGMENTED_DFF_VALUE-------------------------------------------------------


DECLARE
  P_ENTITY_NAME VARCHAR2(200);
  P_FIELD_NAME VARCHAR2(200);
  P_ATTR_VALUE VARCHAR2(200);
  v_Return VARCHAR2(200);
BEGIN
  P_ENTITY_NAME := NULL;
  P_FIELD_NAME := NULL;
  P_ATTR_VALUE := NULL;

  v_Return := GEAE_MYGE_ITEM_CONFIG_PKG.GET_SEGMENTED_DFF_VALUE(
    P_ENTITY_NAME => P_ENTITY_NAME,
    P_FIELD_NAME => P_FIELD_NAME,
    P_ATTR_VALUE => P_ATTR_VALUE
  );
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('v_Return = ' || v_Return);
*/ 
  :v_Return := v_Return;
--rollback; 
END;
