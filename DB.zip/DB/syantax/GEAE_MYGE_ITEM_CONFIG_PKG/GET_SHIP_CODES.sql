

-------------------------------------------------------------------------GET_SHIP_CODES-------------------------------------------------------


DECLARE
  P_INVENTORY_ITEM_ID NUMBER;
  P_ENGINE_MODEL VARCHAR2(200);
  P_BILL_SEQUENCE_ID NUMBER;
  P_BUSINESS_ENTITY VARCHAR2(200);
  P_ORGANIZATION_ID NUMBER;
  P_ORG_ID NUMBER;
  v_Return VARCHAR2(200);
BEGIN
  P_INVENTORY_ITEM_ID := NULL;
  P_ENGINE_MODEL := NULL;
  P_BILL_SEQUENCE_ID := NULL;
  P_BUSINESS_ENTITY := NULL;
  P_ORGANIZATION_ID := NULL;
  P_ORG_ID := NULL;

  v_Return := GEAE_MYGE_ITEM_CONFIG_PKG.GET_SHIP_CODES(
    P_INVENTORY_ITEM_ID => P_INVENTORY_ITEM_ID,
    P_ENGINE_MODEL => P_ENGINE_MODEL,
    P_BILL_SEQUENCE_ID => P_BILL_SEQUENCE_ID,
    P_BUSINESS_ENTITY => P_BUSINESS_ENTITY,
    P_ORGANIZATION_ID => P_ORGANIZATION_ID,
    P_ORG_ID => P_ORG_ID
  );
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('v_Return = ' || v_Return);
*/ 
  :v_Return := v_Return;
--rollback; 
END;
