

-------------------------------------------------------------------------GET_UPQ_PRICE-------------------------------------------------------


DECLARE
  P_ORDERED_ITEM_ID NUMBER;
  P_PRICING_DATE DATE;
  P_PRICE_LIST_ID NUMBER;
  P_LIST_PRICE VARCHAR2(200);
  v_Return VARCHAR2(200);
BEGIN
  P_ORDERED_ITEM_ID := NULL;
  P_PRICING_DATE := NULL;
  P_PRICE_LIST_ID := NULL;

  v_Return := GEAE_MYGE_ITEM_CONFIG_PKG.GET_UPQ_PRICE(
    P_ORDERED_ITEM_ID => P_ORDERED_ITEM_ID,
    P_PRICING_DATE => P_PRICING_DATE,
    P_PRICE_LIST_ID => P_PRICE_LIST_ID,
    P_LIST_PRICE => P_LIST_PRICE
  );
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('v_Return = ' || v_Return);
*/ 
  :v_Return := v_Return;
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_LIST_PRICE = ' || P_LIST_PRICE);
*/ 
  :P_LIST_PRICE := P_LIST_PRICE;
--rollback; 
END;
