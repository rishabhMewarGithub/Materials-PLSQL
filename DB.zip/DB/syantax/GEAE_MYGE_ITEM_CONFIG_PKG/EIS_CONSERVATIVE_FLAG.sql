


-------------------------------------------------------------------------EIS_CONSERVATIVE_FLAG-------------------------------------------------------



DECLARE
  P_ITEM_NUMBER VARCHAR2(200);
  P_ENGINE_MODEL VARCHAR2(200);
  P_BUSINESS_ENTITY VARCHAR2(200);
  P_EIS_DATA_STREAM VARCHAR2(200);
  v_Return VARCHAR2(200);
BEGIN
  P_ITEM_NUMBER := NULL;
  P_ENGINE_MODEL := NULL;
  P_BUSINESS_ENTITY := NULL;
  P_EIS_DATA_STREAM := NULL;

  v_Return := GEAE_MYGE_ITEM_CONFIG_PKG.EIS_CONSERVATIVE_FLAG(
    P_ITEM_NUMBER => P_ITEM_NUMBER,
    P_ENGINE_MODEL => P_ENGINE_MODEL,
    P_BUSINESS_ENTITY => P_BUSINESS_ENTITY,
    P_EIS_DATA_STREAM => P_EIS_DATA_STREAM
  );
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('v_Return = ' || v_Return);
*/ 
  :v_Return := v_Return;
--rollback; 
END;
