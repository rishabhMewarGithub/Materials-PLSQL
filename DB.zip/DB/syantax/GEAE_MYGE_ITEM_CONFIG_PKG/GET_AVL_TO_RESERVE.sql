
-------------------------------------------------------------------------GET_AVL_TO_RESERVE-------------------------------------------------------


DECLARE
  P_ORGANIZATION_ID NUMBER;
  P_INVENTORY_ITEM_ID NUMBER;
  v_Return NUMBER;
BEGIN
  P_ORGANIZATION_ID := NULL;
  P_INVENTORY_ITEM_ID := NULL;

  v_Return := GEAE_MYGE_ITEM_CONFIG_PKG.GET_AVL_TO_RESERVE(
    P_ORGANIZATION_ID => P_ORGANIZATION_ID,
    P_INVENTORY_ITEM_ID => P_INVENTORY_ITEM_ID
  );
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('v_Return = ' || v_Return);
*/ 
  :v_Return := v_Return;
--rollback; 
END;
