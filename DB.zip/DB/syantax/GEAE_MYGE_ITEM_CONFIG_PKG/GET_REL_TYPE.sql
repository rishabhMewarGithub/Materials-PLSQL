

-------------------------------------------------------------------------GET_REL_TYPE-------------------------------------------------------


DECLARE
  P_RELATIONSHIP_TYPE VARCHAR2(200);
  v_Return NUMBER;
BEGIN
  P_RELATIONSHIP_TYPE := NULL;

  v_Return := GEAE_MYGE_ITEM_CONFIG_PKG.GET_REL_TYPE(
    P_RELATIONSHIP_TYPE => P_RELATIONSHIP_TYPE
  );
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('v_Return = ' || v_Return);
*/ 
  :v_Return := v_Return;
--rollback; 
END;
