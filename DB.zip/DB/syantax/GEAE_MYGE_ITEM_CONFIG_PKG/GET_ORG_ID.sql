


-------------------------------------------------------------------------GET_ORG_ID-------------------------------------------------------



DECLARE
  P_ORG_CODE VARCHAR2(200);
  v_Return NUMBER;
BEGIN
  P_ORG_CODE := NULL;

  v_Return := GEAE_MYGE_ITEM_CONFIG_PKG.GET_ORG_ID(
    P_ORG_CODE => P_ORG_CODE
  );
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('v_Return = ' || v_Return);
*/ 
  :v_Return := v_Return;
--rollback; 
END;
