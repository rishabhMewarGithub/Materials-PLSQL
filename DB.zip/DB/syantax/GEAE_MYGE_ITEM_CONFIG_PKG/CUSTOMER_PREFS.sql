

-------------------------------------------------------------------------CUSTOMER_PREFS-------------------------------------------------------


DECLARE
  P_CUST_ACCOUNT_ID NUMBER;
  P_SUBSTITUTION_TYPE VARCHAR2(200);
  P_EIS_SEQUENCE NUMBER;
  P_DG_PREFS NUMBER;
  P_UG_PREFS NUMBER;
  P_ALT_PREFS VARCHAR2(200);
  v_Return VARCHAR2(200);
BEGIN
  P_CUST_ACCOUNT_ID := NULL;
  P_SUBSTITUTION_TYPE := NULL;
  P_EIS_SEQUENCE := NULL;
  P_DG_PREFS := NULL;
  P_UG_PREFS := NULL;
  P_ALT_PREFS := NULL;

  v_Return := GEAE_MYGE_ITEM_CONFIG_PKG.CUSTOMER_PREFS(
    P_CUST_ACCOUNT_ID => P_CUST_ACCOUNT_ID,
    P_SUBSTITUTION_TYPE => P_SUBSTITUTION_TYPE,
    P_EIS_SEQUENCE => P_EIS_SEQUENCE,
    P_DG_PREFS => P_DG_PREFS,
    P_UG_PREFS => P_UG_PREFS,
    P_ALT_PREFS => P_ALT_PREFS
  );
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('v_Return = ' || v_Return);
*/ 
  :v_Return := v_Return;
--rollback; 
END;
