


-------------------------------------------------------------------------GET_IPL_DATA-------------------------------------------------------


DECLARE
  P_ITEM_NUMBER VARCHAR2(200);
  P_ENGINE_MODEL VARCHAR2(200);
  P_BUSINESS_ENTITY VARCHAR2(200);
  v_Return NUMBER;
BEGIN
  P_ITEM_NUMBER := NULL;
  P_ENGINE_MODEL := NULL;
  P_BUSINESS_ENTITY := NULL;

  v_Return := GEAE_MYGE_ITEM_CONFIG_PKG.GET_IPL_DATA(
    P_ITEM_NUMBER => P_ITEM_NUMBER,
    P_ENGINE_MODEL => P_ENGINE_MODEL,
    P_BUSINESS_ENTITY => P_BUSINESS_ENTITY
  );
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('v_Return = ' || v_Return);
*/ 
  :v_Return := v_Return;
--rollback; 
END;
