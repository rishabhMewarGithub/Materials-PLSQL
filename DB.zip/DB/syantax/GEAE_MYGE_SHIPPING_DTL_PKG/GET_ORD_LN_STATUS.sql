

-------------------------------------------------------------------------GET_ORD_LN_STATUS-------------------------------------------------------



DECLARE
  P_SIMPLE_FLAG VARCHAR2(200);
  P_SHIP_LINE_FLAG VARCHAR2(200);
  P_LINE_FLOW_STATUS VARCHAR2(200);
  P_DWNLD_FLAG VARCHAR2(200);
  v_Return VARCHAR2(200);
BEGIN
  P_SIMPLE_FLAG := NULL;
  P_SHIP_LINE_FLAG := NULL;
  P_LINE_FLOW_STATUS := NULL;
  P_DWNLD_FLAG := NULL;

  v_Return := GEAE_MYGE_SHIPPING_DTL_PKG.GET_ORD_LN_STATUS(
    P_SIMPLE_FLAG => P_SIMPLE_FLAG,
    P_SHIP_LINE_FLAG => P_SHIP_LINE_FLAG,
    P_LINE_FLOW_STATUS => P_LINE_FLOW_STATUS,
    P_DWNLD_FLAG => P_DWNLD_FLAG
  );
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('v_Return = ' || v_Return);
*/ 
  :v_Return := v_Return;
--rollback; 
END;
