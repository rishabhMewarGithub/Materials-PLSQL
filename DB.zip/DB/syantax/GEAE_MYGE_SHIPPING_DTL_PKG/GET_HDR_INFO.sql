


-------------------------------------------------------------------------GET_HDR_INFO-------------------------------------------------------

DECLARE
  P_SSO VARCHAR2(200);
  P_IACO_CODE VARCHAR2(200);
  P_CUST_ID APPS.V_CUST_ID_ARRAY;
  P_ROLE VARCHAR2(200);
  P_OU_ID VARCHAR2(200);
  P_MS_NUMBER VARCHAR2(200);
  P_DELIVERY_ID VARCHAR2(200);
  P_ORDER_ID VARCHAR2(200);
  P_INVOICE_ID VARCHAR2(200);
  P_ORDER_HDR_INFO_ARRAY APPS.V_ORDER_HDR_INFO_ARRAY;
  P_COLUMN_GRP_INFO_ARRAY APPS.V_COLUMN_GRP_INFO_ARRAY;
  P_MYGEA_GRP_INFO_ARRAY APPS.V_MYGEA_GRP_INFO_ARRAY;
  P_COLUMN_INFO_ARRAY APPS.V_COLUMN_INFO_ARRAY;
  P_MSG VARCHAR2(200);
  
BEGIN
  P_SSO := NULL;
  P_IACO_CODE := NULL;
  -- Modify the code to initialize the variable
  -- P_CUST_ID := NULL;
  P_ROLE := NULL;
  P_OU_ID := NULL;
  P_MS_NUMBER := NULL;
  P_DELIVERY_ID := NULL;
  P_ORDER_ID := NULL;
  P_INVOICE_ID := NULL;

  GEAE_MYGE_SHIPPING_DTL_PKG.GET_HDR_INFO(
    P_SSO => P_SSO,
    P_IACO_CODE => P_IACO_CODE,
    P_CUST_ID => P_CUST_ID,
    P_ROLE => P_ROLE,
    P_OU_ID => P_OU_ID,
    P_MS_NUMBER => P_MS_NUMBER,
    P_DELIVERY_ID => P_DELIVERY_ID,
    P_ORDER_ID => P_ORDER_ID,
    P_INVOICE_ID => P_INVOICE_ID,
    P_ORDER_HDR_INFO_ARRAY => P_ORDER_HDR_INFO_ARRAY,
    P_COLUMN_GRP_INFO_ARRAY => P_COLUMN_GRP_INFO_ARRAY,
    P_MYGEA_GRP_INFO_ARRAY => P_MYGEA_GRP_INFO_ARRAY,
    P_COLUMN_INFO_ARRAY => P_COLUMN_INFO_ARRAY,
    P_MSG => P_MSG
  );
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_ORDER_HDR_INFO_ARRAY = ' || P_ORDER_HDR_INFO_ARRAY);
*/ 
  --:P_ORDER_HDR_INFO_ARRAY := P_ORDER_HDR_INFO_ARRAY;
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_COLUMN_GRP_INFO_ARRAY = ' || P_COLUMN_GRP_INFO_ARRAY);
*/ 
  --:P_COLUMN_GRP_INFO_ARRAY := P_COLUMN_GRP_INFO_ARRAY;
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_MYGEA_GRP_INFO_ARRAY = ' || P_MYGEA_GRP_INFO_ARRAY);
*/ 
  --:P_MYGEA_GRP_INFO_ARRAY := P_MYGEA_GRP_INFO_ARRAY;
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_COLUMN_INFO_ARRAY = ' || P_COLUMN_INFO_ARRAY);
*/ 
  --:P_COLUMN_INFO_ARRAY := P_COLUMN_INFO_ARRAY;
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_MSG = ' || P_MSG);
*/ 
  :P_MSG := P_MSG;
--rollback; 
END;



-----------------------------------------------------------------------------------------------

create or replace TYPE        "V_ORDER_HDR_INFO_ARRAY" AS VARRAY(2000) OF V_ORDER_HDR_INFO_BO

create or replace TYPE        "V_COLUMN_GRP_INFO_ARRAY" AS VARRAY(2000) OF V_COLUMN_GRP_INFO_BO

create or replace TYPE        "V_MYGEA_GRP_INFO_ARRAY" AS VARRAY(2000) OF V_MYGEA_GRP_INFO_BO

create or replace TYPE        "V_COLUMN_INFO_ARRAY" AS VARRAY(2000) OF V_COLUMN_INFO_BO

-----------------------------------------------------------------------------------------------

create or replace TYPE        "V_ORDER_HDR_INFO_BO" AS OBJECT (
                                    MS_LINK             VARCHAR2(150),
                                    WAREHOUSE           VARCHAR2(100),
                                    SHIP_TO_LOCATION    VARCHAR2(40),
                                    SHIP_TO_ADDRESS1    VARCHAR2(500),
                                    SHIP_TO_ADDRESS2    VARCHAR2(500),
                                    SHIP_TO_ADDRESS3    VARCHAR2(500),
                                    SHIP_TO_ADDRESS4    VARCHAR2(500),
                                    SHIP_TO_ADDRESS5    VARCHAR2(500),
                                    DEL_TO_LOCATION     VARCHAR2(40),
                                    DEL_TO_ADDRESS1     VARCHAR2(500),
                                    DEL_TO_ADDRESS2     VARCHAR2(500),
                                    DEL_TO_ADDRESS3     VARCHAR2(500),
                                    DEL_TO_ADDRESS4     VARCHAR2(500),
                                    DEL_TO_ADDRESS5     VARCHAR2(500),
                                    AWB_NUMBER          VARCHAR2(150),
                                    INVOICE_NUMBER      VARCHAR2(50),
                                    INVOICE_DATE        DATE,
                                    INVOICE_LINK        VARCHAR2(500),
                                    INVOICE_AMOUNT      NUMBER,
                                    CUSTOMER_CODE       VARCHAR2(30),
                                    CUSTOMER_NAME       VARCHAR2(50),
                                    ORDERED_DATE        DATE,
                                    ORDER_TYPE          VARCHAR2(2000),
                                    ORDER_STATUS        VARCHAR2(240),
                                    CUST_PO_NUMBER      VARCHAR2(50),
                                    SUPPLIER_CODE       VARCHAR2(240),
                                    SHIPMENT_DATE       DATE,
                                    BILL_OF_LADING      VARCHAR2(150),
                                    WAREHOUSE_CODE      VARCHAR2(100),
                                    INVC_TO_LOCATION    VARCHAR2(40),
                                    INVC_TO_ADDRESS1    VARCHAR2(500),
                                    INVC_TO_ADDRESS2    VARCHAR2(500),
                                    INVC_TO_ADDRESS3    VARCHAR2(500),
                                    INVC_TO_ADDRESS4    VARCHAR2(500),
                                    INVC_TO_ADDRESS5    VARCHAR2(500),
                                    CUSTOMER_ID         NUMBER,
                                    DISPUTE_ORDER       VARCHAR2(1),
                                    INVOICE_ID          NUMBER,
                                    AWB_LINK            VARCHAR2(500),
                                    TOTAL_ORDER_VALUE   NUMBER,
                                    TOTAL_DISC_VALUE    NUMBER
                                    )
			
			
create or replace TYPE        "V_COLUMN_GRP_INFO_BO" AS OBJECT (
                                    GROUP_NAME          VARCHAR2(50),
                                    COLUMN_ID           VARCHAR2(4000)
                                    );

									
create or replace TYPE        "V_MYGEA_GRP_INFO_BO" AS OBJECT (GROUP_NAME          VARCHAR2(50),
                                                                    COLUMN_ID           VARCHAR2(4000)
                                                                    );

create or replace TYPE        "V_COLUMN_INFO_BO" AS OBJECT (
                                    COLUMN_ID           VARCHAR2(50),
                                    COLUMN_NAME         VARCHAR2(50)
                                    );																	

-----------------------------------------------------------------------------------------------------------
					

DECLARE
  P_SSO VARCHAR2(200);
  P_IACO_CODE VARCHAR2(200);
  P_CUST_ID APPS.V_CUST_ID_ARRAY:= NEW V_CUST_ID_ARRAY();
  P_ROLE VARCHAR2(200);
  P_OU_ID VARCHAR2(200);
  P_MS_NUMBER VARCHAR2(200);
  P_DELIVERY_ID VARCHAR2(200);
  P_ORDER_ID VARCHAR2(200);
  P_INVOICE_ID VARCHAR2(200);
  P_ORDER_HDR_INFO_ARRAY APPS.V_ORDER_HDR_INFO_ARRAY := NEW V_ORDER_HDR_INFO_ARRAY();
  P_COLUMN_GRP_INFO_ARRAY APPS.V_COLUMN_GRP_INFO_ARRAY := NEW V_COLUMN_GRP_INFO_ARRAY();
  P_MYGEA_GRP_INFO_ARRAY APPS.V_MYGEA_GRP_INFO_ARRAY :=NEW V_MYGEA_GRP_INFO_ARRAY() ;
  P_COLUMN_INFO_ARRAY APPS.V_COLUMN_INFO_ARRAY :=NEW V_COLUMN_INFO_ARRAY();
  P_MSG VARCHAR2(200);
  
BEGIN
  P_SSO := '502299002';
  P_IACO_CODE := 'MMBL';
  P_CUST_ID.EXTEND(4);
  p_cust_id(1):=71280;
  p_cust_id(2):=444531;
  p_cust_id(3):=400538;
  p_cust_id(4):=2999218;  
  P_ROLE := 'Buyer';
  P_OU_ID := '60377~117019';
  P_MS_NUMBER := NULL; --'P51990';
  P_DELIVERY_ID := NULL; ---27301797; ---27531555;--  27531555                P51990
  P_ORDER_ID := 15692034 ;
  P_INVOICE_ID := NULL;

  GEAE_MYGE_SHIPPING_DTL_PKG.GET_HDR_INFO(
    P_SSO => P_SSO,
    P_IACO_CODE => P_IACO_CODE,
    P_CUST_ID => P_CUST_ID,
    P_ROLE => P_ROLE,
    P_OU_ID => P_OU_ID,
    P_MS_NUMBER => P_MS_NUMBER,
    P_DELIVERY_ID => P_DELIVERY_ID,
    P_ORDER_ID => P_ORDER_ID,
    P_INVOICE_ID => P_INVOICE_ID,
    P_ORDER_HDR_INFO_ARRAY => P_ORDER_HDR_INFO_ARRAY,
    P_COLUMN_GRP_INFO_ARRAY => P_COLUMN_GRP_INFO_ARRAY,
    P_MYGEA_GRP_INFO_ARRAY => P_MYGEA_GRP_INFO_ARRAY,
    P_COLUMN_INFO_ARRAY => P_COLUMN_INFO_ARRAY,
    P_MSG => P_MSG
  );
  
	For i in 1..P_ORDER_HDR_INFO_ARRAY.COUNT LOOP
		DBMS_OUTPUT.PUT_LINE('P_ORDER_HDR_INFO_ARRAY WAREHOUSE= ' || P_ORDER_HDR_INFO_ARRAY(i).WAREHOUSE);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_HDR_INFO_ARRAY SHIP_TO_LOCATION = ' || P_ORDER_HDR_INFO_ARRAY(i).SHIP_TO_LOCATION);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_HDR_INFO_ARRAY SHIP_TO_ADDRESS1= ' || P_ORDER_HDR_INFO_ARRAY(i).SHIP_TO_ADDRESS1);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_HDR_INFO_ARRAY DEL_TO_LOCATION= ' || P_ORDER_HDR_INFO_ARRAY(i).DEL_TO_LOCATION);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_HDR_INFO_ARRAY AWB_NUMBER= ' || P_ORDER_HDR_INFO_ARRAY(i).AWB_NUMBER);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_HDR_INFO_ARRAY INVOICE_NUMBER= ' || P_ORDER_HDR_INFO_ARRAY(i).INVOICE_NUMBER);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_HDR_INFO_ARRAY INVOICE_DATE= ' || P_ORDER_HDR_INFO_ARRAY(i).INVOICE_DATE);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_HDR_INFO_ARRAY INVOICE_LINK= ' || P_ORDER_HDR_INFO_ARRAY(i).INVOICE_LINK);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_HDR_INFO_ARRAY INVOICE_AMOUNT= ' || P_ORDER_HDR_INFO_ARRAY(i).INVOICE_AMOUNT);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_HDR_INFO_ARRAY CUSTOMER_CODE= ' || P_ORDER_HDR_INFO_ARRAY(i).CUSTOMER_CODE);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_HDR_INFO_ARRAY CUSTOMER_NAME= ' || P_ORDER_HDR_INFO_ARRAY(i).CUSTOMER_NAME);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_HDR_INFO_ARRAY INVOICE_AMOUNT= ' || P_ORDER_HDR_INFO_ARRAY(i).INVOICE_AMOUNT);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_HDR_INFO_ARRAY ORDER_TYPE= ' || P_ORDER_HDR_INFO_ARRAY(i).ORDER_TYPE);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_HDR_INFO_ARRAY ORDER_STATUS= ' || P_ORDER_HDR_INFO_ARRAY(i).ORDER_STATUS);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_HDR_INFO_ARRAY SUPPLIER_CODE= ' || P_ORDER_HDR_INFO_ARRAY(i).SUPPLIER_CODE);
	END LOOP;

	For i in 1..P_COLUMN_GRP_INFO_ARRAY.COUNT LOOP
		DBMS_OUTPUT.PUT_LINE('P_COLUMN_GRP_INFO_ARRAY GROUP_NAME= ' || P_COLUMN_GRP_INFO_ARRAY(i).GROUP_NAME);
		DBMS_OUTPUT.PUT_LINE('P_COLUMN_GRP_INFO_ARRAY COLUMN_ID= ' || P_COLUMN_GRP_INFO_ARRAY(i).COLUMN_ID);
	END LOOP;

	For i in 1..P_MYGEA_GRP_INFO_ARRAY.COUNT LOOP
		DBMS_OUTPUT.PUT_LINE('P_MYGEA_GRP_INFO_ARRAY GROUP_NAME= ' || P_MYGEA_GRP_INFO_ARRAY(i).GROUP_NAME);
		DBMS_OUTPUT.PUT_LINE('P_MYGEA_GRP_INFO_ARRAY COLUMN_ID= ' || P_MYGEA_GRP_INFO_ARRAY(i).COLUMN_ID);
	END LOOP;


	For i in 1..P_COLUMN_INFO_ARRAY.COUNT LOOP
		DBMS_OUTPUT.PUT_LINE('P_COLUMN_INFO_ARRAY COLUMN_ID = ' || P_COLUMN_INFO_ARRAY(i).COLUMN_ID);
		DBMS_OUTPUT.PUT_LINE('P_COLUMN_INFO_ARRAY COLUMN_NAME = ' || P_COLUMN_INFO_ARRAY(i).COLUMN_NAME);
	END LOOP;

	DBMS_OUTPUT.PUT_LINE('P_MSG = ' || P_MSG);

END;


--------------------------------------------------------------------------------------------------------------------------------





