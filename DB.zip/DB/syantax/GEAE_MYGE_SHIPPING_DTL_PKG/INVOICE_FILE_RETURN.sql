

-------------------------------------------------------------------------INVOICE_FILE_RETURN-------------------------------------------------------


DECLARE
  P_SSO VARCHAR2(200);
  P_IACO_CODE VARCHAR2(200);
  P_CUST_ID APPS.V_CUST_ID_ARRAY;
  P_ROLE VARCHAR2(200);
  P_OU_ID VARCHAR2(200);
  P_INVOICE_ID NUMBER;
  P_FILE_DATA BLOB;
  P_FILE_NAME VARCHAR2(200);
  P_MSG VARCHAR2(200);
BEGIN
  P_SSO := NULL;
  P_IACO_CODE := NULL;
  -- Modify the code to initialize the variable
  -- P_CUST_ID := NULL;
  P_ROLE := NULL;
  P_OU_ID := NULL;
  P_INVOICE_ID := NULL;

  GEAE_MYGE_SHIPPING_DTL_PKG.INVOICE_FILE_RETURN(
    P_SSO => P_SSO,
    P_IACO_CODE => P_IACO_CODE,
    P_CUST_ID => P_CUST_ID,
    P_ROLE => P_ROLE,
    P_OU_ID => P_OU_ID,
    P_INVOICE_ID => P_INVOICE_ID,
    P_FILE_DATA => P_FILE_DATA,
    P_FILE_NAME => P_FILE_NAME,
    P_MSG => P_MSG
  );
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_FILE_DATA = ' || P_FILE_DATA);
*/ 
  --:P_FILE_DATA := P_FILE_DATA;
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_FILE_NAME = ' || P_FILE_NAME);
*/ 
  :P_FILE_NAME := P_FILE_NAME;
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_MSG = ' || P_MSG);
*/ 
  :P_MSG := P_MSG;
--rollback; 
END;




