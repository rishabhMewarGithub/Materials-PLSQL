


-------------------------------------------------------------------------GET_CRITAL_PART_FLAG-------------------------------------------------------


DECLARE
  P_HEADER_ID NUMBER;
  P_LINE_ID NUMBER;
  P_ITEM_NUM VARCHAR2(200);
  v_Return VARCHAR2(200);
  
BEGIN
  P_HEADER_ID := NULL;
  P_LINE_ID := NULL;
  P_ITEM_NUM := NULL;

  v_Return := GEAE_MYGE_SHIPPING_DTL_PKG.GET_CRITAL_PART_FLAG(
    P_HEADER_ID => P_HEADER_ID,
    P_LINE_ID => P_LINE_ID,
    P_ITEM_NUM => P_ITEM_NUM
  );
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('v_Return = ' || v_Return);
*/ 
  :v_Return := v_Return;
--rollback; 
END;
