

-------------------------------------------------------------------------RETURN_INV_NUM-------------------------------------------------------


DECLARE
  P_ORDER_NUM NUMBER;
  P_HEADER_ID NUMBER;
  P_LINE_ID NUMBER;
  v_Return VARCHAR2(200);
BEGIN
  P_ORDER_NUM := NULL;
  P_HEADER_ID := NULL;
  P_LINE_ID := NULL;

  v_Return := GEAE_MYGE_SHIPPING_DTL_PKG.RETURN_INV_NUM(
    P_ORDER_NUM => P_ORDER_NUM,
    P_HEADER_ID => P_HEADER_ID,
    P_LINE_ID => P_LINE_ID
  );
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('v_Return = ' || v_Return);
*/ 
  :v_Return := v_Return;
--rollback; 
END;
