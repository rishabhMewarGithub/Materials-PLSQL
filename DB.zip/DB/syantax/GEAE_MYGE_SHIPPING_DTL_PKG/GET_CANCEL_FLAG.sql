

-------------------------------------------------------------------------GET_CANCEL_FLAG-------------------------------------------------------

DECLARE
  P_HEADER_ID NUMBER;
  P_LINE_ID NUMBER;
  P_LINE_DWLD VARCHAR2(200);
  v_Return VARCHAR2(200);
  
BEGIN
  P_HEADER_ID := NULL;
  P_LINE_ID := NULL;
  P_LINE_DWLD := NULL;

  v_Return := GEAE_MYGE_SHIPPING_DTL_PKG.GET_CANCEL_FLAG(
    P_HEADER_ID => P_HEADER_ID,
    P_LINE_ID => P_LINE_ID,
    P_LINE_DWLD => P_LINE_DWLD
  );
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('v_Return = ' || v_Return);
*/ 
  :v_Return := v_Return;
--rollback; 
END;



