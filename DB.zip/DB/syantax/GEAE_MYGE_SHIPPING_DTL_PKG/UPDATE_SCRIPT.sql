
-------------------------------------------------------------------------UPDATE_SCRIPT-------------------------------------------------------


BEGIN
  GEAE_MYGE_SHIPPING_DTL_PKG.UPDATE_SCRIPT();
--rollback; 
END;