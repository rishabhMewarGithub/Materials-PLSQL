

-------------------------------------------------------------------------GET_TRACKING_URL-------------------------------------------------------


DECLARE
  P_SHP_METHD_CD VARCHAR2(200);
  P_BOL_NUMBER VARCHAR2(200);
  v_Return VARCHAR2(200);
BEGIN
  P_SHP_METHD_CD := NULL;
  P_BOL_NUMBER := NULL;

  v_Return := GEAE_MYGE_SHIPPING_DTL_PKG.GET_TRACKING_URL(
    P_SHP_METHD_CD => P_SHP_METHD_CD,
    P_BOL_NUMBER => P_BOL_NUMBER
  );
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('v_Return = ' || v_Return);
*/ 
  :v_Return := v_Return;
--rollback; 
END;
