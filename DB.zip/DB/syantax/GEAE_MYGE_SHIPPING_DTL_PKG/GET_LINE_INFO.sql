

-------------------------------------------------------------------------GET_LINE_INFO-------------------------------------------------------


DECLARE
  P_SSO VARCHAR2(200);
  P_IACO_CODE VARCHAR2(200);
  P_CUST_ID APPS.V_CUST_ID_ARRAY;
  P_ROLE VARCHAR2(200);
  P_OU_ID VARCHAR2(200);
  P_MS_NUMBER VARCHAR2(200);
  P_DELIVERY_ID VARCHAR2(200);
  P_ORDER_ID VARCHAR2(200);
  P_INVOICE_ID VARCHAR2(200);
  P_ORDER_LINE_INFO_ARRAY APPS.V_ORDER_LINE_INFO_ARRAY;
  P_MSG VARCHAR2(200);
BEGIN
  P_SSO := NULL;
  P_IACO_CODE := NULL;
  -- Modify the code to initialize the variable
  -- P_CUST_ID := NULL;
  P_ROLE := NULL;
  P_OU_ID := NULL;
  P_MS_NUMBER := NULL;
  P_DELIVERY_ID := NULL;
  P_ORDER_ID := NULL;
  P_INVOICE_ID := NULL;

  GEAE_MYGE_SHIPPING_DTL_PKG.GET_LINE_INFO(
    P_SSO => P_SSO,
    P_IACO_CODE => P_IACO_CODE,
    P_CUST_ID => P_CUST_ID,
    P_ROLE => P_ROLE,
    P_OU_ID => P_OU_ID,
    P_MS_NUMBER => P_MS_NUMBER,
    P_DELIVERY_ID => P_DELIVERY_ID,
    P_ORDER_ID => P_ORDER_ID,
    P_INVOICE_ID => P_INVOICE_ID,
    P_ORDER_LINE_INFO_ARRAY => P_ORDER_LINE_INFO_ARRAY,
    P_MSG => P_MSG
  );
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY = ' || P_ORDER_LINE_INFO_ARRAY);
*/ 
  --:P_ORDER_LINE_INFO_ARRAY := P_ORDER_LINE_INFO_ARRAY;
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_MSG = ' || P_MSG);
*/ 
  :P_MSG := P_MSG;
--rollback; 
END;

-----------------------------------------------------------------------------------------------

create or replace TYPE      V_ORDER_LINE_INFO_ARRAY AS VARRAY(2250) OF APPS.V_ORDER_LINE_INFO_BO;

-----------------------------------------------------------------------------------------------

create or replace TYPE      V_ORDER_LINE_INFO_BO AS OBJECT (		LINE_ID NUMBER,
                                                                     ORG_ID NUMBER,
                                                                     HEADER_ID NUMBER,
                                                                     LINE_NUMBER NUMBER,
                                                                     ORDERED_ITEM VARCHAR2(40),
                                                                     REQUEST_DATE DATE,
                                                                     PROMISE_DATE DATE,
                                                                     SCHEDULE_ARRIVAL_DATE DATE,
                                                                     SCHEDULE_SHIP_DATE DATE,
                                                                     ORDER_QUANTITY_UOM VARCHAR2(5),
                                                                     CANCELLED_QUANTITY NUMBER,
                                                                     SHIPPED_QUANTITY NUMBER,
                                                                     ORDERED_QUANTITY NUMBER,
                                                                     FULFILLED_QUANTITY NUMBER,
                                                                     SHIPPING_QUANTITY NUMBER,
                                                                     TAX_EXEMPT_FLAG VARCHAR2(1),
                                                                     TAX_EXEMPT_NUMBER VARCHAR2(80),
                                                                     TAX_EXEMPT_REASON_CODE VARCHAR2(30),
                                                                     CUST_PO_NUMBER VARCHAR2(50),
                                                                     SOLD_TO_ORG_ID NUMBER,
                                                                     SHIP_FROM_ORG_ID NUMBER,
                                                                     SHIP_TO_ORG_ID NUMBER,
                                                                     DELIVER_TO_ORG_ID NUMBER,
                                                                     INVOICE_TO_ORG_ID NUMBER,
                                                                     INVENTORY_ITEM_ID NUMBER,
                                                                     TAX_CODE VARCHAR2(50),
                                                                     TAX_RATE NUMBER,
                                                                     SCHEDULE_STATUS_CODE VARCHAR2(30),
                                                                     PRICE_LIST_ID NUMBER,
                                                                     PRICING_DATE DATE,
                                                                     SHIPMENT_NUMBER NUMBER,
                                                                     SHIPMENT_PRIORITY_CODE VARCHAR2(30),
                                                                     SHIPPING_METHOD VARCHAR2(240),
                                                                     FREIGHT_TERMS_CODE VARCHAR2(30),
                                                                     FREIGHT_CARRIER_CODE VARCHAR2(30),
                                                                     FOB_POINT VARCHAR2(240),
                                                                     PAYMENT_TERM_ID NUMBER,
                                                                     RETURN_CONTEXT VARCHAR2(30),
                                                                     COUNTRY_OF_ORIGIN VARCHAR2(1000),
                                                                     RETURN_ATTRIBUTE1 VARCHAR2(240),
                                                                     RETURN_ATTRIBUTE2 VARCHAR2(240),
                                                                     UNIT_SELLING_PRICE NUMBER,
                                                                     UNIT_LIST_PRICE NUMBER,
                                                                     EXT_PRICE NUMBER,
                                                                     TAX_VALUE NUMBER,
                                                                     CREATION_DATE DATE,
                                                                     CREATED_BY VARCHAR2(50),
                                                                     LAST_UPDATE_DATE DATE,
                                                                     LAST_UPDATED_BY VARCHAR2(50),
                                                                     ITEM_TYPE_CODE VARCHAR2(30),
                                                                     COMPONENT_NUMBER NUMBER,
                                                                     ACTUAL_SHIPMENT_DATE DATE,
                                                                     LINE_TYPE VARCHAR2(30),
                                                                     PRICE_LIST VARCHAR2(240),
                                                                     PAYMENT_TERM VARCHAR2(15),
                                                                     SOLD_TO VARCHAR2(360),
                                                                     CUSTOMER_NUMBER VARCHAR2(30),
                                                                     SHIP_FROM VARCHAR2(10),
                                                                     SHIP_TO_LOCATION VARCHAR2(40),
                                                                     SHIP_TO_ADDRESS1 VARCHAR2(240),
                                                                     SHIP_TO_ADDRESS2 VARCHAR2(240),
                                                                     SHIP_TO_ADDRESS3 VARCHAR2(240),
                                                                     SHIP_TO_ADDRESS4 VARCHAR2(240),
                                                                     SHIP_TO_ADDRESS5 VARCHAR2(240),
                                                                     DELIVER_TO_LOCATION VARCHAR2(40),
                                                                     DELIVER_TO_ADDRESS1 VARCHAR2(240),
                                                                     DELIVER_TO_ADDRESS2 VARCHAR2(240),
                                                                     DELIVER_TO_ADDRESS3 VARCHAR2(240),
                                                                     DELIVER_TO_ADDRESS4 VARCHAR2(240),
                                                                     DELIVER_TO_ADDRESS5 VARCHAR2(240),
                                                                     INVOICE_TO_LOCATION VARCHAR2(40),
                                                                     INVOICE_TO_ADDRESS1 VARCHAR2(240),
                                                                     INVOICE_TO_ADDRESS2 VARCHAR2(240),
                                                                     INVOICE_TO_ADDRESS3 VARCHAR2(240),
                                                                     INVOICE_TO_ADDRESS4 VARCHAR2(240),
                                                                     INVOICE_TO_ADDRESS5 VARCHAR2(240),
                                                                     ORDER_NUMBER NUMBER,
                                                                     QUOTE_NUMBER NUMBER,
                                                                     ORDER_TYPE_ID NUMBER,
                                                                     ORDERED_DATE DATE,
                                                                     RETURN_REASON VARCHAR2(240),
                                                                     SPLIT_FROM_LINE_ID NUMBER,
                                                                     SHIP_SET_ID NUMBER,
                                                                     PLANNING_PRIORITY NUMBER,
                                                                     SHIPPING_INSTRUCTIONS VARCHAR2(2000),
                                                                     PACKING_INSTRUCTIONS VARCHAR2(2000),
                                                                     INVOICED_QUANTITY NUMBER,
                                                                     FLOW_STATUS VARCHAR2(240),
                                                                     CUSTOMER_LINE_NUMBER VARCHAR2(50),
                                                                     ORIGINAL_ORDERED_ITEM VARCHAR2(40),
                                                                     ORDER_SOURCE VARCHAR2(240),
                                                                     KEYWORD VARCHAR2(240),
                                                                     PART_NOMEN VARCHAR2(240),
                                                                     SALES_PERSON VARCHAR2(360),
                                                                     DELIVERY_ID NUMBER,
                                                                     INVOICE_NUMBER VARCHAR2(20),
                                                                     DISCOUNT_PERCENTAGE NUMBER,
                                                                     DISCOUNT_AMOUNT NUMBER,
                                                                     INVOICE_DATE DATE,
                                                                     INVOICE_VALUE NUMBER,
                                                                     ORIG_PO_FOR_RETURN VARCHAR2(50),
                                                                     CANCEL_UPDATE_ALLOWED VARCHAR2(1),
                                                                     SHIPMENT_DISPUTE_ALLOWED VARCHAR2(1),
                                                                     MS_NUMBER VARCHAR2(150),
                                                                     SHIPPING_STATUS VARCHAR2(1000),
                                                                     SHIPMENT_QUANTITY NUMBER,
                                                                     DIMENSIONS VARCHAR2(150),
                                                                     GROSS_WEIGHT NUMBER,
                                                                     SERIAL_NUMBERS VARCHAR2(30000),
                                                                     LINK_TO_CARRIER VARCHAR2(150),
                                                                     RETURN_COO VARCHAR2(150),
                                                                     UPQ VARCHAR2(240),
                                                                     INVOICE_ID NUMBER,
                                                                     QTY_UPD_ALLOWED VARCHAR2(1),
                                                                     SHIP_TO_ADDRESS VARCHAR2(1250),
                                                                     DELIVER_TO_ADDRESS VARCHAR2(1250),
                                                                     INVOICE_TO_ADDRESS VARCHAR2(1250),
                                                                     MYGEA_ESN VARCHAR2(6),
                                                                     SHIPMENT_DISPUTE_CREATED VARCHAR2(1),
                                                                     CRITICAL_PART_FLAG VARCHAR2(2),
                                                                     WORKSTP_DATE DATE, -- added for workstop changes
                                                                     WORKSTP_QTY NUMBER); -- added for workstop changes


------------------------------------------------------------------------------------------------------------------------------------------


DECLARE
  P_SSO VARCHAR2(200);
  P_IACO_CODE VARCHAR2(200);
  P_CUST_ID APPS.V_CUST_ID_ARRAY;
  P_ROLE VARCHAR2(200);
  P_OU_ID VARCHAR2(200);
  P_MS_NUMBER VARCHAR2(200);
  P_DELIVERY_ID VARCHAR2(200);
  P_ORDER_ID VARCHAR2(200);
  P_INVOICE_ID VARCHAR2(200);
  P_ORDER_LINE_INFO_ARRAY APPS.V_ORDER_LINE_INFO_ARRAY;
  P_MSG VARCHAR2(200);
  
BEGIN
  P_SSO := NULL;
  P_IACO_CODE := NULL;
  -- Modify the code to initialize the variable
  -- P_CUST_ID := NULL;
  P_ROLE := NULL;
  P_OU_ID := NULL;
  P_MS_NUMBER := NULL;
  P_DELIVERY_ID := NULL;
  P_ORDER_ID := NULL;
  P_INVOICE_ID := NULL;

  GEAE_MYGE_SHIPPING_DTL_PKG.GET_LINE_INFO(
    P_SSO => P_SSO,
    P_IACO_CODE => P_IACO_CODE,
    P_CUST_ID => P_CUST_ID,
    P_ROLE => P_ROLE,
    P_OU_ID => P_OU_ID,
    P_MS_NUMBER => P_MS_NUMBER,
    P_DELIVERY_ID => P_DELIVERY_ID,
    P_ORDER_ID => P_ORDER_ID,
    P_INVOICE_ID => P_INVOICE_ID,
    P_ORDER_LINE_INFO_ARRAY => P_ORDER_LINE_INFO_ARRAY,
    P_MSG => P_MSG
  );
  
  For i in 1..P_ORDER_LINE_INFO_ARRAY.COUNT LOOP
  
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY LINE_ID= ' || P_ORDER_LINE_INFO_ARRAY(i).LINE_ID);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY ORG_ID = ' || P_ORDER_LINE_INFO_ARRAY(i).ORG_ID);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY HEADER_ID= ' || P_ORDER_LINE_INFO_ARRAY(i).HEADER_ID);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY LINE_NUMBER= ' || P_ORDER_LINE_INFO_ARRAY(i).LINE_NUMBER);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY ORDERED_ITEM= ' || P_ORDER_LINE_INFO_ARRAY(i).ORDERED_ITEM);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY REQUEST_DATE= ' || P_ORDER_LINE_INFO_ARRAY(i).REQUEST_DATE);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY PROMISE_DATE= ' || P_ORDER_LINE_INFO_ARRAY(i).PROMISE_DATE);		
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY SCHEDULE_ARRIVAL_DATE= ' || P_ORDER_LINE_INFO_ARRAY(i).SCHEDULE_ARRIVAL_DATE);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY SCHEDULE_SHIP_DATE= ' || P_ORDER_LINE_INFO_ARRAY(i).SCHEDULE_SHIP_DATE);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY ORDER_QUANTITY_UOM= ' || P_ORDER_LINE_INFO_ARRAY(i).ORDER_QUANTITY_UOM);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY CANCELLED_QUANTITY= ' || P_ORDER_LINE_INFO_ARRAY(i).CANCELLED_QUANTITY);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY SHIPPED_QUANTITY= ' || P_ORDER_LINE_INFO_ARRAY(i).SHIPPED_QUANTITY);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY ORDERED_QUANTITY= ' || P_ORDER_LINE_INFO_ARRAY(i).ORDERED_QUANTITY);	
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY FULFILLED_QUANTITY= ' || P_ORDER_LINE_INFO_ARRAY(i).FULFILLED_QUANTITY);	
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY SHIPPING_QUANTITY= ' || P_ORDER_LINE_INFO_ARRAY(i).SHIPPING_QUANTITY);			
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY TAX_EXEMPT_FLAG= ' || P_ORDER_LINE_INFO_ARRAY(i).TAX_EXEMPT_FLAG);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY TAX_EXEMPT_NUMBER = ' || P_ORDER_LINE_INFO_ARRAY(i).TAX_EXEMPT_NUMBER);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY TAX_EXEMPT_REASON_CODE = ' || P_ORDER_LINE_INFO_ARRAY(i).TAX_EXEMPT_REASON_CODE);		
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY CUST_PO_NUMBER= ' || P_ORDER_LINE_INFO_ARRAY(i).CUST_PO_NUMBER);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY SOLD_TO_ORG_ID= ' || P_ORDER_LINE_INFO_ARRAY(i).SOLD_TO_ORG_ID);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY SHIP_FROM_ORG_ID= ' || P_ORDER_LINE_INFO_ARRAY(i).SHIP_FROM_ORG_ID);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY SHIP_TO_ORG_ID= ' || P_ORDER_LINE_INFO_ARRAY(i).SHIP_TO_ORG_ID);		
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY DELIVER_TO_ORG_ID= ' || P_ORDER_LINE_INFO_ARRAY(i).DELIVER_TO_ORG_ID);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY INVOICE_TO_ORG_ID= ' || P_ORDER_LINE_INFO_ARRAY(i).INVOICE_TO_ORG_ID);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY INVENTORY_ITEM_ID= ' || P_ORDER_LINE_INFO_ARRAY(i).INVENTORY_ITEM_ID);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY TAX_CODE= ' || P_ORDER_LINE_INFO_ARRAY(i).TAX_CODE);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY TAX_RATE= ' || P_ORDER_LINE_INFO_ARRAY(i).TAX_RATE);		
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY SCHEDULE_STATUS_CODE= ' || P_ORDER_LINE_INFO_ARRAY(i).SCHEDULE_STATUS_CODE);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY PRICE_LIST_ID= ' || P_ORDER_LINE_INFO_ARRAY(i).PRICE_LIST_ID);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY PRICING_DATE= ' || P_ORDER_LINE_INFO_ARRAY(i).PRICING_DATE);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY SHIPMENT_NUMBER= ' || P_ORDER_LINE_INFO_ARRAY(i).SHIPMENT_NUMBER);		
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY SHIPMENT_PRIORITY_CODE= ' || P_ORDER_LINE_INFO_ARRAY(i).SHIPMENT_PRIORITY_CODE);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY SHIPPING_METHOD = ' || P_ORDER_LINE_INFO_ARRAY(i).SHIPPING_METHOD);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY FREIGHT_TERMS_CODE= ' || P_ORDER_LINE_INFO_ARRAY(i).FREIGHT_TERMS_CODE);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY FREIGHT_CARRIER_CODE= ' || P_ORDER_LINE_INFO_ARRAY(i).FREIGHT_CARRIER_CODE);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY FOB_POINT= ' || P_ORDER_LINE_INFO_ARRAY(i).FOB_POINT);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY PAYMENT_TERM_ID= ' || P_ORDER_LINE_INFO_ARRAY(i).PAYMENT_TERM_ID);		
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY RETURN_CONTEXT= ' || P_ORDER_LINE_INFO_ARRAY(i).RETURN_CONTEXT);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY COUNTRY_OF_ORIGIN= ' || P_ORDER_LINE_INFO_ARRAY(i).COUNTRY_OF_ORIGIN);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY RETURN_ATTRIBUTE1= ' || P_ORDER_LINE_INFO_ARRAY(i).RETURN_ATTRIBUTE1);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY RETURN_ATTRIBUTE2= ' || P_ORDER_LINE_INFO_ARRAY(i).RETURN_ATTRIBUTE2);		
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY UNIT_SELLING_PRICE= ' || P_ORDER_LINE_INFO_ARRAY(i).UNIT_SELLING_PRICE);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY UNIT_LIST_PRICE= ' || P_ORDER_LINE_INFO_ARRAY(i).UNIT_LIST_PRICE);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY EXT_PRICE= ' || P_ORDER_LINE_INFO_ARRAY(i).EXT_PRICE);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY TAX_VALUE= ' || P_ORDER_LINE_INFO_ARRAY(i).TAX_VALUE);		
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY CREATION_DATE= ' || P_ORDER_LINE_INFO_ARRAY(i).CREATION_DATE);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY CREATED_BY= ' || P_ORDER_LINE_INFO_ARRAY(i).CREATED_BY);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY LAST_UPDATE_DATE= ' || P_ORDER_LINE_INFO_ARRAY(i).LAST_UPDATE_DATE);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY LAST_UPDATED_BY= ' || P_ORDER_LINE_INFO_ARRAY(i).LAST_UPDATED_BY);		
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY ITEM_TYPE_CODE= ' || P_ORDER_LINE_INFO_ARRAY(i).ITEM_TYPE_CODE);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY COMPONENT_NUMBER= ' || P_ORDER_LINE_INFO_ARRAY(i).COMPONENT_NUMBER);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY ACTUAL_SHIPMENT_DATE= ' || P_ORDER_LINE_INFO_ARRAY(i).ACTUAL_SHIPMENT_DATE);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY LINE_TYPE= ' || P_ORDER_LINE_INFO_ARRAY(i).LINE_TYPE);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY PRICE_LIST= ' || P_ORDER_LINE_INFO_ARRAY(i).PRICE_LIST);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY PAYMENT_TERM= ' || P_ORDER_LINE_INFO_ARRAY(i).PAYMENT_TERM);		
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY SOLD_TO= ' || P_ORDER_LINE_INFO_ARRAY(i).SOLD_TO);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY CUSTOMER_NUMBER= ' || P_ORDER_LINE_INFO_ARRAY(i).CUSTOMER_NUMBER);		
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY SHIP_FROM= ' || P_ORDER_LINE_INFO_ARRAY(i).SHIP_FROM);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY SHIP_TO_LOCATION= ' || P_ORDER_LINE_INFO_ARRAY(i).SHIP_TO_LOCATION);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY SHIP_TO_ADDRESS1= ' || P_ORDER_LINE_INFO_ARRAY(i).SHIP_TO_ADDRESS1);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY SHIP_TO_ADDRESS2= ' || P_ORDER_LINE_INFO_ARRAY(i).SHIP_TO_ADDRESS2);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY SHIP_TO_ADDRESS3= ' || P_ORDER_LINE_INFO_ARRAY(i).SHIP_TO_ADDRESS3);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY SHIP_TO_ADDRESS4= ' || P_ORDER_LINE_INFO_ARRAY(i).SHIP_TO_ADDRESS4);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY SHIP_TO_ADDRESS5= ' || P_ORDER_LINE_INFO_ARRAY(i).SHIP_TO_ADDRESS5);		
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY DELIVER_TO_LOCATION= ' || P_ORDER_LINE_INFO_ARRAY(i).DELIVER_TO_LOCATION);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY DELIVER_TO_ADDRESS1= ' || P_ORDER_LINE_INFO_ARRAY(i).DELIVER_TO_ADDRESS1);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY DELIVER_TO_ADDRESS2= ' || P_ORDER_LINE_INFO_ARRAY(i).DELIVER_TO_ADDRESS2);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY DELIVER_TO_ADDRESS3= ' || P_ORDER_LINE_INFO_ARRAY(i).DELIVER_TO_ADDRESS3);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY DELIVER_TO_ADDRESS4= ' || P_ORDER_LINE_INFO_ARRAY(i).DELIVER_TO_ADDRESS4);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY DELIVER_TO_ADDRESS5= ' || P_ORDER_LINE_INFO_ARRAY(i).DELIVER_TO_ADDRESS5);		
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY INVOICE_TO_LOCATION= ' || P_ORDER_LINE_INFO_ARRAY(i).INVOICE_TO_LOCATION);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY INVOICE_TO_ADDRESS1= ' || P_ORDER_LINE_INFO_ARRAY(i).INVOICE_TO_ADDRESS1);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY INVOICE_TO_ADDRESS2= ' || P_ORDER_LINE_INFO_ARRAY(i).INVOICE_TO_ADDRESS2);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY INVOICE_TO_ADDRESS3= ' || P_ORDER_LINE_INFO_ARRAY(i).INVOICE_TO_ADDRESS3);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY INVOICE_TO_ADDRESS4= ' || P_ORDER_LINE_INFO_ARRAY(i).INVOICE_TO_ADDRESS4);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY INVOICE_TO_ADDRESS5= ' || P_ORDER_LINE_INFO_ARRAY(i).INVOICE_TO_ADDRESS5);		
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY ORDER_NUMBER= ' || P_ORDER_LINE_INFO_ARRAY(i).ORDER_NUMBER);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY QUOTE_NUMBER= ' || P_ORDER_LINE_INFO_ARRAY(i).QUOTE_NUMBER);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY ORDER_TYPE_ID= ' || P_ORDER_LINE_INFO_ARRAY(i).ORDER_TYPE_ID);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY ORDERED_DATE= ' || P_ORDER_LINE_INFO_ARRAY(i).ORDERED_DATE);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY RETURN_REASON= ' || P_ORDER_LINE_INFO_ARRAY(i).RETURN_REASON);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY SPLIT_FROM_LINE_ID= ' || P_ORDER_LINE_INFO_ARRAY(i).SPLIT_FROM_LINE_ID);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY SHIP_SET_ID= ' || P_ORDER_LINE_INFO_ARRAY(i).SHIP_SET_ID);		
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY PLANNING_PRIORITY= ' || P_ORDER_LINE_INFO_ARRAY(i).PLANNING_PRIORITY);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY SHIPPING_INSTRUCTIONS= ' || P_ORDER_LINE_INFO_ARRAY(i).SHIPPING_INSTRUCTIONS);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY PACKING_INSTRUCTIONS= ' || P_ORDER_LINE_INFO_ARRAY(i).PACKING_INSTRUCTIONS);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY INVOICED_QUANTITY= ' || P_ORDER_LINE_INFO_ARRAY(i).INVOICED_QUANTITY);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY FLOW_STATUS= ' || P_ORDER_LINE_INFO_ARRAY(i).FLOW_STATUS);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY CUSTOMER_LINE_NUMBER= ' || P_ORDER_LINE_INFO_ARRAY(i).CUSTOMER_LINE_NUMBER);		
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY ORIGINAL_ORDERED_ITEM= ' || P_ORDER_LINE_INFO_ARRAY(i).ORIGINAL_ORDERED_ITEM);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY ORDER_SOURCE= ' || P_ORDER_LINE_INFO_ARRAY(i).ORDER_SOURCE);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY KEYWORD= ' || P_ORDER_LINE_INFO_ARRAY(i).KEYWORD);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY PART_NOMEN= ' || P_ORDER_LINE_INFO_ARRAY(i).PART_NOMEN);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY SALES_PERSON= ' || P_ORDER_LINE_INFO_ARRAY(i).SALES_PERSON);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY DELIVERY_ID= ' || P_ORDER_LINE_INFO_ARRAY(i).DELIVERY_ID);		
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY INVOICE_NUMBER= ' || P_ORDER_LINE_INFO_ARRAY(i).INVOICE_NUMBER);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY DISCOUNT_PERCENTAGE= ' || P_ORDER_LINE_INFO_ARRAY(i).DISCOUNT_PERCENTAGE);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY DISCOUNT_AMOUNT= ' || P_ORDER_LINE_INFO_ARRAY(i).DISCOUNT_AMOUNT);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY INVOICE_DATE= ' || P_ORDER_LINE_INFO_ARRAY(i).INVOICE_DATE);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY INVOICE_VALUE= ' || P_ORDER_LINE_INFO_ARRAY(i).INVOICE_VALUE);		
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY ORIG_PO_FOR_RETURN= ' || P_ORDER_LINE_INFO_ARRAY(i).ORIG_PO_FOR_RETURN);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY CANCEL_UPDATE_ALLOWED= ' || P_ORDER_LINE_INFO_ARRAY(i).CANCEL_UPDATE_ALLOWED);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY SHIPMENT_DISPUTE_ALLOWED= ' || P_ORDER_LINE_INFO_ARRAY(i).SHIPMENT_DISPUTE_ALLOWED);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY MS_NUMBER= ' || P_ORDER_LINE_INFO_ARRAY(i).MS_NUMBER);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY SHIPPING_STATUS= ' || P_ORDER_LINE_INFO_ARRAY(i).SHIPPING_STATUS);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY SHIPMENT_QUANTITY= ' || P_ORDER_LINE_INFO_ARRAY(i).SHIPMENT_QUANTITY);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY DIMENSIONS= ' || P_ORDER_LINE_INFO_ARRAY(i).DIMENSIONS);		
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY GROSS_WEIGHT= ' || P_ORDER_LINE_INFO_ARRAY(i).GROSS_WEIGHT);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY SERIAL_NUMBERS= ' || P_ORDER_LINE_INFO_ARRAY(i).SERIAL_NUMBERS);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY LINK_TO_CARRIER= ' || P_ORDER_LINE_INFO_ARRAY(i).LINK_TO_CARRIER);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY RETURN_COO= ' || P_ORDER_LINE_INFO_ARRAY(i).RETURN_COO);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY UPQ= ' || P_ORDER_LINE_INFO_ARRAY(i).UPQ);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY INVOICE_ID= ' || P_ORDER_LINE_INFO_ARRAY(i).INVOICE_ID);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY QTY_UPD_ALLOWED= ' || P_ORDER_LINE_INFO_ARRAY(i).QTY_UPD_ALLOWED);		
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY SHIP_TO_ADDRESS= ' || P_ORDER_LINE_INFO_ARRAY(i).SHIP_TO_ADDRESS);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY DELIVER_TO_ADDRESS= ' || P_ORDER_LINE_INFO_ARRAY(i).DELIVER_TO_ADDRESS);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY INVOICE_TO_ADDRESS= ' || P_ORDER_LINE_INFO_ARRAY(i).INVOICE_TO_ADDRESS);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY MYGEA_ESN= ' || P_ORDER_LINE_INFO_ARRAY(i).MYGEA_ESN);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY SHIPMENT_DISPUTE_CREATED= ' || P_ORDER_LINE_INFO_ARRAY(i).SHIPMENT_DISPUTE_CREATED);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY CRITICAL_PART_FLAG= ' || P_ORDER_LINE_INFO_ARRAY(i).CRITICAL_PART_FLAG);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY WORKSTP_DATE= ' || P_ORDER_LINE_INFO_ARRAY(i).WORKSTP_DATE);
		DBMS_OUTPUT.PUT_LINE('P_ORDER_LINE_INFO_ARRAY WORKSTP_QTY= ' || P_ORDER_LINE_INFO_ARRAY(i).WORKSTP_QTY);
		
		
	END LOOP;

	DBMS_OUTPUT.PUT_LINE('P_MSG = ' || P_MSG);
  
END;





