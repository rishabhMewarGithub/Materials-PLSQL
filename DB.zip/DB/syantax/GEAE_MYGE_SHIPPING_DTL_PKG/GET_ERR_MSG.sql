

-------------------------------------------------------------------------GET_ERR_MSG-------------------------------------------------------



DECLARE
  P_ERR_CODE NUMBER;
  v_Return VARCHAR2(200);
BEGIN
  P_ERR_CODE := NULL;

  v_Return := GEAE_MYGE_SHIPPING_DTL_PKG.GET_ERR_MSG(
    P_ERR_CODE => P_ERR_CODE
  );
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('v_Return = ' || v_Return);
*/ 
  :v_Return := v_Return;
--rollback; 
END;
