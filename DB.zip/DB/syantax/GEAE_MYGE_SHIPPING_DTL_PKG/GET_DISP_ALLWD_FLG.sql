


-------------------------------------------------------------------------GET_DISP_ALLWD_FLG-------------------------------------------------------


DECLARE
  P_OU_ID NUMBER;
  P_ORDER_ID NUMBER;
  P_LINE_ID NUMBER;
  v_Return VARCHAR2(200);
  
BEGIN
  P_OU_ID := NULL;
  P_ORDER_ID := NULL;
  P_LINE_ID := NULL;

  v_Return := GEAE_MYGE_SHIPPING_DTL_PKG.GET_DISP_ALLWD_FLG(
    P_OU_ID => P_OU_ID,
    P_ORDER_ID => P_ORDER_ID,
    P_LINE_ID => P_LINE_ID
  );
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('v_Return = ' || v_Return);
*/ 
  :v_Return := v_Return;
--rollback; 
END;
