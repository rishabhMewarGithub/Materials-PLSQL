

-------------------------------------------------------------------------GET_ORDER_AUDIT_HISTORY_PRC-------------------------------------------------------


DECLARE
  P_SSO VARCHAR2(200);
  P_ROLE VARCHAR2(200);
  P_IACO_CODE VARCHAR2(200);
  P_CUST_ID APPS.V_CUST_ID_ARRAY;
  P_OU_ID VARCHAR2(200);
  P_HEADER_NUMBER NUMBER;
  P_AUDIT_HIST_VIEW APPS.V_AUDIT_HISTORY_ARRAY;
  P_ERROR_STATUS VARCHAR2(200);
  P_MSG VARCHAR2(200);
BEGIN
  P_SSO := NULL;
  P_ROLE := NULL;
  P_IACO_CODE := NULL;
  -- Modify the code to initialize the variable
  -- P_CUST_ID := NULL;
  P_OU_ID := NULL;
  P_HEADER_NUMBER := NULL;

  GEAE_MYGE_SHIPPING_DTL_PKG.GET_ORDER_AUDIT_HISTORY_PRC(
    P_SSO => P_SSO,
    P_ROLE => P_ROLE,
    P_IACO_CODE => P_IACO_CODE,
    P_CUST_ID => P_CUST_ID,
    P_OU_ID => P_OU_ID,
    P_HEADER_NUMBER => P_HEADER_NUMBER,
    P_AUDIT_HIST_VIEW => P_AUDIT_HIST_VIEW,
    P_ERROR_STATUS => P_ERROR_STATUS,
    P_MSG => P_MSG
  );
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_AUDIT_HIST_VIEW = ' || P_AUDIT_HIST_VIEW);
*/ 
  --:P_AUDIT_HIST_VIEW := P_AUDIT_HIST_VIEW;
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_ERROR_STATUS = ' || P_ERROR_STATUS);
*/ 
  :P_ERROR_STATUS := P_ERROR_STATUS;
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_MSG = ' || P_MSG);
*/ 
  :P_MSG := P_MSG;
--rollback; 
END;

-----------------------------------------------------------------------------------------------

create or replace TYPE V_AUDIT_HISTORY_ARRAY AS VARRAY(2250) OF V_AUDIT_HISTORY_OBJECT

-----------------------------------------------------------------------------------------------

create or replace TYPE V_AUDIT_HISTORY_OBJECT AS OBJECT ( 				 LINE_NUMBER VARCHAR2(30),
																		 ATTRIBUTE_DISPLAY_NAME VARCHAR2(2000),
																		 OLD_ATTRIBUTE_VALUE VARCHAR2(100),
																		 NEW_ATTRIBUTE_VALUE VARCHAR2(100),
																		 USER_NAME VARCHAR2(100),
																		 HIST_CREATION_DATE VARCHAR2(20)
                                                                     );
																	 
------------------------------------------------------------------------------------------------------------------------------------------


DECLARE
  P_SSO VARCHAR2(200);
  P_ROLE VARCHAR2(200);
  P_IACO_CODE VARCHAR2(200);
  P_CUST_ID APPS.V_CUST_ID_ARRAY;
  P_OU_ID VARCHAR2(200);
  P_HEADER_NUMBER NUMBER;
  P_AUDIT_HIST_VIEW APPS.V_AUDIT_HISTORY_ARRAY;
  P_ERROR_STATUS VARCHAR2(200);
  P_MSG VARCHAR2(200);
BEGIN
  P_SSO := NULL;
  P_ROLE := NULL;
  P_IACO_CODE := NULL;
  -- Modify the code to initialize the variable
  -- P_CUST_ID := NULL;
  P_OU_ID := NULL;
  P_HEADER_NUMBER := NULL;

  GEAE_MYGE_SHIPPING_DTL_PKG.GET_ORDER_AUDIT_HISTORY_PRC(
    P_SSO => P_SSO,
    P_ROLE => P_ROLE,
    P_IACO_CODE => P_IACO_CODE,
    P_CUST_ID => P_CUST_ID,
    P_OU_ID => P_OU_ID,
    P_HEADER_NUMBER => P_HEADER_NUMBER,
    P_AUDIT_HIST_VIEW => P_AUDIT_HIST_VIEW,
    P_ERROR_STATUS => P_ERROR_STATUS,
    P_MSG => P_MSG
  );
  
  For i in 1..P_AUDIT_HIST_VIEW.COUNT LOOP
  
		DBMS_OUTPUT.PUT_LINE('P_AUDIT_HIST_VIEW LINE_NUMBER= ' || P_AUDIT_HIST_VIEW(i).LINE_NUMBER);
		DBMS_OUTPUT.PUT_LINE('P_AUDIT_HIST_VIEW ATTRIBUTE_DISPLAY_NAME = ' || P_AUDIT_HIST_VIEW(i).ATTRIBUTE_DISPLAY_NAME);
		DBMS_OUTPUT.PUT_LINE('P_AUDIT_HIST_VIEW OLD_ATTRIBUTE_VALUE= ' || P_AUDIT_HIST_VIEW(i).OLD_ATTRIBUTE_VALUE);
		DBMS_OUTPUT.PUT_LINE('P_AUDIT_HIST_VIEW NEW_ATTRIBUTE_VALUE= ' || P_AUDIT_HIST_VIEW(i).NEW_ATTRIBUTE_VALUE);
		DBMS_OUTPUT.PUT_LINE('P_AUDIT_HIST_VIEW USER_NAME= ' || P_AUDIT_HIST_VIEW(i).USER_NAME);
		DBMS_OUTPUT.PUT_LINE('P_AUDIT_HIST_VIEW HIST_CREATION_DATE= ' || P_AUDIT_HIST_VIEW(i).HIST_CREATION_DATE);
		
	END LOOP;
	
	DBMS_OUTPUT.PUT_LINE('P_ERROR_STATUS = ' || P_ERROR_STATUS);
	
	DBMS_OUTPUT.PUT_LINE('P_MSG = ' || P_MSG);
  
END;



