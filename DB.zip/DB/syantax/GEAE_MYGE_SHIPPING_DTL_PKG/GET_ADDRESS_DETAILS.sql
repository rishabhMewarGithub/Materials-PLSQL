

-------------------------------------------------------------------------GET_ADDRESS_DETAILS-------------------------------------------------------


DECLARE
  P_SITE_USE_ID NUMBER;
  P_LOCATION VARCHAR2(200);
  P_ADDRESS1 VARCHAR2(200);
  P_ADDRESS2 VARCHAR2(200);
  P_ADDRESS3 VARCHAR2(200);
  P_ADDRESS4 VARCHAR2(200);
  P_ADDRESS5 VARCHAR2(200);
  P_ADDRESS VARCHAR2(200);
BEGIN
  P_SITE_USE_ID := NULL;

  GEAE_MYGE_SHIPPING_DTL_PKG.GET_ADDRESS_DETAILS(
    P_SITE_USE_ID => P_SITE_USE_ID,
    P_LOCATION => P_LOCATION,
    P_ADDRESS1 => P_ADDRESS1,
    P_ADDRESS2 => P_ADDRESS2,
    P_ADDRESS3 => P_ADDRESS3,
    P_ADDRESS4 => P_ADDRESS4,
    P_ADDRESS5 => P_ADDRESS5,
    P_ADDRESS => P_ADDRESS
  );
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_LOCATION = ' || P_LOCATION);
*/ 
  :P_LOCATION := P_LOCATION;
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_ADDRESS1 = ' || P_ADDRESS1);
*/ 
  :P_ADDRESS1 := P_ADDRESS1;
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_ADDRESS2 = ' || P_ADDRESS2);
*/ 
  :P_ADDRESS2 := P_ADDRESS2;
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_ADDRESS3 = ' || P_ADDRESS3);
*/ 
  :P_ADDRESS3 := P_ADDRESS3;
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_ADDRESS4 = ' || P_ADDRESS4);
*/ 
  :P_ADDRESS4 := P_ADDRESS4;
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_ADDRESS5 = ' || P_ADDRESS5);
*/ 
  :P_ADDRESS5 := P_ADDRESS5;
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('P_ADDRESS = ' || P_ADDRESS);
*/ 
  :P_ADDRESS := P_ADDRESS;
--rollback; 
END;



