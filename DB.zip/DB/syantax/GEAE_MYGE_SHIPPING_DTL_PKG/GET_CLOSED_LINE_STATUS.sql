

-------------------------------------------------------------------------GET_CLOSED_LINE_STATUS-------------------------------------------------------


DECLARE
  P_ORDER_ID NUMBER;
  P_OU_ID NUMBER;
  v_Return VARCHAR2(200);
  
BEGIN
  P_ORDER_ID := NULL;
  P_OU_ID := NULL;

  v_Return := GEAE_MYGE_SHIPPING_DTL_PKG.GET_CLOSED_LINE_STATUS(
    P_ORDER_ID => P_ORDER_ID,
    P_OU_ID => P_OU_ID
  );
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('v_Return = ' || v_Return);
*/ 
  :v_Return := v_Return;
--rollback; 
END;
