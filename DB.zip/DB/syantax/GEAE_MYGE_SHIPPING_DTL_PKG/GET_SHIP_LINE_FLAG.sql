

-------------------------------------------------------------------------GET_SHIP_LINE_FLAG-------------------------------------------------------


DECLARE
  P_HEADER_ID NUMBER;
  P_LINE_ID NUMBER;
  v_Return VARCHAR2(200);
BEGIN
  P_HEADER_ID := NULL;
  P_LINE_ID := NULL;

  v_Return := GEAE_MYGE_SHIPPING_DTL_PKG.GET_SHIP_LINE_FLAG(
    P_HEADER_ID => P_HEADER_ID,
    P_LINE_ID => P_LINE_ID
  );
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('v_Return = ' || v_Return);
*/ 
  :v_Return := v_Return;
--rollback; 
END;
