

-------------------------------------------------------------------------GET_ORIG_PO_NUMBER-------------------------------------------------------


DECLARE
  P_RETURN_CONTEXT VARCHAR2(200);
  P_RETURN_ATTRIBUTE1 VARCHAR2(200);
  P_RETURN_ATTRIBUTE2 VARCHAR2(200);
  v_Return VARCHAR2(200);
BEGIN
  P_RETURN_CONTEXT := NULL;
  P_RETURN_ATTRIBUTE1 := NULL;
  P_RETURN_ATTRIBUTE2 := NULL;

  v_Return := GEAE_MYGE_SHIPPING_DTL_PKG.GET_ORIG_PO_NUMBER(
    P_RETURN_CONTEXT => P_RETURN_CONTEXT,
    P_RETURN_ATTRIBUTE1 => P_RETURN_ATTRIBUTE1,
    P_RETURN_ATTRIBUTE2 => P_RETURN_ATTRIBUTE2
  );
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('v_Return = ' || v_Return);
*/ 
  :v_Return := v_Return;
--rollback; 
END;
